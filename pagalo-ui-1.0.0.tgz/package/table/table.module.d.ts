import * as i0 from "@angular/core";
import * as i1 from "./table.component";
export declare class PgTableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgTableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgTableModule, never, [typeof i1.TableComponent], [typeof i1.TableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgTableModule>;
}
