import * as i0 from "@angular/core";
import * as i1 from "./button.component";
import * as i2 from "./button-group.component";
export declare class PgButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgButtonModule, never, [typeof i1.PgButton, typeof i2.PgButtonGroup], [typeof i1.PgButton, typeof i2.PgButtonGroup]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgButtonModule>;
}
