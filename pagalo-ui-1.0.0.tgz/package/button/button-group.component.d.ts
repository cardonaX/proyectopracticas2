import * as i0 from "@angular/core";
export declare class PgButtonGroup {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgButtonGroup, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PgButtonGroup, "pg-button-group", never, {}, {}, never, ["*"], true, never>;
}
