import * as i0 from "@angular/core";
export type ButtonVariant = 'primary' | 'secondary';
export type ButtonSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';
export type ButtonShape = 'rectangle' | 'pill' | 'circular';
export declare class PgButton {
    label: import("@angular/core").InputSignal<string | undefined>;
    variant: import("@angular/core").InputSignal<ButtonVariant>;
    size: import("@angular/core").InputSignal<ButtonSize>;
    shape: import("@angular/core").InputSignal<ButtonShape>;
    disabled: import("@angular/core").InputSignal<boolean>;
    type: import("@angular/core").InputSignal<"button" | "submit" | "reset">;
    fullWidth: import("@angular/core").InputSignal<boolean>;
    customClass: import("@angular/core").InputSignal<string>;
    classes: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgButton, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PgButton, "pg-button", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "shape": { "alias": "shape"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; "customClass": { "alias": "customClass"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
