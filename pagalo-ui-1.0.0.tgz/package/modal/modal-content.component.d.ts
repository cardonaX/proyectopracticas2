import * as i0 from "@angular/core";
export declare class ModalContentComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ModalContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ModalContentComponent, "pg-modal-content", never, {}, {}, never, ["*"], true, never>;
}
