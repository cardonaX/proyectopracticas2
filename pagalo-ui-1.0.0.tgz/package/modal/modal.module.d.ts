import * as i0 from "@angular/core";
import * as i1 from "./modal.component";
import * as i2 from "./modal-content.component";
import * as i3 from "./modal-footer.component";
import * as i4 from "./modal-header.component";
export declare class PgModalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgModalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgModalModule, never, [typeof i1.ModalComponent, typeof i2.ModalContentComponent, typeof i3.ModalFooterComponent, typeof i4.ModalHeaderComponent], [typeof i1.ModalComponent, typeof i2.ModalContentComponent, typeof i3.ModalFooterComponent, typeof i4.ModalHeaderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgModalModule>;
}
