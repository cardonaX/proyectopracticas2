import * as i0 from "@angular/core";
export declare class ModalFooterComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ModalFooterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ModalFooterComponent, "pg-modal-footer", never, {}, {}, never, ["*"], true, never>;
}
