import { OnInit } from '@angular/core';
import { PgDialogBase } from '@pagalo/ui/core';
import * as i0 from "@angular/core";
export type ModalSize = 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl' | '4xl' | '5xl' | '6xl' | '7xl';
export declare class ModalComponent extends PgDialogBase implements OnInit {
    private readonly idService;
    private readonly _autoId;
    /** Animación de entrada más larga que la salida, igual que la transición original de Tailwind UI. */
    readonly panelEnterDurationMs = 300;
    readonly panelExitDurationMs = 200;
    size: import("@angular/core").InputSignal<ModalSize>;
    id: import("@angular/core").InputSignal<string>;
    /** ID resuelto: usa el input `id` si se provee, sino genera uno automáticamente. */
    readonly dialogId: import("@angular/core").Signal<string>;
    readonly titleId: import("@angular/core").Signal<string>;
    readonly sizeClass: import("@angular/core").Signal<string>;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ModalComponent, "pg-modal", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
