import * as i0 from "@angular/core";
export declare class ModalHeaderComponent {
    showClose: import("@angular/core").InputSignal<boolean>;
    private readonly modal;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModalHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ModalHeaderComponent, "pg-modal-header", never, { "showClose": { "alias": "showClose"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
