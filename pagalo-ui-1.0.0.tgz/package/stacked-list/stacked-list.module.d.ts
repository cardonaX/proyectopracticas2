import * as i0 from "@angular/core";
import * as i1 from "./stacked-list.component";
export declare class PgStackedListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgStackedListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgStackedListModule, never, [typeof i1.StackedListComponent], [typeof i1.StackedListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgStackedListModule>;
}
