import { TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export type StackedListVariant = 'simple' | 'with-links' | 'in-card-with-links' | 'two-columns' | 'narrow-with-sticky-headings' | 'narrow-with-actions';
export interface GroupedItem<T = any> {
    groupName: string;
    items: T[];
}
export declare class StackedListComponent {
    variant: StackedListVariant;
    items: any[];
    groupedItems: GroupedItem[];
    itemAvatar?: TemplateRef<any>;
    itemContent?: TemplateRef<any>;
    itemRight?: TemplateRef<any>;
    footerAction?: TemplateRef<any>;
    get containerClass(): string;
    get listContainerClass(): string;
    get listItemClass(): string;
    get leftSideClass(): string;
    get rightSideClass(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<StackedListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StackedListComponent, "pg-stacked-list", never, { "variant": { "alias": "variant"; "required": false; }; "items": { "alias": "items"; "required": false; }; "groupedItems": { "alias": "groupedItems"; "required": false; }; }, {}, ["itemAvatar", "itemContent", "itemRight", "footerAction"], never, true, never>;
}
