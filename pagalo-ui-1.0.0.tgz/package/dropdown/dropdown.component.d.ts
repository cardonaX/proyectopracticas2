import { ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Trigger wrapper for `pg-dropdown-menu`. Exposes its own `ElementRef` as the
 * CDK overlay's anchor and toggles the projected menu on click. Projects the
 * trigger element (e.g. a `<button>`) followed by a `pg-dropdown-menu`.
 */
export declare class PgDropdownComponent {
    readonly elementRef: ElementRef<any>;
    private readonly menu;
    onTriggerClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgDropdownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PgDropdownComponent, "pg-dropdown", never, {}, {}, ["menu"], ["*"], true, never>;
}
