import * as i0 from "@angular/core";
import * as i1 from "./dropdown.component";
import * as i2 from "./dropdown-menu.component";
export declare class PgDropdownModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgDropdownModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgDropdownModule, never, [typeof i1.PgDropdownComponent, typeof i2.PgDropdownMenuComponent], [typeof i1.PgDropdownComponent, typeof i2.PgDropdownMenuComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgDropdownModule>;
}
