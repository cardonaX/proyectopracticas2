import { ElementRef } from '@angular/core';
import { ConnectedPosition } from '@angular/cdk/overlay';
import * as i0 from "@angular/core";
export type DropdownPlacement = 'bottom-start' | 'bottom-end' | 'top-start' | 'top-end' | 'left-start' | 'left-end' | 'right-start' | 'right-end';
export declare class PgDropdownMenuComponent {
    private readonly elementRef;
    private readonly dropdown;
    /** Placement of the menu relative to its trigger. Default: 'bottom-end'. */
    readonly placement: import("@angular/core").InputSignal<DropdownPlacement>;
    /** Two-way binding to read or programmatically control menu visibility. */
    readonly isOpen: import("@angular/core").ModelSignal<boolean>;
    /** Emitted when the menu opens. */
    readonly opened: import("@angular/core").OutputEmitterRef<void>;
    /** Emitted when the menu closes (after the exit animation completes). */
    readonly closed: import("@angular/core").OutputEmitterRef<void>;
    readonly panelEnterDurationMs = 100;
    readonly panelExitDurationMs = 75;
    /** True while the exit animation plays, before the overlay actually detaches. */
    readonly isClosing: import("@angular/core").WritableSignal<boolean>;
    /** Anchor for the CDK overlay: the parent `pg-dropdown`'s trigger, or this element as a standalone fallback. */
    readonly origin: import("@angular/core").Signal<ElementRef<HTMLElement>>;
    readonly overlayPositions: import("@angular/core").Signal<ConnectedPosition[]>;
    protected readonly menuPanel: import("@angular/core").Signal<ElementRef<HTMLElement> | undefined>;
    private focusKeyManager;
    private closeTimeoutHandle;
    private everOpened;
    /**
     * Drives the exit-animation window: `isOpen` flips immediately (public
     * model contract, unchanged), but the overlay stays attached for
     * `panelExitDurationMs` more via `isOpen() || isClosing()` in the template
     * so the CSS exit animation can play out. Reacts to `isOpen` regardless of
     * whether it changed via `toggle()`/`close()` or an external `[(isOpen)]` set.
     */
    private readonly _closeAnimationEffect;
    open(): void;
    close(): void;
    toggle(): void;
    /** Builds keyboard navigation over the projected items once the overlay content mounts. */
    onOverlayAttach(): void;
    onOverlayDetach(): void;
    onOverlayKeydown(event: KeyboardEvent): void;
    private focusOrigin;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgDropdownMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PgDropdownMenuComponent, "pg-dropdown-menu", never, { "placement": { "alias": "placement"; "required": false; "isSignal": true; }; "isOpen": { "alias": "isOpen"; "required": false; "isSignal": true; }; }, { "isOpen": "isOpenChange"; "opened": "opened"; "closed": "closed"; }, never, ["*"], true, never>;
}
