import { PgControlValueAccessorBase } from '@pagalo/ui/core';
import * as i0 from "@angular/core";
export type CheckboxLayout = 'default' | 'inline-description' | 'checkbox-right';
export declare class CheckboxComponent extends PgControlValueAccessorBase<boolean> {
    layout: import("@angular/core").InputSignal<CheckboxLayout>;
    padding: import("@angular/core").InputSignal<boolean>;
    label: import("@angular/core").InputSignal<string>;
    description: import("@angular/core").InputSignal<string>;
    forId: import("@angular/core").InputSignal<string>;
    /** Estado indeterminate del checkbox — manejado separadamente del value CVA. */
    readonly indeterminate: import("@angular/core").WritableSignal<boolean>;
    setIndeterminate(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckboxComponent, "pg-checkbox", never, { "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "padding": { "alias": "padding"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "forId": { "alias": "forId"; "required": false; "isSignal": true; }; }, {}, never, ["input[pgCheckbox]", "[pgCheckboxLabel]", "[pgCheckboxDescription]"], true, never>;
}
