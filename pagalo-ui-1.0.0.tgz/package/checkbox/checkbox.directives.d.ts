import * as i0 from "@angular/core";
export declare class CheckboxDirective {
    private pgCheckbox;
    private el;
    private renderer;
    constructor();
    onChange(checked: boolean): void;
    onBlur(): void;
    get hostClasses(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CheckboxDirective, "input[pgCheckbox]", never, {}, {}, never, never, true, never>;
}
export declare class CheckboxLabelDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxLabelDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CheckboxLabelDirective, "[pgCheckboxLabel]", never, {}, {}, never, never, true, never>;
}
export declare class CheckboxDescriptionDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxDescriptionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CheckboxDescriptionDirective, "[pgCheckboxDescription]", never, {}, {}, never, never, true, never>;
}
