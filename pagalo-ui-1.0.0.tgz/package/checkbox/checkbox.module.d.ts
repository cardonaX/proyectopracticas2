import * as i0 from "@angular/core";
import * as i1 from "./checkbox.component";
import * as i2 from "./checkbox.directives";
export declare class PgCheckboxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgCheckboxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgCheckboxModule, never, [typeof i1.CheckboxComponent, typeof i2.CheckboxDirective], [typeof i1.CheckboxComponent, typeof i2.CheckboxDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgCheckboxModule>;
}
