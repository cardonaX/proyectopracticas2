import * as i0 from '@angular/core';
import { InjectionToken, inject, input, output, viewChild, computed, ChangeDetectionStrategy, Component, DestroyRef, viewChildren, signal, effect, Renderer2, model, forwardRef } from '@angular/core';
import * as i1$1 from '@angular/cdk/overlay';
import { Overlay, OverlayModule } from '@angular/cdk/overlay';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import * as i2 from '@angular/cdk/a11y';
import { FocusKeyManager, A11yModule } from '@angular/cdk/a11y';
import * as i1 from '@angular/forms';
import { FormControl, ReactiveFormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { IdService, PgControlValueAccessorBase } from '@pagalo/ui/core';
import { SelectComponent } from '@pagalo/ui/select';

/**
 * Default preset palette: one Tailwind `-500` shade per curated color
 * family (green, emerald, blue, indigo, violet, purple, fuchsia, pink,
 * rose, red, orange, amber). Used as the `[presetColors]` fallback for the
 * `swatch-grid` and `palette` variants whenever the consumer leaves that
 * input unbound. Independent of `[savedColors]`.
 */
const PG_DEFAULT_PRESET_COLORS = [
    '#22c55e', // green-500
    '#10b981', // emerald-500
    '#3b82f6', // blue-500
    '#6366f1', // indigo-500
    '#8b5cf6', // violet-500
    '#a855f7', // purple-500
    '#d946ef', // fuchsia-500
    '#ec4899', // pink-500
    '#f43f5e', // rose-500
    '#ef4444', // red-500
    '#f97316', // orange-500
    '#f59e0b', // amber-500
];
/**
 * `generateSpectrumGrid()` step constants (design D6): 12 hue columns x 9
 * rows. Column `i` sits at hue `i * PG_SPECTRUM_HUE_STEP_DEG` (0..330). Row
 * 0 is a neutral (fully desaturated) brightness ramp; rows 1-8 are per-hue
 * levels — the first `PG_SPECTRUM_TINT_ROWS` are saturation tints at full
 * brightness, the remaining rows are brightness shades at full saturation.
 */
const PG_SPECTRUM_COLUMNS = 12;
const PG_SPECTRUM_ROWS = 9;
const PG_SPECTRUM_HUE_STEP_DEG = 360 / PG_SPECTRUM_COLUMNS;
const PG_SPECTRUM_TINT_ROWS = 4;
const PG_SPECTRUM_SATURATION_STEP = 25;
const PG_SPECTRUM_BRIGHTNESS_SHADE_STEP = 20;

/**
 * Injection token to override the CDK scroll strategy used by
 * `pg-color-picker`'s panel. Defaults to `reposition({ autoClose: true })`
 * so the panel follows its trigger on scroll/resize instead of closing or
 * freezing page scroll. Mirrors `PG_SELECT_SCROLL_STRATEGY`
 * (`select/select.tokens.ts`). Override by providing this token at the
 * app/module level; not part of the per-component public API surface.
 */
const PG_COLOR_PICKER_SCROLL_STRATEGY = new InjectionToken('PG_COLOR_PICKER_SCROLL_STRATEGY', {
    providedIn: 'root',
    factory: () => {
        const overlay = inject(Overlay);
        return () => overlay.scrollStrategies.reposition({ autoClose: true });
    },
});

/**
 * Pure color-conversion utilities for `pg-color-picker`. RGB is the
 * conversion hub (design D7): every pairwise conversion routes through
 * `PgRgb` rather than deriving HSB directly from HSL or vice versa. No
 * function throws — invalid input resolves to `null` (parsers) or is
 * clamped into range (formatters/builders).
 */
const HEX_BODY_RE = /^[0-9a-fA-F]+$/;
const NUMBER_TOKEN_RE = /-?\d+(?:\.\d+)?/g;
function clamp$1(value, min, max) {
    if (Number.isNaN(value))
        return min;
    return Math.min(max, Math.max(min, value));
}
function clampByte(value) {
    return Math.round(clamp$1(value, 0, 255));
}
function toHexByte(value) {
    return clampByte(value).toString(16).padStart(2, '0');
}
function round(value, decimals = 0) {
    const factor = 10 ** decimals;
    return Math.round(value * factor) / factor;
}
/** Shared hue-angle math for both `rgbToHsb` and `rgbToHsl` — identical for any max/min/delta triple. */
function hueDegrees(r, g, b, max, delta) {
    if (delta === 0)
        return 0;
    let h;
    if (max === r)
        h = 60 * (((g - b) / delta) % 6);
    else if (max === g)
        h = 60 * ((b - r) / delta + 2);
    else
        h = 60 * ((r - g) / delta + 4);
    return h < 0 ? h + 360 : h;
}
/** Shared chroma-sector math for both `hsbToRgb` and `hslToRgb` — same cone projection, different `c`/`m` inputs. */
function sectorToRgb(h, c, x, m) {
    let rP = 0;
    let gP = 0;
    let bP = 0;
    if (h < 60)
        [rP, gP, bP] = [c, x, 0];
    else if (h < 120)
        [rP, gP, bP] = [x, c, 0];
    else if (h < 180)
        [rP, gP, bP] = [0, c, x];
    else if (h < 240)
        [rP, gP, bP] = [0, x, c];
    else if (h < 300)
        [rP, gP, bP] = [x, 0, c];
    else
        [rP, gP, bP] = [c, 0, x];
    return {
        r: clampByte((rP + m) * 255),
        g: clampByte((gP + m) * 255),
        b: clampByte((bP + m) * 255),
    };
}
/**
 * Parses `#RGB`, `#RGBA`, `#RRGGBB`, or `#RRGGBBAA` into RGB channel bytes
 * plus alpha (`0`-`1`). Returns `null` for anything else — never throws.
 */
function parseHex(hex) {
    if (typeof hex !== 'string')
        return null;
    const trimmed = hex.trim();
    if (!trimmed.startsWith('#'))
        return null;
    const body = trimmed.slice(1);
    if (body.length === 0 || !HEX_BODY_RE.test(body))
        return null;
    let r;
    let g;
    let b;
    let a = 255;
    switch (body.length) {
        case 3:
        case 4:
            r = parseInt(body[0] + body[0], 16);
            g = parseInt(body[1] + body[1], 16);
            b = parseInt(body[2] + body[2], 16);
            if (body.length === 4)
                a = parseInt(body[3] + body[3], 16);
            break;
        case 6:
        case 8:
            r = parseInt(body.slice(0, 2), 16);
            g = parseInt(body.slice(2, 4), 16);
            b = parseInt(body.slice(4, 6), 16);
            if (body.length === 8)
                a = parseInt(body.slice(6, 8), 16);
            break;
        default:
            return null;
    }
    return { rgb: { r, g, b }, alpha: a / 255 };
}
/** `#RRGGBB`, or `#RRGGBBAA` only when `alpha < 1` (CVA value contract). */
function rgbToHex(rgb, alpha = 1) {
    const hex = `#${toHexByte(rgb.r)}${toHexByte(rgb.g)}${toHexByte(rgb.b)}`;
    if (alpha >= 1)
        return hex;
    return `${hex}${toHexByte(clamp$1(alpha, 0, 1) * 255)}`;
}
function rgbToHsb(rgb) {
    const r = clamp$1(rgb.r, 0, 255) / 255;
    const g = clamp$1(rgb.g, 0, 255) / 255;
    const b = clamp$1(rgb.b, 0, 255) / 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const delta = max - min;
    const h = hueDegrees(r, g, b, max, delta);
    const s = max === 0 ? 0 : (delta / max) * 100;
    const brightness = max * 100;
    return { h, s, b: brightness };
}
function hsbToRgb(hsb) {
    const h = ((hsb.h % 360) + 360) % 360;
    const s = clamp$1(hsb.s, 0, 100) / 100;
    const v = clamp$1(hsb.b, 0, 100) / 100;
    const c = v * s;
    const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
    const m = v - c;
    return sectorToRgb(h, c, x, m);
}
function rgbToHsl(rgb) {
    const r = clamp$1(rgb.r, 0, 255) / 255;
    const g = clamp$1(rgb.g, 0, 255) / 255;
    const b = clamp$1(rgb.b, 0, 255) / 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const delta = max - min;
    const h = hueDegrees(r, g, b, max, delta);
    const l = (max + min) / 2;
    const s = delta === 0 ? 0 : delta / (1 - Math.abs(2 * l - 1));
    return { h, s: s * 100, l: l * 100 };
}
function hslToRgb(hsl) {
    const h = ((hsl.h % 360) + 360) % 360;
    const s = clamp$1(hsl.s, 0, 100) / 100;
    const l = clamp$1(hsl.l, 0, 100) / 100;
    const c = (1 - Math.abs(2 * l - 1)) * s;
    const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
    const m = l - c / 2;
    return sectorToRgb(h, c, x, m);
}
function hsbToHex(hsb, alpha = 1) {
    return rgbToHex(hsbToRgb(hsb), alpha);
}
function hexToHsb(hex) {
    const parsed = parseHex(hex);
    if (!parsed)
        return null;
    return rgbToHsb(parsed.rgb);
}
/** Builds a full `PgColor` payload (hex/rgb/hsl/hsb/alpha) from HSB + alpha. */
function buildPgColor(hsb, alpha = 1) {
    const rgb = hsbToRgb(hsb);
    const clampedAlpha = clamp$1(alpha, 0, 1);
    return {
        hex: rgbToHex(rgb, clampedAlpha),
        rgb,
        hsl: rgbToHsl(rgb),
        hsb,
        alpha: clampedAlpha,
    };
}
/** Formats a `PgColor` for display/editing in the given format. Never mutates the underlying color. */
function formatColor(color, format) {
    const { alpha } = color;
    switch (format) {
        case 'hex':
            return color.hex;
        case 'rgb': {
            const { r, g, b } = color.rgb;
            return alpha < 1 ? `rgba(${r}, ${g}, ${b}, ${round(alpha, 2)})` : `rgb(${r}, ${g}, ${b})`;
        }
        case 'hsl': {
            const { h, s, l } = color.hsl;
            return alpha < 1
                ? `hsla(${round(h)}, ${round(s)}%, ${round(l)}%, ${round(alpha, 2)})`
                : `hsl(${round(h)}, ${round(s)}%, ${round(l)}%)`;
        }
        case 'hsb': {
            const { h, s, b } = color.hsb;
            return alpha < 1
                ? `hsba(${round(h)}, ${round(s)}%, ${round(b)}%, ${round(alpha, 2)})`
                : `hsb(${round(h)}, ${round(s)}%, ${round(b)}%)`;
        }
    }
}
/** Extracts numeric tokens from a functional CSS-like string, e.g. `rgb(255, 0, 0)` or `255, 0, 0`. */
function extractNumbers(text) {
    const matches = text.match(NUMBER_TOKEN_RE);
    return matches ? matches.map(Number) : [];
}
/**
 * Parses typed text per the given format back into HSB + alpha. Returns
 * `null` for anything that can't be confidently parsed — callers (the
 * format-input primitive) revert to the last valid value on `null` rather
 * than committing a bad one. Out-of-range numeric channels clamp to the
 * nearest bound instead of failing.
 */
function parseColorInput(text, format) {
    if (typeof text !== 'string' || !text.trim())
        return null;
    const trimmed = text.trim();
    if (format === 'hex') {
        const normalized = trimmed.startsWith('#') ? trimmed : `#${trimmed}`;
        const parsed = parseHex(normalized);
        if (!parsed)
            return null;
        return { hsb: rgbToHsb(parsed.rgb), alpha: parsed.alpha };
    }
    const numbers = extractNumbers(trimmed);
    if (numbers.length < 3)
        return null;
    const [a1, a2, a3, a4] = numbers;
    const alpha = a4 !== undefined ? clamp$1(a4, 0, 1) : 1;
    if (format === 'rgb') {
        const rgb = { r: clamp$1(a1, 0, 255), g: clamp$1(a2, 0, 255), b: clamp$1(a3, 0, 255) };
        return { hsb: rgbToHsb(rgb), alpha };
    }
    if (format === 'hsl') {
        const hsl = { h: clamp$1(a1, 0, 360), s: clamp$1(a2, 0, 100), l: clamp$1(a3, 0, 100) };
        return { hsb: rgbToHsb(hslToRgb(hsl)), alpha };
    }
    // hsb
    const hsb = { h: clamp$1(a1, 0, 360), s: clamp$1(a2, 0, 100), b: clamp$1(a3, 0, 100) };
    return { hsb, alpha };
}
/**
 * Generates the 9x12 `palette` variant spectrum grid at render time (design
 * D6) — a pure function of the step constants, never a stored dataset. Row
 * 0 is a neutral (fully desaturated) brightness ramp; rows 1-8 are per-hue
 * levels (saturation tints, then brightness shades), one column per hue
 * step around the wheel.
 */
function generateSpectrumGrid() {
    const rows = [];
    const neutralRow = [];
    for (let i = 0; i < PG_SPECTRUM_COLUMNS; i++) {
        const brightness = 100 - (i * 100) / (PG_SPECTRUM_COLUMNS - 1);
        neutralRow.push(hsbToHex({ h: 0, s: 0, b: brightness }));
    }
    rows.push(neutralRow);
    for (let j = 0; j < PG_SPECTRUM_ROWS - 1; j++) {
        const row = [];
        const isTint = j < PG_SPECTRUM_TINT_ROWS;
        for (let i = 0; i < PG_SPECTRUM_COLUMNS; i++) {
            const hue = i * PG_SPECTRUM_HUE_STEP_DEG;
            const s = isTint ? PG_SPECTRUM_SATURATION_STEP * (j + 1) : 100;
            const b = isTint
                ? 100
                : 100 - PG_SPECTRUM_BRIGHTNESS_SHADE_STEP * (j - (PG_SPECTRUM_TINT_ROWS - 1));
            row.push(hsbToHex({ h: hue, s, b }));
        }
        rows.push(row);
    }
    return rows;
}

const STEP = 1;
const BIG_STEP = 10;
function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
}
/**
 * Continuous 2D saturation/brightness handle for the `full` and `minimal`
 * variants. One focusable `role="slider"` element (spec requirement "2D
 * Handle Keyboard & ARIA"). Pointer dragging uses `setPointerCapture` so
 * the drag continues to track even when the pointer leaves the element's
 * bounds. `hue` positions the background gradient; this component owns no
 * hue state of its own.
 */
class PgColorGradientSurfaceComponent {
    /** Hue (0-360) driving the surface's background color. */
    hue = input.required();
    /** Current saturation, 0-100. */
    saturation = input(0);
    /** Current brightness, 0-100. */
    brightness = input(100);
    disabled = input(false);
    /**
     * Discrete keyboard nav emits one axis at a time — `emitSaturation`/
     * `emitBrightness` below. Safe as separate outputs: each key press is one
     * full round trip (with an Angular CD tick before the next), so there is
     * no risk of a consumer reading a stale value.
     */
    saturationChange = output();
    brightnessChange = output();
    /**
     * Pointer drag computes BOTH axes from the same `PointerEvent` and MUST
     * emit them together, atomically. Two separate synchronous emissions
     * (formerly `saturationChange`+`brightnessChange` back-to-back) let a
     * consumer that merges via "spread current input, apply one field" read a
     * stale value on the second emit (no CD tick runs between two synchronous
     * emits in the same call stack) — clobbering the first axis. See
     * `updateFromPointer`.
     */
    positionChange = output();
    surfaceRef = viewChild('surface');
    pointerId = null;
    hueBackgroundColor = computed(() => hsbToHex({ h: this.hue(), s: 100, b: 100 }));
    valueText = computed(() => `Saturation ${Math.round(this.saturation())}%, brightness ${Math.round(this.brightness())}%`);
    onPointerDown(event) {
        if (this.disabled())
            return;
        const el = event.currentTarget;
        el.setPointerCapture(event.pointerId);
        this.pointerId = event.pointerId;
        this.updateFromPointer(event);
    }
    onPointerMove(event) {
        if (this.disabled() || this.pointerId === null || event.pointerId !== this.pointerId)
            return;
        this.updateFromPointer(event);
    }
    onPointerUp(event) {
        if (this.pointerId === null || event.pointerId !== this.pointerId)
            return;
        const el = event.currentTarget;
        el.releasePointerCapture(event.pointerId);
        this.pointerId = null;
    }
    updateFromPointer(event) {
        const el = this.surfaceRef()?.nativeElement;
        if (!el)
            return;
        const rect = el.getBoundingClientRect();
        const width = rect.width || 1;
        const height = rect.height || 1;
        const x = clamp((event.clientX - rect.left) / width, 0, 1);
        const y = clamp((event.clientY - rect.top) / height, 0, 1);
        // Pointer drag always emits — every physical move is a real user gesture,
        // even when it happens to compute back to the current value. Both axes
        // MUST go out as ONE atomic emission (see `positionChange` doc above) —
        // never as two separate outputs for the same gesture.
        this.positionChange.emit({ saturation: x * 100, brightness: 100 - y * 100 });
    }
    onKeydown(event) {
        if (this.disabled())
            return;
        const step = event.shiftKey ? BIG_STEP : STEP;
        switch (event.key) {
            case 'ArrowLeft':
                event.preventDefault();
                this.emitSaturation(clamp(this.saturation() - step, 0, 100));
                break;
            case 'ArrowRight':
                event.preventDefault();
                this.emitSaturation(clamp(this.saturation() + step, 0, 100));
                break;
            case 'ArrowUp':
                event.preventDefault();
                this.emitBrightness(clamp(this.brightness() + step, 0, 100));
                break;
            case 'ArrowDown':
                event.preventDefault();
                this.emitBrightness(clamp(this.brightness() - step, 0, 100));
                break;
            case 'Home':
                event.preventDefault();
                this.emitSaturation(0);
                break;
            case 'End':
                event.preventDefault();
                this.emitSaturation(100);
                break;
            case 'PageUp':
                event.preventDefault();
                this.emitBrightness(clamp(this.brightness() + BIG_STEP, 0, 100));
                break;
            case 'PageDown':
                event.preventDefault();
                this.emitBrightness(clamp(this.brightness() - BIG_STEP, 0, 100));
                break;
            default:
                break;
        }
    }
    emitSaturation(value) {
        if (value === this.saturation())
            return;
        this.saturationChange.emit(value);
    }
    emitBrightness(value) {
        if (value === this.brightness())
            return;
        this.brightnessChange.emit(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgColorGradientSurfaceComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "19.2.21", type: PgColorGradientSurfaceComponent, isStandalone: true, selector: "pg-color-gradient-surface", inputs: { hue: { classPropertyName: "hue", publicName: "hue", isSignal: true, isRequired: true, transformFunction: null }, saturation: { classPropertyName: "saturation", publicName: "saturation", isSignal: true, isRequired: false, transformFunction: null }, brightness: { classPropertyName: "brightness", publicName: "brightness", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { saturationChange: "saturationChange", brightnessChange: "brightnessChange", positionChange: "positionChange" }, host: { classAttribute: "pg-color-gradient-surface block" }, viewQueries: [{ propertyName: "surfaceRef", first: true, predicate: ["surface"], descendants: true, isSignal: true }], ngImport: i0, template: "<div\n  #surface\n  class=\"pg-color-gradient-surface__area relative w-full rounded-md overflow-hidden touch-none select-none cursor-crosshair\"\n  [style.background-color]=\"hueBackgroundColor()\"\n  role=\"slider\"\n  tabindex=\"0\"\n  aria-label=\"Saturation and brightness\"\n  [attr.aria-valuetext]=\"valueText()\"\n  [attr.aria-disabled]=\"disabled() || null\"\n  (pointerdown)=\"onPointerDown($event)\"\n  (pointermove)=\"onPointerMove($event)\"\n  (pointerup)=\"onPointerUp($event)\"\n  (pointercancel)=\"onPointerUp($event)\"\n  (keydown)=\"onKeydown($event)\"\n>\n  <div class=\"pg-color-gradient-surface__white-layer absolute inset-0\"></div>\n  <div class=\"pg-color-gradient-surface__black-layer absolute inset-0\"></div>\n  <div\n    class=\"pg-color-gradient-surface__handle absolute size-4 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-white shadow pointer-events-none\"\n    [style.left.%]=\"saturation()\"\n    [style.top.%]=\"100 - brightness()\"\n  ></div>\n</div>\n", styles: [".pg-color-checkerboard{background-image:linear-gradient(45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(-45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%),linear-gradient(-45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%);background-size:8px 8px;background-position:0 0,0 4px,4px -4px,-4px 0;background-color:rgb(var(--pg-checker-base, 255 255 255))}\n", ":host{display:block}.pg-color-gradient-surface__area{aspect-ratio:1 / 1}.pg-color-gradient-surface__white-layer{background-image:linear-gradient(to right,#fff,transparent)}.pg-color-gradient-surface__black-layer{background-image:linear-gradient(to top,#000,transparent)}.pg-color-gradient-surface__handle{box-shadow:0 0 0 1px #0000004d}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgColorGradientSurfaceComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-color-gradient-surface', imports: [], changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'pg-color-gradient-surface block' }, template: "<div\n  #surface\n  class=\"pg-color-gradient-surface__area relative w-full rounded-md overflow-hidden touch-none select-none cursor-crosshair\"\n  [style.background-color]=\"hueBackgroundColor()\"\n  role=\"slider\"\n  tabindex=\"0\"\n  aria-label=\"Saturation and brightness\"\n  [attr.aria-valuetext]=\"valueText()\"\n  [attr.aria-disabled]=\"disabled() || null\"\n  (pointerdown)=\"onPointerDown($event)\"\n  (pointermove)=\"onPointerMove($event)\"\n  (pointerup)=\"onPointerUp($event)\"\n  (pointercancel)=\"onPointerUp($event)\"\n  (keydown)=\"onKeydown($event)\"\n>\n  <div class=\"pg-color-gradient-surface__white-layer absolute inset-0\"></div>\n  <div class=\"pg-color-gradient-surface__black-layer absolute inset-0\"></div>\n  <div\n    class=\"pg-color-gradient-surface__handle absolute size-4 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-white shadow pointer-events-none\"\n    [style.left.%]=\"saturation()\"\n    [style.top.%]=\"100 - brightness()\"\n  ></div>\n</div>\n", styles: [".pg-color-checkerboard{background-image:linear-gradient(45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(-45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%),linear-gradient(-45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%);background-size:8px 8px;background-position:0 0,0 4px,4px -4px,-4px 0;background-color:rgb(var(--pg-checker-base, 255 255 255))}\n", ":host{display:block}.pg-color-gradient-surface__area{aspect-ratio:1 / 1}.pg-color-gradient-surface__white-layer{background-image:linear-gradient(to right,#fff,transparent)}.pg-color-gradient-surface__black-layer{background-image:linear-gradient(to top,#000,transparent)}.pg-color-gradient-surface__handle{box-shadow:0 0 0 1px #0000004d}\n"] }]
        }] });

/**
 * Hue or alpha channel control. Uses a native `<input type="range">` so
 * keyboard interaction and form semantics come for free from the browser
 * (spec requirement "Channel Sliders Keyboard & ARIA") — this component
 * never intercepts keydown. The alpha channel renders over the shared
 * checkerboard background (design D8) so full transparency stays visible.
 */
class PgColorChannelSliderComponent {
    channel = input.required();
    /** Hue: 0-360 degrees. Alpha: 0-1. */
    value = input(0);
    /** Current hue (0-360) — only used to color the alpha track's opaque end. */
    hue = input(0);
    disabled = input(false);
    valueChange = output();
    ariaLabel = computed(() => (this.channel() === 'hue' ? 'Hue' : 'Alpha'));
    valueText = computed(() => this.channel() === 'hue' ? `${Math.round(this.value())}°` : `${Math.round(this.value() * 100)}%`);
    hueOpaqueColor = computed(() => hsbToHex({ h: this.hue(), s: 100, b: 100 }));
    onInput(event) {
        if (this.disabled())
            return;
        const raw = Number(event.target.value);
        if (Number.isNaN(raw))
            return;
        this.valueChange.emit(raw);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgColorChannelSliderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: PgColorChannelSliderComponent, isStandalone: true, selector: "pg-color-channel-slider", inputs: { channel: { classPropertyName: "channel", publicName: "channel", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, hue: { classPropertyName: "hue", publicName: "hue", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, host: { classAttribute: "pg-color-channel-slider block" }, ngImport: i0, template: "@if (channel() === 'hue') {\n  <input\n    type=\"range\"\n    min=\"0\"\n    max=\"360\"\n    step=\"1\"\n    class=\"pg-color-channel-slider__input pg-color-channel-slider__input--hue\"\n    [attr.aria-label]=\"ariaLabel()\"\n    [attr.aria-valuetext]=\"valueText()\"\n    [value]=\"value()\"\n    [disabled]=\"disabled()\"\n    (input)=\"onInput($event)\"\n  />\n} @else {\n  <input\n    type=\"range\"\n    min=\"0\"\n    max=\"1\"\n    step=\"0.01\"\n    class=\"pg-color-channel-slider__input pg-color-channel-slider__input--alpha\"\n    [attr.aria-label]=\"ariaLabel()\"\n    [attr.aria-valuetext]=\"valueText()\"\n    [value]=\"value()\"\n    [disabled]=\"disabled()\"\n    [style.--pg-color-channel-slider-hue-color]=\"hueOpaqueColor()\"\n    (input)=\"onInput($event)\"\n  />\n}\n", styles: [".pg-color-checkerboard{background-image:linear-gradient(45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(-45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%),linear-gradient(-45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%);background-size:8px 8px;background-position:0 0,0 4px,4px -4px,-4px 0;background-color:rgb(var(--pg-checker-base, 255 255 255))}\n", ":host{display:block}.pg-color-channel-slider__input{width:100%;height:12px;border-radius:9999px;appearance:none;cursor:pointer}.pg-color-channel-slider__input--hue{background-image:linear-gradient(to right,red,#ff0 17%,#0f0 33%,#0ff,#00f 67%,#f0f 83%,red)}.pg-color-channel-slider__input--alpha{background-image:linear-gradient(to right,transparent,var(--pg-color-channel-slider-hue-color, #000)),linear-gradient(45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(-45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%),linear-gradient(-45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%);background-size:100% 100%,8px 8px,8px 8px,8px 8px,8px 8px;background-position:0 0,0 0,0 4px,4px -4px,-4px 0;background-color:rgb(var(--pg-checker-base, 255 255 255))}.pg-color-channel-slider__input::-webkit-slider-thumb{appearance:none;width:16px;height:16px;border-radius:9999px;background:rgb(var(--pg-surface, 255 255 255));border:2px solid rgb(var(--pg-outline, 209 213 219));box-shadow:0 1px 2px #0003}.pg-color-channel-slider__input::-moz-range-thumb{width:16px;height:16px;border-radius:9999px;background:rgb(var(--pg-surface, 255 255 255));border:2px solid rgb(var(--pg-outline, 209 213 219));box-shadow:0 1px 2px #0003}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgColorChannelSliderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-color-channel-slider', imports: [], changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'pg-color-channel-slider block' }, template: "@if (channel() === 'hue') {\n  <input\n    type=\"range\"\n    min=\"0\"\n    max=\"360\"\n    step=\"1\"\n    class=\"pg-color-channel-slider__input pg-color-channel-slider__input--hue\"\n    [attr.aria-label]=\"ariaLabel()\"\n    [attr.aria-valuetext]=\"valueText()\"\n    [value]=\"value()\"\n    [disabled]=\"disabled()\"\n    (input)=\"onInput($event)\"\n  />\n} @else {\n  <input\n    type=\"range\"\n    min=\"0\"\n    max=\"1\"\n    step=\"0.01\"\n    class=\"pg-color-channel-slider__input pg-color-channel-slider__input--alpha\"\n    [attr.aria-label]=\"ariaLabel()\"\n    [attr.aria-valuetext]=\"valueText()\"\n    [value]=\"value()\"\n    [disabled]=\"disabled()\"\n    [style.--pg-color-channel-slider-hue-color]=\"hueOpaqueColor()\"\n    (input)=\"onInput($event)\"\n  />\n}\n", styles: [".pg-color-checkerboard{background-image:linear-gradient(45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(-45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%),linear-gradient(-45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%);background-size:8px 8px;background-position:0 0,0 4px,4px -4px,-4px 0;background-color:rgb(var(--pg-checker-base, 255 255 255))}\n", ":host{display:block}.pg-color-channel-slider__input{width:100%;height:12px;border-radius:9999px;appearance:none;cursor:pointer}.pg-color-channel-slider__input--hue{background-image:linear-gradient(to right,red,#ff0 17%,#0f0 33%,#0ff,#00f 67%,#f0f 83%,red)}.pg-color-channel-slider__input--alpha{background-image:linear-gradient(to right,transparent,var(--pg-color-channel-slider-hue-color, #000)),linear-gradient(45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(-45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%),linear-gradient(-45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%);background-size:100% 100%,8px 8px,8px 8px,8px 8px,8px 8px;background-position:0 0,0 0,0 4px,4px -4px,-4px 0;background-color:rgb(var(--pg-checker-base, 255 255 255))}.pg-color-channel-slider__input::-webkit-slider-thumb{appearance:none;width:16px;height:16px;border-radius:9999px;background:rgb(var(--pg-surface, 255 255 255));border:2px solid rgb(var(--pg-outline, 209 213 219));box-shadow:0 1px 2px #0003}.pg-color-channel-slider__input::-moz-range-thumb{width:16px;height:16px;border-radius:9999px;background:rgb(var(--pg-surface, 255 255 255));border:2px solid rgb(var(--pg-outline, 209 213 219));box-shadow:0 1px 2px #0003}\n"] }]
        }] });

/** Wraps a rendered swatch `<button>` as a CDK-navigable grid cell. */
class SwatchFocusableOption {
    el;
    hex;
    disabled = false;
    constructor(el, hex) {
        this.el = el;
        this.hex = hex;
    }
    focus() {
        this.el.focus();
    }
    getLabel() {
        return this.hex;
    }
}
/**
 * Roving-tabindex color grid — serves the preset palette, the saved-colors
 * row, AND the `palette` variant's generated spectrum, all via the same
 * `role="grid"`/`gridcell` + `FocusKeyManager` contract (pattern mirrors
 * `dropdown-menu.component.ts`'s `MenuItemFocusableOption`/key-manager
 * wiring). Enter/Space select the active cell; Delete removes it, but only
 * when `[removable]` is set (saved swatches only — spec requirement
 * "Swatch Grid Keyboard & ARIA").
 */
class PgColorSwatchGridComponent {
    destroyRef = inject(DestroyRef);
    colors = input([]);
    selected = input(null);
    /** Allows Delete/Backspace to remove the active cell — saved-colors grids only. */
    removable = input(false);
    ariaLabel = input('Colors');
    disabled = input(false);
    /** Cell size — `'sm'` for the `swatch-grid` variant's `density="compact"`. */
    size = input('md');
    /**
     * Column count for a REAL 2D grid (e.g. `palette`'s 12x9 spectrum: pass
     * `12`). Omitted/`null` (the default) keeps the flat 1D roving-tabindex
     * list every other swatch grid (presets, saved colors) already uses —
     * that shape is a single logical row, so a dedicated `columns` isn't
     * meaningful for it.
     */
    columns = input(null);
    colorSelected = output();
    colorRemoved = output();
    cellRefs = viewChildren('cell');
    /**
     * Cell indices grouped by DOM row. A single group (one `role="row"`) when
     * `[columns]` is unset/`<= 1`/`>=` the cell count — matches every existing
     * 1D usage exactly. Multiple groups (one `role="row"` each) when `columns`
     * genuinely describes a 2D layout, giving real per-row ARIA structure
     * instead of one `role="row"` wrapping every cell.
     */
    rowGroups = computed(() => {
        const cols = this.columns();
        const total = this.colors().length;
        if (!cols || cols <= 1 || total <= cols) {
            return [Array.from({ length: total }, (_, i) => i)];
        }
        const groups = [];
        for (let start = 0; start < total; start += cols) {
            groups.push(Array.from({ length: Math.min(cols, total - start) }, (_, j) => start + j));
        }
        return groups;
    });
    isGrid2D = computed(() => this.rowGroups().length > 1);
    keyManager = null;
    activeIndex = signal(0);
    constructor() {
        // Rebuild the key manager whenever the rendered cells change, mirroring
        // `PgSelectBase`'s `optionItems` effect — keeps the active index from
        // ever pointing at a stale/removed cell.
        effect(() => {
            const refs = this.cellRefs();
            const colors = this.colors();
            this.keyManager?.destroy();
            const items = refs.map((ref, i) => new SwatchFocusableOption(ref.nativeElement, colors[i]));
            this.keyManager = new FocusKeyManager(items).withWrap().withHorizontalOrientation('ltr').withHomeAndEnd();
            const selectedHex = this.selected();
            const initialIndex = selectedHex ? colors.indexOf(selectedHex) : -1;
            this.keyManager.updateActiveItem(initialIndex >= 0 ? initialIndex : 0);
            this.activeIndex.set(this.keyManager.activeItemIndex ?? 0);
            this.keyManager.change.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((index) => {
                this.activeIndex.set(index);
            });
        });
    }
    isActive(index) {
        return this.activeIndex() === index;
    }
    onCellClick(index, hex) {
        if (this.disabled())
            return;
        this.keyManager?.setActiveItem(index);
        this.colorSelected.emit(hex);
    }
    onGridKeydown(event) {
        if (this.disabled())
            return;
        if (event.key === 'Enter' || event.key === ' ' || event.key === 'Spacebar') {
            event.preventDefault();
            const active = this.keyManager?.activeItem;
            if (active)
                this.colorSelected.emit(active.hex);
            return;
        }
        if (event.key === 'Delete' || event.key === 'Backspace') {
            if (!this.removable())
                return;
            event.preventDefault();
            const active = this.keyManager?.activeItem;
            if (active)
                this.colorRemoved.emit(active.hex);
            return;
        }
        if (this.isGrid2D() && this.handle2DNavigation(event))
            return;
        this.keyManager?.onKeydown(event);
    }
    /**
     * Real row/column-aware navigation for a genuine 2D grid (`[columns]`
     * set — e.g. `palette`'s 12x9 spectrum). `FocusKeyManager`'s
     * `ListKeyManager` is flat/1D: its `vertical`/`horizontal` orientation
     * flags both walk the SAME underlying array by ±1, so without this,
     * ArrowUp/ArrowDown would be indistinguishable from ArrowLeft/ArrowRight
     * (the bug this method fixes).
     *
     * Decisions (no spec/design mandate beyond "12 hue columns x 9 rows" +
     * WAI-ARIA grid semantics, so documented here):
     * - ArrowLeft/ArrowRight move within the current row and CLAMP at its
     *   edges — no wrap into the adjacent row, so a boundary press is a
     *   deliberate no-op rather than a surprising jump to a different row.
     * - ArrowUp/ArrowDown move by a full row (±`columns`) and CLAMP at the
     *   grid's top/bottom for the same reason.
     * - Home/End move to the current row's start/end (mirrors native
     *   spreadsheet/grid widgets); Ctrl+Home/Ctrl+End jump to the whole
     *   grid's first/last cell.
     */
    handle2DNavigation(event) {
        const cols = this.columns();
        if (!cols || !this.keyManager)
            return false;
        const total = this.colors().length;
        const current = this.keyManager.activeItemIndex ?? 0;
        const rowStart = Math.floor(current / cols) * cols;
        const rowEnd = Math.min(rowStart + cols, total) - 1;
        let next;
        switch (event.key) {
            case 'ArrowUp':
                next = current - cols >= 0 ? current - cols : current;
                break;
            case 'ArrowDown':
                next = current + cols < total ? current + cols : current;
                break;
            case 'ArrowLeft':
                next = current > rowStart ? current - 1 : current;
                break;
            case 'ArrowRight':
                next = current < rowEnd ? current + 1 : current;
                break;
            case 'Home':
                next = event.ctrlKey ? 0 : rowStart;
                break;
            case 'End':
                next = event.ctrlKey ? total - 1 : rowEnd;
                break;
            default:
                return false;
        }
        event.preventDefault();
        this.keyManager.setActiveItem(next);
        return true;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgColorSwatchGridComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: PgColorSwatchGridComponent, isStandalone: true, selector: "pg-color-swatch-grid", inputs: { colors: { classPropertyName: "colors", publicName: "colors", isSignal: true, isRequired: false, transformFunction: null }, selected: { classPropertyName: "selected", publicName: "selected", isSignal: true, isRequired: false, transformFunction: null }, removable: { classPropertyName: "removable", publicName: "removable", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { colorSelected: "colorSelected", colorRemoved: "colorRemoved" }, host: { classAttribute: "pg-color-swatch-grid block" }, viewQueries: [{ propertyName: "cellRefs", predicate: ["cell"], descendants: true, isSignal: true }], ngImport: i0, template: "<div\n  class=\"pg-color-swatch-grid__grid\"\n  role=\"grid\"\n  [attr.aria-label]=\"ariaLabel()\"\n  (keydown)=\"onGridKeydown($event)\"\n>\n  @for (row of rowGroups(); track $index) {\n    <div role=\"row\" class=\"pg-color-swatch-grid__row flex flex-wrap gap-1.5\">\n      @for (i of row; track i) {\n        <button\n          #cell\n          type=\"button\"\n          role=\"gridcell\"\n          class=\"pg-color-swatch-grid__cell pg-color-checkerboard size-6 rounded-full overflow-hidden\"\n          [class.pg-color-swatch-grid__cell--sm]=\"size() === 'sm'\"\n          [attr.tabindex]=\"isActive(i) ? 0 : -1\"\n          [attr.aria-selected]=\"selected() === colors()[i]\"\n          [attr.aria-label]=\"colors()[i]\"\n          [disabled]=\"disabled()\"\n          (click)=\"onCellClick(i, colors()[i])\"\n        >\n          <span class=\"pg-color-swatch-grid__swatch block size-full\" [style.background-color]=\"colors()[i]\"></span>\n        </button>\n      }\n    </div>\n  }\n</div>\n", styles: [".pg-color-checkerboard{background-image:linear-gradient(45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(-45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%),linear-gradient(-45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%);background-size:8px 8px;background-position:0 0,0 4px,4px -4px,-4px 0;background-color:rgb(var(--pg-checker-base, 255 255 255))}\n", ":host{display:block}.pg-color-swatch-grid__cell{cursor:pointer;padding:0;border:2px solid transparent}.pg-color-swatch-grid__cell:focus-visible{outline:2px solid var(--pg-color-swatch-grid-focus, #f87a54);outline-offset:1px}.pg-color-swatch-grid__cell[aria-selected=true]{border-color:rgb(var(--pg-outline-strong, 17 24 39))}.pg-color-swatch-grid__cell:disabled{cursor:not-allowed;opacity:.5}.pg-color-swatch-grid__cell--sm{width:1rem;height:1rem}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgColorSwatchGridComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-color-swatch-grid', imports: [], changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'pg-color-swatch-grid block' }, template: "<div\n  class=\"pg-color-swatch-grid__grid\"\n  role=\"grid\"\n  [attr.aria-label]=\"ariaLabel()\"\n  (keydown)=\"onGridKeydown($event)\"\n>\n  @for (row of rowGroups(); track $index) {\n    <div role=\"row\" class=\"pg-color-swatch-grid__row flex flex-wrap gap-1.5\">\n      @for (i of row; track i) {\n        <button\n          #cell\n          type=\"button\"\n          role=\"gridcell\"\n          class=\"pg-color-swatch-grid__cell pg-color-checkerboard size-6 rounded-full overflow-hidden\"\n          [class.pg-color-swatch-grid__cell--sm]=\"size() === 'sm'\"\n          [attr.tabindex]=\"isActive(i) ? 0 : -1\"\n          [attr.aria-selected]=\"selected() === colors()[i]\"\n          [attr.aria-label]=\"colors()[i]\"\n          [disabled]=\"disabled()\"\n          (click)=\"onCellClick(i, colors()[i])\"\n        >\n          <span class=\"pg-color-swatch-grid__swatch block size-full\" [style.background-color]=\"colors()[i]\"></span>\n        </button>\n      }\n    </div>\n  }\n</div>\n", styles: [".pg-color-checkerboard{background-image:linear-gradient(45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(-45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%),linear-gradient(-45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%);background-size:8px 8px;background-position:0 0,0 4px,4px -4px,-4px 0;background-color:rgb(var(--pg-checker-base, 255 255 255))}\n", ":host{display:block}.pg-color-swatch-grid__cell{cursor:pointer;padding:0;border:2px solid transparent}.pg-color-swatch-grid__cell:focus-visible{outline:2px solid var(--pg-color-swatch-grid-focus, #f87a54);outline-offset:1px}.pg-color-swatch-grid__cell[aria-selected=true]{border-color:rgb(var(--pg-outline-strong, 17 24 39))}.pg-color-swatch-grid__cell:disabled{cursor:not-allowed;opacity:.5}.pg-color-swatch-grid__cell--sm{width:1rem;height:1rem}\n"] }]
        }], ctorParameters: () => [] });

const ALL_FORMATS$1 = ['hex', 'rgb', 'hsl', 'hsb'];
/**
 * Format selector (Hex/RGB/HSL/HSB) + commit-on-confirm text entry (spec
 * requirements "Format Switching" and "Input Validation & Edge Cases").
 * Purely presentational/controlled: `color`/`format` are owned by the
 * shell, this component only ever proposes changes via `(formatChange)`
 * (switching format alone never touches the color) and `(commit)` (a
 * confirmed, already-clamped edit). Invalid text reverts to the last valid
 * value on blur without emitting.
 */
class PgColorFormatInputComponent {
    renderer = inject(Renderer2);
    idService = inject(IdService);
    textInputRef = viewChild('textInput');
    color = input.required();
    format = input('hex');
    /** Which formats the selector offers. A single entry hides the selector (e.g. `minimal`/`swatch-grid`/`palette` variants: hex only). */
    formats = input(ALL_FORMATS$1);
    disabled = input(false);
    formatChange = output();
    commit = output();
    formatSelectId = this.idService.generate('pg-color-format-select');
    formatOptions = computed(() => this.formats().map((f) => ({ label: f.toUpperCase(), value: f })));
    /**
     * `pg-select` only exposes disabled state through `ControlValueAccessor.setDisabledState`
     * (no plain `[disabled]` input) — a local `FormControl` is the only way to drive that,
     * kept in sync with the `format`/`disabled` inputs via the effects below.
     */
    formatControl = new FormControl('hex', { nonNullable: true });
    /** Text currently shown in the input — diverges from `formatColor(color, format)` only while actively editing. */
    draftText = signal('');
    isEditing = false;
    constructor() {
        effect(() => {
            const text = formatColor(this.color(), this.format());
            if (!this.isEditing)
                this.draftText.set(text);
        });
        effect(() => {
            const f = this.format();
            if (this.formatControl.value !== f)
                this.formatControl.setValue(f, { emitEvent: false });
        });
        effect(() => {
            if (this.disabled())
                this.formatControl.disable({ emitEvent: false });
            else
                this.formatControl.enable({ emitEvent: false });
        });
        this.formatControl.valueChanges.pipe(takeUntilDestroyed()).subscribe((value) => {
            this.formatChange.emit(value);
        });
        // Imperative `Renderer2.setProperty` — mirrors `InputDirective`'s value-sync
        // pattern (`forms/input.directives.ts`). A plain `[value]` binding would
        // silently no-op here: once the user types, the native `value` diverges
        // from Angular's last-seen bound string; reverting `draftText` back to
        // that SAME original string then looks like "no change" to Angular's own
        // dirty-check and it skips the DOM write, leaving the stale typed text
        // on screen even though the signal is correct.
        effect(() => {
            const text = this.draftText();
            const el = this.textInputRef()?.nativeElement;
            if (el)
                this.renderer.setProperty(el, 'value', text);
        });
    }
    onFocus() {
        this.isEditing = true;
    }
    onInput(event) {
        this.draftText.set(event.target.value);
    }
    onBlur() {
        this.confirm();
    }
    onKeydown(event) {
        if (event.key === 'Enter') {
            event.preventDefault();
            this.confirm();
            event.target.blur();
        }
        else if (event.key === 'Escape') {
            event.preventDefault();
            this.revert();
        }
    }
    confirm() {
        // Guards against a double-commit: pressing Enter confirms and then
        // explicitly blurs the input, which fires a second, synthetic `blur` ->
        // `onBlur()` -> `confirm()` call for the same already-settled text.
        if (!this.isEditing)
            return;
        const parsed = parseColorInput(this.draftText(), this.format());
        this.isEditing = false;
        if (!parsed) {
            this.revert();
            return;
        }
        this.commit.emit(parsed);
    }
    revert() {
        this.isEditing = false;
        this.draftText.set(formatColor(this.color(), this.format()));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgColorFormatInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: PgColorFormatInputComponent, isStandalone: true, selector: "pg-color-format-input", inputs: { color: { classPropertyName: "color", publicName: "color", isSignal: true, isRequired: true, transformFunction: null }, format: { classPropertyName: "format", publicName: "format", isSignal: true, isRequired: false, transformFunction: null }, formats: { classPropertyName: "formats", publicName: "formats", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { formatChange: "formatChange", commit: "commit" }, host: { classAttribute: "pg-color-format-input block" }, viewQueries: [{ propertyName: "textInputRef", first: true, predicate: ["textInput"], descendants: true, isSignal: true }], ngImport: i0, template: "<div class=\"pg-color-format-input__row flex items-center gap-2\">\n  @if (formats().length > 1) {\n    <div class=\"pg-color-format-input__format-select w-20 shrink-0\">\n      <label class=\"sr-only\" [attr.for]=\"formatSelectId\">Color format</label>\n      <pg-select\n        [forId]=\"formatSelectId\"\n        [options]=\"formatOptions()\"\n        [formControl]=\"formatControl\"\n        [clearable]=\"false\"\n      ></pg-select>\n    </div>\n  }\n  <input\n    #textInput\n    type=\"text\"\n    class=\"pg-color-format-input__text flex-1 min-w-0 rounded bg-transparent text-content outline outline-1 -outline-offset-1 outline-outline px-2 py-1 text-sm focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-[var(--pg-color-picker-primary,theme(colors.primary.DEFAULT))]\"\n    [attr.aria-label]=\"'Color value (' + format().toUpperCase() + ')'\"\n    [disabled]=\"disabled()\"\n    (focus)=\"onFocus()\"\n    (input)=\"onInput($event)\"\n    (blur)=\"onBlur()\"\n    (keydown)=\"onKeydown($event)\"\n  />\n</div>\n", styles: [":host{display:block}:host ::ng-deep .pg-color-format-input__format-select .pg-select-trigger{padding-left:0.5rem;padding-right:0.5rem;padding-top:0.375rem;padding-bottom:0.375rem;font-size:14px;line-height:1.5;line-height:1.25rem}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "component", type: SelectComponent, selector: "pg-select", inputs: ["variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgColorFormatInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-color-format-input', imports: [ReactiveFormsModule, SelectComponent], changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'pg-color-format-input block' }, template: "<div class=\"pg-color-format-input__row flex items-center gap-2\">\n  @if (formats().length > 1) {\n    <div class=\"pg-color-format-input__format-select w-20 shrink-0\">\n      <label class=\"sr-only\" [attr.for]=\"formatSelectId\">Color format</label>\n      <pg-select\n        [forId]=\"formatSelectId\"\n        [options]=\"formatOptions()\"\n        [formControl]=\"formatControl\"\n        [clearable]=\"false\"\n      ></pg-select>\n    </div>\n  }\n  <input\n    #textInput\n    type=\"text\"\n    class=\"pg-color-format-input__text flex-1 min-w-0 rounded bg-transparent text-content outline outline-1 -outline-offset-1 outline-outline px-2 py-1 text-sm focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-[var(--pg-color-picker-primary,theme(colors.primary.DEFAULT))]\"\n    [attr.aria-label]=\"'Color value (' + format().toUpperCase() + ')'\"\n    [disabled]=\"disabled()\"\n    (focus)=\"onFocus()\"\n    (input)=\"onInput($event)\"\n    (blur)=\"onBlur()\"\n    (keydown)=\"onKeydown($event)\"\n  />\n</div>\n", styles: [":host{display:block}:host ::ng-deep .pg-color-format-input__format-select .pg-select-trigger{padding-left:0.5rem;padding-right:0.5rem;padding-top:0.375rem;padding-bottom:0.375rem;font-size:14px;line-height:1.5;line-height:1.25rem}\n"] }]
        }], ctorParameters: () => [] });

const ALL_FORMATS = ['hex', 'rgb', 'hsl', 'hsb'];
const HEX_ONLY_FORMATS = ['hex'];
/**
 * Internal presentational panel — composes the shared primitives per
 * `variant()` (design's variant composition table). Owns zero forms logic:
 * every primitive event is relayed upward via this component's own outputs,
 * and the shell (`PgColorPickerComponent`) is the single CVA/state owner.
 * Also the seam for a future D1 Popover migration (design note).
 */
class PgColorPickerPanelComponent {
    variant = input.required();
    density = input('default');
    hsb = input.required();
    alpha = input(1);
    format = input('hex');
    presetColors = input(PG_DEFAULT_PRESET_COLORS);
    savedColors = input([]);
    disabled = input(false);
    hsbChange = output();
    alphaChange = output();
    /**
     * Fired instead of `hsbChange`/`alphaChange` when both change together as
     * one atomic user action (format-input commit, preset/spectrum/saved
     * swatch selection) — keeps the shell's `(colorChange)` a single emission
     * per gesture rather than two.
     */
    colorCommit = output();
    formatChange = output();
    savedColorAdded = output();
    savedColorRemoved = output();
    savedColorSelected = output();
    allFormats = ALL_FORMATS;
    hexOnlyFormats = HEX_ONLY_FORMATS;
    currentColor = computed(() => buildPgColor(this.hsb(), this.alpha()));
    /**
     * Flattened `generateSpectrumGrid()` (design D6: 12 hue columns x 9 rows =
     * 108 cells), rendered as ONE `pg-color-swatch-grid` instance with
     * `[columns]="spectrumColumns"` so it gets REAL 2D grid semantics (one
     * `role="row"` per row of 12 cells, ArrowUp/ArrowDown move a full row) —
     * see `color-swatch-grid.component.ts`'s `handle2DNavigation`.
     */
    flatSpectrum = computed(() => generateSpectrumGrid().flat());
    spectrumColumns = PG_SPECTRUM_COLUMNS;
    swatchSize = computed(() => (this.density() === 'compact' ? 'sm' : 'md'));
    onSaturationChange(s) {
        this.hsbChange.emit({ ...this.hsb(), s });
    }
    onBrightnessChange(b) {
        this.hsbChange.emit({ ...this.hsb(), b });
    }
    /**
     * Pointer-driven gradient-surface update: both axes come from ONE physical
     * gesture and MUST be merged into the next `hsb` value in a single atomic
     * spread. Splitting this into two separate `hsbChange` emissions (one per
     * axis, like `onSaturationChange`/`onBrightnessChange` above) would race:
     * this panel's own `hsb` INPUT signal only reflects the shell's committed
     * state after a full round trip through the parent, and no CD tick runs
     * between two synchronous emissions in the same pointer event — so the
     * second emit would read a stale `hsb()` and clobber the first axis.
     */
    onPositionChange(position) {
        this.hsbChange.emit({ ...this.hsb(), s: position.saturation, b: position.brightness });
    }
    onHueChange(h) {
        this.hsbChange.emit({ ...this.hsb(), h });
    }
    onAlphaInput(a) {
        this.alphaChange.emit(a);
    }
    onFormatSelect(f) {
        this.formatChange.emit(f);
    }
    onCommit(parsed) {
        this.colorCommit.emit(parsed);
    }
    onPresetSelected(hex) {
        this.applyHex(hex);
    }
    onSpectrumSelected(hex) {
        this.applyHex(hex);
    }
    onSavedSelected(hex) {
        this.applyHex(hex);
        this.savedColorSelected.emit(hex);
    }
    onSavedRemoved(hex) {
        this.savedColorRemoved.emit(hex);
    }
    onAddSaved() {
        this.savedColorAdded.emit(this.currentColor().hex);
    }
    applyHex(hex) {
        const parsed = parseHex(hex);
        if (!parsed)
            return;
        this.colorCommit.emit({ hsb: rgbToHsb(parsed.rgb), alpha: parsed.alpha });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgColorPickerPanelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: PgColorPickerPanelComponent, isStandalone: true, selector: "pg-color-picker-panel", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: true, transformFunction: null }, density: { classPropertyName: "density", publicName: "density", isSignal: true, isRequired: false, transformFunction: null }, hsb: { classPropertyName: "hsb", publicName: "hsb", isSignal: true, isRequired: true, transformFunction: null }, alpha: { classPropertyName: "alpha", publicName: "alpha", isSignal: true, isRequired: false, transformFunction: null }, format: { classPropertyName: "format", publicName: "format", isSignal: true, isRequired: false, transformFunction: null }, presetColors: { classPropertyName: "presetColors", publicName: "presetColors", isSignal: true, isRequired: false, transformFunction: null }, savedColors: { classPropertyName: "savedColors", publicName: "savedColors", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { hsbChange: "hsbChange", alphaChange: "alphaChange", colorCommit: "colorCommit", formatChange: "formatChange", savedColorAdded: "savedColorAdded", savedColorRemoved: "savedColorRemoved", savedColorSelected: "savedColorSelected" }, host: { classAttribute: "pg-color-picker-panel block" }, ngImport: i0, template: "@switch (variant()) {\n  @case ('full') {\n    <div class=\"pg-color-picker-panel__full flex flex-col gap-3\">\n      <pg-color-gradient-surface\n        [hue]=\"hsb().h\"\n        [saturation]=\"hsb().s\"\n        [brightness]=\"hsb().b\"\n        [disabled]=\"disabled()\"\n        (saturationChange)=\"onSaturationChange($event)\"\n        (brightnessChange)=\"onBrightnessChange($event)\"\n        (positionChange)=\"onPositionChange($event)\"\n      ></pg-color-gradient-surface>\n      <pg-color-channel-slider\n        channel=\"hue\"\n        [value]=\"hsb().h\"\n        [disabled]=\"disabled()\"\n        (valueChange)=\"onHueChange($event)\"\n      ></pg-color-channel-slider>\n      <pg-color-channel-slider\n        channel=\"alpha\"\n        [value]=\"alpha()\"\n        [hue]=\"hsb().h\"\n        [disabled]=\"disabled()\"\n        (valueChange)=\"onAlphaInput($event)\"\n      ></pg-color-channel-slider>\n      <pg-color-format-input\n        [color]=\"currentColor()\"\n        [format]=\"format()\"\n        [formats]=\"allFormats\"\n        [disabled]=\"disabled()\"\n        (formatChange)=\"onFormatSelect($event)\"\n        (commit)=\"onCommit($event)\"\n      ></pg-color-format-input>\n      @if (savedColors().length > 0) {\n        <div class=\"pg-color-picker-panel__saved flex items-center gap-2\">\n          <pg-color-swatch-grid\n            class=\"flex-1\"\n            [colors]=\"savedColors()\"\n            [selected]=\"currentColor().hex\"\n            [removable]=\"true\"\n            ariaLabel=\"Saved colors\"\n            [disabled]=\"disabled()\"\n            (colorSelected)=\"onSavedSelected($event)\"\n            (colorRemoved)=\"onSavedRemoved($event)\"\n          ></pg-color-swatch-grid>\n          <button\n            type=\"button\"\n            class=\"pg-color-picker-panel__add-saved shrink-0 text-xs font-medium text-content-muted hover:text-content\"\n            [disabled]=\"disabled()\"\n            (click)=\"onAddSaved()\"\n          >\n            + Add\n          </button>\n        </div>\n      }\n    </div>\n  }\n  @case ('minimal') {\n    <div class=\"pg-color-picker-panel__minimal flex flex-col gap-2\">\n      <pg-color-channel-slider\n        channel=\"alpha\"\n        [value]=\"alpha()\"\n        [hue]=\"hsb().h\"\n        [disabled]=\"disabled()\"\n        (valueChange)=\"onAlphaInput($event)\"\n      ></pg-color-channel-slider>\n      <pg-color-format-input\n        [color]=\"currentColor()\"\n        [format]=\"format()\"\n        [formats]=\"hexOnlyFormats\"\n        [disabled]=\"disabled()\"\n        (formatChange)=\"onFormatSelect($event)\"\n        (commit)=\"onCommit($event)\"\n      ></pg-color-format-input>\n    </div>\n  }\n  @case ('swatch-grid') {\n    <div class=\"pg-color-picker-panel__swatch-grid flex flex-col gap-2\">\n      @if (density() === 'default') {\n        <div\n          class=\"pg-color-picker-panel__preview pg-color-checkerboard h-10 w-full rounded-md border border-outline overflow-hidden\"\n        >\n          <span class=\"block size-full\" [style.background-color]=\"currentColor().hex\"></span>\n        </div>\n      }\n      <pg-color-swatch-grid\n        [colors]=\"presetColors()\"\n        [selected]=\"currentColor().hex\"\n        [size]=\"swatchSize()\"\n        ariaLabel=\"Preset colors\"\n        [disabled]=\"disabled()\"\n        (colorSelected)=\"onPresetSelected($event)\"\n      ></pg-color-swatch-grid>\n      <pg-color-channel-slider\n        channel=\"alpha\"\n        [value]=\"alpha()\"\n        [hue]=\"hsb().h\"\n        [disabled]=\"disabled()\"\n        (valueChange)=\"onAlphaInput($event)\"\n      ></pg-color-channel-slider>\n      @if (density() === 'compact') {\n        <pg-color-format-input\n          [color]=\"currentColor()\"\n          [format]=\"format()\"\n          [formats]=\"hexOnlyFormats\"\n          [disabled]=\"disabled()\"\n          (formatChange)=\"onFormatSelect($event)\"\n          (commit)=\"onCommit($event)\"\n        ></pg-color-format-input>\n      }\n    </div>\n  }\n  @case ('palette') {\n    <div class=\"pg-color-picker-panel__palette flex flex-col gap-2\">\n      <div class=\"pg-color-picker-panel__spectrum\">\n        <pg-color-swatch-grid\n          [colors]=\"flatSpectrum()\"\n          [selected]=\"currentColor().hex\"\n          [columns]=\"spectrumColumns\"\n          size=\"sm\"\n          ariaLabel=\"Color spectrum\"\n          [disabled]=\"disabled()\"\n          (colorSelected)=\"onSpectrumSelected($event)\"\n        ></pg-color-swatch-grid>\n      </div>\n      <pg-color-channel-slider\n        channel=\"alpha\"\n        [value]=\"alpha()\"\n        [hue]=\"hsb().h\"\n        [disabled]=\"disabled()\"\n        (valueChange)=\"onAlphaInput($event)\"\n      ></pg-color-channel-slider>\n      @if (savedColors().length > 0) {\n        <div class=\"pg-color-picker-panel__saved flex items-center gap-2\">\n          <pg-color-swatch-grid\n            class=\"flex-1\"\n            [colors]=\"savedColors()\"\n            [selected]=\"currentColor().hex\"\n            [removable]=\"true\"\n            ariaLabel=\"Saved colors\"\n            [disabled]=\"disabled()\"\n            (colorSelected)=\"onSavedSelected($event)\"\n            (colorRemoved)=\"onSavedRemoved($event)\"\n          ></pg-color-swatch-grid>\n          <button\n            type=\"button\"\n            class=\"pg-color-picker-panel__add-saved shrink-0 text-xs font-medium text-content-muted hover:text-content\"\n            [disabled]=\"disabled()\"\n            (click)=\"onAddSaved()\"\n          >\n            + Add\n          </button>\n        </div>\n      }\n    </div>\n  }\n}\n", styles: [".pg-color-checkerboard{background-image:linear-gradient(45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(-45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%),linear-gradient(-45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%);background-size:8px 8px;background-position:0 0,0 4px,4px -4px,-4px 0;background-color:rgb(var(--pg-checker-base, 255 255 255))}\n", ":host{display:block}.pg-color-picker-panel__full{width:260px}\n"], dependencies: [{ kind: "component", type: PgColorGradientSurfaceComponent, selector: "pg-color-gradient-surface", inputs: ["hue", "saturation", "brightness", "disabled"], outputs: ["saturationChange", "brightnessChange", "positionChange"] }, { kind: "component", type: PgColorChannelSliderComponent, selector: "pg-color-channel-slider", inputs: ["channel", "value", "hue", "disabled"], outputs: ["valueChange"] }, { kind: "component", type: PgColorSwatchGridComponent, selector: "pg-color-swatch-grid", inputs: ["colors", "selected", "removable", "ariaLabel", "disabled", "size", "columns"], outputs: ["colorSelected", "colorRemoved"] }, { kind: "component", type: PgColorFormatInputComponent, selector: "pg-color-format-input", inputs: ["color", "format", "formats", "disabled"], outputs: ["formatChange", "commit"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgColorPickerPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-color-picker-panel', imports: [
                        PgColorGradientSurfaceComponent,
                        PgColorChannelSliderComponent,
                        PgColorSwatchGridComponent,
                        PgColorFormatInputComponent,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'pg-color-picker-panel block' }, template: "@switch (variant()) {\n  @case ('full') {\n    <div class=\"pg-color-picker-panel__full flex flex-col gap-3\">\n      <pg-color-gradient-surface\n        [hue]=\"hsb().h\"\n        [saturation]=\"hsb().s\"\n        [brightness]=\"hsb().b\"\n        [disabled]=\"disabled()\"\n        (saturationChange)=\"onSaturationChange($event)\"\n        (brightnessChange)=\"onBrightnessChange($event)\"\n        (positionChange)=\"onPositionChange($event)\"\n      ></pg-color-gradient-surface>\n      <pg-color-channel-slider\n        channel=\"hue\"\n        [value]=\"hsb().h\"\n        [disabled]=\"disabled()\"\n        (valueChange)=\"onHueChange($event)\"\n      ></pg-color-channel-slider>\n      <pg-color-channel-slider\n        channel=\"alpha\"\n        [value]=\"alpha()\"\n        [hue]=\"hsb().h\"\n        [disabled]=\"disabled()\"\n        (valueChange)=\"onAlphaInput($event)\"\n      ></pg-color-channel-slider>\n      <pg-color-format-input\n        [color]=\"currentColor()\"\n        [format]=\"format()\"\n        [formats]=\"allFormats\"\n        [disabled]=\"disabled()\"\n        (formatChange)=\"onFormatSelect($event)\"\n        (commit)=\"onCommit($event)\"\n      ></pg-color-format-input>\n      @if (savedColors().length > 0) {\n        <div class=\"pg-color-picker-panel__saved flex items-center gap-2\">\n          <pg-color-swatch-grid\n            class=\"flex-1\"\n            [colors]=\"savedColors()\"\n            [selected]=\"currentColor().hex\"\n            [removable]=\"true\"\n            ariaLabel=\"Saved colors\"\n            [disabled]=\"disabled()\"\n            (colorSelected)=\"onSavedSelected($event)\"\n            (colorRemoved)=\"onSavedRemoved($event)\"\n          ></pg-color-swatch-grid>\n          <button\n            type=\"button\"\n            class=\"pg-color-picker-panel__add-saved shrink-0 text-xs font-medium text-content-muted hover:text-content\"\n            [disabled]=\"disabled()\"\n            (click)=\"onAddSaved()\"\n          >\n            + Add\n          </button>\n        </div>\n      }\n    </div>\n  }\n  @case ('minimal') {\n    <div class=\"pg-color-picker-panel__minimal flex flex-col gap-2\">\n      <pg-color-channel-slider\n        channel=\"alpha\"\n        [value]=\"alpha()\"\n        [hue]=\"hsb().h\"\n        [disabled]=\"disabled()\"\n        (valueChange)=\"onAlphaInput($event)\"\n      ></pg-color-channel-slider>\n      <pg-color-format-input\n        [color]=\"currentColor()\"\n        [format]=\"format()\"\n        [formats]=\"hexOnlyFormats\"\n        [disabled]=\"disabled()\"\n        (formatChange)=\"onFormatSelect($event)\"\n        (commit)=\"onCommit($event)\"\n      ></pg-color-format-input>\n    </div>\n  }\n  @case ('swatch-grid') {\n    <div class=\"pg-color-picker-panel__swatch-grid flex flex-col gap-2\">\n      @if (density() === 'default') {\n        <div\n          class=\"pg-color-picker-panel__preview pg-color-checkerboard h-10 w-full rounded-md border border-outline overflow-hidden\"\n        >\n          <span class=\"block size-full\" [style.background-color]=\"currentColor().hex\"></span>\n        </div>\n      }\n      <pg-color-swatch-grid\n        [colors]=\"presetColors()\"\n        [selected]=\"currentColor().hex\"\n        [size]=\"swatchSize()\"\n        ariaLabel=\"Preset colors\"\n        [disabled]=\"disabled()\"\n        (colorSelected)=\"onPresetSelected($event)\"\n      ></pg-color-swatch-grid>\n      <pg-color-channel-slider\n        channel=\"alpha\"\n        [value]=\"alpha()\"\n        [hue]=\"hsb().h\"\n        [disabled]=\"disabled()\"\n        (valueChange)=\"onAlphaInput($event)\"\n      ></pg-color-channel-slider>\n      @if (density() === 'compact') {\n        <pg-color-format-input\n          [color]=\"currentColor()\"\n          [format]=\"format()\"\n          [formats]=\"hexOnlyFormats\"\n          [disabled]=\"disabled()\"\n          (formatChange)=\"onFormatSelect($event)\"\n          (commit)=\"onCommit($event)\"\n        ></pg-color-format-input>\n      }\n    </div>\n  }\n  @case ('palette') {\n    <div class=\"pg-color-picker-panel__palette flex flex-col gap-2\">\n      <div class=\"pg-color-picker-panel__spectrum\">\n        <pg-color-swatch-grid\n          [colors]=\"flatSpectrum()\"\n          [selected]=\"currentColor().hex\"\n          [columns]=\"spectrumColumns\"\n          size=\"sm\"\n          ariaLabel=\"Color spectrum\"\n          [disabled]=\"disabled()\"\n          (colorSelected)=\"onSpectrumSelected($event)\"\n        ></pg-color-swatch-grid>\n      </div>\n      <pg-color-channel-slider\n        channel=\"alpha\"\n        [value]=\"alpha()\"\n        [hue]=\"hsb().h\"\n        [disabled]=\"disabled()\"\n        (valueChange)=\"onAlphaInput($event)\"\n      ></pg-color-channel-slider>\n      @if (savedColors().length > 0) {\n        <div class=\"pg-color-picker-panel__saved flex items-center gap-2\">\n          <pg-color-swatch-grid\n            class=\"flex-1\"\n            [colors]=\"savedColors()\"\n            [selected]=\"currentColor().hex\"\n            [removable]=\"true\"\n            ariaLabel=\"Saved colors\"\n            [disabled]=\"disabled()\"\n            (colorSelected)=\"onSavedSelected($event)\"\n            (colorRemoved)=\"onSavedRemoved($event)\"\n          ></pg-color-swatch-grid>\n          <button\n            type=\"button\"\n            class=\"pg-color-picker-panel__add-saved shrink-0 text-xs font-medium text-content-muted hover:text-content\"\n            [disabled]=\"disabled()\"\n            (click)=\"onAddSaved()\"\n          >\n            + Add\n          </button>\n        </div>\n      }\n    </div>\n  }\n}\n", styles: [".pg-color-checkerboard{background-image:linear-gradient(45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(-45deg,rgb(var(--pg-checker-square, 209 213 219)) 25%,transparent 25%),linear-gradient(45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%),linear-gradient(-45deg,transparent 75%,rgb(var(--pg-checker-square, 209 213 219)) 75%);background-size:8px 8px;background-position:0 0,0 4px,4px -4px,-4px 0;background-color:rgb(var(--pg-checker-base, 255 255 255))}\n", ":host{display:block}.pg-color-picker-panel__full{width:260px}\n"] }]
        }] });

/**
 * `pg-color-picker` — accessible color selection with 4 layout variants
 * (`full`/`minimal`/`swatch-grid`/`palette`), always-on alpha, and
 * multi-format text entry. Single public component + CVA implementation
 * (design: "one component + conditional templates" — no per-variant base
 * directive needed, unlike `pg-select`). Trigger + `cdkConnectedOverlay`
 * panel mirror `select.component.html`'s overlay setup; the panel itself is
 * wrapped in `cdkTrapFocus` since opening it MUST trap focus (spec
 * requirement "Panel Focus Management").
 */
class PgColorPickerComponent extends PgControlValueAccessorBase {
    idService = inject(IdService);
    renderer = inject(Renderer2);
    // Non-optional: the token is `providedIn: 'root'` with a factory default, so it always resolves.
    _scrollStrategyFactory = inject(PG_COLOR_PICKER_SCROLL_STRATEGY);
    _autoId = this.idService.generate('pg-color-picker');
    scrollStrategy = this._scrollStrategyFactory();
    /** Primary bottom-start with a top-start flip fallback, plus horizontal shift variants. Mirrors `PgSelectBase`. */
    overlayPositions = [
        { originX: 'start', originY: 'bottom', overlayX: 'start', overlayY: 'top', offsetY: 4 },
        { originX: 'start', originY: 'top', overlayX: 'start', overlayY: 'bottom', offsetY: -4 },
        { originX: 'end', originY: 'bottom', overlayX: 'end', overlayY: 'top', offsetY: 4 },
        { originX: 'end', originY: 'top', overlayX: 'end', overlayY: 'bottom', offsetY: -4 },
    ];
    // ---- Inputs ----
    variant = input('full');
    density = input('default');
    /** Two-way: reflects/drives the format-selector's currently displayed format. */
    format = model('hex');
    presetColors = input(undefined);
    savedColors = input([]);
    placeholder = input('Select a color');
    readonly = input(false);
    error = input(undefined);
    forId = input('');
    customClass = input('');
    primaryColor = input('');
    // ---- Outputs ----
    colorChange = output();
    opened = output();
    closed = output();
    savedColorAdded = output();
    savedColorRemoved = output();
    savedColorSelected = output();
    computedForId = computed(() => this.forId() || this._autoId);
    resolvedPresetColors = computed(() => this.presetColors() ?? PG_DEFAULT_PRESET_COLORS);
    hasError = computed(() => {
        const override = this.error();
        if (override !== undefined)
            return override;
        const ctrl = this.ngControl?.control;
        if (!ctrl)
            return false;
        return ctrl.invalid && (ctrl.touched || ctrl.dirty);
    });
    triggerStateClasses = computed(() => {
        const extra = this.customClass();
        const suffix = extra ? ` ${extra}` : '';
        if (this.disabled()) {
            return `cursor-not-allowed bg-surface-muted text-content-muted outline-outline${suffix}`;
        }
        if (this.readonly()) {
            return `cursor-default bg-surface-muted text-content outline-outline${suffix}`;
        }
        if (this.hasError()) {
            return `cursor-pointer bg-surface text-content-danger outline-red-300 focus:outline-error${suffix}`;
        }
        return `cursor-pointer bg-surface text-content outline-outline focus:outline-[var(--pg-color-picker-primary,theme(colors.primary.DEFAULT))]${suffix}`;
    });
    // ---- Internal state (design D7: HSB is the source of truth, hex only at boundaries) ----
    _hsb = signal({ h: 0, s: 0, b: 0 });
    _alpha = signal(1);
    /** Guards against re-deriving HSB from a hex string this component itself just emitted (lossy round trip at s=0/b=0). */
    _lastEmittedHex = null;
    currentColor = computed(() => buildPgColor(this._hsb(), this._alpha()));
    // ---- Panel / overlay state ----
    isOpen = signal(false);
    isClosing = signal(false);
    panelEnterDurationMs = 150;
    panelExitDurationMs = 200;
    _closeTimeoutHandle = null;
    swatchBtnRef = viewChild('swatchBtn');
    valueInputRef = viewChild('valueInput');
    /** Text currently shown in the trigger's value input — diverges from `currentColor().hex` only while actively editing (mirrors `PgColorFormatInputComponent`'s draft pattern). */
    draftHex = signal('');
    _editingHex = false;
    constructor() {
        super();
        effect(() => {
            const hex = this.currentColor().hex;
            if (!this._editingHex)
                this.draftHex.set(hex);
        });
        // Imperative `Renderer2.setProperty` — see `PgColorFormatInputComponent`'s
        // identical effect for why a plain `[value]` binding silently no-ops here.
        effect(() => {
            const text = this.draftHex();
            const el = this.valueInputRef()?.nativeElement;
            if (el)
                this.renderer.setProperty(el, 'value', text);
        });
    }
    writeValue(value) {
        super.writeValue(value);
        // D7 guard: a value equal to what we just emitted ourselves must never
        // re-derive HSB — that round trip is lossy (e.g. hue is unrecoverable
        // from a hex string at s=0), and it would clobber in-progress state on
        // every `[(ngModel)]`/reactive-forms round trip.
        if (value !== null && value === this._lastEmittedHex)
            return;
        if (value === null)
            return;
        const parsed = parseHex(value);
        if (!parsed)
            return;
        this._hsb.set(rgbToHsb(parsed.rgb));
        this._alpha.set(parsed.alpha);
    }
    // ---- Open / close ----
    open() {
        if (this.disabled() || this.readonly())
            return;
        if (this.isOpen())
            return;
        this.isOpen.set(true);
        this.opened.emit();
    }
    close() {
        if (!this.isOpen() || this.isClosing())
            return;
        this.isClosing.set(true);
        this._closeTimeoutHandle = setTimeout(() => {
            this.isOpen.set(false);
            this.isClosing.set(false);
            this._closeTimeoutHandle = null;
            this.closed.emit();
        }, this.panelExitDurationMs);
    }
    toggle() {
        if (this.isOpen())
            this.close();
        else
            this.open();
    }
    onTriggerClick() {
        if (this.readonly())
            return;
        this.toggle();
    }
    onEscape() {
        if (!this.isOpen())
            return;
        this.close();
        this.swatchBtnRef()?.nativeElement.focus();
    }
    // ---- Trigger value input (direct hex entry without opening the panel) ----
    onValueFocus() {
        this._editingHex = true;
    }
    onValueInput(event) {
        this.draftHex.set(event.target.value);
    }
    onValueBlur() {
        this.markAsTouched();
        this.confirmValueEdit();
    }
    onValueKeydown(event) {
        if (event.key === 'Enter') {
            event.preventDefault();
            this.confirmValueEdit();
            event.target.blur();
        }
        else if (event.key === 'Escape') {
            event.preventDefault();
            if (this._editingHex) {
                this.revertValueEdit();
                event.target.blur();
            }
            else {
                this.onEscape();
            }
        }
    }
    confirmValueEdit() {
        // Guards against a double-commit: Enter confirms and then explicitly
        // blurs the input, which fires a second, synthetic `blur` -> same call.
        if (!this._editingHex)
            return;
        const parsed = parseColorInput(this.draftHex(), 'hex');
        this._editingHex = false;
        if (!parsed) {
            this.revertValueEdit();
            return;
        }
        this.commit(parsed.hsb, parsed.alpha);
    }
    revertValueEdit() {
        this._editingHex = false;
        this.draftHex.set(this.currentColor().hex);
    }
    // ---- Panel event relays ----
    onHsbChange(hsb) {
        this.commit(hsb, this._alpha());
    }
    onAlphaChange(alpha) {
        this.commit(this._hsb(), alpha);
    }
    /** Atomic hsb+alpha commit (format-input confirm, swatch/spectrum/saved selection) — single `colorChange` emission. */
    onColorCommit(parsed) {
        this.commit(parsed.hsb, parsed.alpha);
    }
    onFormatChange(format) {
        this.format.set(format);
    }
    onSavedColorAdded(hex) {
        this.savedColorAdded.emit(hex);
    }
    onSavedColorRemoved(hex) {
        this.savedColorRemoved.emit(hex);
    }
    onSavedColorSelected(hex) {
        this.savedColorSelected.emit(hex);
    }
    commit(hsb, alpha) {
        this._hsb.set(hsb);
        this._alpha.set(alpha);
        const color = buildPgColor(hsb, alpha);
        this._lastEmittedHex = color.hex;
        this.setValue(color.hex);
        this.colorChange.emit(color);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgColorPickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "19.2.21", type: PgColorPickerComponent, isStandalone: true, selector: "pg-color-picker", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, density: { classPropertyName: "density", publicName: "density", isSignal: true, isRequired: false, transformFunction: null }, format: { classPropertyName: "format", publicName: "format", isSignal: true, isRequired: false, transformFunction: null }, presetColors: { classPropertyName: "presetColors", publicName: "presetColors", isSignal: true, isRequired: false, transformFunction: null }, savedColors: { classPropertyName: "savedColors", publicName: "savedColors", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, forId: { classPropertyName: "forId", publicName: "forId", isSignal: true, isRequired: false, transformFunction: null }, customClass: { classPropertyName: "customClass", publicName: "customClass", isSignal: true, isRequired: false, transformFunction: null }, primaryColor: { classPropertyName: "primaryColor", publicName: "primaryColor", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { format: "formatChange", colorChange: "colorChange", opened: "opened", closed: "closed", savedColorAdded: "savedColorAdded", savedColorRemoved: "savedColorRemoved", savedColorSelected: "savedColorSelected" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => PgColorPickerComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "swatchBtnRef", first: true, predicate: ["swatchBtn"], descendants: true, isSignal: true }, { propertyName: "valueInputRef", first: true, predicate: ["valueInput"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "<div class=\"pg-color-picker relative\" cdkOverlayOrigin #origin=\"cdkOverlayOrigin\">\n  <div\n    class=\"pg-color-picker-trigger flex items-center gap-2 w-full rounded-md px-3 py-2 text-left text-sm leading-6 outline outline-1 -outline-offset-1 focus-within:outline focus-within:outline-2 focus-within:-outline-offset-2\"\n    [class]=\"triggerStateClasses()\"\n    [style.--pg-color-picker-primary]=\"primaryColor() || null\"\n  >\n    <button\n      #swatchBtn\n      type=\"button\"\n      aria-haspopup=\"dialog\"\n      aria-label=\"Open color picker\"\n      [attr.aria-expanded]=\"isOpen()\"\n      [attr.aria-disabled]=\"disabled() || null\"\n      [disabled]=\"disabled()\"\n      class=\"pg-color-picker-trigger__swatch-btn shrink-0 inline-flex items-center justify-center appearance-none rounded border-0 bg-transparent p-0 cursor-pointer outline-none disabled:cursor-not-allowed\"\n      (click)=\"onTriggerClick()\"\n      (keydown.escape)=\"onEscape()\"\n      (blur)=\"markAsTouched()\"\n    >\n      <span\n        class=\"pg-color-picker-trigger__swatch pg-color-checkerboard inline-block size-5 rounded outline outline-1 -outline-offset-1 outline-outline overflow-hidden\"\n      >\n        <span class=\"block size-full\" [style.background-color]=\"currentColor().hex\"></span>\n      </span>\n    </button>\n    <input\n      #valueInput\n      type=\"text\"\n      [id]=\"computedForId()\"\n      aria-label=\"Color value (hex)\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"disabled()\"\n      [readOnly]=\"readonly()\"\n      class=\"pg-color-picker-trigger__value flex-1 min-w-0 border-0 bg-transparent p-0 outline-none placeholder:text-content-subtle\"\n      (focus)=\"onValueFocus()\"\n      (input)=\"onValueInput($event)\"\n      (blur)=\"onValueBlur()\"\n      (keydown)=\"onValueKeydown($event)\"\n    />\n  </div>\n\n  <ng-template\n    cdkConnectedOverlay\n    [cdkConnectedOverlayOrigin]=\"origin\"\n    [cdkConnectedOverlayOpen]=\"isOpen()\"\n    [cdkConnectedOverlayPositions]=\"overlayPositions\"\n    [cdkConnectedOverlayFlexibleDimensions]=\"true\"\n    [cdkConnectedOverlayPush]=\"true\"\n    [cdkConnectedOverlayGrowAfterOpen]=\"true\"\n    [cdkConnectedOverlayScrollStrategy]=\"scrollStrategy\"\n    [cdkConnectedOverlayHasBackdrop]=\"true\"\n    cdkConnectedOverlayBackdropClass=\"cdk-overlay-transparent-backdrop\"\n    (backdropClick)=\"close()\"\n    (detach)=\"close()\"\n  >\n    <div\n      class=\"pg-color-picker-overlay rounded-md bg-surface-raised p-3 shadow-lg ring-1 ring-outline-contrast/5\"\n      cdkTrapFocus\n      [cdkTrapFocusAutoCapture]=\"true\"\n      [class.animate-fade-in]=\"!isClosing()\"\n      [class.animate-fade-out]=\"isClosing()\"\n      [style.animation-duration.ms]=\"isClosing() ? panelExitDurationMs : panelEnterDurationMs\"\n      (keydown.escape)=\"onEscape()\"\n    >\n      <pg-color-picker-panel\n        [variant]=\"variant()\"\n        [density]=\"density()\"\n        [hsb]=\"currentColor().hsb\"\n        [alpha]=\"currentColor().alpha\"\n        [format]=\"format()\"\n        [presetColors]=\"resolvedPresetColors()\"\n        [savedColors]=\"savedColors()\"\n        [disabled]=\"disabled()\"\n        (hsbChange)=\"onHsbChange($event)\"\n        (alphaChange)=\"onAlphaChange($event)\"\n        (colorCommit)=\"onColorCommit($event)\"\n        (formatChange)=\"onFormatChange($event)\"\n        (savedColorAdded)=\"onSavedColorAdded($event)\"\n        (savedColorRemoved)=\"onSavedColorRemoved($event)\"\n        (savedColorSelected)=\"onSavedColorSelected($event)\"\n      ></pg-color-picker-panel>\n    </div>\n  </ng-template>\n</div>\n", styles: [":host{display:block;width:100%}\n"], dependencies: [{ kind: "ngmodule", type: OverlayModule }, { kind: "directive", type: i1$1.CdkConnectedOverlay, selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]", inputs: ["cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayPositionStrategy", "cdkConnectedOverlayOffsetX", "cdkConnectedOverlayOffsetY", "cdkConnectedOverlayWidth", "cdkConnectedOverlayHeight", "cdkConnectedOverlayMinWidth", "cdkConnectedOverlayMinHeight", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayPanelClass", "cdkConnectedOverlayViewportMargin", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOpen", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayTransformOriginOn", "cdkConnectedOverlayHasBackdrop", "cdkConnectedOverlayLockPosition", "cdkConnectedOverlayFlexibleDimensions", "cdkConnectedOverlayGrowAfterOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayDisposeOnNavigation"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cdkConnectedOverlay"] }, { kind: "directive", type: i1$1.CdkOverlayOrigin, selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]", exportAs: ["cdkOverlayOrigin"] }, { kind: "ngmodule", type: A11yModule }, { kind: "directive", type: i2.CdkTrapFocus, selector: "[cdkTrapFocus]", inputs: ["cdkTrapFocus", "cdkTrapFocusAutoCapture"], exportAs: ["cdkTrapFocus"] }, { kind: "component", type: PgColorPickerPanelComponent, selector: "pg-color-picker-panel", inputs: ["variant", "density", "hsb", "alpha", "format", "presetColors", "savedColors", "disabled"], outputs: ["hsbChange", "alphaChange", "colorCommit", "formatChange", "savedColorAdded", "savedColorRemoved", "savedColorSelected"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgColorPickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-color-picker', imports: [OverlayModule, A11yModule, PgColorPickerPanelComponent], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => PgColorPickerComponent),
                            multi: true,
                        },
                    ], template: "<div class=\"pg-color-picker relative\" cdkOverlayOrigin #origin=\"cdkOverlayOrigin\">\n  <div\n    class=\"pg-color-picker-trigger flex items-center gap-2 w-full rounded-md px-3 py-2 text-left text-sm leading-6 outline outline-1 -outline-offset-1 focus-within:outline focus-within:outline-2 focus-within:-outline-offset-2\"\n    [class]=\"triggerStateClasses()\"\n    [style.--pg-color-picker-primary]=\"primaryColor() || null\"\n  >\n    <button\n      #swatchBtn\n      type=\"button\"\n      aria-haspopup=\"dialog\"\n      aria-label=\"Open color picker\"\n      [attr.aria-expanded]=\"isOpen()\"\n      [attr.aria-disabled]=\"disabled() || null\"\n      [disabled]=\"disabled()\"\n      class=\"pg-color-picker-trigger__swatch-btn shrink-0 inline-flex items-center justify-center appearance-none rounded border-0 bg-transparent p-0 cursor-pointer outline-none disabled:cursor-not-allowed\"\n      (click)=\"onTriggerClick()\"\n      (keydown.escape)=\"onEscape()\"\n      (blur)=\"markAsTouched()\"\n    >\n      <span\n        class=\"pg-color-picker-trigger__swatch pg-color-checkerboard inline-block size-5 rounded outline outline-1 -outline-offset-1 outline-outline overflow-hidden\"\n      >\n        <span class=\"block size-full\" [style.background-color]=\"currentColor().hex\"></span>\n      </span>\n    </button>\n    <input\n      #valueInput\n      type=\"text\"\n      [id]=\"computedForId()\"\n      aria-label=\"Color value (hex)\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"disabled()\"\n      [readOnly]=\"readonly()\"\n      class=\"pg-color-picker-trigger__value flex-1 min-w-0 border-0 bg-transparent p-0 outline-none placeholder:text-content-subtle\"\n      (focus)=\"onValueFocus()\"\n      (input)=\"onValueInput($event)\"\n      (blur)=\"onValueBlur()\"\n      (keydown)=\"onValueKeydown($event)\"\n    />\n  </div>\n\n  <ng-template\n    cdkConnectedOverlay\n    [cdkConnectedOverlayOrigin]=\"origin\"\n    [cdkConnectedOverlayOpen]=\"isOpen()\"\n    [cdkConnectedOverlayPositions]=\"overlayPositions\"\n    [cdkConnectedOverlayFlexibleDimensions]=\"true\"\n    [cdkConnectedOverlayPush]=\"true\"\n    [cdkConnectedOverlayGrowAfterOpen]=\"true\"\n    [cdkConnectedOverlayScrollStrategy]=\"scrollStrategy\"\n    [cdkConnectedOverlayHasBackdrop]=\"true\"\n    cdkConnectedOverlayBackdropClass=\"cdk-overlay-transparent-backdrop\"\n    (backdropClick)=\"close()\"\n    (detach)=\"close()\"\n  >\n    <div\n      class=\"pg-color-picker-overlay rounded-md bg-surface-raised p-3 shadow-lg ring-1 ring-outline-contrast/5\"\n      cdkTrapFocus\n      [cdkTrapFocusAutoCapture]=\"true\"\n      [class.animate-fade-in]=\"!isClosing()\"\n      [class.animate-fade-out]=\"isClosing()\"\n      [style.animation-duration.ms]=\"isClosing() ? panelExitDurationMs : panelEnterDurationMs\"\n      (keydown.escape)=\"onEscape()\"\n    >\n      <pg-color-picker-panel\n        [variant]=\"variant()\"\n        [density]=\"density()\"\n        [hsb]=\"currentColor().hsb\"\n        [alpha]=\"currentColor().alpha\"\n        [format]=\"format()\"\n        [presetColors]=\"resolvedPresetColors()\"\n        [savedColors]=\"savedColors()\"\n        [disabled]=\"disabled()\"\n        (hsbChange)=\"onHsbChange($event)\"\n        (alphaChange)=\"onAlphaChange($event)\"\n        (colorCommit)=\"onColorCommit($event)\"\n        (formatChange)=\"onFormatChange($event)\"\n        (savedColorAdded)=\"onSavedColorAdded($event)\"\n        (savedColorRemoved)=\"onSavedColorRemoved($event)\"\n        (savedColorSelected)=\"onSavedColorSelected($event)\"\n      ></pg-color-picker-panel>\n    </div>\n  </ng-template>\n</div>\n", styles: [":host{display:block;width:100%}\n"] }]
        }], ctorParameters: () => [] });

/**
 * Generated bundle index. Do not edit.
 */

export { PG_COLOR_PICKER_SCROLL_STRATEGY, PG_DEFAULT_PRESET_COLORS, PG_SPECTRUM_BRIGHTNESS_SHADE_STEP, PG_SPECTRUM_COLUMNS, PG_SPECTRUM_HUE_STEP_DEG, PG_SPECTRUM_ROWS, PG_SPECTRUM_SATURATION_STEP, PG_SPECTRUM_TINT_ROWS, PgColorChannelSliderComponent, PgColorFormatInputComponent, PgColorGradientSurfaceComponent, PgColorPickerComponent, PgColorPickerPanelComponent, PgColorSwatchGridComponent };
//# sourceMappingURL=pagalo-ui-color-picker.mjs.map
