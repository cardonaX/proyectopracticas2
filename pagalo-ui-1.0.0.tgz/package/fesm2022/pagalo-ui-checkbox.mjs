import * as i0 from '@angular/core';
import { input, signal, forwardRef, ChangeDetectionStrategy, Component, inject, ElementRef, Renderer2, effect, HostBinding, HostListener, Directive, NgModule } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { PgControlValueAccessorBase } from '@pagalo/ui/core';

class CheckboxComponent extends PgControlValueAccessorBase {
    layout = input('default');
    padding = input(true);
    label = input('');
    description = input('');
    forId = input('');
    /** Estado indeterminate del checkbox — manejado separadamente del value CVA. */
    indeterminate = signal(false);
    setIndeterminate(value) {
        this.indeterminate.set(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: CheckboxComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: CheckboxComponent, isStandalone: true, selector: "pg-checkbox", inputs: { layout: { classPropertyName: "layout", publicName: "layout", isSignal: true, isRequired: false, transformFunction: null }, padding: { classPropertyName: "padding", publicName: "padding", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, forId: { classPropertyName: "forId", publicName: "forId", isSignal: true, isRequired: false, transformFunction: null } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => CheckboxComponent),
                multi: true,
            },
        ], usesInheritance: true, ngImport: i0, template: "<ng-template #checkboxSlot>\n  <div class=\"group grid w-4 h-4 grid-cols-1\">\n    <ng-content select=\"input[pgCheckbox]\"></ng-content>\n    <svg\n      viewBox=\"0 0 14 14\"\n      fill=\"none\"\n      class=\"pointer-events-none col-start-1 row-start-1 w-3.5 h-3.5 self-center justify-self-center stroke-white group-has-[:disabled]:stroke-gray-950/25\"\n    >\n      <path\n        d=\"M3 8L6 11L11 3.5\"\n        stroke-width=\"2\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n        class=\"opacity-0 group-has-[:checked]:opacity-100\"\n      />\n      <path\n        d=\"M3 7H11\"\n        stroke-width=\"2\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n        class=\"opacity-0 group-has-[:indeterminate]:opacity-100\"\n      />\n    </svg>\n  </div>\n</ng-template>\n\n<div\n  class=\"relative flex gap-3\"\n  [class.py-4]=\"padding() && layout() !== 'checkbox-right'\"\n  [class.pb-4]=\"padding() && layout() === 'checkbox-right'\"\n  [class.pt-3.5]=\"padding() && layout() === 'checkbox-right'\"\n>\n  @if (layout() !== 'checkbox-right') {\n    <div class=\"flex h-6 shrink-0 items-center\">\n      <ng-container *ngTemplateOutlet=\"checkboxSlot\"></ng-container>\n    </div>\n  }\n\n  <div class=\"min-w-0 flex-1 text-sm/6\">\n    <label [for]=\"forId()\" class=\"font-medium text-gray-900\" [class.select-none]=\"true\">\n      {{ label() }}\n      <ng-content select=\"[pgCheckboxLabel]\"></ng-content>\n    </label>\n\n    @if (description()) {\n      @if (layout() === 'inline-description') {\n        <span [id]=\"forId() + '-description'\" class=\"text-gray-500\">\n          <span class=\"sr-only\">{{ label() }} </span>{{ description() }}\n        </span>\n      } @else {\n        <p [id]=\"forId() + '-description'\" class=\"text-gray-500\">{{ description() }}</p>\n      }\n    }\n    <ng-content select=\"[pgCheckboxDescription]\"></ng-content>\n  </div>\n\n  @if (layout() === 'checkbox-right') {\n    <div class=\"flex h-6 shrink-0 items-center\">\n      <ng-container *ngTemplateOutlet=\"checkboxSlot\"></ng-container>\n    </div>\n  }\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: CheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-checkbox', imports: [NgTemplateOutlet], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => CheckboxComponent),
                            multi: true,
                        },
                    ], template: "<ng-template #checkboxSlot>\n  <div class=\"group grid w-4 h-4 grid-cols-1\">\n    <ng-content select=\"input[pgCheckbox]\"></ng-content>\n    <svg\n      viewBox=\"0 0 14 14\"\n      fill=\"none\"\n      class=\"pointer-events-none col-start-1 row-start-1 w-3.5 h-3.5 self-center justify-self-center stroke-white group-has-[:disabled]:stroke-gray-950/25\"\n    >\n      <path\n        d=\"M3 8L6 11L11 3.5\"\n        stroke-width=\"2\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n        class=\"opacity-0 group-has-[:checked]:opacity-100\"\n      />\n      <path\n        d=\"M3 7H11\"\n        stroke-width=\"2\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n        class=\"opacity-0 group-has-[:indeterminate]:opacity-100\"\n      />\n    </svg>\n  </div>\n</ng-template>\n\n<div\n  class=\"relative flex gap-3\"\n  [class.py-4]=\"padding() && layout() !== 'checkbox-right'\"\n  [class.pb-4]=\"padding() && layout() === 'checkbox-right'\"\n  [class.pt-3.5]=\"padding() && layout() === 'checkbox-right'\"\n>\n  @if (layout() !== 'checkbox-right') {\n    <div class=\"flex h-6 shrink-0 items-center\">\n      <ng-container *ngTemplateOutlet=\"checkboxSlot\"></ng-container>\n    </div>\n  }\n\n  <div class=\"min-w-0 flex-1 text-sm/6\">\n    <label [for]=\"forId()\" class=\"font-medium text-gray-900\" [class.select-none]=\"true\">\n      {{ label() }}\n      <ng-content select=\"[pgCheckboxLabel]\"></ng-content>\n    </label>\n\n    @if (description()) {\n      @if (layout() === 'inline-description') {\n        <span [id]=\"forId() + '-description'\" class=\"text-gray-500\">\n          <span class=\"sr-only\">{{ label() }} </span>{{ description() }}\n        </span>\n      } @else {\n        <p [id]=\"forId() + '-description'\" class=\"text-gray-500\">{{ description() }}</p>\n      }\n    }\n    <ng-content select=\"[pgCheckboxDescription]\"></ng-content>\n  </div>\n\n  @if (layout() === 'checkbox-right') {\n    <div class=\"flex h-6 shrink-0 items-center\">\n      <ng-container *ngTemplateOutlet=\"checkboxSlot\"></ng-container>\n    </div>\n  }\n</div>\n" }]
        }] });

class CheckboxDirective {
    pgCheckbox = inject(CheckboxComponent, { optional: true });
    el = inject((ElementRef));
    renderer = inject(Renderer2);
    constructor() {
        if (this.pgCheckbox) {
            effect(() => {
                this.renderer.setProperty(this.el.nativeElement, 'checked', this.pgCheckbox.value() ?? false);
            });
            effect(() => {
                this.renderer.setProperty(this.el.nativeElement, 'disabled', this.pgCheckbox.disabled());
            });
            effect(() => {
                this.el.nativeElement.indeterminate = this.pgCheckbox.indeterminate();
            });
        }
    }
    onChange(checked) {
        this.pgCheckbox?.setValue(checked);
        this.pgCheckbox?.setIndeterminate(false);
    }
    onBlur() {
        this.pgCheckbox?.markAsTouched();
    }
    get hostClasses() {
        return 'col-start-1 row-start-1 appearance-none rounded border border-gray-300 bg-white checked:border-primary checked:bg-primary indeterminate:border-primary indeterminate:bg-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary disabled:border-gray-300 disabled:bg-gray-100 disabled:checked:bg-gray-100 forced-colors:appearance-auto';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: CheckboxDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: CheckboxDirective, isStandalone: true, selector: "input[pgCheckbox]", host: { listeners: { "change": "onChange($event.target.checked)", "blur": "onBlur()" }, properties: { "class": "this.hostClasses" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: CheckboxDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input[pgCheckbox]',
                    standalone: true,
                }]
        }], ctorParameters: () => [], propDecorators: { onChange: [{
                type: HostListener,
                args: ['change', ['$event.target.checked']]
            }], onBlur: [{
                type: HostListener,
                args: ['blur']
            }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }] } });
class CheckboxLabelDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: CheckboxLabelDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: CheckboxLabelDirective, isStandalone: true, selector: "[pgCheckboxLabel]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: CheckboxLabelDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pgCheckboxLabel]',
                    standalone: true,
                }]
        }] });
class CheckboxDescriptionDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: CheckboxDescriptionDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: CheckboxDescriptionDirective, isStandalone: true, selector: "[pgCheckboxDescription]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: CheckboxDescriptionDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pgCheckboxDescription]',
                    standalone: true,
                }]
        }] });

class PgCheckboxModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgCheckboxModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.21", ngImport: i0, type: PgCheckboxModule, imports: [CheckboxComponent,
            CheckboxDirective], exports: [CheckboxComponent,
            CheckboxDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgCheckboxModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgCheckboxModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CheckboxComponent,
                        CheckboxDirective
                    ],
                    exports: [
                        CheckboxComponent,
                        CheckboxDirective
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { CheckboxComponent, CheckboxDescriptionDirective, CheckboxDirective, CheckboxLabelDirective, PgCheckboxModule };
//# sourceMappingURL=pagalo-ui-checkbox.mjs.map
