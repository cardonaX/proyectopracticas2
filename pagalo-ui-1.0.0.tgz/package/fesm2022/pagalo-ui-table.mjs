import * as i0 from '@angular/core';
import { input, output, signal, computed, ContentChild, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

class TableComponent {
    variant = input('simple');
    columns = input([]);
    rows = input([]);
    title = input('');
    description = input('');
    selectable = input(false);
    loading = input(false);
    showEmptyState = input(false);
    trackBy = input((item) => item);
    selectionChange = output();
    sortChange = output();
    headerActions;
    tableActions;
    actionDef;
    emptyStateTemplate;
    selectedItems = signal(new Set());
    sortState = signal(null);
    sortedRows = computed(() => {
        const state = this.sortState();
        const rows = this.rows();
        if (!state)
            return rows;
        const copy = [...rows]; // avoid mutating the input-bound array
        copy.sort((a, b) => {
            const av = a[state.key];
            const bv = b[state.key];
            const cmp = av == null
                ? -1
                : bv == null
                    ? 1
                    : typeof av === 'number' && typeof bv === 'number'
                        ? av - bv
                        : String(av).localeCompare(String(bv));
            return state.direction === 'asc' ? cmp : -cmp;
        });
        return copy;
    });
    totalColSpan = computed(() => this.columns().length + (this.selectable() ? 1 : 0) + (this.actionDef ? 1 : 0));
    allChecked = computed(() => {
        const r = this.rows();
        return r.length > 0 && this.selectedItems().size === r.length;
    });
    someChecked = computed(() => {
        return this.selectedItems().size > 0 && !this.allChecked();
    });
    toggleAll(event) {
        const checked = event.target.checked;
        if (checked) {
            this.selectedItems.set(new Set(this.rows().map(r => this.trackBy()(r))));
        }
        else {
            this.selectedItems.set(new Set());
        }
        this.emitSelection();
    }
    toggleRow(item, event) {
        const checked = event.target.checked;
        const key = this.trackBy()(item);
        this.selectedItems.update(set => {
            const newSet = new Set(set);
            if (checked) {
                newSet.add(key);
            }
            else {
                newSet.delete(key);
            }
            return newSet;
        });
        this.emitSelection();
    }
    emitSelection() {
        const keys = this.selectedItems();
        const selected = this.rows().filter(r => keys.has(this.trackBy()(r)));
        this.selectionChange.emit(selected);
    }
    toggleSort(col) {
        if (!col.sortable)
            return;
        const current = this.sortState();
        if (!current || current.key !== col.key) {
            const next = { key: col.key, direction: 'asc' };
            this.sortState.set(next);
            this.sortChange.emit(next);
            return;
        }
        if (current.direction === 'asc') {
            const next = { key: col.key, direction: 'desc' };
            this.sortState.set(next);
            this.sortChange.emit(next);
            return;
        }
        // desc -> none: reset internal sort state but do NOT emit sortChange.
        // The output type is strictly `{ key; direction: 'asc' | 'desc' }` — it has
        // no representation for "unsorted", so emitting a fabricated value here
        // would be a type lie. Consumers who need "sort cleared" should read
        // sortState()/sortedRows() directly.
        this.sortState.set(null);
    }
    ariaSortFor(col) {
        const state = this.sortState();
        if (!col.sortable || !state || state.key !== col.key)
            return 'none';
        return state.direction === 'asc' ? 'ascending' : 'descending';
    }
    isConstrained = computed(() => this.variant() === 'full-width-constrained');
    outerContainerClass = computed(() => {
        if (this.isConstrained())
            return '';
        return 'px-4 sm:px-6 lg:px-8';
    });
    headerContainerClass = computed(() => {
        if (this.isConstrained())
            return 'mx-auto max-w-7xl px-4 sm:px-6 lg:px-8';
        return '';
    });
    flowRootClass = computed(() => {
        let classes = 'mt-8 flow-root';
        if (this.isConstrained())
            classes += ' overflow-hidden';
        if (this.variant() === 'border')
            return 'mt-10';
        return classes;
    });
    overflowWrapperClass = computed(() => {
        if (this.isConstrained())
            return 'mx-auto max-w-7xl px-4 sm:px-6 lg:px-8';
        if (this.variant() === 'border')
            return '-mx-4 ring-1 ring-gray-300 sm:mx-0 sm:rounded-lg';
        if (this.variant() === 'sticky-header')
            return '-mx-4 -my-2 sm:-mx-6 lg:-mx-8';
        return '-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8';
    });
    inlineBlockClass = computed(() => {
        const v = this.variant();
        if (this.isConstrained() || v === 'border')
            return '';
        let classes = 'inline-block min-w-full py-2 align-middle';
        if (v === 'simple' || v === 'simple-in-card' || v === 'vertical-lines' || this.selectable()) {
            classes += ' sm:px-6 lg:px-8';
        }
        return classes;
    });
    cardWrapperClass = computed(() => {
        if (this.variant() === 'simple-in-card') {
            return 'overflow-hidden shadow outline outline-1 outline-black/5 sm:rounded-lg';
        }
        return '';
    });
    tableClass = computed(() => {
        if (this.isConstrained())
            return 'w-full text-left';
        if (this.variant() === 'sticky-header')
            return 'min-w-full border-separate border-spacing-0';
        let classes = 'relative min-w-full divide-y divide-gray-300';
        if (this.selectable())
            classes += ' table-fixed';
        return classes;
    });
    theadClass = computed(() => {
        const v = this.variant();
        if (v === 'simple-in-card' || this.isConstrained())
            return 'bg-gray-50';
        if (this.isConstrained() || v === 'border')
            return 'bg-white';
        return '';
    });
    actualTheadClass = computed(() => {
        if (this.variant() === 'simple-in-card')
            return 'bg-gray-50';
        if (this.isConstrained())
            return 'bg-white';
        return '';
    });
    theadTrClass = computed(() => {
        if (this.variant() === 'vertical-lines')
            return 'divide-x divide-gray-200';
        return '';
    });
    tbodyClass = computed(() => {
        if (this.variant() === 'sticky-header')
            return '';
        let classes = 'divide-y divide-gray-200';
        if (this.variant() !== 'simple')
            classes += ' bg-white';
        return classes;
    });
    tbodyTrClass = computed(() => {
        if (this.variant() === 'vertical-lines')
            return 'divide-x divide-gray-200';
        if (this.selectable())
            return 'group has-[:checked]:bg-gray-50';
        return '';
    });
    getThClass(colIndex, col) {
        let classes = col.headerClass || '';
        if (!classes) {
            if (this.variant() === 'sticky-header') {
                classes = `sticky top-0 z-10 border-b border-gray-300 bg-white/75 py-3.5 text-left text-sm font-semibold text-gray-900 backdrop-blur backdrop-filter`;
                if (colIndex === 0)
                    classes += ' pl-4 pr-3 sm:pl-6 lg:pl-8';
                else
                    classes += ' px-3';
            }
            else if (this.isConstrained()) {
                classes = `py-3.5 text-left text-sm font-semibold text-gray-900`;
                if (colIndex === 0)
                    classes += ' relative isolate pr-3';
                else
                    classes += ' px-3';
            }
            else if (this.variant() === 'vertical-lines') {
                classes = `py-3.5 text-left text-sm font-semibold text-gray-900`;
                if (colIndex === 0)
                    classes += ' pl-4 pr-4 sm:pl-0';
                else
                    classes += ' px-4';
            }
            else {
                classes = `py-3.5 text-left text-sm font-semibold text-gray-900`;
                if (colIndex === 0) {
                    classes += ' pr-3';
                    if (this.selectable()) {
                        classes += ' pl-3 sm:pl-4';
                    }
                    else {
                        classes += ' pl-4';
                        if (this.variant() === 'simple-in-card' || this.variant() === 'border')
                            classes += ' sm:pl-6';
                        else if (this.variant() === 'full-width')
                            classes += ' sm:pl-6 lg:pl-8';
                        else
                            classes += ' sm:pl-0';
                    }
                }
                else {
                    classes += ' px-3';
                }
            }
        }
        return classes;
    }
    getTdClass(colIndex, col, item) {
        let classes = '';
        if (typeof col.cellClass === 'function') {
            classes = col.cellClass(item);
        }
        else if (col.cellClass) {
            classes = col.cellClass;
        }
        if (!classes) {
            if (this.variant() === 'sticky-header') {
                classes = 'whitespace-nowrap border-b border-gray-200 py-4 text-sm text-gray-500';
                if (colIndex === 0)
                    classes =
                        classes.replace('text-gray-500', 'font-medium text-gray-900') +
                            ' pl-4 pr-3 sm:pl-6 lg:pl-8';
                else
                    classes += ' px-3';
            }
            else if (this.isConstrained()) {
                classes = 'py-4 text-sm text-gray-500';
                if (colIndex === 0)
                    classes =
                        classes.replace('text-gray-500', 'font-medium text-gray-900') + ' relative pr-3';
                else
                    classes += ' px-3';
            }
            else if (this.variant() === 'border') {
                classes = 'border-t border-gray-200 py-4 text-sm text-gray-500';
                if (colIndex === 0)
                    classes =
                        classes.replace('border-t border-gray-200 text-gray-500', 'relative border-t border-transparent font-medium text-gray-900') + ' pl-4 pr-3 sm:pl-6';
                else
                    classes += ' px-3';
            }
            else if (this.variant() === 'vertical-lines') {
                classes = 'whitespace-nowrap py-4 text-sm text-gray-500';
                if (colIndex === 0)
                    classes =
                        classes.replace('py-4 text-gray-500', 'py-4 font-medium text-gray-900') +
                            ' pl-4 pr-4 sm:pl-0';
                else
                    classes = classes.replace('py-4', 'p-4') + ' px-4';
            }
            else {
                classes = 'whitespace-nowrap py-4 text-sm text-gray-500';
                if (this.selectable())
                    classes = classes.replace('text-gray-500', 'text-gray-500 group-has-[:checked]:text-primary');
                if (colIndex === 0) {
                    classes = classes.replace('text-gray-500', 'font-medium text-gray-900') + ' pr-3';
                    if (this.selectable()) {
                        classes += ' pl-3 sm:pl-4';
                    }
                    else {
                        classes += ' pl-4';
                        if (this.variant() === 'simple-in-card')
                            classes += ' sm:pl-6';
                        else if (this.variant() === 'full-width')
                            classes += ' sm:pl-6 lg:pl-8';
                        else
                            classes += ' sm:pl-0';
                    }
                }
                else {
                    classes += ' px-3';
                }
            }
        }
        return classes;
    }
    actionThClass = computed(() => {
        let base = 'relative py-3.5 pl-3 pr-4 sm:pr-6';
        if (this.variant() === 'sticky-header')
            return base + ' border-b border-gray-300 bg-white/75 backdrop-blur backdrop-filter lg:pr-8';
        if (this.variant() === 'full-width')
            return base + ' lg:pr-8';
        return base;
    });
    actionTdClass = computed(() => {
        let base = 'relative whitespace-nowrap py-4 pl-3 pr-4 sm:pr-6 text-right text-sm font-medium';
        if (this.variant() === 'sticky-header')
            return base + ' border-b border-gray-200 lg:pr-8';
        if (this.variant() === 'border')
            return base + ' border-t border-transparent';
        if (this.variant() === 'full-width')
            return base + ' lg:pr-8';
        return base;
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: TableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: TableComponent, isStandalone: true, selector: "pg-table", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: false, transformFunction: null }, rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, selectable: { classPropertyName: "selectable", publicName: "selectable", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, showEmptyState: { classPropertyName: "showEmptyState", publicName: "showEmptyState", isSignal: true, isRequired: false, transformFunction: null }, trackBy: { classPropertyName: "trackBy", publicName: "trackBy", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectionChange: "selectionChange", sortChange: "sortChange" }, queries: [{ propertyName: "headerActions", first: true, predicate: ["headerActions"], descendants: true }, { propertyName: "tableActions", first: true, predicate: ["tableActions"], descendants: true }, { propertyName: "actionDef", first: true, predicate: ["actionDef"], descendants: true }, { propertyName: "emptyStateTemplate", first: true, predicate: ["emptyState"], descendants: true }], ngImport: i0, template: "<div [ngClass]=\"outerContainerClass()\">\n  @if (title() || description() || headerActions) {\n    <div\n      class=\"sm:flex sm:items-center\"\n      [ngClass]=\"headerContainerClass()\"\n      >\n      <div class=\"sm:flex-auto\">\n        @if (title()) {\n          <h1 class=\"text-base font-semibold text-gray-900\">{{ title() }}</h1>\n        }\n        @if (description()) {\n          <p class=\"mt-2 text-sm text-gray-700\" [innerHTML]=\"description()\"></p>\n        }\n      </div>\n      @if (headerActions) {\n        <div class=\"mt-4 sm:ml-16 sm:mt-0 sm:flex-none\">\n          <ng-container [ngTemplateOutlet]=\"headerActions\"></ng-container>\n        </div>\n      }\n    </div>\n  }\n  <div [ngClass]=\"flowRootClass()\">\n    <div [ngClass]=\"overflowWrapperClass()\">\n      <div [ngClass]=\"inlineBlockClass()\">\n        @if (selectable() && someChecked()) {\n          <div class=\"group/table relative\">\n            <div\n              class=\"absolute left-14 top-0 z-10 hidden h-12 items-center space-x-3 bg-white group-has-[:checked]/table:flex sm:left-12\"\n              >\n              @if (tableActions) {\n                <ng-container\n                  [ngTemplateOutlet]=\"tableActions\"\n                  [ngTemplateOutletContext]=\"{ $implicit: selectedItems }\"\n                ></ng-container>\n              } @else {\n                <span class=\"text-sm font-semibold text-gray-700\"\n                  >{{ selectedItems().size }} selected</span\n                  >\n                }\n              </div>\n            </div>\n          }\n\n          <div [ngClass]=\"cardWrapperClass()\">\n            <table [ngClass]=\"tableClass()\">\n              <thead [ngClass]=\"theadClass()\">\n                <tr [ngClass]=\"theadTrClass()\">\n                  @if (selectable()) {\n                    <th scope=\"col\" class=\"relative px-7 sm:w-12 sm:px-6\">\n                      <div class=\"group absolute left-4 top-1/2 -mt-2 grid size-4 grid-cols-1\">\n                        <input\n                          type=\"checkbox\"\n                          [checked]=\"allChecked()\"\n                          [indeterminate]=\"someChecked() && !allChecked()\"\n                          (change)=\"toggleAll($event)\"\n                          class=\"col-start-1 row-start-1 appearance-none rounded border border-gray-300 bg-white checked:border-primary checked:bg-primary indeterminate:border-primary indeterminate:bg-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary disabled:border-gray-300 disabled:bg-gray-100 disabled:checked:bg-gray-100 forced-colors:appearance-auto\"\n                          />\n                        <svg\n                          viewBox=\"0 0 14 14\"\n                          fill=\"none\"\n                          class=\"pointer-events-none col-start-1 row-start-1 size-3.5 self-center justify-self-center stroke-white group-has-[:disabled]:stroke-gray-950/25\"\n                          >\n                          <path\n                            d=\"M3 8L6 11L11 3.5\"\n                            stroke-width=\"2\"\n                            stroke-linecap=\"round\"\n                            stroke-linejoin=\"round\"\n                            class=\"opacity-0 group-has-[:checked]:opacity-100\"\n                          ></path>\n                          <path\n                            d=\"M3 7H11\"\n                            stroke-width=\"2\"\n                            stroke-linecap=\"round\"\n                            stroke-linejoin=\"round\"\n                            class=\"opacity-0 group-has-[:indeterminate]:opacity-100\"\n                          ></path>\n                        </svg>\n                      </div>\n                    </th>\n                  }\n\n                  @for (col of columns(); track col; let i = $index) {\n                    <th\n                      scope=\"col\"\n                      [ngClass]=\"getThClass(i, col)\"\n                      [attr.aria-sort]=\"col.sortable ? ariaSortFor(col) : null\"\n                      [class.cursor-pointer]=\"col.sortable\"\n                      [class.select-none]=\"col.sortable\"\n                      (click)=\"toggleSort(col)\"\n                      >\n                      <span class=\"inline-flex items-center gap-1\">\n                        {{ col.label }}\n                        @if (col.sortable) {\n                          <svg viewBox=\"0 0 14 14\" fill=\"none\" class=\"size-3.5 shrink-0 stroke-gray-400\">\n                            @if (ariaSortFor(col) === 'ascending') {\n                              <path\n                                d=\"M3 8L7 4L11 8\"\n                                stroke-width=\"1.5\"\n                                stroke-linecap=\"round\"\n                                stroke-linejoin=\"round\"\n                                class=\"stroke-gray-700\"\n                              ></path>\n                            } @else if (ariaSortFor(col) === 'descending') {\n                              <path\n                                d=\"M3 6L7 10L11 6\"\n                                stroke-width=\"1.5\"\n                                stroke-linecap=\"round\"\n                                stroke-linejoin=\"round\"\n                                class=\"stroke-gray-700\"\n                              ></path>\n                            } @else {\n                              <path d=\"M3 5L7 2L11 5\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path>\n                              <path d=\"M3 9L7 12L11 9\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path>\n                            }\n                          </svg>\n                        }\n                      </span>\n                      @if (isConstrained() && i === 0) {\n                        <div\n                          class=\"absolute inset-y-0 right-full -z-10 w-screen border-b border-b-gray-200\"\n                        ></div>\n                        <div\n                          class=\"absolute inset-y-0 left-0 -z-10 w-screen border-b border-b-gray-200\"\n                        ></div>\n                      }\n                    </th>\n                  }\n\n                  @if (actionDef) {\n                    <th scope=\"col\" [ngClass]=\"actionThClass()\">\n                      <span class=\"sr-only\">Actions</span>\n                    </th>\n                  }\n                </tr>\n              </thead>\n              <tbody [ngClass]=\"tbodyClass()\">\n                @if (loading()) {\n                  <tr>\n                    <td [attr.colspan]=\"totalColSpan()\" class=\"p-4\">\n                      <div class=\"animate-pulse space-y-3\" role=\"status\" aria-label=\"Loading\">\n                        <div class=\"h-4 rounded bg-gray-200\"></div>\n                        <div class=\"h-4 rounded bg-gray-200\"></div>\n                        <div class=\"h-4 w-2/3 rounded bg-gray-200\"></div>\n                      </div>\n                    </td>\n                  </tr>\n                } @else if (showEmptyState() && sortedRows().length === 0) {\n                  <tr>\n                    <td [attr.colspan]=\"totalColSpan()\" class=\"py-10 text-center\">\n                      @if (emptyStateTemplate) {\n                        <ng-container [ngTemplateOutlet]=\"emptyStateTemplate\"></ng-container>\n                      } @else {\n                        <p class=\"text-sm text-gray-500\">No data available.</p>\n                      }\n                    </td>\n                  </tr>\n                } @else {\n                  @for (item of sortedRows(); track trackBy()(item)) {\n                    <tr [ngClass]=\"tbodyTrClass()\">\n                      @if (selectable()) {\n                        <td class=\"relative px-7 sm:w-12 sm:px-6\">\n                          @if (selectedItems().has(trackBy()(item))) {\n                            <div\n                              class=\"absolute inset-y-0 left-0 w-0.5 bg-primary block\"\n                            ></div>\n                          }\n                          <div class=\"group absolute left-4 top-1/2 -mt-2 grid size-4 grid-cols-1\">\n                            <input\n                              type=\"checkbox\"\n                              [checked]=\"selectedItems().has(trackBy()(item))\"\n                              (change)=\"toggleRow(item, $event)\"\n                              class=\"col-start-1 row-start-1 appearance-none rounded border border-gray-300 bg-white checked:border-primary checked:bg-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary disabled:border-gray-300 disabled:bg-gray-100 disabled:checked:bg-gray-100 forced-colors:appearance-auto\"\n                              />\n                            <svg\n                              viewBox=\"0 0 14 14\"\n                              fill=\"none\"\n                              class=\"pointer-events-none col-start-1 row-start-1 size-3.5 self-center justify-self-center stroke-white group-has-[:disabled]:stroke-gray-950/25\"\n                              >\n                              <path\n                                d=\"M3 8L6 11L11 3.5\"\n                                stroke-width=\"2\"\n                                stroke-linecap=\"round\"\n                                stroke-linejoin=\"round\"\n                                class=\"opacity-0 group-has-[:checked]:opacity-100\"\n                              ></path>\n                            </svg>\n                          </div>\n                        </td>\n                      }\n                      @for (col of columns(); track col; let i = $index) {\n                        <td [ngClass]=\"getTdClass(i, col, item)\">\n                          {{ col.format ? col.format(item[col.key], item) : item[col.key] }}\n                          @if (isConstrained() && i === 0) {\n                            <div class=\"absolute bottom-0 right-full h-px w-screen bg-gray-100\"></div>\n                            <div class=\"absolute bottom-0 left-0 h-px w-screen bg-gray-100\"></div>\n                          }\n                          @if (variant() === 'border' && i === 0) {\n                            <div class=\"absolute -top-px left-6 right-0 h-px bg-gray-200\"></div>\n                          }\n                        </td>\n                      }\n                      @if (actionDef) {\n                        <td [ngClass]=\"actionTdClass()\">\n                          <ng-container\n                            [ngTemplateOutlet]=\"actionDef\"\n                            [ngTemplateOutletContext]=\"{ $implicit: item }\"\n                          ></ng-container>\n                          @if (variant() === 'border') {\n                            <div class=\"absolute -top-px left-0 right-6 h-px bg-gray-200\"></div>\n                          }\n                        </td>\n                      }\n                    </tr>\n                  }\n                }\n              </tbody>\n            </table>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: TableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-table', imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div [ngClass]=\"outerContainerClass()\">\n  @if (title() || description() || headerActions) {\n    <div\n      class=\"sm:flex sm:items-center\"\n      [ngClass]=\"headerContainerClass()\"\n      >\n      <div class=\"sm:flex-auto\">\n        @if (title()) {\n          <h1 class=\"text-base font-semibold text-gray-900\">{{ title() }}</h1>\n        }\n        @if (description()) {\n          <p class=\"mt-2 text-sm text-gray-700\" [innerHTML]=\"description()\"></p>\n        }\n      </div>\n      @if (headerActions) {\n        <div class=\"mt-4 sm:ml-16 sm:mt-0 sm:flex-none\">\n          <ng-container [ngTemplateOutlet]=\"headerActions\"></ng-container>\n        </div>\n      }\n    </div>\n  }\n  <div [ngClass]=\"flowRootClass()\">\n    <div [ngClass]=\"overflowWrapperClass()\">\n      <div [ngClass]=\"inlineBlockClass()\">\n        @if (selectable() && someChecked()) {\n          <div class=\"group/table relative\">\n            <div\n              class=\"absolute left-14 top-0 z-10 hidden h-12 items-center space-x-3 bg-white group-has-[:checked]/table:flex sm:left-12\"\n              >\n              @if (tableActions) {\n                <ng-container\n                  [ngTemplateOutlet]=\"tableActions\"\n                  [ngTemplateOutletContext]=\"{ $implicit: selectedItems }\"\n                ></ng-container>\n              } @else {\n                <span class=\"text-sm font-semibold text-gray-700\"\n                  >{{ selectedItems().size }} selected</span\n                  >\n                }\n              </div>\n            </div>\n          }\n\n          <div [ngClass]=\"cardWrapperClass()\">\n            <table [ngClass]=\"tableClass()\">\n              <thead [ngClass]=\"theadClass()\">\n                <tr [ngClass]=\"theadTrClass()\">\n                  @if (selectable()) {\n                    <th scope=\"col\" class=\"relative px-7 sm:w-12 sm:px-6\">\n                      <div class=\"group absolute left-4 top-1/2 -mt-2 grid size-4 grid-cols-1\">\n                        <input\n                          type=\"checkbox\"\n                          [checked]=\"allChecked()\"\n                          [indeterminate]=\"someChecked() && !allChecked()\"\n                          (change)=\"toggleAll($event)\"\n                          class=\"col-start-1 row-start-1 appearance-none rounded border border-gray-300 bg-white checked:border-primary checked:bg-primary indeterminate:border-primary indeterminate:bg-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary disabled:border-gray-300 disabled:bg-gray-100 disabled:checked:bg-gray-100 forced-colors:appearance-auto\"\n                          />\n                        <svg\n                          viewBox=\"0 0 14 14\"\n                          fill=\"none\"\n                          class=\"pointer-events-none col-start-1 row-start-1 size-3.5 self-center justify-self-center stroke-white group-has-[:disabled]:stroke-gray-950/25\"\n                          >\n                          <path\n                            d=\"M3 8L6 11L11 3.5\"\n                            stroke-width=\"2\"\n                            stroke-linecap=\"round\"\n                            stroke-linejoin=\"round\"\n                            class=\"opacity-0 group-has-[:checked]:opacity-100\"\n                          ></path>\n                          <path\n                            d=\"M3 7H11\"\n                            stroke-width=\"2\"\n                            stroke-linecap=\"round\"\n                            stroke-linejoin=\"round\"\n                            class=\"opacity-0 group-has-[:indeterminate]:opacity-100\"\n                          ></path>\n                        </svg>\n                      </div>\n                    </th>\n                  }\n\n                  @for (col of columns(); track col; let i = $index) {\n                    <th\n                      scope=\"col\"\n                      [ngClass]=\"getThClass(i, col)\"\n                      [attr.aria-sort]=\"col.sortable ? ariaSortFor(col) : null\"\n                      [class.cursor-pointer]=\"col.sortable\"\n                      [class.select-none]=\"col.sortable\"\n                      (click)=\"toggleSort(col)\"\n                      >\n                      <span class=\"inline-flex items-center gap-1\">\n                        {{ col.label }}\n                        @if (col.sortable) {\n                          <svg viewBox=\"0 0 14 14\" fill=\"none\" class=\"size-3.5 shrink-0 stroke-gray-400\">\n                            @if (ariaSortFor(col) === 'ascending') {\n                              <path\n                                d=\"M3 8L7 4L11 8\"\n                                stroke-width=\"1.5\"\n                                stroke-linecap=\"round\"\n                                stroke-linejoin=\"round\"\n                                class=\"stroke-gray-700\"\n                              ></path>\n                            } @else if (ariaSortFor(col) === 'descending') {\n                              <path\n                                d=\"M3 6L7 10L11 6\"\n                                stroke-width=\"1.5\"\n                                stroke-linecap=\"round\"\n                                stroke-linejoin=\"round\"\n                                class=\"stroke-gray-700\"\n                              ></path>\n                            } @else {\n                              <path d=\"M3 5L7 2L11 5\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path>\n                              <path d=\"M3 9L7 12L11 9\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path>\n                            }\n                          </svg>\n                        }\n                      </span>\n                      @if (isConstrained() && i === 0) {\n                        <div\n                          class=\"absolute inset-y-0 right-full -z-10 w-screen border-b border-b-gray-200\"\n                        ></div>\n                        <div\n                          class=\"absolute inset-y-0 left-0 -z-10 w-screen border-b border-b-gray-200\"\n                        ></div>\n                      }\n                    </th>\n                  }\n\n                  @if (actionDef) {\n                    <th scope=\"col\" [ngClass]=\"actionThClass()\">\n                      <span class=\"sr-only\">Actions</span>\n                    </th>\n                  }\n                </tr>\n              </thead>\n              <tbody [ngClass]=\"tbodyClass()\">\n                @if (loading()) {\n                  <tr>\n                    <td [attr.colspan]=\"totalColSpan()\" class=\"p-4\">\n                      <div class=\"animate-pulse space-y-3\" role=\"status\" aria-label=\"Loading\">\n                        <div class=\"h-4 rounded bg-gray-200\"></div>\n                        <div class=\"h-4 rounded bg-gray-200\"></div>\n                        <div class=\"h-4 w-2/3 rounded bg-gray-200\"></div>\n                      </div>\n                    </td>\n                  </tr>\n                } @else if (showEmptyState() && sortedRows().length === 0) {\n                  <tr>\n                    <td [attr.colspan]=\"totalColSpan()\" class=\"py-10 text-center\">\n                      @if (emptyStateTemplate) {\n                        <ng-container [ngTemplateOutlet]=\"emptyStateTemplate\"></ng-container>\n                      } @else {\n                        <p class=\"text-sm text-gray-500\">No data available.</p>\n                      }\n                    </td>\n                  </tr>\n                } @else {\n                  @for (item of sortedRows(); track trackBy()(item)) {\n                    <tr [ngClass]=\"tbodyTrClass()\">\n                      @if (selectable()) {\n                        <td class=\"relative px-7 sm:w-12 sm:px-6\">\n                          @if (selectedItems().has(trackBy()(item))) {\n                            <div\n                              class=\"absolute inset-y-0 left-0 w-0.5 bg-primary block\"\n                            ></div>\n                          }\n                          <div class=\"group absolute left-4 top-1/2 -mt-2 grid size-4 grid-cols-1\">\n                            <input\n                              type=\"checkbox\"\n                              [checked]=\"selectedItems().has(trackBy()(item))\"\n                              (change)=\"toggleRow(item, $event)\"\n                              class=\"col-start-1 row-start-1 appearance-none rounded border border-gray-300 bg-white checked:border-primary checked:bg-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary disabled:border-gray-300 disabled:bg-gray-100 disabled:checked:bg-gray-100 forced-colors:appearance-auto\"\n                              />\n                            <svg\n                              viewBox=\"0 0 14 14\"\n                              fill=\"none\"\n                              class=\"pointer-events-none col-start-1 row-start-1 size-3.5 self-center justify-self-center stroke-white group-has-[:disabled]:stroke-gray-950/25\"\n                              >\n                              <path\n                                d=\"M3 8L6 11L11 3.5\"\n                                stroke-width=\"2\"\n                                stroke-linecap=\"round\"\n                                stroke-linejoin=\"round\"\n                                class=\"opacity-0 group-has-[:checked]:opacity-100\"\n                              ></path>\n                            </svg>\n                          </div>\n                        </td>\n                      }\n                      @for (col of columns(); track col; let i = $index) {\n                        <td [ngClass]=\"getTdClass(i, col, item)\">\n                          {{ col.format ? col.format(item[col.key], item) : item[col.key] }}\n                          @if (isConstrained() && i === 0) {\n                            <div class=\"absolute bottom-0 right-full h-px w-screen bg-gray-100\"></div>\n                            <div class=\"absolute bottom-0 left-0 h-px w-screen bg-gray-100\"></div>\n                          }\n                          @if (variant() === 'border' && i === 0) {\n                            <div class=\"absolute -top-px left-6 right-0 h-px bg-gray-200\"></div>\n                          }\n                        </td>\n                      }\n                      @if (actionDef) {\n                        <td [ngClass]=\"actionTdClass()\">\n                          <ng-container\n                            [ngTemplateOutlet]=\"actionDef\"\n                            [ngTemplateOutletContext]=\"{ $implicit: item }\"\n                          ></ng-container>\n                          @if (variant() === 'border') {\n                            <div class=\"absolute -top-px left-0 right-6 h-px bg-gray-200\"></div>\n                          }\n                        </td>\n                      }\n                    </tr>\n                  }\n                }\n              </tbody>\n            </table>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n" }]
        }], propDecorators: { headerActions: [{
                type: ContentChild,
                args: ['headerActions']
            }], tableActions: [{
                type: ContentChild,
                args: ['tableActions']
            }], actionDef: [{
                type: ContentChild,
                args: ['actionDef']
            }], emptyStateTemplate: [{
                type: ContentChild,
                args: ['emptyState']
            }] } });

class PgTableModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgTableModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.21", ngImport: i0, type: PgTableModule, imports: [TableComponent], exports: [TableComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgTableModule, imports: [TableComponent] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgTableModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        TableComponent
                    ],
                    exports: [
                        TableComponent
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { PgTableModule, TableComponent };
//# sourceMappingURL=pagalo-ui-table.mjs.map
