import * as i0 from '@angular/core';
import { Pipe, EventEmitter, inject, signal, effect, Output, Input, Component, NgModule } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { NgClass } from '@angular/common';
import { Router, NavigationEnd } from '@angular/router';
import { filter, map } from 'rxjs/operators';
import { PgLinkDirective } from '@pagalo/ui/core';
import * as i1 from '@angular/platform-browser';

class SafeHtmlPipe {
    sanitizer;
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
    }
    /**
     * ⚠️ XSS WARNING: bypasses Angular's built-in sanitization.
     * Only use with content you fully control. Never use with user-generated input.
     */
    transform(value) {
        if (!value)
            return '';
        return this.sanitizer.bypassSecurityTrustHtml(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: SafeHtmlPipe, deps: [{ token: i1.DomSanitizer }], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.21", ngImport: i0, type: SafeHtmlPipe, isStandalone: true, name: "safeHtml" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: SafeHtmlPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'safeHtml',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i1.DomSanitizer }] });

class SidebarComponent {
    variant = 'light';
    logoUrl;
    navigation = [];
    teams = [];
    userProfile;
    hasSecondaryNavigation = true;
    teamsLabel = 'Your teams';
    navClick = new EventEmitter();
    teamClick = new EventEmitter();
    profileClick = new EventEmitter();
    router = inject(Router, { optional: true });
    /**
     * Reactive snapshot of the current router URL, used to derive `current`
     * for items that don't set it explicitly. Falls back to a static `null`
     * signal when no Router is available (e.g. the library used outside a
     * routed app) -- in that case every path comparison simply never matches.
     */
    _currentUrl = this.router
        ? toSignal(this.router.events.pipe(filter((event) => event instanceof NavigationEnd), map(() => this.router.url)), { initialValue: this.router.url })
        : signal(null);
    _expandedIds = signal(new Set());
    /**
     * Ids ever auto-seeded into `_expandedIds`, either because `item.expanded
     * === true` or because a descendant matched the router-current URL. This
     * is intentionally plain bookkeeping (not a signal) rather than render
     * state.
     *
     * Tradeoff (see plan's "seed once" rule): seeding an id happens at most
     * once, ever. If a consumer manually closes a submenu that was
     * auto-opened, and later passes a *new* `navigation` array reference (or
     * the router re-derives the same descendant match) where that same item
     * is still flagged, we do NOT reopen it -- the manual close wins from
     * that point on. The alternative (re-seed every time the flag/condition
     * is present) would make it impossible for a consumer to ever keep a
     * flagged submenu closed, fighting the user's toggle on every subsequent
     * `navigation` reassignment or route change. See
     * sidebar.component.spec.ts for the behavior this locks in.
     */
    _autoSeededIds = new Set();
    constructor() {
        // Router URL changes (without a new `navigation` reference) should still
        // auto-expand a parent whose descendant just became router-current.
        effect(() => {
            this._currentUrl();
            this._seedAutoExpand(this._idsWithCurrentDescendant());
        });
    }
    ngOnChanges(changes) {
        if (changes['navigation']) {
            const ids = new Set();
            for (const item of this.navigation) {
                if (item.expanded === true) {
                    ids.add(item.id ?? item.name);
                }
            }
            for (const id of this._idsWithCurrentDescendant()) {
                ids.add(id);
            }
            this._seedAutoExpand(ids);
        }
    }
    _idsWithCurrentDescendant() {
        const ids = [];
        for (const item of this.navigation) {
            if (item.children && this._hasCurrentDescendant(item)) {
                ids.push(item.id ?? item.name);
            }
        }
        return ids;
    }
    _hasCurrentDescendant(item) {
        if (!item.children)
            return false;
        const url = this._currentUrl();
        for (const child of item.children) {
            if (child.path && child.path === url)
                return true;
            if (child.children && this._hasCurrentDescendant(child))
                return true;
        }
        return false;
    }
    _seedAutoExpand(ids) {
        const toAdd = [];
        for (const id of ids) {
            if (!this._autoSeededIds.has(id)) {
                toAdd.push(id);
                this._autoSeededIds.add(id);
            }
        }
        if (toAdd.length === 0)
            return;
        this._expandedIds.update(current => {
            const next = new Set(current);
            for (const id of toAdd)
                next.add(id);
            return next;
        });
    }
    isExpanded(item) {
        return this._expandedIds().has(item.id ?? item.name);
    }
    toggleSubMenu(item, event) {
        event.preventDefault();
        if (!item.children)
            return;
        const key = item.id ?? item.name;
        this._expandedIds.update(ids => {
            const next = new Set(ids);
            next.has(key) ? next.delete(key) : next.add(key);
            return next;
        });
    }
    /**
     * Resolves whether `item` should be rendered as "current"/active.
     * Precedence:
     *  1. An explicit `item.current` always wins.
     *  2. Otherwise, when a Router is injected:
     *     - leaf item (no `children`): exact match of `item.path` against the
     *       tracked URL.
     *     - parent item (`children` present): true if any descendant's
     *       `path` exactly matches the tracked URL (recursive).
     *  3. Otherwise `false`.
     */
    isCurrent(item) {
        if (item.current !== undefined)
            return item.current;
        if (!this.router)
            return false;
        if (item.children)
            return this._hasCurrentDescendant(item);
        return !!item.path && this._currentUrl() === item.path;
    }
    onNavClick(item, event) {
        if (item.children) {
            this.toggleSubMenu(item, event);
        }
        else {
            this.navClick.emit(item);
        }
    }
    onTeamClick(team, event) {
        event.preventDefault();
        this.teamClick.emit(team);
    }
    onProfileClick(event) {
        event.preventDefault();
        if (this.userProfile) {
            this.profileClick.emit(this.userProfile);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: SidebarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: SidebarComponent, isStandalone: true, selector: "pg-sidebar", inputs: { variant: "variant", logoUrl: "logoUrl", navigation: "navigation", teams: "teams", userProfile: "userProfile", hasSecondaryNavigation: "hasSecondaryNavigation", teamsLabel: "teamsLabel" }, outputs: { navClick: "navClick", teamClick: "teamClick", profileClick: "profileClick" }, usesOnChanges: true, ngImport: i0, template: "<div\n  class=\"relative flex grow flex-col gap-y-5 overflow-y-auto px-6 h-full\"\n  [class.border-r]=\"variant === 'light'\"\n  [class.border-gray-200]=\"variant === 'light'\"\n  [class.bg-white]=\"variant === 'light'\"\n  [class.bg-gray-900]=\"variant === 'dark'\"\n  [class.bg-primary]=\"variant === 'brand'\"\n>\n  <div class=\"relative flex h-16 shrink-0 items-center\">\n    <img [src]=\"logoUrl\" alt=\"\" class=\"h-8 w-auto\" />\n  </div>\n\n  <nav class=\"relative flex flex-1 flex-col\">\n    <ul role=\"list\" class=\"flex flex-1 flex-col gap-y-7\">\n      <li>\n        <ul role=\"list\" class=\"-mx-2 space-y-1\">\n          @for (item of navigation; track item.name) {\n            <li>\n              @if (item.children) {\n                <button\n                  type=\"button\"\n                  (click)=\"toggleSubMenu(item, $event)\"\n                  class=\"flex w-full items-center gap-x-3 rounded-md p-2 text-left text-sm/6 font-semibold\"\n                  [class.bg-gray-50]=\"variant === 'light' && isCurrent(item)\"\n                  [class.text-primary]=\"variant === 'light' && isCurrent(item)\"\n                  [class.text-gray-700]=\"variant === 'light' && !isCurrent(item)\"\n                  [class.hover:bg-gray-50]=\"variant === 'light' && !isCurrent(item)\"\n                  [class.hover:text-primary-hover]=\"variant === 'light' && !isCurrent(item)\"\n                  [ngClass]=\"{\n                    'bg-white/5': variant === 'dark' && isCurrent(item),\n                    'hover:bg-white/5': variant === 'dark' && !isCurrent(item),\n                  }\"\n                  [class.text-white]=\"variant === 'dark' && isCurrent(item)\"\n                  [class.text-gray-400]=\"variant === 'dark' && !isCurrent(item)\"\n                  [class.hover:text-white]=\"variant === 'dark' && !isCurrent(item)\"\n                  [class.bg-indigo-700]=\"variant === 'brand' && isCurrent(item)\"\n                  [class.text-white]=\"variant === 'brand' && isCurrent(item)\"\n                  [class.text-indigo-200]=\"variant === 'brand' && !isCurrent(item)\"\n                  [class.hover:bg-indigo-700]=\"variant === 'brand' && !isCurrent(item)\"\n                  [class.hover:text-white]=\"variant === 'brand' && !isCurrent(item)\"\n                >\n                  @if (item.icon) {\n                    <span\n                      class=\"size-5 shrink-0\"\n                      [class.text-primary]=\"variant === 'light' && isCurrent(item)\"\n                      [class.text-gray-400]=\"\n                        (variant === 'light' || variant === 'dark') && !isCurrent(item)\n                      \"\n                      [class.text-indigo-200]=\"variant === 'brand' && !isCurrent(item)\"\n                      [class.text-white]=\"\n                        (variant === 'dark' || variant === 'brand') && isCurrent(item)\n                      \"\n                      [innerHTML]=\"item.icon | safeHtml\"\n                    ></span>\n                  }\n                  {{ item.name }}\n\n                  <svg\n                    viewBox=\"0 0 20 20\"\n                    fill=\"currentColor\"\n                    aria-hidden=\"true\"\n                    class=\"ml-auto size-5 shrink-0 transition-transform\"\n                    [class.rotate-90]=\"isExpanded(item)\"\n                    [class.text-gray-500]=\"\n                      isExpanded(item) && (variant === 'light' || variant === 'dark')\n                    \"\n                    [class.text-white]=\"isExpanded(item) && variant === 'brand'\"\n                    [class.text-gray-400]=\"\n                      !isExpanded(item) && (variant === 'light' || variant === 'dark')\n                    \"\n                    [class.text-indigo-200]=\"!isExpanded(item) && variant === 'brand'\"\n                  >\n                    <path\n                      d=\"M8.22 5.22a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.75.75 0 0 1-1.06-1.06L11.94 10 8.22 6.28a.75.75 0 0 1 0-1.06Z\"\n                      clip-rule=\"evenodd\"\n                      fill-rule=\"evenodd\"\n                    />\n                  </svg>\n                </button>\n\n                @if (isExpanded(item)) {\n                  <ul class=\"mt-1 px-2\">\n                    @for (subItem of item.children; track subItem.name) {\n                      <li>\n                        <a\n                          [pgLink]=\"subItem.path ?? ''\"\n                          (click)=\"onNavClick(subItem, $event)\"\n                          class=\"block rounded-md py-2 pl-9 pr-2 text-sm/6\"\n                          [class.bg-gray-50]=\"variant === 'light' && isCurrent(subItem)\"\n                          [class.text-gray-900]=\"variant === 'light' && isCurrent(subItem)\"\n                          [class.text-gray-700]=\"variant === 'light' && !isCurrent(subItem)\"\n                          [class.hover:bg-gray-50]=\"variant === 'light' && !isCurrent(subItem)\"\n                          [ngClass]=\"{\n                            'bg-white/5': variant === 'dark' && isCurrent(subItem),\n                            'hover:bg-white/5': variant === 'dark' && !isCurrent(subItem),\n                          }\"\n                          [class.text-white]=\"variant === 'dark' && isCurrent(subItem)\"\n                          [class.text-gray-400]=\"variant === 'dark' && !isCurrent(subItem)\"\n                          [class.hover:text-white]=\"variant === 'dark' && !isCurrent(subItem)\"\n                          [class.bg-indigo-700]=\"variant === 'brand' && isCurrent(subItem)\"\n                          [class.text-white]=\"variant === 'brand' && isCurrent(subItem)\"\n                          [class.text-indigo-200]=\"variant === 'brand' && !isCurrent(subItem)\"\n                          [class.hover:bg-indigo-700]=\"variant === 'brand' && !isCurrent(subItem)\"\n                          [class.hover:text-white]=\"variant === 'brand' && !isCurrent(subItem)\"\n                        >\n                          {{ subItem.name }}\n                        </a>\n                      </li>\n                    }\n                  </ul>\n                }\n              } @else {\n                <a\n                  [pgLink]=\"item.path ?? ''\"\n                  (click)=\"onNavClick(item, $event)\"\n                  class=\"group flex gap-x-3 rounded-md p-2 text-sm/6 font-semibold\"\n                  [class.bg-gray-50]=\"variant === 'light' && isCurrent(item)\"\n                  [class.text-primary]=\"variant === 'light' && isCurrent(item)\"\n                  [class.text-gray-700]=\"variant === 'light' && !isCurrent(item)\"\n                  [class.hover:bg-gray-50]=\"variant === 'light' && !isCurrent(item)\"\n                  [class.hover:text-primary-hover]=\"variant === 'light' && !isCurrent(item)\"\n                  [ngClass]=\"{\n                    'bg-white/5': variant === 'dark' && isCurrent(item),\n                    'hover:bg-white/5': variant === 'dark' && !isCurrent(item),\n                  }\"\n                  [class.text-white]=\"variant === 'dark' && isCurrent(item)\"\n                  [class.text-gray-400]=\"variant === 'dark' && !isCurrent(item)\"\n                  [class.hover:text-white]=\"variant === 'dark' && !isCurrent(item)\"\n                  [class.bg-indigo-700]=\"variant === 'brand' && isCurrent(item)\"\n                  [class.text-white]=\"variant === 'brand' && isCurrent(item)\"\n                  [class.text-indigo-200]=\"variant === 'brand' && !isCurrent(item)\"\n                  [class.hover:bg-indigo-700]=\"variant === 'brand' && !isCurrent(item)\"\n                  [class.hover:text-white]=\"variant === 'brand' && !isCurrent(item)\"\n                  [class.pl-10]=\"item.icon === undefined && hasSecondaryNavigation\"\n                >\n                  @if (item.icon) {\n                    <span\n                      class=\"size-6 shrink-0\"\n                      [class.text-primary]=\"variant === 'light' && isCurrent(item)\"\n                      [class.text-gray-400]=\"\n                        (variant === 'light' || variant === 'dark') && !isCurrent(item)\n                      \"\n                      [class.group-hover:text-primary-hover]=\"variant === 'light'\"\n                      [class.group-hover:text-white]=\"variant === 'dark' || variant === 'brand'\"\n                      [class.text-indigo-200]=\"variant === 'brand' && !isCurrent(item)\"\n                      [class.text-white]=\"\n                        (variant === 'dark' || variant === 'brand') && isCurrent(item)\n                      \"\n                      [innerHTML]=\"item.icon | safeHtml\"\n                    ></span>\n                  }\n\n                  <span>{{ item.name }}</span>\n\n                  @if (item.badge) {\n                    <span\n                      aria-hidden=\"true\"\n                      class=\"ml-auto w-9 min-w-max whitespace-nowrap rounded-full px-2.5 py-0.5 text-center text-xs/5 font-medium outline outline-1 -outline-offset-1\"\n                      [class.bg-white]=\"variant === 'light'\"\n                      [class.text-gray-600]=\"variant === 'light'\"\n                      [class.outline-gray-200]=\"variant === 'light'\"\n                      [class.bg-gray-900]=\"variant === 'dark'\"\n                      [class.text-white]=\"variant === 'dark' || variant === 'brand'\"\n                      [ngClass]=\"{ 'outline-white/15': variant === 'dark' }\"\n                      [class.bg-primary]=\"variant === 'brand' && isCurrent(item)\"\n                      [class.outline-primary]=\"variant === 'brand' && isCurrent(item)\"\n                      [class.bg-primary]=\"variant === 'brand' && !isCurrent(item)\"\n                    >\n                      {{ item.badge }}\n                    </span>\n                  }\n                </a>\n              }\n            </li>\n          }\n        </ul>\n      </li>\n\n      @if (teams && teams.length > 0) {\n        <li>\n          <div\n            class=\"text-xs/6 font-semibold\"\n            [class.text-gray-400]=\"variant === 'light' || variant === 'dark'\"\n            [class.text-indigo-200]=\"variant === 'brand'\"\n          >\n            {{ teamsLabel }}\n          </div>\n          <ul role=\"list\" class=\"-mx-2 mt-2 space-y-1\">\n            @for (team of teams; track team.id) {\n              <li>\n                <a\n                  href=\"#\"\n                  (click)=\"onTeamClick(team, $event)\"\n                  class=\"group flex gap-x-3 rounded-md p-2 text-sm/6 font-semibold\"\n                  [class.bg-gray-50]=\"variant === 'light' && team.current\"\n                  [class.text-primary]=\"variant === 'light' && team.current\"\n                  [class.text-gray-700]=\"variant === 'light' && !team.current\"\n                  [class.hover:bg-gray-50]=\"variant === 'light' && !team.current\"\n                  [class.hover:text-primary-hover]=\"variant === 'light' && !team.current\"\n                  [ngClass]=\"{\n                    'bg-white/5': variant === 'dark' && team.current,\n                    'hover:bg-white/5': variant === 'dark' && !team.current,\n                  }\"\n                  [class.text-white]=\"variant === 'dark' && team.current\"\n                  [class.text-gray-400]=\"variant === 'dark' && !team.current\"\n                  [class.hover:text-white]=\"variant === 'dark' && !team.current\"\n                  [class.bg-indigo-700]=\"variant === 'brand' && team.current\"\n                  [class.text-white]=\"variant === 'brand' && team.current\"\n                  [class.text-indigo-200]=\"variant === 'brand' && !team.current\"\n                  [class.hover:bg-indigo-700]=\"variant === 'brand' && !team.current\"\n                  [class.hover:text-white]=\"variant === 'brand' && !team.current\"\n                >\n                  <span\n                    class=\"flex size-6 shrink-0 items-center justify-center rounded-lg border text-[0.625rem] font-medium\"\n                    [class.bg-white]=\"variant === 'light'\"\n                    [class.border-gray-200]=\"variant === 'light'\"\n                    [class.text-gray-400]=\"variant === 'light'\"\n                    [class.group-hover:border-primary-hover]=\"variant === 'light'\"\n                    [class.group-hover:text-primary-hover]=\"variant === 'light'\"\n                    [class.border-primary]=\"variant === 'light' && team.current\"\n                    [class.text-primary]=\"variant === 'light' && team.current\"\n                    [ngClass]=\"{\n                      'bg-white/5': variant === 'dark',\n                      'border-white/10': variant === 'dark',\n                      'group-hover:border-white/20': variant === 'dark',\n                      'border-white/20': variant === 'dark' && team.current,\n                    }\"\n                    [class.text-gray-400]=\"variant === 'dark'\"\n                    [class.group-hover:text-white]=\"variant === 'dark'\"\n                    [class.text-white]=\"variant === 'dark' && team.current\"\n                    [class.bg-primary]=\"variant === 'brand'\"\n                    [class.border-indigo-400]=\"variant === 'brand'\"\n                    [class.text-white]=\"variant === 'brand'\"\n                  >\n                    {{ team.initial }}\n                  </span>\n                  <span class=\"truncate\">{{ team.name }}</span>\n                </a>\n              </li>\n            }\n          </ul>\n        </li>\n      }\n\n      @if (userProfile) {\n        <li class=\"-mx-6 mt-auto\">\n          <a\n            href=\"#\"\n            (click)=\"onProfileClick($event)\"\n            class=\"flex items-center gap-x-4 px-6 py-3 text-sm/6 font-semibold\"\n            [class.text-gray-900]=\"variant === 'light'\"\n            [class.hover:bg-gray-50]=\"variant === 'light'\"\n            [class.text-white]=\"variant === 'dark' || variant === 'brand'\"\n            [ngClass]=\"{ 'hover:bg-white/5': variant === 'dark' }\"\n            [class.hover:bg-indigo-700]=\"variant === 'brand'\"\n          >\n            <img\n              [src]=\"userProfile.avatarUrl\"\n              alt=\"\"\n              class=\"size-8 rounded-full outline outline-1 -outline-offset-1\"\n              [class.bg-gray-50]=\"variant === 'light'\"\n              [ngClass]=\"{\n                'outline-black/5': variant === 'light',\n                'outline-white/10': variant === 'dark' || variant === 'brand',\n              }\"\n              [class.bg-gray-800]=\"variant === 'dark'\"\n              [class.bg-indigo-700]=\"variant === 'brand'\"\n            />\n            <span class=\"sr-only\">Your profile</span>\n            <span aria-hidden=\"true\">{{ userProfile.name }}</span>\n          </a>\n        </li>\n      }\n    </ul>\n  </nav>\n</div>\n", styles: [""], dependencies: [{ kind: "pipe", type: SafeHtmlPipe, name: "safeHtml" }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: PgLinkDirective, selector: "[pgLink]", inputs: ["pgLink"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: SidebarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-sidebar', imports: [SafeHtmlPipe, NgClass, PgLinkDirective], template: "<div\n  class=\"relative flex grow flex-col gap-y-5 overflow-y-auto px-6 h-full\"\n  [class.border-r]=\"variant === 'light'\"\n  [class.border-gray-200]=\"variant === 'light'\"\n  [class.bg-white]=\"variant === 'light'\"\n  [class.bg-gray-900]=\"variant === 'dark'\"\n  [class.bg-primary]=\"variant === 'brand'\"\n>\n  <div class=\"relative flex h-16 shrink-0 items-center\">\n    <img [src]=\"logoUrl\" alt=\"\" class=\"h-8 w-auto\" />\n  </div>\n\n  <nav class=\"relative flex flex-1 flex-col\">\n    <ul role=\"list\" class=\"flex flex-1 flex-col gap-y-7\">\n      <li>\n        <ul role=\"list\" class=\"-mx-2 space-y-1\">\n          @for (item of navigation; track item.name) {\n            <li>\n              @if (item.children) {\n                <button\n                  type=\"button\"\n                  (click)=\"toggleSubMenu(item, $event)\"\n                  class=\"flex w-full items-center gap-x-3 rounded-md p-2 text-left text-sm/6 font-semibold\"\n                  [class.bg-gray-50]=\"variant === 'light' && isCurrent(item)\"\n                  [class.text-primary]=\"variant === 'light' && isCurrent(item)\"\n                  [class.text-gray-700]=\"variant === 'light' && !isCurrent(item)\"\n                  [class.hover:bg-gray-50]=\"variant === 'light' && !isCurrent(item)\"\n                  [class.hover:text-primary-hover]=\"variant === 'light' && !isCurrent(item)\"\n                  [ngClass]=\"{\n                    'bg-white/5': variant === 'dark' && isCurrent(item),\n                    'hover:bg-white/5': variant === 'dark' && !isCurrent(item),\n                  }\"\n                  [class.text-white]=\"variant === 'dark' && isCurrent(item)\"\n                  [class.text-gray-400]=\"variant === 'dark' && !isCurrent(item)\"\n                  [class.hover:text-white]=\"variant === 'dark' && !isCurrent(item)\"\n                  [class.bg-indigo-700]=\"variant === 'brand' && isCurrent(item)\"\n                  [class.text-white]=\"variant === 'brand' && isCurrent(item)\"\n                  [class.text-indigo-200]=\"variant === 'brand' && !isCurrent(item)\"\n                  [class.hover:bg-indigo-700]=\"variant === 'brand' && !isCurrent(item)\"\n                  [class.hover:text-white]=\"variant === 'brand' && !isCurrent(item)\"\n                >\n                  @if (item.icon) {\n                    <span\n                      class=\"size-5 shrink-0\"\n                      [class.text-primary]=\"variant === 'light' && isCurrent(item)\"\n                      [class.text-gray-400]=\"\n                        (variant === 'light' || variant === 'dark') && !isCurrent(item)\n                      \"\n                      [class.text-indigo-200]=\"variant === 'brand' && !isCurrent(item)\"\n                      [class.text-white]=\"\n                        (variant === 'dark' || variant === 'brand') && isCurrent(item)\n                      \"\n                      [innerHTML]=\"item.icon | safeHtml\"\n                    ></span>\n                  }\n                  {{ item.name }}\n\n                  <svg\n                    viewBox=\"0 0 20 20\"\n                    fill=\"currentColor\"\n                    aria-hidden=\"true\"\n                    class=\"ml-auto size-5 shrink-0 transition-transform\"\n                    [class.rotate-90]=\"isExpanded(item)\"\n                    [class.text-gray-500]=\"\n                      isExpanded(item) && (variant === 'light' || variant === 'dark')\n                    \"\n                    [class.text-white]=\"isExpanded(item) && variant === 'brand'\"\n                    [class.text-gray-400]=\"\n                      !isExpanded(item) && (variant === 'light' || variant === 'dark')\n                    \"\n                    [class.text-indigo-200]=\"!isExpanded(item) && variant === 'brand'\"\n                  >\n                    <path\n                      d=\"M8.22 5.22a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.75.75 0 0 1-1.06-1.06L11.94 10 8.22 6.28a.75.75 0 0 1 0-1.06Z\"\n                      clip-rule=\"evenodd\"\n                      fill-rule=\"evenodd\"\n                    />\n                  </svg>\n                </button>\n\n                @if (isExpanded(item)) {\n                  <ul class=\"mt-1 px-2\">\n                    @for (subItem of item.children; track subItem.name) {\n                      <li>\n                        <a\n                          [pgLink]=\"subItem.path ?? ''\"\n                          (click)=\"onNavClick(subItem, $event)\"\n                          class=\"block rounded-md py-2 pl-9 pr-2 text-sm/6\"\n                          [class.bg-gray-50]=\"variant === 'light' && isCurrent(subItem)\"\n                          [class.text-gray-900]=\"variant === 'light' && isCurrent(subItem)\"\n                          [class.text-gray-700]=\"variant === 'light' && !isCurrent(subItem)\"\n                          [class.hover:bg-gray-50]=\"variant === 'light' && !isCurrent(subItem)\"\n                          [ngClass]=\"{\n                            'bg-white/5': variant === 'dark' && isCurrent(subItem),\n                            'hover:bg-white/5': variant === 'dark' && !isCurrent(subItem),\n                          }\"\n                          [class.text-white]=\"variant === 'dark' && isCurrent(subItem)\"\n                          [class.text-gray-400]=\"variant === 'dark' && !isCurrent(subItem)\"\n                          [class.hover:text-white]=\"variant === 'dark' && !isCurrent(subItem)\"\n                          [class.bg-indigo-700]=\"variant === 'brand' && isCurrent(subItem)\"\n                          [class.text-white]=\"variant === 'brand' && isCurrent(subItem)\"\n                          [class.text-indigo-200]=\"variant === 'brand' && !isCurrent(subItem)\"\n                          [class.hover:bg-indigo-700]=\"variant === 'brand' && !isCurrent(subItem)\"\n                          [class.hover:text-white]=\"variant === 'brand' && !isCurrent(subItem)\"\n                        >\n                          {{ subItem.name }}\n                        </a>\n                      </li>\n                    }\n                  </ul>\n                }\n              } @else {\n                <a\n                  [pgLink]=\"item.path ?? ''\"\n                  (click)=\"onNavClick(item, $event)\"\n                  class=\"group flex gap-x-3 rounded-md p-2 text-sm/6 font-semibold\"\n                  [class.bg-gray-50]=\"variant === 'light' && isCurrent(item)\"\n                  [class.text-primary]=\"variant === 'light' && isCurrent(item)\"\n                  [class.text-gray-700]=\"variant === 'light' && !isCurrent(item)\"\n                  [class.hover:bg-gray-50]=\"variant === 'light' && !isCurrent(item)\"\n                  [class.hover:text-primary-hover]=\"variant === 'light' && !isCurrent(item)\"\n                  [ngClass]=\"{\n                    'bg-white/5': variant === 'dark' && isCurrent(item),\n                    'hover:bg-white/5': variant === 'dark' && !isCurrent(item),\n                  }\"\n                  [class.text-white]=\"variant === 'dark' && isCurrent(item)\"\n                  [class.text-gray-400]=\"variant === 'dark' && !isCurrent(item)\"\n                  [class.hover:text-white]=\"variant === 'dark' && !isCurrent(item)\"\n                  [class.bg-indigo-700]=\"variant === 'brand' && isCurrent(item)\"\n                  [class.text-white]=\"variant === 'brand' && isCurrent(item)\"\n                  [class.text-indigo-200]=\"variant === 'brand' && !isCurrent(item)\"\n                  [class.hover:bg-indigo-700]=\"variant === 'brand' && !isCurrent(item)\"\n                  [class.hover:text-white]=\"variant === 'brand' && !isCurrent(item)\"\n                  [class.pl-10]=\"item.icon === undefined && hasSecondaryNavigation\"\n                >\n                  @if (item.icon) {\n                    <span\n                      class=\"size-6 shrink-0\"\n                      [class.text-primary]=\"variant === 'light' && isCurrent(item)\"\n                      [class.text-gray-400]=\"\n                        (variant === 'light' || variant === 'dark') && !isCurrent(item)\n                      \"\n                      [class.group-hover:text-primary-hover]=\"variant === 'light'\"\n                      [class.group-hover:text-white]=\"variant === 'dark' || variant === 'brand'\"\n                      [class.text-indigo-200]=\"variant === 'brand' && !isCurrent(item)\"\n                      [class.text-white]=\"\n                        (variant === 'dark' || variant === 'brand') && isCurrent(item)\n                      \"\n                      [innerHTML]=\"item.icon | safeHtml\"\n                    ></span>\n                  }\n\n                  <span>{{ item.name }}</span>\n\n                  @if (item.badge) {\n                    <span\n                      aria-hidden=\"true\"\n                      class=\"ml-auto w-9 min-w-max whitespace-nowrap rounded-full px-2.5 py-0.5 text-center text-xs/5 font-medium outline outline-1 -outline-offset-1\"\n                      [class.bg-white]=\"variant === 'light'\"\n                      [class.text-gray-600]=\"variant === 'light'\"\n                      [class.outline-gray-200]=\"variant === 'light'\"\n                      [class.bg-gray-900]=\"variant === 'dark'\"\n                      [class.text-white]=\"variant === 'dark' || variant === 'brand'\"\n                      [ngClass]=\"{ 'outline-white/15': variant === 'dark' }\"\n                      [class.bg-primary]=\"variant === 'brand' && isCurrent(item)\"\n                      [class.outline-primary]=\"variant === 'brand' && isCurrent(item)\"\n                      [class.bg-primary]=\"variant === 'brand' && !isCurrent(item)\"\n                    >\n                      {{ item.badge }}\n                    </span>\n                  }\n                </a>\n              }\n            </li>\n          }\n        </ul>\n      </li>\n\n      @if (teams && teams.length > 0) {\n        <li>\n          <div\n            class=\"text-xs/6 font-semibold\"\n            [class.text-gray-400]=\"variant === 'light' || variant === 'dark'\"\n            [class.text-indigo-200]=\"variant === 'brand'\"\n          >\n            {{ teamsLabel }}\n          </div>\n          <ul role=\"list\" class=\"-mx-2 mt-2 space-y-1\">\n            @for (team of teams; track team.id) {\n              <li>\n                <a\n                  href=\"#\"\n                  (click)=\"onTeamClick(team, $event)\"\n                  class=\"group flex gap-x-3 rounded-md p-2 text-sm/6 font-semibold\"\n                  [class.bg-gray-50]=\"variant === 'light' && team.current\"\n                  [class.text-primary]=\"variant === 'light' && team.current\"\n                  [class.text-gray-700]=\"variant === 'light' && !team.current\"\n                  [class.hover:bg-gray-50]=\"variant === 'light' && !team.current\"\n                  [class.hover:text-primary-hover]=\"variant === 'light' && !team.current\"\n                  [ngClass]=\"{\n                    'bg-white/5': variant === 'dark' && team.current,\n                    'hover:bg-white/5': variant === 'dark' && !team.current,\n                  }\"\n                  [class.text-white]=\"variant === 'dark' && team.current\"\n                  [class.text-gray-400]=\"variant === 'dark' && !team.current\"\n                  [class.hover:text-white]=\"variant === 'dark' && !team.current\"\n                  [class.bg-indigo-700]=\"variant === 'brand' && team.current\"\n                  [class.text-white]=\"variant === 'brand' && team.current\"\n                  [class.text-indigo-200]=\"variant === 'brand' && !team.current\"\n                  [class.hover:bg-indigo-700]=\"variant === 'brand' && !team.current\"\n                  [class.hover:text-white]=\"variant === 'brand' && !team.current\"\n                >\n                  <span\n                    class=\"flex size-6 shrink-0 items-center justify-center rounded-lg border text-[0.625rem] font-medium\"\n                    [class.bg-white]=\"variant === 'light'\"\n                    [class.border-gray-200]=\"variant === 'light'\"\n                    [class.text-gray-400]=\"variant === 'light'\"\n                    [class.group-hover:border-primary-hover]=\"variant === 'light'\"\n                    [class.group-hover:text-primary-hover]=\"variant === 'light'\"\n                    [class.border-primary]=\"variant === 'light' && team.current\"\n                    [class.text-primary]=\"variant === 'light' && team.current\"\n                    [ngClass]=\"{\n                      'bg-white/5': variant === 'dark',\n                      'border-white/10': variant === 'dark',\n                      'group-hover:border-white/20': variant === 'dark',\n                      'border-white/20': variant === 'dark' && team.current,\n                    }\"\n                    [class.text-gray-400]=\"variant === 'dark'\"\n                    [class.group-hover:text-white]=\"variant === 'dark'\"\n                    [class.text-white]=\"variant === 'dark' && team.current\"\n                    [class.bg-primary]=\"variant === 'brand'\"\n                    [class.border-indigo-400]=\"variant === 'brand'\"\n                    [class.text-white]=\"variant === 'brand'\"\n                  >\n                    {{ team.initial }}\n                  </span>\n                  <span class=\"truncate\">{{ team.name }}</span>\n                </a>\n              </li>\n            }\n          </ul>\n        </li>\n      }\n\n      @if (userProfile) {\n        <li class=\"-mx-6 mt-auto\">\n          <a\n            href=\"#\"\n            (click)=\"onProfileClick($event)\"\n            class=\"flex items-center gap-x-4 px-6 py-3 text-sm/6 font-semibold\"\n            [class.text-gray-900]=\"variant === 'light'\"\n            [class.hover:bg-gray-50]=\"variant === 'light'\"\n            [class.text-white]=\"variant === 'dark' || variant === 'brand'\"\n            [ngClass]=\"{ 'hover:bg-white/5': variant === 'dark' }\"\n            [class.hover:bg-indigo-700]=\"variant === 'brand'\"\n          >\n            <img\n              [src]=\"userProfile.avatarUrl\"\n              alt=\"\"\n              class=\"size-8 rounded-full outline outline-1 -outline-offset-1\"\n              [class.bg-gray-50]=\"variant === 'light'\"\n              [ngClass]=\"{\n                'outline-black/5': variant === 'light',\n                'outline-white/10': variant === 'dark' || variant === 'brand',\n              }\"\n              [class.bg-gray-800]=\"variant === 'dark'\"\n              [class.bg-indigo-700]=\"variant === 'brand'\"\n            />\n            <span class=\"sr-only\">Your profile</span>\n            <span aria-hidden=\"true\">{{ userProfile.name }}</span>\n          </a>\n        </li>\n      }\n    </ul>\n  </nav>\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { variant: [{
                type: Input
            }], logoUrl: [{
                type: Input
            }], navigation: [{
                type: Input
            }], teams: [{
                type: Input
            }], userProfile: [{
                type: Input
            }], hasSecondaryNavigation: [{
                type: Input
            }], teamsLabel: [{
                type: Input
            }], navClick: [{
                type: Output
            }], teamClick: [{
                type: Output
            }], profileClick: [{
                type: Output
            }] } });

class PgSidebarModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgSidebarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.21", ngImport: i0, type: PgSidebarModule, imports: [SidebarComponent], exports: [SidebarComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgSidebarModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgSidebarModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        SidebarComponent
                    ],
                    exports: [
                        SidebarComponent
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { PgSidebarModule, SidebarComponent };
//# sourceMappingURL=pagalo-ui-sidebar.mjs.map
