import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, Component, NgModule } from '@angular/core';

class BadgeComponent {
    label;
    variant = 'outline';
    size = 'md';
    shape = 'rounded';
    color = 'neutral';
    dot = false;
    dotColor;
    dismissible = false;
    dismiss = new EventEmitter();
    get classes() {
        const baseClasses = 'inline-flex items-center font-medium';
        const hasExtras = this.dot || this.dismissible;
        let sizeClasses = '';
        if (this.size === 'sm') {
            sizeClasses = 'px-1.5 py-0.5 text-xs';
        }
        else {
            sizeClasses = 'px-2 py-1 text-xs';
        }
        let gapClasses = '';
        if (this.dot && this.dismissible) {
            gapClasses = 'gap-x-1.5';
        }
        else if (this.dot) {
            gapClasses = 'gap-x-1.5';
        }
        else if (this.dismissible) {
            gapClasses = 'gap-x-0.5';
        }
        const shapeClasses = this.shape === 'pill' ? 'rounded-full' : 'rounded-md';
        let colorClasses = '';
        if (this.variant === 'outline') {
            colorClasses = {
                primary: 'bg-primary/10 text-primary ring-1 ring-inset ring-primary/20',
                secondary: 'bg-secondary/10 text-secondary ring-1 ring-inset ring-secondary/20',
                info: 'bg-info/10 text-info ring-1 ring-inset ring-info/20',
                success: 'bg-success/10 text-success ring-1 ring-inset ring-success/20',
                warning: 'bg-warning/10 text-warning ring-1 ring-inset ring-warning/20',
                error: 'bg-error/10 text-error ring-1 ring-inset ring-error/20',
                neutral: 'bg-neutral/10 text-gray-600 ring-1 ring-inset ring-neutral/20',
                disabled: 'bg-disabled/10 text-disabled-text ring-1 ring-inset ring-disabled/20',
            }[this.color];
        }
        else if (this.variant === 'flat') {
            colorClasses = {
                primary: 'bg-primary/20 text-primary',
                secondary: 'bg-secondary/20 text-secondary',
                info: 'bg-info/20 text-info',
                success: 'bg-success/20 text-success',
                warning: 'bg-warning/20 text-warning',
                error: 'bg-error/20 text-error',
                neutral: 'bg-gray-100 text-gray-600',
                disabled: 'bg-disabled text-disabled-text',
            }[this.color];
        }
        return [baseClasses, sizeClasses, gapClasses, shapeClasses, colorClasses]
            .filter(Boolean)
            .join(' ');
    }
    get dotClasses() {
        const color = this.dotColor || this.color;
        const dotColorMap = {
            primary: 'fill-primary',
            secondary: 'fill-secondary',
            info: 'fill-info',
            success: 'fill-success',
            warning: 'fill-warning',
            error: 'fill-error',
            neutral: 'fill-gray-400',
            disabled: 'fill-disabled-text',
        };
        return `size-1.5 ${dotColorMap[color]}`;
    }
    get removeButtonClasses() {
        const hoverBgMap = {
            primary: 'hover:bg-primary/20',
            secondary: 'hover:bg-secondary/20',
            info: 'hover:bg-info/20',
            success: 'hover:bg-success/20',
            warning: 'hover:bg-warning/20',
            error: 'hover:bg-error/20',
            neutral: 'hover:bg-gray-200',
            disabled: 'hover:bg-disabled/20',
        };
        return `group relative -mr-1 size-3.5 rounded-sm ${hoverBgMap[this.color]}`;
    }
    get removeIconClasses() {
        const strokeMap = {
            primary: 'stroke-primary/50 group-hover:stroke-primary/75',
            secondary: 'stroke-secondary/50 group-hover:stroke-secondary/75',
            info: 'stroke-info/50 group-hover:stroke-info/75',
            success: 'stroke-success/50 group-hover:stroke-success/75',
            warning: 'stroke-warning/50 group-hover:stroke-warning/75',
            error: 'stroke-error/50 group-hover:stroke-error/75',
            neutral: 'stroke-gray-400 group-hover:stroke-gray-600',
            disabled: 'stroke-disabled-text/50 group-hover:stroke-disabled-text/75',
        };
        return `size-3.5 ${strokeMap[this.color]}`;
    }
    onDismiss(event) {
        event.stopPropagation();
        this.dismiss.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: BadgeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: BadgeComponent, isStandalone: true, selector: "pg-badge", inputs: { label: "label", variant: "variant", size: "size", shape: "shape", color: "color", dot: "dot", dotColor: "dotColor", dismissible: "dismissible" }, outputs: { dismiss: "dismiss" }, ngImport: i0, template: "<span [class]=\"classes\">\n  @if (dot) {\n    <svg viewBox=\"0 0 6 6\" aria-hidden=\"true\" [class]=\"dotClasses\" fill=\"currentColor\">\n      <circle r=\"3\" cx=\"3\" cy=\"3\" />\n    </svg>\n  }\n  <ng-content></ng-content>\n  @if (label) {\n    {{ label }}\n  }\n  @if (dismissible) {\n    <button type=\"button\" [class]=\"removeButtonClasses\" (click)=\"onDismiss($event)\">\n      <span class=\"sr-only\">Remove</span>\n      <svg\n        viewBox=\"0 0 14 14\"\n        [class]=\"removeIconClasses\"\n        fill=\"none\"\n        stroke=\"currentColor\"\n        stroke-width=\"1.5\"\n      >\n        <path d=\"M4 4l6 6m0-6l-6 6\" />\n      </svg>\n      <span class=\"absolute -inset-1\"></span>\n    </button>\n  }\n</span>\n", styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: BadgeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-badge', imports: [], template: "<span [class]=\"classes\">\n  @if (dot) {\n    <svg viewBox=\"0 0 6 6\" aria-hidden=\"true\" [class]=\"dotClasses\" fill=\"currentColor\">\n      <circle r=\"3\" cx=\"3\" cy=\"3\" />\n    </svg>\n  }\n  <ng-content></ng-content>\n  @if (label) {\n    {{ label }}\n  }\n  @if (dismissible) {\n    <button type=\"button\" [class]=\"removeButtonClasses\" (click)=\"onDismiss($event)\">\n      <span class=\"sr-only\">Remove</span>\n      <svg\n        viewBox=\"0 0 14 14\"\n        [class]=\"removeIconClasses\"\n        fill=\"none\"\n        stroke=\"currentColor\"\n        stroke-width=\"1.5\"\n      >\n        <path d=\"M4 4l6 6m0-6l-6 6\" />\n      </svg>\n      <span class=\"absolute -inset-1\"></span>\n    </button>\n  }\n</span>\n" }]
        }], propDecorators: { label: [{
                type: Input
            }], variant: [{
                type: Input
            }], size: [{
                type: Input
            }], shape: [{
                type: Input
            }], color: [{
                type: Input
            }], dot: [{
                type: Input
            }], dotColor: [{
                type: Input
            }], dismissible: [{
                type: Input
            }], dismiss: [{
                type: Output
            }] } });

class PgBadgeModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgBadgeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.21", ngImport: i0, type: PgBadgeModule, imports: [BadgeComponent], exports: [BadgeComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgBadgeModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgBadgeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        BadgeComponent
                    ],
                    exports: [
                        BadgeComponent
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { BadgeComponent, PgBadgeModule };
//# sourceMappingURL=pagalo-ui-badge.mjs.map
