import * as i0 from '@angular/core';
import { ContentChild, Input, Component, NgModule } from '@angular/core';
import { NgTemplateOutlet, NgClass } from '@angular/common';

class StackedListComponent {
    variant = 'simple';
    items = [];
    groupedItems = [];
    itemAvatar;
    itemContent;
    itemRight;
    footerAction;
    get containerClass() {
        if (this.variant === 'in-card-with-links') {
            return 'overflow-hidden bg-white shadow-sm outline outline-1 outline-gray-900/5 sm:rounded-xl';
        }
        if (this.variant === 'narrow-with-sticky-headings') {
            return 'h-full overflow-y-auto';
        }
        return '';
    }
    get listContainerClass() {
        return 'divide-y divide-gray-100';
    }
    get listItemClass() {
        let classes = 'flex justify-between gap-x-6';
        switch (this.variant) {
            case 'simple':
                return `${classes} py-5`;
            case 'with-links':
                return `relative ${classes} py-5`;
            case 'in-card-with-links':
                return `relative ${classes} px-4 py-5 hover:bg-gray-50 sm:px-6`;
            case 'two-columns':
                return `relative ${classes} py-5`;
            case 'narrow-with-sticky-headings':
                return `flex gap-x-4 px-3 py-5`;
            case 'narrow-with-actions':
                return `flex items-center justify-between gap-x-6 py-5`;
            default:
                return `${classes} py-5`;
        }
    }
    get leftSideClass() {
        if (this.variant === 'two-columns') {
            return 'flex gap-x-4 pr-6 sm:w-1/2 sm:flex-none';
        }
        return 'flex min-w-0 gap-x-4';
    }
    get rightSideClass() {
        if (this.variant === 'narrow-with-sticky-headings') {
            return 'hidden';
        }
        if (this.variant === 'two-columns') {
            return 'flex items-center justify-between gap-x-4 sm:w-1/2 sm:flex-none';
        }
        if (this.variant === 'narrow-with-actions') {
            return 'shrink-0';
        }
        if (this.variant === 'simple') {
            return 'hidden shrink-0 sm:flex sm:flex-col sm:items-end';
        }
        return 'flex shrink-0 items-center gap-x-4';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: StackedListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: StackedListComponent, isStandalone: true, selector: "pg-stacked-list", inputs: { variant: "variant", items: "items", groupedItems: "groupedItems" }, queries: [{ propertyName: "itemAvatar", first: true, predicate: ["itemAvatar"], descendants: true }, { propertyName: "itemContent", first: true, predicate: ["itemContent"], descendants: true }, { propertyName: "itemRight", first: true, predicate: ["itemRight"], descendants: true }, { propertyName: "footerAction", first: true, predicate: ["footerAction"], descendants: true }], ngImport: i0, template: "@if (variant === 'narrow-with-sticky-headings') {\n  <nav\n    aria-label=\"Directory\"\n    [ngClass]=\"containerClass\"\n    >\n    @for (group of groupedItems; track group) {\n      <div class=\"relative\">\n        <div\n          class=\"sticky top-0 z-10 border-y border-b-gray-200 border-t-gray-100 bg-gray-50 px-3 py-1.5 text-sm/6 font-semibold text-gray-900\"\n          >\n          <h3 class=\"relative\">{{ group.groupName }}</h3>\n        </div>\n        <ul role=\"list\" [ngClass]=\"listContainerClass\">\n          @for (item of group.items; track item) {\n            <li [ngClass]=\"listItemClass\">\n              @if (itemAvatar) {\n                <ng-container\n                  [ngTemplateOutlet]=\"itemAvatar\"\n                  [ngTemplateOutletContext]=\"{ $implicit: item }\"\n                ></ng-container>\n              }\n              <div class=\"min-w-0 flex-auto\">\n                @if (itemContent) {\n                  <ng-container\n                    [ngTemplateOutlet]=\"itemContent\"\n                    [ngTemplateOutletContext]=\"{ $implicit: item }\"\n                  ></ng-container>\n                }\n              </div>\n            </li>\n          }\n        </ul>\n      </div>\n    }\n  </nav>\n}\n\n@if (variant !== 'narrow-with-sticky-headings') {\n  <div [ngClass]=\"containerClass\">\n    <ul role=\"list\" [ngClass]=\"listContainerClass\">\n      @for (item of items; track item) {\n        <li [ngClass]=\"listItemClass\">\n          <div [ngClass]=\"leftSideClass\">\n            @if (itemAvatar) {\n              <ng-container\n                [ngTemplateOutlet]=\"itemAvatar\"\n                [ngTemplateOutletContext]=\"{ $implicit: item }\"\n              ></ng-container>\n            }\n            <div class=\"min-w-0 flex-auto\">\n              @if (itemContent) {\n                <ng-container\n                  [ngTemplateOutlet]=\"itemContent\"\n                  [ngTemplateOutletContext]=\"{ $implicit: item }\"\n                ></ng-container>\n              }\n            </div>\n          </div>\n          @if (itemRight) {\n            <div [ngClass]=\"rightSideClass\">\n              <ng-container\n                [ngTemplateOutlet]=\"itemRight\"\n                [ngTemplateOutletContext]=\"{ $implicit: item }\"\n              ></ng-container>\n            </div>\n          }\n        </li>\n      }\n    </ul>\n    @if (footerAction) {\n      <ng-container [ngTemplateOutlet]=\"footerAction\"></ng-container>\n    }\n  </div>\n}\n", styles: [""], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: StackedListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-stacked-list', imports: [NgTemplateOutlet, NgClass], template: "@if (variant === 'narrow-with-sticky-headings') {\n  <nav\n    aria-label=\"Directory\"\n    [ngClass]=\"containerClass\"\n    >\n    @for (group of groupedItems; track group) {\n      <div class=\"relative\">\n        <div\n          class=\"sticky top-0 z-10 border-y border-b-gray-200 border-t-gray-100 bg-gray-50 px-3 py-1.5 text-sm/6 font-semibold text-gray-900\"\n          >\n          <h3 class=\"relative\">{{ group.groupName }}</h3>\n        </div>\n        <ul role=\"list\" [ngClass]=\"listContainerClass\">\n          @for (item of group.items; track item) {\n            <li [ngClass]=\"listItemClass\">\n              @if (itemAvatar) {\n                <ng-container\n                  [ngTemplateOutlet]=\"itemAvatar\"\n                  [ngTemplateOutletContext]=\"{ $implicit: item }\"\n                ></ng-container>\n              }\n              <div class=\"min-w-0 flex-auto\">\n                @if (itemContent) {\n                  <ng-container\n                    [ngTemplateOutlet]=\"itemContent\"\n                    [ngTemplateOutletContext]=\"{ $implicit: item }\"\n                  ></ng-container>\n                }\n              </div>\n            </li>\n          }\n        </ul>\n      </div>\n    }\n  </nav>\n}\n\n@if (variant !== 'narrow-with-sticky-headings') {\n  <div [ngClass]=\"containerClass\">\n    <ul role=\"list\" [ngClass]=\"listContainerClass\">\n      @for (item of items; track item) {\n        <li [ngClass]=\"listItemClass\">\n          <div [ngClass]=\"leftSideClass\">\n            @if (itemAvatar) {\n              <ng-container\n                [ngTemplateOutlet]=\"itemAvatar\"\n                [ngTemplateOutletContext]=\"{ $implicit: item }\"\n              ></ng-container>\n            }\n            <div class=\"min-w-0 flex-auto\">\n              @if (itemContent) {\n                <ng-container\n                  [ngTemplateOutlet]=\"itemContent\"\n                  [ngTemplateOutletContext]=\"{ $implicit: item }\"\n                ></ng-container>\n              }\n            </div>\n          </div>\n          @if (itemRight) {\n            <div [ngClass]=\"rightSideClass\">\n              <ng-container\n                [ngTemplateOutlet]=\"itemRight\"\n                [ngTemplateOutletContext]=\"{ $implicit: item }\"\n              ></ng-container>\n            </div>\n          }\n        </li>\n      }\n    </ul>\n    @if (footerAction) {\n      <ng-container [ngTemplateOutlet]=\"footerAction\"></ng-container>\n    }\n  </div>\n}\n" }]
        }], propDecorators: { variant: [{
                type: Input
            }], items: [{
                type: Input
            }], groupedItems: [{
                type: Input
            }], itemAvatar: [{
                type: ContentChild,
                args: ['itemAvatar']
            }], itemContent: [{
                type: ContentChild,
                args: ['itemContent']
            }], itemRight: [{
                type: ContentChild,
                args: ['itemRight']
            }], footerAction: [{
                type: ContentChild,
                args: ['footerAction']
            }] } });

class PgStackedListModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgStackedListModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.21", ngImport: i0, type: PgStackedListModule, imports: [StackedListComponent], exports: [StackedListComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgStackedListModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgStackedListModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        StackedListComponent
                    ],
                    exports: [
                        StackedListComponent
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { PgStackedListModule, StackedListComponent };
//# sourceMappingURL=pagalo-ui-stacked-list.mjs.map
