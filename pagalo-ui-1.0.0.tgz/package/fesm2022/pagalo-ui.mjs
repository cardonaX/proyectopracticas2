const VERSION = '1.0.0';

/**
 * Generated bundle index. Do not edit.
 */

export { VERSION };
//# sourceMappingURL=pagalo-ui.mjs.map
