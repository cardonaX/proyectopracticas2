import * as i0 from '@angular/core';
import { signal, Injectable, input, computed, ChangeDetectionStrategy, Component, output, inject, model, viewChild, effect, NgModule } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule, NgClass, NgTemplateOutlet } from '@angular/common';
import { PgDialogBase, IdService } from '@pagalo/ui/core';

class AlertService {
    _alerts = signal([]);
    alerts = this._alerts.asReadonly();
    defaultDuration = 5000;
    setDefaultDuration(duration) {
        this.defaultDuration = duration;
    }
    generateId() {
        return Math.random().toString(36).substring(2, 9);
    }
    show(config) {
        return new Promise((resolve) => {
            const isModal = config.variant === 'modal';
            if (isModal) {
                const existing = this._alerts().filter((a) => a.variant === 'modal');
                for (const modal of existing) {
                    modal._resolve?.({
                        isConfirmed: false,
                        isDenied: false,
                        isDismissed: true,
                        dismissReason: 'close',
                    });
                }
                this._alerts.update((alerts) => alerts.filter((a) => a.variant !== 'modal'));
            }
            const duration = config.duration !== undefined ? config.duration : isModal ? 0 : this.defaultDuration;
            const showConfirmButton = config.showConfirmButton !== undefined ? config.showConfirmButton : isModal;
            const newAlert = {
                id: this.generateId(),
                duration,
                showConfirmButton,
                ...config,
                _resolve: resolve,
            };
            if (newAlert.willOpen) {
                newAlert.willOpen();
            }
            this._alerts.update((nots) => [...nots, newAlert]);
            if (newAlert.didOpen) {
                setTimeout(() => newAlert.didOpen(), 50);
            }
            // El auto-dismiss por duración de los modales corre ahora dentro de
            // AlertModalComponent (effect() interno), por el mismo camino animado
            // que el resto de los cierres. Este timer corría ANTES de que el
            // componente existiera y le ganaba la carrera al cierre animado.
            if (duration > 0 && !isModal) {
                setTimeout(() => {
                    this.close(newAlert.id, {
                        isConfirmed: false,
                        isDenied: false,
                        isDismissed: true,
                        dismissReason: 'timer',
                    });
                }, duration);
            }
        });
    }
    close(id, result) {
        const notif = this._alerts().find((n) => n.id === id);
        if (!notif)
            return;
        if (notif.isLeaving)
            return;
        if (notif.willClose) {
            notif.willClose();
        }
        this._alerts.update((nots) => nots.map((n) => (n.id === id ? { ...n, isLeaving: true } : n)));
        if (notif._resolve) {
            notif._resolve(result);
        }
        if (notif.variant === 'modal') {
            // La remoción real queda diferida: AlertModalComponent (PgDialogBase)
            // corre su propia animación de salida y notifica vía (closed) cuando
            // termina — recién ahí el container llama a finalizeRemoval().
            return;
        }
        setTimeout(() => {
            this._alerts.update((nots) => nots.filter((n) => n.id !== id));
            if (notif.didClose) {
                notif.didClose();
            }
        }, 200);
    }
    /**
     * Saca el alert del array + dispara `didClose()`. Se llama desde el
     * container cuando el `(closed)` de `PgDialogBase` confirma que la
     * animación de salida del modal terminó de verdad.
     */
    finalizeRemoval(id) {
        const notif = this._alerts().find((n) => n.id === id);
        if (!notif)
            return;
        this._alerts.update((nots) => nots.filter((n) => n.id !== id));
        if (notif.didClose) {
            notif.didClose();
        }
    }
    remove(id) {
        this.close(id, {
            isConfirmed: false,
            isDenied: false,
            isDismissed: true,
            dismissReason: 'close',
        });
    }
    success(title, message, duration) {
        return this.show({ type: 'success', title, message, duration });
    }
    error(title, message, duration) {
        return this.show({ type: 'error', title, message, duration });
    }
    info(title, message, duration) {
        return this.show({ type: 'info', title, message, duration });
    }
    warning(title, message, duration) {
        return this.show({ type: 'warning', title, message, duration });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: AlertService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: AlertService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: AlertService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

// Mirrors tailwind.preset.js — see colors.{success,error,info,warning} keys.
const ICON_PALETTE = {
    success: { fill: '#20a383', foreground: '#ffffff', tint: '#dcfce7' },
    error: { fill: '#ff2b00', foreground: '#ffffff', tint: '#fee2e2' },
    warning: { fill: '#fbd87f', foreground: '#1f2937', tint: '#fef9c3' },
    info: { fill: '#0074e8', foreground: '#ffffff', tint: '#dbeafe' },
    question: { fill: '#9ca3af', foreground: '#ffffff', tint: '#f3f4f6' },
};
class AlertIconComponent {
    type = input.required();
    size = input('lg');
    hostClass = computed(() => `pg-icon pg-icon-${this.size()} pg-icon-${this.type()}`);
    palette = computed(() => ICON_PALETTE[this.type()]);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: AlertIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: AlertIconComponent, isStandalone: true, selector: "pg-alert-icon", inputs: { type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: true, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "img", "aria-hidden": "true" }, properties: { "class": "hostClass()", "style.--pg-icon-fill": "palette().fill", "style.--pg-icon-fg": "palette().foreground", "style.--pg-icon-tint": "palette().tint" } }, ngImport: i0, template: "<svg class=\"pg-icon-svg\" viewBox=\"0 0 100 100\" xmlns=\"http://www.w3.org/2000/svg\" focusable=\"false\">\n  <g class=\"pg-icon-container\">\n    @switch (type()) {\n      @case ('success') {\n        <path\n          class=\"pg-icon-badge\"\n          d=\"M50.00,4.30 C51.91,4.30 53.99,5.37 55.72,6.53 C57.46,7.68 58.90,9.87 60.39,11.22 C61.88,12.57 63.04,13.95 64.66,14.62 C66.27,15.28 68.07,15.13 70.07,15.23 C72.08,15.33 74.65,14.80 76.69,15.21 C78.73,15.62 80.97,16.34 82.31,17.69 C83.66,19.03 84.38,21.27 84.79,23.31 C85.20,25.35 84.67,27.92 84.77,29.92 C84.87,31.93 84.72,33.73 85.38,35.34 C86.05,36.96 87.43,38.12 88.78,39.61 C90.13,41.10 92.32,42.54 93.47,44.28 C94.63,46.01 95.70,48.09 95.70,50.00 C95.70,51.91 94.63,53.99 93.47,55.72 C92.32,57.46 90.13,58.90 88.78,60.39 C87.43,61.88 86.05,63.04 85.38,64.66 C84.72,66.27 84.87,68.07 84.77,70.07 C84.67,72.08 85.20,74.65 84.79,76.69 C84.38,78.73 83.66,80.97 82.31,82.31 C80.97,83.66 78.73,84.38 76.69,84.79 C74.65,85.20 72.08,84.67 70.07,84.77 C68.07,84.87 66.27,84.72 64.66,85.38 C63.04,86.05 61.88,87.43 60.39,88.78 C58.90,90.13 57.46,92.32 55.72,93.47 C53.99,94.63 51.91,95.70 50.00,95.70 C48.09,95.70 46.01,94.63 44.28,93.47 C42.54,92.32 41.10,90.13 39.61,88.78 C38.12,87.43 36.96,86.05 35.34,85.38 C33.73,84.72 31.93,84.87 29.93,84.77 C27.92,84.67 25.35,85.20 23.31,84.79 C21.27,84.38 19.03,83.66 17.69,82.31 C16.34,80.97 15.62,78.73 15.21,76.69 C14.80,74.65 15.33,72.08 15.23,70.08 C15.13,68.07 15.28,66.27 14.62,64.66 C13.95,63.04 12.57,61.88 11.22,60.39 C9.87,58.90 7.68,57.46 6.53,55.72 C5.37,53.99 4.30,51.91 4.30,50.00 C4.30,48.09 5.37,46.01 6.53,44.28 C7.68,42.54 9.87,41.10 11.22,39.61 C12.57,38.12 13.95,36.96 14.62,35.34 C15.28,33.73 15.13,31.93 15.23,29.92 C15.33,27.92 14.80,25.35 15.21,23.31 C15.62,21.27 16.34,19.03 17.69,17.69 C19.03,16.34 21.27,15.62 23.31,15.21 C25.35,14.80 27.92,15.33 29.92,15.23 C31.93,15.13 33.73,15.28 35.34,14.62 C36.96,13.95 38.12,12.57 39.61,11.22 C41.10,9.87 42.54,7.68 44.28,6.53 C46.01,5.37 48.09,4.30 50.00,4.30Z\"\n        />\n        <polyline class=\"pg-icon-glyph pg-icon-glyph-success\" points=\"27,53 44,68 72,34\" />\n      }\n      @case ('error') {\n        <path\n          class=\"pg-icon-badge\"\n          d=\"M50.00,4.30 C51.91,4.30 53.99,5.37 55.72,6.53 C57.46,7.68 58.90,9.87 60.39,11.22 C61.88,12.57 63.04,13.95 64.66,14.62 C66.27,15.28 68.07,15.13 70.07,15.23 C72.08,15.33 74.65,14.80 76.69,15.21 C78.73,15.62 80.97,16.34 82.31,17.69 C83.66,19.03 84.38,21.27 84.79,23.31 C85.20,25.35 84.67,27.92 84.77,29.92 C84.87,31.93 84.72,33.73 85.38,35.34 C86.05,36.96 87.43,38.12 88.78,39.61 C90.13,41.10 92.32,42.54 93.47,44.28 C94.63,46.01 95.70,48.09 95.70,50.00 C95.70,51.91 94.63,53.99 93.47,55.72 C92.32,57.46 90.13,58.90 88.78,60.39 C87.43,61.88 86.05,63.04 85.38,64.66 C84.72,66.27 84.87,68.07 84.77,70.07 C84.67,72.08 85.20,74.65 84.79,76.69 C84.38,78.73 83.66,80.97 82.31,82.31 C80.97,83.66 78.73,84.38 76.69,84.79 C74.65,85.20 72.08,84.67 70.07,84.77 C68.07,84.87 66.27,84.72 64.66,85.38 C63.04,86.05 61.88,87.43 60.39,88.78 C58.90,90.13 57.46,92.32 55.72,93.47 C53.99,94.63 51.91,95.70 50.00,95.70 C48.09,95.70 46.01,94.63 44.28,93.47 C42.54,92.32 41.10,90.13 39.61,88.78 C38.12,87.43 36.96,86.05 35.34,85.38 C33.73,84.72 31.93,84.87 29.93,84.77 C27.92,84.67 25.35,85.20 23.31,84.79 C21.27,84.38 19.03,83.66 17.69,82.31 C16.34,80.97 15.62,78.73 15.21,76.69 C14.80,74.65 15.33,72.08 15.23,70.08 C15.13,68.07 15.28,66.27 14.62,64.66 C13.95,63.04 12.57,61.88 11.22,60.39 C9.87,58.90 7.68,57.46 6.53,55.72 C5.37,53.99 4.30,51.91 4.30,50.00 C4.30,48.09 5.37,46.01 6.53,44.28 C7.68,42.54 9.87,41.10 11.22,39.61 C12.57,38.12 13.95,36.96 14.62,35.34 C15.28,33.73 15.13,31.93 15.23,29.92 C15.33,27.92 14.80,25.35 15.21,23.31 C15.62,21.27 16.34,19.03 17.69,17.69 C19.03,16.34 21.27,15.62 23.31,15.21 C25.35,14.80 27.92,15.33 29.92,15.23 C31.93,15.13 33.73,15.28 35.34,14.62 C36.96,13.95 38.12,12.57 39.61,11.22 C41.10,9.87 42.54,7.68 44.28,6.53 C46.01,5.37 48.09,4.30 50.00,4.30Z\"\n        />\n        <g class=\"pg-icon-glyph pg-icon-glyph-error\">\n          <line class=\"pg-icon-x pg-icon-x-1\" x1=\"35\" y1=\"35\" x2=\"65\" y2=\"65\" />\n          <line class=\"pg-icon-x pg-icon-x-2\" x1=\"65\" y1=\"35\" x2=\"35\" y2=\"65\" />\n        </g>\n      }\n      @case ('warning') {\n        <path\n          class=\"pg-icon-badge\"\n          d=\"M50.00,4.30 C51.91,4.30 53.99,5.37 55.72,6.53 C57.46,7.68 58.90,9.87 60.39,11.22 C61.88,12.57 63.04,13.95 64.66,14.62 C66.27,15.28 68.07,15.13 70.07,15.23 C72.08,15.33 74.65,14.80 76.69,15.21 C78.73,15.62 80.97,16.34 82.31,17.69 C83.66,19.03 84.38,21.27 84.79,23.31 C85.20,25.35 84.67,27.92 84.77,29.92 C84.87,31.93 84.72,33.73 85.38,35.34 C86.05,36.96 87.43,38.12 88.78,39.61 C90.13,41.10 92.32,42.54 93.47,44.28 C94.63,46.01 95.70,48.09 95.70,50.00 C95.70,51.91 94.63,53.99 93.47,55.72 C92.32,57.46 90.13,58.90 88.78,60.39 C87.43,61.88 86.05,63.04 85.38,64.66 C84.72,66.27 84.87,68.07 84.77,70.07 C84.67,72.08 85.20,74.65 84.79,76.69 C84.38,78.73 83.66,80.97 82.31,82.31 C80.97,83.66 78.73,84.38 76.69,84.79 C74.65,85.20 72.08,84.67 70.07,84.77 C68.07,84.87 66.27,84.72 64.66,85.38 C63.04,86.05 61.88,87.43 60.39,88.78 C58.90,90.13 57.46,92.32 55.72,93.47 C53.99,94.63 51.91,95.70 50.00,95.70 C48.09,95.70 46.01,94.63 44.28,93.47 C42.54,92.32 41.10,90.13 39.61,88.78 C38.12,87.43 36.96,86.05 35.34,85.38 C33.73,84.72 31.93,84.87 29.93,84.77 C27.92,84.67 25.35,85.20 23.31,84.79 C21.27,84.38 19.03,83.66 17.69,82.31 C16.34,80.97 15.62,78.73 15.21,76.69 C14.80,74.65 15.33,72.08 15.23,70.08 C15.13,68.07 15.28,66.27 14.62,64.66 C13.95,63.04 12.57,61.88 11.22,60.39 C9.87,58.90 7.68,57.46 6.53,55.72 C5.37,53.99 4.30,51.91 4.30,50.00 C4.30,48.09 5.37,46.01 6.53,44.28 C7.68,42.54 9.87,41.10 11.22,39.61 C12.57,38.12 13.95,36.96 14.62,35.34 C15.28,33.73 15.13,31.93 15.23,29.92 C15.33,27.92 14.80,25.35 15.21,23.31 C15.62,21.27 16.34,19.03 17.69,17.69 C19.03,16.34 21.27,15.62 23.31,15.21 C25.35,14.80 27.92,15.33 29.92,15.23 C31.93,15.13 33.73,15.28 35.34,14.62 C36.96,13.95 38.12,12.57 39.61,11.22 C41.10,9.87 42.54,7.68 44.28,6.53 C46.01,5.37 48.09,4.30 50.00,4.30Z\"\n        />\n        <g class=\"pg-icon-glyph pg-icon-glyph-warning\">\n          <line class=\"pg-icon-bar\" x1=\"50\" y1=\"30\" x2=\"50\" y2=\"58\" />\n          <circle class=\"pg-icon-dot\" cx=\"50\" cy=\"70\" r=\"3.5\" />\n        </g>\n      }\n      @case ('info') {\n        <path\n          class=\"pg-icon-badge\"\n          d=\"M50.00,4.30 C51.91,4.30 53.99,5.37 55.72,6.53 C57.46,7.68 58.90,9.87 60.39,11.22 C61.88,12.57 63.04,13.95 64.66,14.62 C66.27,15.28 68.07,15.13 70.07,15.23 C72.08,15.33 74.65,14.80 76.69,15.21 C78.73,15.62 80.97,16.34 82.31,17.69 C83.66,19.03 84.38,21.27 84.79,23.31 C85.20,25.35 84.67,27.92 84.77,29.92 C84.87,31.93 84.72,33.73 85.38,35.34 C86.05,36.96 87.43,38.12 88.78,39.61 C90.13,41.10 92.32,42.54 93.47,44.28 C94.63,46.01 95.70,48.09 95.70,50.00 C95.70,51.91 94.63,53.99 93.47,55.72 C92.32,57.46 90.13,58.90 88.78,60.39 C87.43,61.88 86.05,63.04 85.38,64.66 C84.72,66.27 84.87,68.07 84.77,70.07 C84.67,72.08 85.20,74.65 84.79,76.69 C84.38,78.73 83.66,80.97 82.31,82.31 C80.97,83.66 78.73,84.38 76.69,84.79 C74.65,85.20 72.08,84.67 70.07,84.77 C68.07,84.87 66.27,84.72 64.66,85.38 C63.04,86.05 61.88,87.43 60.39,88.78 C58.90,90.13 57.46,92.32 55.72,93.47 C53.99,94.63 51.91,95.70 50.00,95.70 C48.09,95.70 46.01,94.63 44.28,93.47 C42.54,92.32 41.10,90.13 39.61,88.78 C38.12,87.43 36.96,86.05 35.34,85.38 C33.73,84.72 31.93,84.87 29.93,84.77 C27.92,84.67 25.35,85.20 23.31,84.79 C21.27,84.38 19.03,83.66 17.69,82.31 C16.34,80.97 15.62,78.73 15.21,76.69 C14.80,74.65 15.33,72.08 15.23,70.08 C15.13,68.07 15.28,66.27 14.62,64.66 C13.95,63.04 12.57,61.88 11.22,60.39 C9.87,58.90 7.68,57.46 6.53,55.72 C5.37,53.99 4.30,51.91 4.30,50.00 C4.30,48.09 5.37,46.01 6.53,44.28 C7.68,42.54 9.87,41.10 11.22,39.61 C12.57,38.12 13.95,36.96 14.62,35.34 C15.28,33.73 15.13,31.93 15.23,29.92 C15.33,27.92 14.80,25.35 15.21,23.31 C15.62,21.27 16.34,19.03 17.69,17.69 C19.03,16.34 21.27,15.62 23.31,15.21 C25.35,14.80 27.92,15.33 29.92,15.23 C31.93,15.13 33.73,15.28 35.34,14.62 C36.96,13.95 38.12,12.57 39.61,11.22 C41.10,9.87 42.54,7.68 44.28,6.53 C46.01,5.37 48.09,4.30 50.00,4.30Z\"\n        />\n        <g class=\"pg-icon-glyph pg-icon-glyph-info\">\n          <circle class=\"pg-icon-dot pg-icon-dot-top\" cx=\"50\" cy=\"32\" r=\"3.5\" />\n          <line class=\"pg-icon-bar\" x1=\"50\" y1=\"42\" x2=\"50\" y2=\"72\" />\n        </g>\n      }\n      @case ('question') {\n        <path\n          class=\"pg-icon-badge\"\n          d=\"M50.00,4.30 C51.91,4.30 53.99,5.37 55.72,6.53 C57.46,7.68 58.90,9.87 60.39,11.22 C61.88,12.57 63.04,13.95 64.66,14.62 C66.27,15.28 68.07,15.13 70.07,15.23 C72.08,15.33 74.65,14.80 76.69,15.21 C78.73,15.62 80.97,16.34 82.31,17.69 C83.66,19.03 84.38,21.27 84.79,23.31 C85.20,25.35 84.67,27.92 84.77,29.92 C84.87,31.93 84.72,33.73 85.38,35.34 C86.05,36.96 87.43,38.12 88.78,39.61 C90.13,41.10 92.32,42.54 93.47,44.28 C94.63,46.01 95.70,48.09 95.70,50.00 C95.70,51.91 94.63,53.99 93.47,55.72 C92.32,57.46 90.13,58.90 88.78,60.39 C87.43,61.88 86.05,63.04 85.38,64.66 C84.72,66.27 84.87,68.07 84.77,70.07 C84.67,72.08 85.20,74.65 84.79,76.69 C84.38,78.73 83.66,80.97 82.31,82.31 C80.97,83.66 78.73,84.38 76.69,84.79 C74.65,85.20 72.08,84.67 70.07,84.77 C68.07,84.87 66.27,84.72 64.66,85.38 C63.04,86.05 61.88,87.43 60.39,88.78 C58.90,90.13 57.46,92.32 55.72,93.47 C53.99,94.63 51.91,95.70 50.00,95.70 C48.09,95.70 46.01,94.63 44.28,93.47 C42.54,92.32 41.10,90.13 39.61,88.78 C38.12,87.43 36.96,86.05 35.34,85.38 C33.73,84.72 31.93,84.87 29.93,84.77 C27.92,84.67 25.35,85.20 23.31,84.79 C21.27,84.38 19.03,83.66 17.69,82.31 C16.34,80.97 15.62,78.73 15.21,76.69 C14.80,74.65 15.33,72.08 15.23,70.08 C15.13,68.07 15.28,66.27 14.62,64.66 C13.95,63.04 12.57,61.88 11.22,60.39 C9.87,58.90 7.68,57.46 6.53,55.72 C5.37,53.99 4.30,51.91 4.30,50.00 C4.30,48.09 5.37,46.01 6.53,44.28 C7.68,42.54 9.87,41.10 11.22,39.61 C12.57,38.12 13.95,36.96 14.62,35.34 C15.28,33.73 15.13,31.93 15.23,29.92 C15.33,27.92 14.80,25.35 15.21,23.31 C15.62,21.27 16.34,19.03 17.69,17.69 C19.03,16.34 21.27,15.62 23.31,15.21 C25.35,14.80 27.92,15.33 29.92,15.23 C31.93,15.13 33.73,15.28 35.34,14.62 C36.96,13.95 38.12,12.57 39.61,11.22 C41.10,9.87 42.54,7.68 44.28,6.53 C46.01,5.37 48.09,4.30 50.00,4.30Z\"\n        />\n        <g class=\"pg-icon-glyph pg-icon-glyph-question\">\n          <path class=\"pg-icon-curve\" d=\"M40 40 Q40 28 50 28 Q60 28 60 38 Q60 46 50 50 L50 58\" />\n          <circle class=\"pg-icon-dot\" cx=\"50\" cy=\"70\" r=\"3.5\" />\n        </g>\n      }\n    }\n  </g>\n</svg>\n", styles: [":host{display:inline-flex;align-items:center;justify-content:center;border-radius:9999px}:host.pg-icon-xl{width:64px;height:64px}:host.pg-icon-lg{width:48px;height:48px}:host.pg-icon-sm{width:24px;height:24px}.pg-icon-svg{width:80%;height:80%;overflow:visible}.pg-icon-container{transform-origin:50px 50px}.pg-icon-badge{fill:var(--pg-icon-fill);transform:scale(0);transform-origin:50px 50px}@keyframes pg-icon-draw-glyph{to{stroke-dashoffset:0}}@keyframes pg-icon-pop{to{transform:scale(1)}}@keyframes pg-icon-badge-pop{to{transform:scale(1)}}@keyframes pg-icon-elastic{0%{transform:scale(1)}50%{transform:scale(1.15)}to{transform:scale(1)}}@keyframes pg-icon-shake{0%,to{transform:translate(0)}25%{transform:translate(-3px)}75%{transform:translate(3px)}}@keyframes pg-icon-bounce-y{0%,to{transform:translateY(0)}50%{transform:translateY(-4px)}}.pg-icon-glyph-success{fill:none;stroke:var(--pg-icon-fg);stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:70;stroke-dashoffset:70}:host.pg-icon-xl .pg-icon-glyph-success{stroke-width:6}:host.pg-icon-lg .pg-icon-glyph-success{stroke-width:7}:host.pg-icon-sm .pg-icon-glyph-success{stroke-width:9}.pg-icon-glyph-error .pg-icon-x{stroke:var(--pg-icon-fg);stroke-linecap:round;stroke-dasharray:43;stroke-dashoffset:43}:host.pg-icon-xl .pg-icon-glyph-error .pg-icon-x{stroke-width:5}:host.pg-icon-lg .pg-icon-glyph-error .pg-icon-x{stroke-width:6}:host.pg-icon-sm .pg-icon-glyph-error .pg-icon-x{stroke-width:8}.pg-icon-glyph-warning .pg-icon-bar{stroke:var(--pg-icon-fg);stroke-linecap:round;stroke-dasharray:28;stroke-dashoffset:28}.pg-icon-glyph-warning .pg-icon-dot{fill:var(--pg-icon-fg);transform:scale(0);transform-origin:50px 70px}:host.pg-icon-xl .pg-icon-glyph-warning .pg-icon-bar{stroke-width:5}:host.pg-icon-lg .pg-icon-glyph-warning .pg-icon-bar{stroke-width:6}:host.pg-icon-sm .pg-icon-glyph-warning .pg-icon-bar{stroke-width:8}.pg-icon-glyph-info .pg-icon-bar{stroke:var(--pg-icon-fg);stroke-linecap:round;stroke-dasharray:30;stroke-dashoffset:30}.pg-icon-glyph-info .pg-icon-dot{fill:var(--pg-icon-fg);transform:scale(0);transform-origin:50px 32px}:host.pg-icon-xl .pg-icon-glyph-info .pg-icon-bar{stroke-width:5}:host.pg-icon-lg .pg-icon-glyph-info .pg-icon-bar{stroke-width:6}:host.pg-icon-sm .pg-icon-glyph-info .pg-icon-bar{stroke-width:8}.pg-icon-glyph-question .pg-icon-curve{fill:none;stroke:var(--pg-icon-fg);stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:55;stroke-dashoffset:55}.pg-icon-glyph-question .pg-icon-dot{fill:var(--pg-icon-fg);transform:scale(0);transform-origin:50px 70px}:host.pg-icon-xl .pg-icon-glyph-question .pg-icon-curve{stroke-width:5}:host.pg-icon-lg .pg-icon-glyph-question .pg-icon-curve{stroke-width:6}:host.pg-icon-sm .pg-icon-glyph-question .pg-icon-curve{stroke-width:8}@media(prefers-reduced-motion:no-preference){:host.pg-icon-xl .pg-icon-badge,:host.pg-icon-lg .pg-icon-badge{animation:pg-icon-badge-pop .5s cubic-bezier(.34,1.56,.64,1) forwards}:host.pg-icon-sm .pg-icon-badge{animation:pg-icon-badge-pop .35s cubic-bezier(.34,1.56,.64,1) forwards}:host.pg-icon-xl .pg-icon-glyph-success,:host.pg-icon-lg .pg-icon-glyph-success{animation:pg-icon-draw-glyph .4s .42s ease-out forwards}:host.pg-icon-sm .pg-icon-glyph-success{animation:pg-icon-draw-glyph .28s .29s ease-out forwards}:host.pg-icon-xl .pg-icon-x-1,:host.pg-icon-lg .pg-icon-x-1{animation:pg-icon-draw-glyph .3s .7s ease-out forwards}:host.pg-icon-xl .pg-icon-x-2,:host.pg-icon-lg .pg-icon-x-2{animation:pg-icon-draw-glyph .3s .9s ease-out forwards}:host.pg-icon-sm .pg-icon-x-1{animation:pg-icon-draw-glyph .2s .5s ease-out forwards}:host.pg-icon-sm .pg-icon-x-2{animation:pg-icon-draw-glyph .2s .65s ease-out forwards}:host.pg-icon-xl.pg-icon-error .pg-icon-container,:host.pg-icon-lg.pg-icon-error .pg-icon-container{animation:pg-icon-shake .4s 1.1s ease-in-out}:host.pg-icon-xl .pg-icon-glyph-warning .pg-icon-bar,:host.pg-icon-lg .pg-icon-glyph-warning .pg-icon-bar{animation:pg-icon-draw-glyph .3s .7s ease-out forwards}:host.pg-icon-xl .pg-icon-glyph-warning .pg-icon-dot,:host.pg-icon-lg .pg-icon-glyph-warning .pg-icon-dot{animation:pg-icon-pop .25s 1.05s cubic-bezier(.25,1,.5,1.5) forwards}:host.pg-icon-sm .pg-icon-glyph-warning .pg-icon-bar{animation:pg-icon-draw-glyph .2s .5s ease-out forwards}:host.pg-icon-sm .pg-icon-glyph-warning .pg-icon-dot{animation:pg-icon-pop .2s .75s ease-out forwards}:host.pg-icon-xl.pg-icon-warning .pg-icon-container,:host.pg-icon-lg.pg-icon-warning .pg-icon-container{animation:pg-icon-bounce-y .5s 1.3s ease-out}:host.pg-icon-xl .pg-icon-glyph-info .pg-icon-dot,:host.pg-icon-lg .pg-icon-glyph-info .pg-icon-dot{animation:pg-icon-pop .25s .7s cubic-bezier(.25,1,.5,1.5) forwards}:host.pg-icon-xl .pg-icon-glyph-info .pg-icon-bar,:host.pg-icon-lg .pg-icon-glyph-info .pg-icon-bar{animation:pg-icon-draw-glyph .3s .9s ease-out forwards}:host.pg-icon-sm .pg-icon-glyph-info .pg-icon-dot{animation:pg-icon-pop .2s .5s ease-out forwards}:host.pg-icon-sm .pg-icon-glyph-info .pg-icon-bar{animation:pg-icon-draw-glyph .2s .65s ease-out forwards}:host.pg-icon-xl .pg-icon-glyph-question .pg-icon-curve,:host.pg-icon-lg .pg-icon-glyph-question .pg-icon-curve{animation:pg-icon-draw-glyph .4s .7s ease-out forwards}:host.pg-icon-xl .pg-icon-glyph-question .pg-icon-dot,:host.pg-icon-lg .pg-icon-glyph-question .pg-icon-dot{animation:pg-icon-pop .25s 1.1s cubic-bezier(.25,1,.5,1.5) forwards}:host.pg-icon-sm .pg-icon-glyph-question .pg-icon-curve{animation:pg-icon-draw-glyph .3s .5s ease-out forwards}:host.pg-icon-sm .pg-icon-glyph-question .pg-icon-dot{animation:pg-icon-pop .2s .8s ease-out forwards}}@media(prefers-reduced-motion:reduce){.pg-icon-badge{transform:scale(1)}.pg-icon-glyph,.pg-icon-glyph *{stroke-dashoffset:0;transform:scale(1)}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: AlertIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-alert-icon', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        '[class]': 'hostClass()',
                        '[style.--pg-icon-fill]': 'palette().fill',
                        '[style.--pg-icon-fg]': 'palette().foreground',
                        '[style.--pg-icon-tint]': 'palette().tint',
                        role: 'img',
                        'aria-hidden': 'true',
                    }, template: "<svg class=\"pg-icon-svg\" viewBox=\"0 0 100 100\" xmlns=\"http://www.w3.org/2000/svg\" focusable=\"false\">\n  <g class=\"pg-icon-container\">\n    @switch (type()) {\n      @case ('success') {\n        <path\n          class=\"pg-icon-badge\"\n          d=\"M50.00,4.30 C51.91,4.30 53.99,5.37 55.72,6.53 C57.46,7.68 58.90,9.87 60.39,11.22 C61.88,12.57 63.04,13.95 64.66,14.62 C66.27,15.28 68.07,15.13 70.07,15.23 C72.08,15.33 74.65,14.80 76.69,15.21 C78.73,15.62 80.97,16.34 82.31,17.69 C83.66,19.03 84.38,21.27 84.79,23.31 C85.20,25.35 84.67,27.92 84.77,29.92 C84.87,31.93 84.72,33.73 85.38,35.34 C86.05,36.96 87.43,38.12 88.78,39.61 C90.13,41.10 92.32,42.54 93.47,44.28 C94.63,46.01 95.70,48.09 95.70,50.00 C95.70,51.91 94.63,53.99 93.47,55.72 C92.32,57.46 90.13,58.90 88.78,60.39 C87.43,61.88 86.05,63.04 85.38,64.66 C84.72,66.27 84.87,68.07 84.77,70.07 C84.67,72.08 85.20,74.65 84.79,76.69 C84.38,78.73 83.66,80.97 82.31,82.31 C80.97,83.66 78.73,84.38 76.69,84.79 C74.65,85.20 72.08,84.67 70.07,84.77 C68.07,84.87 66.27,84.72 64.66,85.38 C63.04,86.05 61.88,87.43 60.39,88.78 C58.90,90.13 57.46,92.32 55.72,93.47 C53.99,94.63 51.91,95.70 50.00,95.70 C48.09,95.70 46.01,94.63 44.28,93.47 C42.54,92.32 41.10,90.13 39.61,88.78 C38.12,87.43 36.96,86.05 35.34,85.38 C33.73,84.72 31.93,84.87 29.93,84.77 C27.92,84.67 25.35,85.20 23.31,84.79 C21.27,84.38 19.03,83.66 17.69,82.31 C16.34,80.97 15.62,78.73 15.21,76.69 C14.80,74.65 15.33,72.08 15.23,70.08 C15.13,68.07 15.28,66.27 14.62,64.66 C13.95,63.04 12.57,61.88 11.22,60.39 C9.87,58.90 7.68,57.46 6.53,55.72 C5.37,53.99 4.30,51.91 4.30,50.00 C4.30,48.09 5.37,46.01 6.53,44.28 C7.68,42.54 9.87,41.10 11.22,39.61 C12.57,38.12 13.95,36.96 14.62,35.34 C15.28,33.73 15.13,31.93 15.23,29.92 C15.33,27.92 14.80,25.35 15.21,23.31 C15.62,21.27 16.34,19.03 17.69,17.69 C19.03,16.34 21.27,15.62 23.31,15.21 C25.35,14.80 27.92,15.33 29.92,15.23 C31.93,15.13 33.73,15.28 35.34,14.62 C36.96,13.95 38.12,12.57 39.61,11.22 C41.10,9.87 42.54,7.68 44.28,6.53 C46.01,5.37 48.09,4.30 50.00,4.30Z\"\n        />\n        <polyline class=\"pg-icon-glyph pg-icon-glyph-success\" points=\"27,53 44,68 72,34\" />\n      }\n      @case ('error') {\n        <path\n          class=\"pg-icon-badge\"\n          d=\"M50.00,4.30 C51.91,4.30 53.99,5.37 55.72,6.53 C57.46,7.68 58.90,9.87 60.39,11.22 C61.88,12.57 63.04,13.95 64.66,14.62 C66.27,15.28 68.07,15.13 70.07,15.23 C72.08,15.33 74.65,14.80 76.69,15.21 C78.73,15.62 80.97,16.34 82.31,17.69 C83.66,19.03 84.38,21.27 84.79,23.31 C85.20,25.35 84.67,27.92 84.77,29.92 C84.87,31.93 84.72,33.73 85.38,35.34 C86.05,36.96 87.43,38.12 88.78,39.61 C90.13,41.10 92.32,42.54 93.47,44.28 C94.63,46.01 95.70,48.09 95.70,50.00 C95.70,51.91 94.63,53.99 93.47,55.72 C92.32,57.46 90.13,58.90 88.78,60.39 C87.43,61.88 86.05,63.04 85.38,64.66 C84.72,66.27 84.87,68.07 84.77,70.07 C84.67,72.08 85.20,74.65 84.79,76.69 C84.38,78.73 83.66,80.97 82.31,82.31 C80.97,83.66 78.73,84.38 76.69,84.79 C74.65,85.20 72.08,84.67 70.07,84.77 C68.07,84.87 66.27,84.72 64.66,85.38 C63.04,86.05 61.88,87.43 60.39,88.78 C58.90,90.13 57.46,92.32 55.72,93.47 C53.99,94.63 51.91,95.70 50.00,95.70 C48.09,95.70 46.01,94.63 44.28,93.47 C42.54,92.32 41.10,90.13 39.61,88.78 C38.12,87.43 36.96,86.05 35.34,85.38 C33.73,84.72 31.93,84.87 29.93,84.77 C27.92,84.67 25.35,85.20 23.31,84.79 C21.27,84.38 19.03,83.66 17.69,82.31 C16.34,80.97 15.62,78.73 15.21,76.69 C14.80,74.65 15.33,72.08 15.23,70.08 C15.13,68.07 15.28,66.27 14.62,64.66 C13.95,63.04 12.57,61.88 11.22,60.39 C9.87,58.90 7.68,57.46 6.53,55.72 C5.37,53.99 4.30,51.91 4.30,50.00 C4.30,48.09 5.37,46.01 6.53,44.28 C7.68,42.54 9.87,41.10 11.22,39.61 C12.57,38.12 13.95,36.96 14.62,35.34 C15.28,33.73 15.13,31.93 15.23,29.92 C15.33,27.92 14.80,25.35 15.21,23.31 C15.62,21.27 16.34,19.03 17.69,17.69 C19.03,16.34 21.27,15.62 23.31,15.21 C25.35,14.80 27.92,15.33 29.92,15.23 C31.93,15.13 33.73,15.28 35.34,14.62 C36.96,13.95 38.12,12.57 39.61,11.22 C41.10,9.87 42.54,7.68 44.28,6.53 C46.01,5.37 48.09,4.30 50.00,4.30Z\"\n        />\n        <g class=\"pg-icon-glyph pg-icon-glyph-error\">\n          <line class=\"pg-icon-x pg-icon-x-1\" x1=\"35\" y1=\"35\" x2=\"65\" y2=\"65\" />\n          <line class=\"pg-icon-x pg-icon-x-2\" x1=\"65\" y1=\"35\" x2=\"35\" y2=\"65\" />\n        </g>\n      }\n      @case ('warning') {\n        <path\n          class=\"pg-icon-badge\"\n          d=\"M50.00,4.30 C51.91,4.30 53.99,5.37 55.72,6.53 C57.46,7.68 58.90,9.87 60.39,11.22 C61.88,12.57 63.04,13.95 64.66,14.62 C66.27,15.28 68.07,15.13 70.07,15.23 C72.08,15.33 74.65,14.80 76.69,15.21 C78.73,15.62 80.97,16.34 82.31,17.69 C83.66,19.03 84.38,21.27 84.79,23.31 C85.20,25.35 84.67,27.92 84.77,29.92 C84.87,31.93 84.72,33.73 85.38,35.34 C86.05,36.96 87.43,38.12 88.78,39.61 C90.13,41.10 92.32,42.54 93.47,44.28 C94.63,46.01 95.70,48.09 95.70,50.00 C95.70,51.91 94.63,53.99 93.47,55.72 C92.32,57.46 90.13,58.90 88.78,60.39 C87.43,61.88 86.05,63.04 85.38,64.66 C84.72,66.27 84.87,68.07 84.77,70.07 C84.67,72.08 85.20,74.65 84.79,76.69 C84.38,78.73 83.66,80.97 82.31,82.31 C80.97,83.66 78.73,84.38 76.69,84.79 C74.65,85.20 72.08,84.67 70.07,84.77 C68.07,84.87 66.27,84.72 64.66,85.38 C63.04,86.05 61.88,87.43 60.39,88.78 C58.90,90.13 57.46,92.32 55.72,93.47 C53.99,94.63 51.91,95.70 50.00,95.70 C48.09,95.70 46.01,94.63 44.28,93.47 C42.54,92.32 41.10,90.13 39.61,88.78 C38.12,87.43 36.96,86.05 35.34,85.38 C33.73,84.72 31.93,84.87 29.93,84.77 C27.92,84.67 25.35,85.20 23.31,84.79 C21.27,84.38 19.03,83.66 17.69,82.31 C16.34,80.97 15.62,78.73 15.21,76.69 C14.80,74.65 15.33,72.08 15.23,70.08 C15.13,68.07 15.28,66.27 14.62,64.66 C13.95,63.04 12.57,61.88 11.22,60.39 C9.87,58.90 7.68,57.46 6.53,55.72 C5.37,53.99 4.30,51.91 4.30,50.00 C4.30,48.09 5.37,46.01 6.53,44.28 C7.68,42.54 9.87,41.10 11.22,39.61 C12.57,38.12 13.95,36.96 14.62,35.34 C15.28,33.73 15.13,31.93 15.23,29.92 C15.33,27.92 14.80,25.35 15.21,23.31 C15.62,21.27 16.34,19.03 17.69,17.69 C19.03,16.34 21.27,15.62 23.31,15.21 C25.35,14.80 27.92,15.33 29.92,15.23 C31.93,15.13 33.73,15.28 35.34,14.62 C36.96,13.95 38.12,12.57 39.61,11.22 C41.10,9.87 42.54,7.68 44.28,6.53 C46.01,5.37 48.09,4.30 50.00,4.30Z\"\n        />\n        <g class=\"pg-icon-glyph pg-icon-glyph-warning\">\n          <line class=\"pg-icon-bar\" x1=\"50\" y1=\"30\" x2=\"50\" y2=\"58\" />\n          <circle class=\"pg-icon-dot\" cx=\"50\" cy=\"70\" r=\"3.5\" />\n        </g>\n      }\n      @case ('info') {\n        <path\n          class=\"pg-icon-badge\"\n          d=\"M50.00,4.30 C51.91,4.30 53.99,5.37 55.72,6.53 C57.46,7.68 58.90,9.87 60.39,11.22 C61.88,12.57 63.04,13.95 64.66,14.62 C66.27,15.28 68.07,15.13 70.07,15.23 C72.08,15.33 74.65,14.80 76.69,15.21 C78.73,15.62 80.97,16.34 82.31,17.69 C83.66,19.03 84.38,21.27 84.79,23.31 C85.20,25.35 84.67,27.92 84.77,29.92 C84.87,31.93 84.72,33.73 85.38,35.34 C86.05,36.96 87.43,38.12 88.78,39.61 C90.13,41.10 92.32,42.54 93.47,44.28 C94.63,46.01 95.70,48.09 95.70,50.00 C95.70,51.91 94.63,53.99 93.47,55.72 C92.32,57.46 90.13,58.90 88.78,60.39 C87.43,61.88 86.05,63.04 85.38,64.66 C84.72,66.27 84.87,68.07 84.77,70.07 C84.67,72.08 85.20,74.65 84.79,76.69 C84.38,78.73 83.66,80.97 82.31,82.31 C80.97,83.66 78.73,84.38 76.69,84.79 C74.65,85.20 72.08,84.67 70.07,84.77 C68.07,84.87 66.27,84.72 64.66,85.38 C63.04,86.05 61.88,87.43 60.39,88.78 C58.90,90.13 57.46,92.32 55.72,93.47 C53.99,94.63 51.91,95.70 50.00,95.70 C48.09,95.70 46.01,94.63 44.28,93.47 C42.54,92.32 41.10,90.13 39.61,88.78 C38.12,87.43 36.96,86.05 35.34,85.38 C33.73,84.72 31.93,84.87 29.93,84.77 C27.92,84.67 25.35,85.20 23.31,84.79 C21.27,84.38 19.03,83.66 17.69,82.31 C16.34,80.97 15.62,78.73 15.21,76.69 C14.80,74.65 15.33,72.08 15.23,70.08 C15.13,68.07 15.28,66.27 14.62,64.66 C13.95,63.04 12.57,61.88 11.22,60.39 C9.87,58.90 7.68,57.46 6.53,55.72 C5.37,53.99 4.30,51.91 4.30,50.00 C4.30,48.09 5.37,46.01 6.53,44.28 C7.68,42.54 9.87,41.10 11.22,39.61 C12.57,38.12 13.95,36.96 14.62,35.34 C15.28,33.73 15.13,31.93 15.23,29.92 C15.33,27.92 14.80,25.35 15.21,23.31 C15.62,21.27 16.34,19.03 17.69,17.69 C19.03,16.34 21.27,15.62 23.31,15.21 C25.35,14.80 27.92,15.33 29.92,15.23 C31.93,15.13 33.73,15.28 35.34,14.62 C36.96,13.95 38.12,12.57 39.61,11.22 C41.10,9.87 42.54,7.68 44.28,6.53 C46.01,5.37 48.09,4.30 50.00,4.30Z\"\n        />\n        <g class=\"pg-icon-glyph pg-icon-glyph-info\">\n          <circle class=\"pg-icon-dot pg-icon-dot-top\" cx=\"50\" cy=\"32\" r=\"3.5\" />\n          <line class=\"pg-icon-bar\" x1=\"50\" y1=\"42\" x2=\"50\" y2=\"72\" />\n        </g>\n      }\n      @case ('question') {\n        <path\n          class=\"pg-icon-badge\"\n          d=\"M50.00,4.30 C51.91,4.30 53.99,5.37 55.72,6.53 C57.46,7.68 58.90,9.87 60.39,11.22 C61.88,12.57 63.04,13.95 64.66,14.62 C66.27,15.28 68.07,15.13 70.07,15.23 C72.08,15.33 74.65,14.80 76.69,15.21 C78.73,15.62 80.97,16.34 82.31,17.69 C83.66,19.03 84.38,21.27 84.79,23.31 C85.20,25.35 84.67,27.92 84.77,29.92 C84.87,31.93 84.72,33.73 85.38,35.34 C86.05,36.96 87.43,38.12 88.78,39.61 C90.13,41.10 92.32,42.54 93.47,44.28 C94.63,46.01 95.70,48.09 95.70,50.00 C95.70,51.91 94.63,53.99 93.47,55.72 C92.32,57.46 90.13,58.90 88.78,60.39 C87.43,61.88 86.05,63.04 85.38,64.66 C84.72,66.27 84.87,68.07 84.77,70.07 C84.67,72.08 85.20,74.65 84.79,76.69 C84.38,78.73 83.66,80.97 82.31,82.31 C80.97,83.66 78.73,84.38 76.69,84.79 C74.65,85.20 72.08,84.67 70.07,84.77 C68.07,84.87 66.27,84.72 64.66,85.38 C63.04,86.05 61.88,87.43 60.39,88.78 C58.90,90.13 57.46,92.32 55.72,93.47 C53.99,94.63 51.91,95.70 50.00,95.70 C48.09,95.70 46.01,94.63 44.28,93.47 C42.54,92.32 41.10,90.13 39.61,88.78 C38.12,87.43 36.96,86.05 35.34,85.38 C33.73,84.72 31.93,84.87 29.93,84.77 C27.92,84.67 25.35,85.20 23.31,84.79 C21.27,84.38 19.03,83.66 17.69,82.31 C16.34,80.97 15.62,78.73 15.21,76.69 C14.80,74.65 15.33,72.08 15.23,70.08 C15.13,68.07 15.28,66.27 14.62,64.66 C13.95,63.04 12.57,61.88 11.22,60.39 C9.87,58.90 7.68,57.46 6.53,55.72 C5.37,53.99 4.30,51.91 4.30,50.00 C4.30,48.09 5.37,46.01 6.53,44.28 C7.68,42.54 9.87,41.10 11.22,39.61 C12.57,38.12 13.95,36.96 14.62,35.34 C15.28,33.73 15.13,31.93 15.23,29.92 C15.33,27.92 14.80,25.35 15.21,23.31 C15.62,21.27 16.34,19.03 17.69,17.69 C19.03,16.34 21.27,15.62 23.31,15.21 C25.35,14.80 27.92,15.33 29.92,15.23 C31.93,15.13 33.73,15.28 35.34,14.62 C36.96,13.95 38.12,12.57 39.61,11.22 C41.10,9.87 42.54,7.68 44.28,6.53 C46.01,5.37 48.09,4.30 50.00,4.30Z\"\n        />\n        <g class=\"pg-icon-glyph pg-icon-glyph-question\">\n          <path class=\"pg-icon-curve\" d=\"M40 40 Q40 28 50 28 Q60 28 60 38 Q60 46 50 50 L50 58\" />\n          <circle class=\"pg-icon-dot\" cx=\"50\" cy=\"70\" r=\"3.5\" />\n        </g>\n      }\n    }\n  </g>\n</svg>\n", styles: [":host{display:inline-flex;align-items:center;justify-content:center;border-radius:9999px}:host.pg-icon-xl{width:64px;height:64px}:host.pg-icon-lg{width:48px;height:48px}:host.pg-icon-sm{width:24px;height:24px}.pg-icon-svg{width:80%;height:80%;overflow:visible}.pg-icon-container{transform-origin:50px 50px}.pg-icon-badge{fill:var(--pg-icon-fill);transform:scale(0);transform-origin:50px 50px}@keyframes pg-icon-draw-glyph{to{stroke-dashoffset:0}}@keyframes pg-icon-pop{to{transform:scale(1)}}@keyframes pg-icon-badge-pop{to{transform:scale(1)}}@keyframes pg-icon-elastic{0%{transform:scale(1)}50%{transform:scale(1.15)}to{transform:scale(1)}}@keyframes pg-icon-shake{0%,to{transform:translate(0)}25%{transform:translate(-3px)}75%{transform:translate(3px)}}@keyframes pg-icon-bounce-y{0%,to{transform:translateY(0)}50%{transform:translateY(-4px)}}.pg-icon-glyph-success{fill:none;stroke:var(--pg-icon-fg);stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:70;stroke-dashoffset:70}:host.pg-icon-xl .pg-icon-glyph-success{stroke-width:6}:host.pg-icon-lg .pg-icon-glyph-success{stroke-width:7}:host.pg-icon-sm .pg-icon-glyph-success{stroke-width:9}.pg-icon-glyph-error .pg-icon-x{stroke:var(--pg-icon-fg);stroke-linecap:round;stroke-dasharray:43;stroke-dashoffset:43}:host.pg-icon-xl .pg-icon-glyph-error .pg-icon-x{stroke-width:5}:host.pg-icon-lg .pg-icon-glyph-error .pg-icon-x{stroke-width:6}:host.pg-icon-sm .pg-icon-glyph-error .pg-icon-x{stroke-width:8}.pg-icon-glyph-warning .pg-icon-bar{stroke:var(--pg-icon-fg);stroke-linecap:round;stroke-dasharray:28;stroke-dashoffset:28}.pg-icon-glyph-warning .pg-icon-dot{fill:var(--pg-icon-fg);transform:scale(0);transform-origin:50px 70px}:host.pg-icon-xl .pg-icon-glyph-warning .pg-icon-bar{stroke-width:5}:host.pg-icon-lg .pg-icon-glyph-warning .pg-icon-bar{stroke-width:6}:host.pg-icon-sm .pg-icon-glyph-warning .pg-icon-bar{stroke-width:8}.pg-icon-glyph-info .pg-icon-bar{stroke:var(--pg-icon-fg);stroke-linecap:round;stroke-dasharray:30;stroke-dashoffset:30}.pg-icon-glyph-info .pg-icon-dot{fill:var(--pg-icon-fg);transform:scale(0);transform-origin:50px 32px}:host.pg-icon-xl .pg-icon-glyph-info .pg-icon-bar{stroke-width:5}:host.pg-icon-lg .pg-icon-glyph-info .pg-icon-bar{stroke-width:6}:host.pg-icon-sm .pg-icon-glyph-info .pg-icon-bar{stroke-width:8}.pg-icon-glyph-question .pg-icon-curve{fill:none;stroke:var(--pg-icon-fg);stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:55;stroke-dashoffset:55}.pg-icon-glyph-question .pg-icon-dot{fill:var(--pg-icon-fg);transform:scale(0);transform-origin:50px 70px}:host.pg-icon-xl .pg-icon-glyph-question .pg-icon-curve{stroke-width:5}:host.pg-icon-lg .pg-icon-glyph-question .pg-icon-curve{stroke-width:6}:host.pg-icon-sm .pg-icon-glyph-question .pg-icon-curve{stroke-width:8}@media(prefers-reduced-motion:no-preference){:host.pg-icon-xl .pg-icon-badge,:host.pg-icon-lg .pg-icon-badge{animation:pg-icon-badge-pop .5s cubic-bezier(.34,1.56,.64,1) forwards}:host.pg-icon-sm .pg-icon-badge{animation:pg-icon-badge-pop .35s cubic-bezier(.34,1.56,.64,1) forwards}:host.pg-icon-xl .pg-icon-glyph-success,:host.pg-icon-lg .pg-icon-glyph-success{animation:pg-icon-draw-glyph .4s .42s ease-out forwards}:host.pg-icon-sm .pg-icon-glyph-success{animation:pg-icon-draw-glyph .28s .29s ease-out forwards}:host.pg-icon-xl .pg-icon-x-1,:host.pg-icon-lg .pg-icon-x-1{animation:pg-icon-draw-glyph .3s .7s ease-out forwards}:host.pg-icon-xl .pg-icon-x-2,:host.pg-icon-lg .pg-icon-x-2{animation:pg-icon-draw-glyph .3s .9s ease-out forwards}:host.pg-icon-sm .pg-icon-x-1{animation:pg-icon-draw-glyph .2s .5s ease-out forwards}:host.pg-icon-sm .pg-icon-x-2{animation:pg-icon-draw-glyph .2s .65s ease-out forwards}:host.pg-icon-xl.pg-icon-error .pg-icon-container,:host.pg-icon-lg.pg-icon-error .pg-icon-container{animation:pg-icon-shake .4s 1.1s ease-in-out}:host.pg-icon-xl .pg-icon-glyph-warning .pg-icon-bar,:host.pg-icon-lg .pg-icon-glyph-warning .pg-icon-bar{animation:pg-icon-draw-glyph .3s .7s ease-out forwards}:host.pg-icon-xl .pg-icon-glyph-warning .pg-icon-dot,:host.pg-icon-lg .pg-icon-glyph-warning .pg-icon-dot{animation:pg-icon-pop .25s 1.05s cubic-bezier(.25,1,.5,1.5) forwards}:host.pg-icon-sm .pg-icon-glyph-warning .pg-icon-bar{animation:pg-icon-draw-glyph .2s .5s ease-out forwards}:host.pg-icon-sm .pg-icon-glyph-warning .pg-icon-dot{animation:pg-icon-pop .2s .75s ease-out forwards}:host.pg-icon-xl.pg-icon-warning .pg-icon-container,:host.pg-icon-lg.pg-icon-warning .pg-icon-container{animation:pg-icon-bounce-y .5s 1.3s ease-out}:host.pg-icon-xl .pg-icon-glyph-info .pg-icon-dot,:host.pg-icon-lg .pg-icon-glyph-info .pg-icon-dot{animation:pg-icon-pop .25s .7s cubic-bezier(.25,1,.5,1.5) forwards}:host.pg-icon-xl .pg-icon-glyph-info .pg-icon-bar,:host.pg-icon-lg .pg-icon-glyph-info .pg-icon-bar{animation:pg-icon-draw-glyph .3s .9s ease-out forwards}:host.pg-icon-sm .pg-icon-glyph-info .pg-icon-dot{animation:pg-icon-pop .2s .5s ease-out forwards}:host.pg-icon-sm .pg-icon-glyph-info .pg-icon-bar{animation:pg-icon-draw-glyph .2s .65s ease-out forwards}:host.pg-icon-xl .pg-icon-glyph-question .pg-icon-curve,:host.pg-icon-lg .pg-icon-glyph-question .pg-icon-curve{animation:pg-icon-draw-glyph .4s .7s ease-out forwards}:host.pg-icon-xl .pg-icon-glyph-question .pg-icon-dot,:host.pg-icon-lg .pg-icon-glyph-question .pg-icon-dot{animation:pg-icon-pop .25s 1.1s cubic-bezier(.25,1,.5,1.5) forwards}:host.pg-icon-sm .pg-icon-glyph-question .pg-icon-curve{animation:pg-icon-draw-glyph .3s .5s ease-out forwards}:host.pg-icon-sm .pg-icon-glyph-question .pg-icon-dot{animation:pg-icon-pop .2s .8s ease-out forwards}}@media(prefers-reduced-motion:reduce){.pg-icon-badge{transform:scale(1)}.pg-icon-glyph,.pg-icon-glyph *{stroke-dashoffset:0;transform:scale(1)}}\n"] }]
        }] });

class AlertToastComponent {
    alert = input.required();
    close = output();
    iconInfo = computed(() => {
        switch (this.alert().type) {
            case 'success': return { timerClass: 'bg-success' };
            case 'error': return { timerClass: 'bg-error' };
            case 'warning': return { timerClass: 'bg-warning' };
            case 'question': return { timerClass: 'bg-gray-400' };
            case 'info':
            default: return { timerClass: 'bg-blue-400' };
        }
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: AlertToastComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: AlertToastComponent, isStandalone: true, selector: "pg-alert-toast", inputs: { alert: { classPropertyName: "alert", publicName: "alert", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { close: "close" }, host: { classAttribute: "block w-full max-w-sm pointer-events-auto" }, ngImport: i0, template: "<div\n  class=\"relative overflow-hidden w-full rounded-lg shadow-lg outline outline-1 outline-black/5\"\n  [ngClass]=\"[\n    alert().customClass?.popup || '',\n    alert().isLeaving\n      ? 'animate-' + (alert().animationLeave || 'fade-out')\n      : 'animate-' + (alert().animationEnter || 'horizontal-bounce'),\n  ]\"\n  [style.animation-duration.ms]=\"\n    alert().isLeaving\n      ? (alert().animationDurationLeave ?? 200)\n      : (alert().animationDurationEnter ?? 100)\n  \"\n  [ngStyle]=\"{\n    background: alert().background || 'white',\n    color: alert().color,\n    width: alert().width || '100%',\n    'max-width': alert().width ? 'none' : '24rem',\n  }\"\n>\n  <div class=\"p-4\" [ngClass]=\"alert().customClass?.container\">\n    <div class=\"flex items-center\">\n      <div class=\"shrink-0\">\n        @if (alert().iconHtml) {\n          <div [innerHTML]=\"alert().iconHtml\" [ngClass]=\"alert().customClass?.icon\"></div>\n        } @else if (alert().type) {\n          <pg-alert-icon [type]=\"alert().type!\" size=\"lg\" [ngClass]=\"alert().customClass?.icon\" />\n        }\n      </div>\n      <div class=\"ml-3 w-0 flex-1 pt-0.5\">\n        @if (alert().title) {\n          <p class=\"text-sm font-medium\" [ngClass]=\"alert().customClass?.title || 'text-gray-900'\">\n            {{ alert().title }}\n          </p>\n        }\n        <div class=\"mt-1 text-sm text-gray-500\" [ngClass]=\"alert().customClass?.htmlContainer\">\n          @if (alert().html) {\n            <div [innerHTML]=\"alert().html\"></div>\n          } @else if (alert().message || alert().text) {\n            <p [ngClass]=\"[alert().color ? '' : 'text-gray-500', alert().customClass?.message || '']\">\n              {{ alert().message || alert().text }}\n            </p>\n          }\n        </div>\n      </div>\n      @if (alert().showCloseButton !== false) {\n        <div class=\"ml-4 flex shrink-0\">\n          <button\n            type=\"button\"\n            (click)=\"close.emit()\"\n            class=\"inline-flex rounded-md text-gray-400 hover:text-gray-500 focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-primary\"\n            [ngClass]=\"alert().customClass?.closeButton\"\n          >\n            <span class=\"sr-only\">Close</span>\n            <svg\n              class=\"size-5\"\n              viewBox=\"0 0 20 20\"\n              fill=\"currentColor\"\n              data-slot=\"icon\"\n              aria-hidden=\"true\"\n            >\n              <path\n                d=\"M6.28 5.22a.75.75 0 0 0-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 1 0 1.06 1.06L10 11.06l3.72 3.72a.75.75 0 1 0 1.06-1.06L11.06 10l3.72-3.72a.75.75 0 0 0-1.06-1.06L10 8.94 6.28 5.22Z\"\n              />\n            </svg>\n          </button>\n        </div>\n      }\n    </div>\n  </div>\n  @if (alert().timerProgressBar && (alert().duration || 0) > 0) {\n    <div\n      class=\"h-1 absolute bottom-0 left-0 animate-progress\"\n      [style.animation-duration.ms]=\"alert().duration\"\n      [ngClass]=\"[alert().customClass?.timerProgressBar || '', iconInfo().timerClass]\"\n    ></div>\n  }\n</div>\n", styles: [""], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: AlertIconComponent, selector: "pg-alert-icon", inputs: ["type", "size"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: AlertToastComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-alert-toast', imports: [CommonModule, AlertIconComponent], host: {
                        class: 'block w-full max-w-sm pointer-events-auto',
                    }, template: "<div\n  class=\"relative overflow-hidden w-full rounded-lg shadow-lg outline outline-1 outline-black/5\"\n  [ngClass]=\"[\n    alert().customClass?.popup || '',\n    alert().isLeaving\n      ? 'animate-' + (alert().animationLeave || 'fade-out')\n      : 'animate-' + (alert().animationEnter || 'horizontal-bounce'),\n  ]\"\n  [style.animation-duration.ms]=\"\n    alert().isLeaving\n      ? (alert().animationDurationLeave ?? 200)\n      : (alert().animationDurationEnter ?? 100)\n  \"\n  [ngStyle]=\"{\n    background: alert().background || 'white',\n    color: alert().color,\n    width: alert().width || '100%',\n    'max-width': alert().width ? 'none' : '24rem',\n  }\"\n>\n  <div class=\"p-4\" [ngClass]=\"alert().customClass?.container\">\n    <div class=\"flex items-center\">\n      <div class=\"shrink-0\">\n        @if (alert().iconHtml) {\n          <div [innerHTML]=\"alert().iconHtml\" [ngClass]=\"alert().customClass?.icon\"></div>\n        } @else if (alert().type) {\n          <pg-alert-icon [type]=\"alert().type!\" size=\"lg\" [ngClass]=\"alert().customClass?.icon\" />\n        }\n      </div>\n      <div class=\"ml-3 w-0 flex-1 pt-0.5\">\n        @if (alert().title) {\n          <p class=\"text-sm font-medium\" [ngClass]=\"alert().customClass?.title || 'text-gray-900'\">\n            {{ alert().title }}\n          </p>\n        }\n        <div class=\"mt-1 text-sm text-gray-500\" [ngClass]=\"alert().customClass?.htmlContainer\">\n          @if (alert().html) {\n            <div [innerHTML]=\"alert().html\"></div>\n          } @else if (alert().message || alert().text) {\n            <p [ngClass]=\"[alert().color ? '' : 'text-gray-500', alert().customClass?.message || '']\">\n              {{ alert().message || alert().text }}\n            </p>\n          }\n        </div>\n      </div>\n      @if (alert().showCloseButton !== false) {\n        <div class=\"ml-4 flex shrink-0\">\n          <button\n            type=\"button\"\n            (click)=\"close.emit()\"\n            class=\"inline-flex rounded-md text-gray-400 hover:text-gray-500 focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-primary\"\n            [ngClass]=\"alert().customClass?.closeButton\"\n          >\n            <span class=\"sr-only\">Close</span>\n            <svg\n              class=\"size-5\"\n              viewBox=\"0 0 20 20\"\n              fill=\"currentColor\"\n              data-slot=\"icon\"\n              aria-hidden=\"true\"\n            >\n              <path\n                d=\"M6.28 5.22a.75.75 0 0 0-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 1 0 1.06 1.06L10 11.06l3.72 3.72a.75.75 0 1 0 1.06-1.06L11.06 10l3.72-3.72a.75.75 0 0 0-1.06-1.06L10 8.94 6.28 5.22Z\"\n              />\n            </svg>\n          </button>\n        </div>\n      }\n    </div>\n  </div>\n  @if (alert().timerProgressBar && (alert().duration || 0) > 0) {\n    <div\n      class=\"h-1 absolute bottom-0 left-0 animate-progress\"\n      [style.animation-duration.ms]=\"alert().duration\"\n      [ngClass]=\"[alert().customClass?.timerProgressBar || '', iconInfo().timerClass]\"\n    ></div>\n  }\n</div>\n" }]
        }] });

class AlertModalComponent extends PgDialogBase {
    idService = inject(IdService);
    _autoId = this.idService.generate('pg-alert-modal');
    alert = input.required();
    closeResult = output();
    /**
     * A diferencia de Modal (que alterna visibilidad en un template siempre montado),
     * AlertModal solo se monta mientras hay un alert activo en el AlertService.
     */
    isOpen = model(true);
    /** Re-declarada por requerimiento de PgDialogBase. */
    dialogRef = viewChild.required('dialogRef');
    /**
     * Defaults que matchean animationDurationEnter/Leave actuales.
     * Los overrides per-instance viven en el TEMPLATE (bindings directos a
     * notif().animationDurationEnter/Leave) — NO como getters acá: son fields
     * planos asignados en el constructor de la clase base, y un `get` accessor
     * en la subclase rompería con "Cannot set property which has only a getter".
     */
    panelEnterDurationMs = 150;
    panelExitDurationMs = 200;
    dialogId = computed(() => this._autoId);
    titleId = computed(() => `${this.dialogId()}-title`);
    notif = computed(() => this.alert());
    backdropColor = computed(() => {
        const bg = this.notif().backdrop;
        if (typeof bg === 'string')
            return bg;
        return 'rgba(107, 114, 128, 0.75)';
    });
    iconInfo = computed(() => {
        switch (this.notif().type) {
            case 'success':
                return { timerClass: 'bg-green-400' };
            case 'error':
                return { timerClass: 'bg-red-400' };
            case 'warning':
                return { timerClass: 'bg-yellow-400' };
            case 'question':
                return { timerClass: 'bg-gray-400' };
            case 'info':
            default:
                return { timerClass: 'bg-blue-400' };
        }
    });
    /** Header: wrapper de ícono + botón de cerrar según `headerLayout`. */
    headerWrapperClass = computed(() => this.notif().headerLayout === 'centered'
        ? 'flex justify-center mb-3 sm:mb-4'
        : 'flex items-start justify-between mb-3 sm:mb-4');
    /** Contenido: alineación de título/mensaje según `headerLayout`. */
    contentAlignClass = computed(() => this.notif().headerLayout === 'centered' ? 'text-center' : 'text-center sm:text-left');
    /** Footer de acciones: wrapper según `buttonsLayout` (+ `reverseButtons`). */
    actionsWrapperClass = computed(() => {
        const reverse = this.notif().reverseButtons ?? false;
        switch (this.notif().buttonsLayout) {
            case 'stacked':
                return `flex ${reverse ? 'flex-col' : 'flex-col-reverse'} gap-3`;
            case 'inline-start':
                return `flex gap-3 justify-start ${reverse ? 'flex-row-reverse' : 'flex-row'}`;
            case 'inline-center':
                return `flex gap-3 justify-center ${reverse ? 'flex-row-reverse' : 'flex-row'}`;
            case 'inline-end':
                return `flex gap-3 justify-end ${reverse ? 'flex-row-reverse' : 'flex-row'}`;
            default:
                return `flex flex-col sm:flex-row gap-3 justify-center sm:justify-end${reverse ? ' sm:flex-row-reverse' : ''}`;
        }
    });
    /** Footer de acciones: ancho de cada botón según `buttonsLayout`. */
    actionButtonWidthClass = computed(() => {
        const layout = this.notif().buttonsLayout;
        if (layout === 'stacked')
            return 'w-full';
        if (layout === 'inline-start' || layout === 'inline-center' || layout === 'inline-end') {
            return 'w-auto';
        }
        return 'w-full sm:w-auto';
    });
    constructor() {
        super();
        // El único emisor restante de `dismissed` (heredado) es el handler de ESC
        // nativo de PgDialogBase — onBackdropClick() se overridea completo abajo
        // y no llama a super(), así que backdrop nunca pasa por acá.
        this.dismissed.subscribe(() => this.onDismiss('esc'));
        // Auto-dismiss por `duration`: antes vivía en AlertService (corría ANTES
        // de que el componente existiera, ganándole la carrera al cierre animado).
        // Ahora corre por el mismo camino animado que el resto de los cierres.
        effect((onCleanup) => {
            const duration = this.notif().duration ?? 0;
            if (duration <= 0)
                return;
            const handle = setTimeout(() => this.onDismiss('timer'), duration);
            onCleanup(() => clearTimeout(handle));
        });
    }
    canDismiss(source) {
        if (source === 'escape')
            return this.notif().allowEscapeKey !== false;
        return true; // backdrop se maneja aparte, en el override de onBackdropClick().
    }
    onBackdropClick() {
        if (this.notif().allowOutsideClick === false)
            return;
        this.onDismiss('backdrop');
    }
    onDismiss(reason) {
        this.closeResult.emit({
            isConfirmed: false,
            isDenied: false,
            isDismissed: true,
            dismissReason: reason,
        });
        this.close();
    }
    onConfirm() {
        this.closeResult.emit({
            isConfirmed: true,
            isDenied: false,
            isDismissed: false,
        });
        this.close();
    }
    onCancel() {
        this.closeResult.emit({
            isConfirmed: false,
            isDenied: false,
            isDismissed: true,
            dismissReason: 'cancel',
        });
        this.close();
    }
    onDeny() {
        this.closeResult.emit({
            isConfirmed: false,
            isDenied: true,
            isDismissed: false,
        });
        this.close();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: AlertModalComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: AlertModalComponent, isStandalone: true, selector: "pg-alert-modal", inputs: { alert: { classPropertyName: "alert", publicName: "alert", isSignal: true, isRequired: true, transformFunction: null }, isOpen: { classPropertyName: "isOpen", publicName: "isOpen", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { closeResult: "closeResult", isOpen: "isOpenChange" }, viewQueries: [{ propertyName: "dialogRef", first: true, predicate: ["dialogRef"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "<dialog\n  #dialogRef\n  [id]=\"dialogId()\"\n  [attr.aria-labelledby]=\"titleId()\"\n  [ngClass]=\"notif().customClass?.container\"\n  class=\"fixed inset-0 m-0 size-auto max-h-none max-w-none overflow-y-auto bg-transparent p-0 backdrop:bg-transparent\"\n>\n  @if (notif().backdrop !== false) {\n    <div\n      class=\"fixed inset-0\"\n      [class.animate-fade-in]=\"!isClosing()\"\n      [class.animate-fade-out]=\"isClosing()\"\n      [style.animation-duration.ms]=\"\n        isClosing()\n          ? (notif().animationDurationLeave ?? panelExitDurationMs)\n          : (notif().animationDurationEnter ?? panelEnterDurationMs)\n      \"\n      [style.background]=\"backdropColor()\"\n    ></div>\n  }\n\n  <div\n    tabindex=\"0\"\n    class=\"fixed inset-0 flex min-h-full items-end justify-center overflow-y-auto p-4 text-center focus:outline focus:outline-0 sm:items-center sm:p-0\"\n    [style.pointer-events]=\"notif().backdrop === false ? 'none' : 'auto'\"\n    (click)=\"$event.target === $event.currentTarget && onBackdropClick()\"\n  >\n    <div\n      class=\"relative overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left shadow-xl sm:my-8 sm:p-6\"\n      [ngClass]=\"[\n        notif().customClass?.popup || '',\n        isClosing()\n          ? 'animate-' + (notif().animationLeave || 'fade-out')\n          : 'animate-' + (notif().animationEnter || 'slide-in-top'),\n      ]\"\n      [style.animation-duration.ms]=\"\n        isClosing()\n          ? (notif().animationDurationLeave ?? panelExitDurationMs)\n          : (notif().animationDurationEnter ?? panelEnterDurationMs)\n      \"\n      [ngStyle]=\"{\n        background: notif().background,\n        color: notif().color,\n        width: notif().width || '100%',\n        'max-width': notif().width ? 'none' : '24rem',\n        'pointer-events': 'auto',\n      }\"\n    >\n      <!-- \u2500\u2500 Header: icon + close button, layout seg\u00FAn `headerLayout` \u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n      @if (notif().iconHtml || notif().type || notif().showCloseButton) {\n        <div [ngClass]=\"headerWrapperClass()\">\n          @if (notif().iconHtml) {\n            <div\n              class=\"flex size-12 items-center justify-center rounded-full bg-gray-100\"\n              [ngClass]=\"notif().customClass?.icon\"\n              [innerHTML]=\"notif().iconHtml\"\n            ></div>\n          } @else if (notif().type) {\n            <pg-alert-icon\n              [type]=\"notif().type!\"\n              size=\"xl\"\n              [ngClass]=\"notif().customClass?.icon\"\n            />\n          }\n\n          @if (notif().showCloseButton && notif().headerLayout !== 'centered') {\n            <div class=\"ml-4 mt-1 flex h-7 items-center sm:ml-6 sm:mt-0\">\n              <button\n                type=\"button\"\n                class=\"rounded-md text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-primary\"\n                [ngClass]=\"notif().customClass?.closeButton\"\n                (click)=\"onDismiss('close')\"\n              >\n                <span class=\"sr-only\">Cerrar</span>\n                <svg\n                  class=\"size-6\"\n                  fill=\"none\"\n                  viewBox=\"0 0 24 24\"\n                  stroke-width=\"1.5\"\n                  stroke=\"currentColor\"\n                >\n                  <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M6 18L18 6M6 6l12 12\" />\n                </svg>\n              </button>\n            </div>\n          }\n        </div>\n\n        @if (notif().showCloseButton && notif().headerLayout === 'centered') {\n          <button\n            type=\"button\"\n            class=\"absolute right-4 top-4 rounded-md text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-primary\"\n            [ngClass]=\"notif().customClass?.closeButton\"\n            (click)=\"onDismiss('close')\"\n          >\n            <span class=\"sr-only\">Cerrar</span>\n            <svg\n              class=\"size-6\"\n              fill=\"none\"\n              viewBox=\"0 0 24 24\"\n              stroke-width=\"1.5\"\n              stroke=\"currentColor\"\n            >\n              <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M6 18L18 6M6 6l12 12\" />\n            </svg>\n          </button>\n        }\n      }\n\n      <!-- \u2500\u2500 Content: title + message \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n      <div [ngClass]=\"contentAlignClass()\">\n        @if (notif().title) {\n          <h3\n            [id]=\"titleId()\"\n            class=\"text-lg font-semibold leading-6 text-gray-900\"\n            [ngClass]=\"notif().customClass?.title\"\n          >\n            {{ notif().title }}\n          </h3>\n        } @else {\n          <span [id]=\"titleId()\" class=\"sr-only\">Alert</span>\n        }\n\n        @if (notif().html || notif().message || notif().text) {\n          <div class=\"mt-2\" [ngClass]=\"notif().customClass?.htmlContainer\">\n            @if (notif().html) {\n              <div class=\"text-sm text-gray-500\" [innerHTML]=\"notif().html\"></div>\n            } @else {\n              <p class=\"text-sm text-gray-500\">{{ notif().message || notif().text }}</p>\n            }\n          </div>\n        }\n      </div>\n\n      <!-- \u2500\u2500 Actions: deny / cancel / confirm \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n      @if (notif().showConfirmButton || notif().showCancelButton || notif().showDenyButton) {\n        <div\n          class=\"mt-5 sm:mt-6\"\n          [ngClass]=\"[actionsWrapperClass(), notif().customClass?.actions || '']\"\n        >\n          @if (notif().showDenyButton) {\n            <button\n              type=\"button\"\n              (click)=\"onDeny()\"\n              [ngStyle]=\"{ 'background-color': notif().denyButtonColor || 'var(--color-danger, #dc3545)' }\"\n              class=\"inline-flex justify-center rounded-md px-3 py-2 text-sm font-semibold text-white shadow-sm hover:opacity-90\"\n              [ngClass]=\"[actionButtonWidthClass(), notif().customClass?.denyButton || '']\"\n            >\n              {{ notif().denyButtonText || 'No' }}\n            </button>\n          }\n          @if (notif().showCancelButton) {\n            <button\n              type=\"button\"\n              (click)=\"onCancel()\"\n              [ngStyle]=\"{\n                'background-color': notif().cancelButtonColor || 'transparent',\n                'border-color': 'var(--color-neutral, #d1d5db)',\n              }\"\n              class=\"inline-flex justify-center rounded-md border px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm hover:bg-gray-50\"\n              [ngClass]=\"[actionButtonWidthClass(), notif().customClass?.cancelButton || '']\"\n            >\n              {{ notif().cancelButtonText || 'Cancel' }}\n            </button>\n          }\n          @if (notif().showConfirmButton) {\n            <button\n              type=\"button\"\n              (click)=\"onConfirm()\"\n              [ngStyle]=\"{ 'background-color': notif().confirmButtonColor || 'var(--color-primary, #f87a54)' }\"\n              class=\"inline-flex justify-center rounded-md px-3 py-2 text-sm font-semibold text-white shadow-sm hover:opacity-90\"\n              [ngClass]=\"[actionButtonWidthClass(), notif().customClass?.confirmButton || '']\"\n            >\n              {{ notif().confirmButtonText || 'OK' }}\n            </button>\n          }\n        </div>\n      }\n\n      <!-- \u2500\u2500 Footer \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n      @if (notif().footer) {\n        <div\n          class=\"mt-4 border-t border-gray-200 pt-4 text-center text-sm text-gray-500\"\n          [ngClass]=\"notif().customClass?.footer\"\n          [innerHTML]=\"notif().footer\"\n        ></div>\n      }\n\n      @if (notif().timerProgressBar && (notif().duration || 0) > 0) {\n        <div\n          class=\"h-1 absolute bottom-0 left-0 animate-progress\"\n          [style.animation-duration.ms]=\"notif().duration\"\n          [ngClass]=\"[notif().customClass?.timerProgressBar || '', iconInfo()?.timerClass]\"\n        ></div>\n      }\n    </div>\n  </div>\n</dialog>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: AlertIconComponent, selector: "pg-alert-icon", inputs: ["type", "size"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: AlertModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-alert-modal', imports: [CommonModule, AlertIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<dialog\n  #dialogRef\n  [id]=\"dialogId()\"\n  [attr.aria-labelledby]=\"titleId()\"\n  [ngClass]=\"notif().customClass?.container\"\n  class=\"fixed inset-0 m-0 size-auto max-h-none max-w-none overflow-y-auto bg-transparent p-0 backdrop:bg-transparent\"\n>\n  @if (notif().backdrop !== false) {\n    <div\n      class=\"fixed inset-0\"\n      [class.animate-fade-in]=\"!isClosing()\"\n      [class.animate-fade-out]=\"isClosing()\"\n      [style.animation-duration.ms]=\"\n        isClosing()\n          ? (notif().animationDurationLeave ?? panelExitDurationMs)\n          : (notif().animationDurationEnter ?? panelEnterDurationMs)\n      \"\n      [style.background]=\"backdropColor()\"\n    ></div>\n  }\n\n  <div\n    tabindex=\"0\"\n    class=\"fixed inset-0 flex min-h-full items-end justify-center overflow-y-auto p-4 text-center focus:outline focus:outline-0 sm:items-center sm:p-0\"\n    [style.pointer-events]=\"notif().backdrop === false ? 'none' : 'auto'\"\n    (click)=\"$event.target === $event.currentTarget && onBackdropClick()\"\n  >\n    <div\n      class=\"relative overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left shadow-xl sm:my-8 sm:p-6\"\n      [ngClass]=\"[\n        notif().customClass?.popup || '',\n        isClosing()\n          ? 'animate-' + (notif().animationLeave || 'fade-out')\n          : 'animate-' + (notif().animationEnter || 'slide-in-top'),\n      ]\"\n      [style.animation-duration.ms]=\"\n        isClosing()\n          ? (notif().animationDurationLeave ?? panelExitDurationMs)\n          : (notif().animationDurationEnter ?? panelEnterDurationMs)\n      \"\n      [ngStyle]=\"{\n        background: notif().background,\n        color: notif().color,\n        width: notif().width || '100%',\n        'max-width': notif().width ? 'none' : '24rem',\n        'pointer-events': 'auto',\n      }\"\n    >\n      <!-- \u2500\u2500 Header: icon + close button, layout seg\u00FAn `headerLayout` \u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n      @if (notif().iconHtml || notif().type || notif().showCloseButton) {\n        <div [ngClass]=\"headerWrapperClass()\">\n          @if (notif().iconHtml) {\n            <div\n              class=\"flex size-12 items-center justify-center rounded-full bg-gray-100\"\n              [ngClass]=\"notif().customClass?.icon\"\n              [innerHTML]=\"notif().iconHtml\"\n            ></div>\n          } @else if (notif().type) {\n            <pg-alert-icon\n              [type]=\"notif().type!\"\n              size=\"xl\"\n              [ngClass]=\"notif().customClass?.icon\"\n            />\n          }\n\n          @if (notif().showCloseButton && notif().headerLayout !== 'centered') {\n            <div class=\"ml-4 mt-1 flex h-7 items-center sm:ml-6 sm:mt-0\">\n              <button\n                type=\"button\"\n                class=\"rounded-md text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-primary\"\n                [ngClass]=\"notif().customClass?.closeButton\"\n                (click)=\"onDismiss('close')\"\n              >\n                <span class=\"sr-only\">Cerrar</span>\n                <svg\n                  class=\"size-6\"\n                  fill=\"none\"\n                  viewBox=\"0 0 24 24\"\n                  stroke-width=\"1.5\"\n                  stroke=\"currentColor\"\n                >\n                  <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M6 18L18 6M6 6l12 12\" />\n                </svg>\n              </button>\n            </div>\n          }\n        </div>\n\n        @if (notif().showCloseButton && notif().headerLayout === 'centered') {\n          <button\n            type=\"button\"\n            class=\"absolute right-4 top-4 rounded-md text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-primary\"\n            [ngClass]=\"notif().customClass?.closeButton\"\n            (click)=\"onDismiss('close')\"\n          >\n            <span class=\"sr-only\">Cerrar</span>\n            <svg\n              class=\"size-6\"\n              fill=\"none\"\n              viewBox=\"0 0 24 24\"\n              stroke-width=\"1.5\"\n              stroke=\"currentColor\"\n            >\n              <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M6 18L18 6M6 6l12 12\" />\n            </svg>\n          </button>\n        }\n      }\n\n      <!-- \u2500\u2500 Content: title + message \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n      <div [ngClass]=\"contentAlignClass()\">\n        @if (notif().title) {\n          <h3\n            [id]=\"titleId()\"\n            class=\"text-lg font-semibold leading-6 text-gray-900\"\n            [ngClass]=\"notif().customClass?.title\"\n          >\n            {{ notif().title }}\n          </h3>\n        } @else {\n          <span [id]=\"titleId()\" class=\"sr-only\">Alert</span>\n        }\n\n        @if (notif().html || notif().message || notif().text) {\n          <div class=\"mt-2\" [ngClass]=\"notif().customClass?.htmlContainer\">\n            @if (notif().html) {\n              <div class=\"text-sm text-gray-500\" [innerHTML]=\"notif().html\"></div>\n            } @else {\n              <p class=\"text-sm text-gray-500\">{{ notif().message || notif().text }}</p>\n            }\n          </div>\n        }\n      </div>\n\n      <!-- \u2500\u2500 Actions: deny / cancel / confirm \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n      @if (notif().showConfirmButton || notif().showCancelButton || notif().showDenyButton) {\n        <div\n          class=\"mt-5 sm:mt-6\"\n          [ngClass]=\"[actionsWrapperClass(), notif().customClass?.actions || '']\"\n        >\n          @if (notif().showDenyButton) {\n            <button\n              type=\"button\"\n              (click)=\"onDeny()\"\n              [ngStyle]=\"{ 'background-color': notif().denyButtonColor || 'var(--color-danger, #dc3545)' }\"\n              class=\"inline-flex justify-center rounded-md px-3 py-2 text-sm font-semibold text-white shadow-sm hover:opacity-90\"\n              [ngClass]=\"[actionButtonWidthClass(), notif().customClass?.denyButton || '']\"\n            >\n              {{ notif().denyButtonText || 'No' }}\n            </button>\n          }\n          @if (notif().showCancelButton) {\n            <button\n              type=\"button\"\n              (click)=\"onCancel()\"\n              [ngStyle]=\"{\n                'background-color': notif().cancelButtonColor || 'transparent',\n                'border-color': 'var(--color-neutral, #d1d5db)',\n              }\"\n              class=\"inline-flex justify-center rounded-md border px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm hover:bg-gray-50\"\n              [ngClass]=\"[actionButtonWidthClass(), notif().customClass?.cancelButton || '']\"\n            >\n              {{ notif().cancelButtonText || 'Cancel' }}\n            </button>\n          }\n          @if (notif().showConfirmButton) {\n            <button\n              type=\"button\"\n              (click)=\"onConfirm()\"\n              [ngStyle]=\"{ 'background-color': notif().confirmButtonColor || 'var(--color-primary, #f87a54)' }\"\n              class=\"inline-flex justify-center rounded-md px-3 py-2 text-sm font-semibold text-white shadow-sm hover:opacity-90\"\n              [ngClass]=\"[actionButtonWidthClass(), notif().customClass?.confirmButton || '']\"\n            >\n              {{ notif().confirmButtonText || 'OK' }}\n            </button>\n          }\n        </div>\n      }\n\n      <!-- \u2500\u2500 Footer \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n      @if (notif().footer) {\n        <div\n          class=\"mt-4 border-t border-gray-200 pt-4 text-center text-sm text-gray-500\"\n          [ngClass]=\"notif().customClass?.footer\"\n          [innerHTML]=\"notif().footer\"\n        ></div>\n      }\n\n      @if (notif().timerProgressBar && (notif().duration || 0) > 0) {\n        <div\n          class=\"h-1 absolute bottom-0 left-0 animate-progress\"\n          [style.animation-duration.ms]=\"notif().duration\"\n          [ngClass]=\"[notif().customClass?.timerProgressBar || '', iconInfo()?.timerClass]\"\n        ></div>\n      }\n    </div>\n  </div>\n</dialog>\n" }]
        }], ctorParameters: () => [] });

// Cantidad de toasts que quedan siempre visibles en flujo normal antes de
// que el resto empiece a apilarse (traslapados) detrás del último.
const STACK_VISIBLE_COUNT = 2;
const STACK_MAX_DEPTH = 3;
const STACK_OFFSET_PX = 10;
const STACK_SCALE_STEP = 0.05;
// z-index bajo y local a la pila de una misma posición (ej. varios toasts en
// top-end apilados). NO compite con Modal/Drawer/AlertModal: esos viven en el
// top layer del navegador vía popover/<dialog>, una capa que siempre pinta por
// encima de cualquier stacking context normal sin importar el número. Este
// z-index solo revierte el orden natural del DOM entre los toasts superpuestos
// dentro de la propia pila (el más viejo va al frente, ver getDepth()).
const STACK_BASE_Z_INDEX = 5;
class AlertContainerComponent {
    alertService = inject(AlertService);
    duration = input(5000);
    /**
     * Referencia al contenedor `popover="manual"` que envuelve todas las
     * posiciones de toasts (ver template). `#toastLayer` ancla el elemento
     * al DOM; ver el effect() del constructor para el show/hidePopover().
     */
    toastLayer = viewChild('toastLayer');
    toasts = computed(() => this.alertService.alerts().filter((n) => !n.variant || n.variant === 'toast'));
    hasToasts = computed(() => this.toasts().length > 0);
    modals = computed(() => this.alertService.alerts().filter((n) => n.variant === 'modal'));
    groupedToasts = computed(() => {
        const ts = this.toasts();
        const grouped = new Map();
        for (const t of ts) {
            const pos = t.position || 'top-end';
            if (!grouped.has(pos))
                grouped.set(pos, []);
            grouped.get(pos).push(t);
        }
        return Array.from(grouped.entries()).map(([position, alerts]) => {
            const topAnchored = this.isTopAnchored(position);
            const normal = alerts.length <= STACK_VISIBLE_COUNT
                ? alerts
                : topAnchored
                    ? alerts.slice(0, STACK_VISIBLE_COUNT)
                    : alerts.slice(-STACK_VISIBLE_COUNT);
            const pile = alerts.length <= STACK_VISIBLE_COUNT
                ? []
                : topAnchored
                    ? alerts.slice(STACK_VISIBLE_COUNT)
                    : alerts.slice(0, alerts.length - STACK_VISIBLE_COUNT);
            return { position, normal, pile, pileFirst: !topAnchored };
        });
    });
    getPositionClasses(pos) {
        switch (pos) {
            case 'top':
                return 'items-center justify-start px-6 pt-6';
            case 'top-start':
                return 'items-start justify-start p-6';
            case 'top-end':
                return 'items-end justify-start p-6';
            case 'center':
                return 'items-center justify-center p-6';
            case 'center-start':
                return 'items-start justify-center p-6';
            case 'center-end':
                return 'items-end justify-center p-6';
            case 'bottom':
                return 'items-center justify-end px-6 pb-6';
            case 'bottom-start':
                return 'items-start justify-end p-6';
            case 'bottom-end':
                return 'items-end justify-end p-6';
            default:
                return 'items-end justify-start p-6';
        }
    }
    getAlignmentClasses(pos) {
        if (pos.includes('start'))
            return 'items-start';
        if (pos.includes('end'))
            return 'items-end';
        return 'items-center';
    }
    isTopAnchored(pos) {
        return !pos.includes('bottom');
    }
    getDepth(pile, alert, pos) {
        const index = pile.findIndex((a) => a.id === alert.id);
        return this.isTopAnchored(pos) ? index : pile.length - 1 - index;
    }
    getStackStyle(pile, alert, pos) {
        const depth = this.getDepth(pile, alert, pos);
        if (depth === 0) {
            return { position: 'relative', 'z-index': `${STACK_BASE_Z_INDEX}` };
        }
        const topAnchored = this.isTopAnchored(pos);
        const cappedDepth = Math.min(depth, STACK_MAX_DEPTH);
        const direction = topAnchored ? 1 : -1;
        return {
            position: 'absolute',
            [topAnchored ? 'top' : 'bottom']: '0',
            left: '0',
            right: '0',
            overflow: 'hidden',
            transform: `translateY(${cappedDepth * STACK_OFFSET_PX * direction}px) scale(${1 - cappedDepth * STACK_SCALE_STEP})`,
            opacity: depth <= STACK_MAX_DEPTH ? '1' : '0',
            'pointer-events': 'none',
            'z-index': `${STACK_BASE_Z_INDEX - depth}`,
        };
    }
    closeToast(id) {
        this.alertService.close(id, {
            isConfirmed: false,
            isDenied: false,
            isDismissed: true,
            dismissReason: 'close',
        });
    }
    constructor() {
        effect(() => {
            this.alertService.setDefaultDuration(this.duration());
        });
        // Modal y Drawer abren con <dialog>.showModal(), que los sube al top layer
        // del navegador — una capa que siempre se pinta por encima de cualquier
        // stacking context normal, sin importar el z-index. El toast vivía en el
        // flujo normal del DOM, así que un toast disparado con un Modal/Drawer
        // abierto quedaba tapado por su backdrop pasara lo que pasara con su
        // z-index. Solución: subir también el contenedor de toasts al top layer
        // vía popover="manual" (no light-dismiss, no cierre por ESC — ver template)
        // y abrirlo/cerrarlo en sync con si hay toasts. Como el top layer ordena
        // por inserción, el toast (agregado último) gana visualmente sin tener
        // que coordinar números de z-index con Modal/Drawer.
        effect(() => {
            const el = this.toastLayer()?.nativeElement;
            if (!el || typeof el.showPopover !== 'function')
                return;
            if (this.hasToasts()) {
                if (!el.matches(':popover-open'))
                    el.showPopover();
            }
            else if (el.matches(':popover-open')) {
                el.hidePopover();
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: AlertContainerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: AlertContainerComponent, isStandalone: true, selector: "pg-alert-container", inputs: { duration: { classPropertyName: "duration", publicName: "duration", isSignal: true, isRequired: false, transformFunction: null } }, viewQueries: [{ propertyName: "toastLayer", first: true, predicate: ["toastLayer"], descendants: true, isSignal: true }], ngImport: i0, template: "<div\n  #toastLayer\n  popover=\"manual\"\n  class=\"pg-toast-layer pointer-events-none fixed inset-0\"\n>\n  @for (group of groupedToasts(); track group.position) {\n    <div\n      class=\"pointer-events-none absolute inset-0 flex flex-col\"\n      [ngClass]=\"getPositionClasses(group.position)\"\n    >\n      <div\n        class=\"alert-stack relative flex w-full flex-col gap-4 max-w-sm pointer-events-none\"\n        [ngClass]=\"getAlignmentClasses(group.position)\"\n      >\n        <ng-template #normalList>\n          @for (notif of group.normal; track notif.id) {\n            <pg-alert-toast [alert]=\"notif\" (close)=\"closeToast(notif.id)\" />\n          }\n        </ng-template>\n\n        <ng-template #pileList>\n          @if (group.pile.length > 0) {\n            <div class=\"relative flex w-full flex-col gap-4\">\n              @for (notif of group.pile; track notif.id) {\n                <pg-alert-toast\n                  class=\"stack-item\"\n                  [style]=\"getStackStyle(group.pile, notif, group.position)\"\n                  [alert]=\"notif\"\n                  (close)=\"closeToast(notif.id)\"\n                />\n              }\n            </div>\n          }\n        </ng-template>\n\n        @if (group.pileFirst) {\n          <ng-container [ngTemplateOutlet]=\"pileList\" />\n          <ng-container [ngTemplateOutlet]=\"normalList\" />\n        } @else {\n          <ng-container [ngTemplateOutlet]=\"normalList\" />\n          <ng-container [ngTemplateOutlet]=\"pileList\" />\n        }\n      </div>\n    </div>\n  }\n</div>\n\n@for (notif of modals(); track notif.id) {\n  <pg-alert-modal\n    [alert]=\"notif\"\n    (closeResult)=\"alertService.close(notif.id, $event)\"\n    (closed)=\"alertService.finalizeRemoval(notif.id)\"\n  />\n}\n", styles: [".pg-toast-layer{margin:0;border:none;padding:0;width:auto;height:auto;max-width:none;max-height:none;background:transparent;color:inherit;overflow:visible}.stack-item{transition:transform .25s ease,opacity .25s ease}.alert-stack:has(.stack-item:hover) .stack-item{position:relative!important;inset:auto!important;height:auto!important;overflow:visible!important;transform:none!important;opacity:1!important;pointer-events:auto!important;z-index:auto!important}\n"], dependencies: [{ kind: "component", type: AlertToastComponent, selector: "pg-alert-toast", inputs: ["alert"], outputs: ["close"] }, { kind: "component", type: AlertModalComponent, selector: "pg-alert-modal", inputs: ["alert", "isOpen"], outputs: ["closeResult", "isOpenChange"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: AlertContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-alert-container', imports: [AlertToastComponent, AlertModalComponent, NgClass, NgTemplateOutlet], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  #toastLayer\n  popover=\"manual\"\n  class=\"pg-toast-layer pointer-events-none fixed inset-0\"\n>\n  @for (group of groupedToasts(); track group.position) {\n    <div\n      class=\"pointer-events-none absolute inset-0 flex flex-col\"\n      [ngClass]=\"getPositionClasses(group.position)\"\n    >\n      <div\n        class=\"alert-stack relative flex w-full flex-col gap-4 max-w-sm pointer-events-none\"\n        [ngClass]=\"getAlignmentClasses(group.position)\"\n      >\n        <ng-template #normalList>\n          @for (notif of group.normal; track notif.id) {\n            <pg-alert-toast [alert]=\"notif\" (close)=\"closeToast(notif.id)\" />\n          }\n        </ng-template>\n\n        <ng-template #pileList>\n          @if (group.pile.length > 0) {\n            <div class=\"relative flex w-full flex-col gap-4\">\n              @for (notif of group.pile; track notif.id) {\n                <pg-alert-toast\n                  class=\"stack-item\"\n                  [style]=\"getStackStyle(group.pile, notif, group.position)\"\n                  [alert]=\"notif\"\n                  (close)=\"closeToast(notif.id)\"\n                />\n              }\n            </div>\n          }\n        </ng-template>\n\n        @if (group.pileFirst) {\n          <ng-container [ngTemplateOutlet]=\"pileList\" />\n          <ng-container [ngTemplateOutlet]=\"normalList\" />\n        } @else {\n          <ng-container [ngTemplateOutlet]=\"normalList\" />\n          <ng-container [ngTemplateOutlet]=\"pileList\" />\n        }\n      </div>\n    </div>\n  }\n</div>\n\n@for (notif of modals(); track notif.id) {\n  <pg-alert-modal\n    [alert]=\"notif\"\n    (closeResult)=\"alertService.close(notif.id, $event)\"\n    (closed)=\"alertService.finalizeRemoval(notif.id)\"\n  />\n}\n", styles: [".pg-toast-layer{margin:0;border:none;padding:0;width:auto;height:auto;max-width:none;max-height:none;background:transparent;color:inherit;overflow:visible}.stack-item{transition:transform .25s ease,opacity .25s ease}.alert-stack:has(.stack-item:hover) .stack-item{position:relative!important;inset:auto!important;height:auto!important;overflow:visible!important;transform:none!important;opacity:1!important;pointer-events:auto!important;z-index:auto!important}\n"] }]
        }], ctorParameters: () => [] });

class PgAlertModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgAlertModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.21", ngImport: i0, type: PgAlertModule, imports: [AlertToastComponent, AlertModalComponent, AlertContainerComponent], exports: [AlertToastComponent, AlertModalComponent, AlertContainerComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgAlertModule, imports: [AlertToastComponent, AlertModalComponent, AlertContainerComponent] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgAlertModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [AlertToastComponent, AlertModalComponent, AlertContainerComponent],
                    exports: [AlertToastComponent, AlertModalComponent, AlertContainerComponent],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { AlertContainerComponent, AlertIconComponent, AlertModalComponent, AlertService, AlertToastComponent, PgAlertModule };
//# sourceMappingURL=pagalo-ui-alert.mjs.map
