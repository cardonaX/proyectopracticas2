import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';

class BreadcrumbComponent {
    variant = 'simple-chevrons';
    items = [];
    homeUrl = '#';
    itemClick = new EventEmitter();
    onItemClick(item, event) {
        if (!item.url || item.url === '#') {
            event.preventDefault();
        }
        this.itemClick.emit(item);
    }
    get navClass() {
        switch (this.variant) {
            case 'full-width':
                return 'flex border-b border-gray-200 bg-white';
            default:
                return 'flex';
        }
    }
    get olClass() {
        switch (this.variant) {
            case 'contained':
                return 'flex space-x-4 rounded-md bg-white px-6 shadow';
            case 'full-width':
                return 'mx-auto flex w-full max-w-screen-xl space-x-4 px-4 sm:px-6 lg:px-8';
            case 'simple-chevrons':
            case 'simple-slashes':
                return 'flex items-center space-x-4';
            default:
                return 'flex items-center space-x-4';
        }
    }
    get liClass() {
        switch (this.variant) {
            case 'contained':
            case 'full-width':
                return 'flex';
            default:
                return '';
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: BreadcrumbComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: BreadcrumbComponent, isStandalone: true, selector: "pg-breadcrumbs", inputs: { variant: "variant", items: "items", homeUrl: "homeUrl" }, outputs: { itemClick: "itemClick" }, ngImport: i0, template: "<nav aria-label=\"Breadcrumb\" [class]=\"navClass\">\n  <ol role=\"list\" [class]=\"olClass\">\n    <li [class]=\"liClass\">\n      <div [class]=\"liClass ? 'flex items-center' : ''\">\n        <a [href]=\"homeUrl\" class=\"text-gray-400 hover:text-gray-500\">\n          <svg\n            viewBox=\"0 0 20 20\"\n            fill=\"currentColor\"\n            data-slot=\"icon\"\n            aria-hidden=\"true\"\n            class=\"size-5 shrink-0\"\n          >\n            <path\n              d=\"M9.293 2.293a1 1 0 0 1 1.414 0l7 7A1 1 0 0 1 17 11h-1v6a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-3a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-6H3a1 1 0 0 1-.707-1.707l7-7Z\"\n              clip-rule=\"evenodd\"\n              fill-rule=\"evenodd\"\n            />\n          </svg>\n          <span class=\"sr-only\">Home</span>\n        </a>\n      </div>\n    </li>\n\n    @for (item of items; track item.label; let last = $last) {\n      <li [class]=\"liClass\">\n        <div class=\"flex items-center\">\n          @if (variant === 'contained' || variant === 'full-width') {\n            <svg\n              viewBox=\"0 0 24 44\"\n              fill=\"currentColor\"\n              preserveAspectRatio=\"none\"\n              aria-hidden=\"true\"\n              class=\"h-full w-6 shrink-0 text-gray-200\"\n            >\n              <path d=\"M.293 0l22 22-22 22h1.414l22-22-22-22H.293z\" />\n            </svg>\n          } @else if (variant === 'simple-chevrons') {\n            <svg\n              viewBox=\"0 0 20 20\"\n              fill=\"currentColor\"\n              data-slot=\"icon\"\n              aria-hidden=\"true\"\n              class=\"size-5 shrink-0 text-gray-400\"\n            >\n              <path\n                d=\"M8.22 5.22a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.75.75 0 0 1-1.06-1.06L11.94 10 8.22 6.28a.75.75 0 0 1 0-1.06Z\"\n                clip-rule=\"evenodd\"\n                fill-rule=\"evenodd\"\n              />\n            </svg>\n          } @else if (variant === 'simple-slashes') {\n            <svg\n              viewBox=\"0 0 20 20\"\n              fill=\"currentColor\"\n              aria-hidden=\"true\"\n              class=\"size-5 shrink-0 text-gray-300\"\n            >\n              <path d=\"M5.555 17.776l8-16 .894.448-8 16-.894-.448z\" />\n            </svg>\n          }\n\n          <a\n            [href]=\"item.url || '#'\"\n            [attr.aria-current]=\"last ? 'page' : null\"\n            (click)=\"onItemClick(item, $event)\"\n            class=\"ml-4 text-sm font-medium text-gray-500 hover:text-gray-700\"\n          >\n            {{ item.label }}\n          </a>\n        </div>\n      </li>\n    }\n  </ol>\n</nav>\n", styles: [""], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: BreadcrumbComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-breadcrumbs', imports: [], changeDetection: ChangeDetectionStrategy.OnPush, template: "<nav aria-label=\"Breadcrumb\" [class]=\"navClass\">\n  <ol role=\"list\" [class]=\"olClass\">\n    <li [class]=\"liClass\">\n      <div [class]=\"liClass ? 'flex items-center' : ''\">\n        <a [href]=\"homeUrl\" class=\"text-gray-400 hover:text-gray-500\">\n          <svg\n            viewBox=\"0 0 20 20\"\n            fill=\"currentColor\"\n            data-slot=\"icon\"\n            aria-hidden=\"true\"\n            class=\"size-5 shrink-0\"\n          >\n            <path\n              d=\"M9.293 2.293a1 1 0 0 1 1.414 0l7 7A1 1 0 0 1 17 11h-1v6a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-3a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-6H3a1 1 0 0 1-.707-1.707l7-7Z\"\n              clip-rule=\"evenodd\"\n              fill-rule=\"evenodd\"\n            />\n          </svg>\n          <span class=\"sr-only\">Home</span>\n        </a>\n      </div>\n    </li>\n\n    @for (item of items; track item.label; let last = $last) {\n      <li [class]=\"liClass\">\n        <div class=\"flex items-center\">\n          @if (variant === 'contained' || variant === 'full-width') {\n            <svg\n              viewBox=\"0 0 24 44\"\n              fill=\"currentColor\"\n              preserveAspectRatio=\"none\"\n              aria-hidden=\"true\"\n              class=\"h-full w-6 shrink-0 text-gray-200\"\n            >\n              <path d=\"M.293 0l22 22-22 22h1.414l22-22-22-22H.293z\" />\n            </svg>\n          } @else if (variant === 'simple-chevrons') {\n            <svg\n              viewBox=\"0 0 20 20\"\n              fill=\"currentColor\"\n              data-slot=\"icon\"\n              aria-hidden=\"true\"\n              class=\"size-5 shrink-0 text-gray-400\"\n            >\n              <path\n                d=\"M8.22 5.22a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.75.75 0 0 1-1.06-1.06L11.94 10 8.22 6.28a.75.75 0 0 1 0-1.06Z\"\n                clip-rule=\"evenodd\"\n                fill-rule=\"evenodd\"\n              />\n            </svg>\n          } @else if (variant === 'simple-slashes') {\n            <svg\n              viewBox=\"0 0 20 20\"\n              fill=\"currentColor\"\n              aria-hidden=\"true\"\n              class=\"size-5 shrink-0 text-gray-300\"\n            >\n              <path d=\"M5.555 17.776l8-16 .894.448-8 16-.894-.448z\" />\n            </svg>\n          }\n\n          <a\n            [href]=\"item.url || '#'\"\n            [attr.aria-current]=\"last ? 'page' : null\"\n            (click)=\"onItemClick(item, $event)\"\n            class=\"ml-4 text-sm font-medium text-gray-500 hover:text-gray-700\"\n          >\n            {{ item.label }}\n          </a>\n        </div>\n      </li>\n    }\n  </ol>\n</nav>\n" }]
        }], propDecorators: { variant: [{
                type: Input
            }], items: [{
                type: Input
            }], homeUrl: [{
                type: Input
            }], itemClick: [{
                type: Output
            }] } });

class PgBreadcrumbModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgBreadcrumbModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.21", ngImport: i0, type: PgBreadcrumbModule, imports: [BreadcrumbComponent], exports: [BreadcrumbComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgBreadcrumbModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgBreadcrumbModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        BreadcrumbComponent
                    ],
                    exports: [
                        BreadcrumbComponent
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { BreadcrumbComponent, PgBreadcrumbModule };
//# sourceMappingURL=pagalo-ui-breadcrumb.mjs.map
