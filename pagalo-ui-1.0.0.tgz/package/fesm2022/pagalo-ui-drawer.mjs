import * as i0 from '@angular/core';
import { inject, input, computed, ChangeDetectionStrategy, Component, ElementRef, NgModule } from '@angular/core';
import { PgDialogBase, IdService } from '@pagalo/ui/core';

class DrawerComponent extends PgDialogBase {
    idService = inject(IdService);
    _autoId = this.idService.generate('pg-drawer');
    panelEnterDurationMs = 500;
    panelExitDurationMs = 500;
    size = input('md');
    id = input('');
    /** ID resuelto: usa el input `id` si se provee, sino genera uno automáticamente. */
    dialogId = computed(() => this.id() || this._autoId);
    titleId = computed(() => `${this.dialogId()}-title`);
    sizeClass = computed(() => {
        const defaultClasses = 'ml-auto block size-full';
        const sizeMap = {
            sm: 'max-w-sm',
            md: 'max-w-md',
            lg: 'max-w-lg',
            xl: 'max-w-xl',
            '2xl': 'max-w-2xl',
            full: 'max-w-full',
        };
        return `${defaultClasses} ${sizeMap[this.size()]}`;
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: DrawerComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.21", type: DrawerComponent, isStandalone: true, selector: "pg-drawer", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null } }, usesInheritance: true, ngImport: i0, template: "<dialog\n  #dialogRef\n  [id]=\"dialogId()\"\n  [attr.aria-labelledby]=\"titleId()\"\n  class=\"fixed inset-0 m-0 size-auto max-h-none max-w-none overflow-hidden bg-transparent p-0 backdrop:bg-transparent\"\n>\n  <div\n    class=\"fixed inset-0 bg-gray-500/75\"\n    [class.animate-fade-in]=\"!isClosing()\"\n    [class.animate-fade-out]=\"isClosing()\"\n    [style.animation-duration.ms]=\"isClosing() ? panelExitDurationMs : panelEnterDurationMs\"\n  ></div>\n\n  <div\n    tabindex=\"0\"\n    class=\"absolute inset-0 pl-10 focus:outline focus:outline-0 sm:pl-16\"\n    (click)=\"$event.target === $event.currentTarget && onBackdropClick()\"\n  >\n    <div\n      [class]=\"sizeClass()\"\n      [class.pg-drawer-slide-in]=\"!isClosing()\"\n      [class.pg-drawer-slide-out]=\"isClosing()\"\n      [style.animation-duration.ms]=\"isClosing() ? panelExitDurationMs : panelEnterDurationMs\"\n    >\n      <div class=\"relative flex h-full flex-col overflow-y-auto bg-white py-6 shadow-xl\">\n        <span [id]=\"titleId()\" class=\"sr-only\">Drawer</span>\n        <ng-content></ng-content>\n      </div>\n    </div>\n  </div>\n</dialog>\n", styles: ["@keyframes pg-drawer-slide-in{0%{transform:translate(100%)}to{transform:translate(0)}}@keyframes pg-drawer-slide-out{0%{transform:translate(0)}to{transform:translate(100%)}}.pg-drawer-slide-in{animation-name:pg-drawer-slide-in;animation-timing-function:ease-in-out;animation-fill-mode:both}.pg-drawer-slide-out{animation-name:pg-drawer-slide-out;animation-timing-function:ease-in-out;animation-fill-mode:both}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: DrawerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-drawer', imports: [], changeDetection: ChangeDetectionStrategy.OnPush, template: "<dialog\n  #dialogRef\n  [id]=\"dialogId()\"\n  [attr.aria-labelledby]=\"titleId()\"\n  class=\"fixed inset-0 m-0 size-auto max-h-none max-w-none overflow-hidden bg-transparent p-0 backdrop:bg-transparent\"\n>\n  <div\n    class=\"fixed inset-0 bg-gray-500/75\"\n    [class.animate-fade-in]=\"!isClosing()\"\n    [class.animate-fade-out]=\"isClosing()\"\n    [style.animation-duration.ms]=\"isClosing() ? panelExitDurationMs : panelEnterDurationMs\"\n  ></div>\n\n  <div\n    tabindex=\"0\"\n    class=\"absolute inset-0 pl-10 focus:outline focus:outline-0 sm:pl-16\"\n    (click)=\"$event.target === $event.currentTarget && onBackdropClick()\"\n  >\n    <div\n      [class]=\"sizeClass()\"\n      [class.pg-drawer-slide-in]=\"!isClosing()\"\n      [class.pg-drawer-slide-out]=\"isClosing()\"\n      [style.animation-duration.ms]=\"isClosing() ? panelExitDurationMs : panelEnterDurationMs\"\n    >\n      <div class=\"relative flex h-full flex-col overflow-y-auto bg-white py-6 shadow-xl\">\n        <span [id]=\"titleId()\" class=\"sr-only\">Drawer</span>\n        <ng-content></ng-content>\n      </div>\n    </div>\n  </div>\n</dialog>\n", styles: ["@keyframes pg-drawer-slide-in{0%{transform:translate(100%)}to{transform:translate(0)}}@keyframes pg-drawer-slide-out{0%{transform:translate(0)}to{transform:translate(100%)}}.pg-drawer-slide-in{animation-name:pg-drawer-slide-in;animation-timing-function:ease-in-out;animation-fill-mode:both}.pg-drawer-slide-out{animation-name:pg-drawer-slide-out;animation-timing-function:ease-in-out;animation-fill-mode:both}\n"] }]
        }] });

class DrawerHeaderComponent {
    showClose = input(true);
    el = inject((ElementRef));
    drawer = inject(DrawerComponent, { optional: true });
    close() {
        if (this.drawer) {
            this.drawer.close();
        }
        else {
            // Fallback when DI doesn't resolve (e.g. used outside pg-drawer)
            const dialog = this.el.nativeElement.closest('dialog');
            dialog?.close();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: DrawerHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: DrawerHeaderComponent, isStandalone: true, selector: "pg-drawer-header", inputs: { showClose: { classPropertyName: "showClose", publicName: "showClose", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <div class="px-4 sm:px-6 w-full">
      <div class="flex items-start justify-between">
        <div class="w-full">
          <ng-content></ng-content>
        </div>
        @if (showClose()) {
          <div class="ml-3 flex h-7 items-center">
            <button
              type="button"
              (click)="close()"
              class="relative rounded-md text-disabled-text hover:text-disabled-hover focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
            >
              <span class="absolute -inset-2.5"></span>
              <span class="sr-only">Close panel</span>
              <svg
                class="size-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke-width="1.5"
                stroke="currentColor"
                aria-hidden="true"
                data-slot="icon"
              >
                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        }
      </div>
    </div>
  `, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: DrawerHeaderComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'pg-drawer-header',
                    imports: [],
                    template: `
    <div class="px-4 sm:px-6 w-full">
      <div class="flex items-start justify-between">
        <div class="w-full">
          <ng-content></ng-content>
        </div>
        @if (showClose()) {
          <div class="ml-3 flex h-7 items-center">
            <button
              type="button"
              (click)="close()"
              class="relative rounded-md text-disabled-text hover:text-disabled-hover focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
            >
              <span class="absolute -inset-2.5"></span>
              <span class="sr-only">Close panel</span>
              <svg
                class="size-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke-width="1.5"
                stroke="currentColor"
                aria-hidden="true"
                data-slot="icon"
              >
                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        }
      </div>
    </div>
  `
                }]
        }] });

class DrawerContentComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: DrawerContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.21", type: DrawerContentComponent, isStandalone: true, selector: "pg-drawer-content", host: { classAttribute: "flex-1 flex flex-col mb-4" }, ngImport: i0, template: `
    <div class="relative mt-6 flex-1 px-4 sm:px-6">
      <ng-content></ng-content>
    </div>
  `, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: DrawerContentComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'pg-drawer-content',
                    standalone: true,
                    template: `
    <div class="relative mt-6 flex-1 px-4 sm:px-6">
      <ng-content></ng-content>
    </div>
  `,
                    host: {
                        class: 'flex-1 flex flex-col mb-4',
                    },
                }]
        }] });

class DrawerFooterComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: DrawerFooterComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.21", type: DrawerFooterComponent, isStandalone: true, selector: "pg-drawer-footer", ngImport: i0, template: `
    <div class="mt-auto flex border-t border-gray-200 px-4 py-4 sm:px-6 justify-end gap-3">
      <ng-content></ng-content>
    </div>
  `, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: DrawerFooterComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'pg-drawer-footer',
                    standalone: true,
                    template: `
    <div class="mt-auto flex border-t border-gray-200 px-4 py-4 sm:px-6 justify-end gap-3">
      <ng-content></ng-content>
    </div>
  `,
                }]
        }] });

class PgDrawerModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgDrawerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.21", ngImport: i0, type: PgDrawerModule, imports: [DrawerComponent,
            DrawerContentComponent,
            DrawerFooterComponent,
            DrawerHeaderComponent], exports: [DrawerComponent,
            DrawerContentComponent,
            DrawerFooterComponent,
            DrawerHeaderComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgDrawerModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgDrawerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DrawerComponent,
                        DrawerContentComponent,
                        DrawerFooterComponent,
                        DrawerHeaderComponent,
                    ],
                    exports: [
                        DrawerComponent,
                        DrawerContentComponent,
                        DrawerFooterComponent,
                        DrawerHeaderComponent,
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DrawerComponent, DrawerContentComponent, DrawerFooterComponent, DrawerHeaderComponent, PgDrawerModule };
//# sourceMappingURL=pagalo-ui-drawer.mjs.map
