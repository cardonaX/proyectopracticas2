import * as i0 from '@angular/core';
import { InjectionToken, input, computed, Component, inject, HostBinding, ElementRef, Renderer2, effect, HostListener, Input, Directive, signal, contentChild, forwardRef, ChangeDetectionStrategy, output, NgModule } from '@angular/core';
import { NgTemplateOutlet, NgClass } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { PgControlValueAccessorBase, IdService } from '@pagalo/ui/core';
import { PgLoaderComponent } from '@pagalo/ui/loader';

const FORM_VARIANT_TOKEN = new InjectionToken('FORM_VARIANT_TOKEN');
class PgForm {
    /**
     * Define la variante de diseño del formulario.
     * - stacked: Formulario vertical tradicional.
     * - two-column: Formulario dividido en dos columnas (título a la izquierda, campos a la derecha).
     * - cards: Secciones del formulario separadas por bordes y tarjetas con sombras.
     * - labels-on-left: Campos del formulario divididos con las etiquetas a la izquierda y las entradas a la derecha.
     */
    variant = input('stacked');
    containerClasses = computed(() => {
        switch (this.variant()) {
            case 'stacked':
            case 'two-column':
            case 'labels-on-left':
                return 'space-y-12 sm:space-y-16';
            case 'cards':
                return 'divide-y divide-outline-contrast/10';
            default:
                return 'space-y-12 sm:space-y-16';
        }
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgForm, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.21", type: PgForm, isStandalone: true, selector: "pg-form", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null } }, providers: [
            {
                provide: FORM_VARIANT_TOKEN,
                useFactory: (form) => form.variant,
                deps: [PgForm],
            },
        ], ngImport: i0, template: "<form [className]=\"containerClasses()\">\n  <ng-content></ng-content>\n</form>\n", styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgForm, decorators: [{
            type: Component,
            args: [{ selector: 'pg-form', imports: [], providers: [
                        {
                            provide: FORM_VARIANT_TOKEN,
                            useFactory: (form) => form.variant,
                            deps: [PgForm],
                        },
                    ], template: "<form [className]=\"containerClasses()\">\n  <ng-content></ng-content>\n</form>\n" }]
        }] });

class FormFieldComponent {
    label = input.required();
    description = input();
    forId = input('');
    colSpanClass = input('col-span-full');
    form = inject(PgForm, { optional: true });
    variant = computed(() => {
        return this.form?.variant() || 'stacked';
    });
    get hostClasses() {
        switch (this.variant()) {
            case 'labels-on-left':
                return 'block';
            default:
                return this.colSpanClass();
        }
    }
    fieldContainerClasses = computed(() => {
        switch (this.variant()) {
            case 'labels-on-left':
                return 'sm:grid sm:grid-cols-3 sm:items-start sm:gap-4 sm:py-6';
            default:
                return '';
        }
    });
    labelClasses = computed(() => {
        if (this.variant() === 'labels-on-left') {
            return 'block text-sm/6 font-medium text-content sm:pt-1.5';
        }
        return 'block text-sm/6 font-medium text-content';
    });
    inputContainerClasses = computed(() => {
        if (this.variant() === 'labels-on-left') {
            return 'mt-2 sm:col-span-2 sm:mt-0';
        }
        return 'mt-2';
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: FormFieldComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: FormFieldComponent, isStandalone: true, selector: "pg-form-field", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, forId: { classPropertyName: "forId", publicName: "forId", isSignal: true, isRequired: false, transformFunction: null }, colSpanClass: { classPropertyName: "colSpanClass", publicName: "colSpanClass", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "this.hostClasses" } }, ngImport: i0, template: "<div [className]=\"fieldContainerClasses()\">\n  <label [for]=\"forId()\" [className]=\"labelClasses()\">{{ label() }}</label>\n  <div [className]=\"inputContainerClasses()\">\n    <ng-content></ng-content>\n    @if (description()) {\n      <p class=\"mt-3 text-sm/6 text-content-muted\">{{ description() }}</p>\n    }\n  </div>\n</div>\n" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: FormFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-form-field', imports: [], template: "<div [className]=\"fieldContainerClasses()\">\n  <label [for]=\"forId()\" [className]=\"labelClasses()\">{{ label() }}</label>\n  <div [className]=\"inputContainerClasses()\">\n    <ng-content></ng-content>\n    @if (description()) {\n      <p class=\"mt-3 text-sm/6 text-content-muted\">{{ description() }}</p>\n    }\n  </div>\n</div>\n" }]
        }], propDecorators: { hostClasses: [{
                type: HostBinding,
                args: ['class']
            }] } });

class FormSectionComponent {
    title = input.required();
    description = input();
    form = inject(PgForm, { optional: true });
    variant = computed(() => {
        return this.form?.variant() || 'stacked';
    });
    sectionClasses = computed(() => {
        switch (this.variant()) {
            case 'stacked':
                return 'border-b border-outline-contrast/10 pb-12';
            case 'two-column':
            case 'cards':
            case 'labels-on-left':
                return 'grid grid-cols-1 gap-x-8 gap-y-10 border-b border-outline-contrast/10 pb-12 md:grid-cols-3 sm:py-6';
            default:
                return 'border-b border-outline-contrast/10 pb-12';
        }
    });
    headerContainerClasses = computed(() => {
        if (this.variant() === 'cards') {
            return 'px-4 sm:px-0';
        }
        return '';
    });
    fieldsContainerClasses = computed(() => {
        switch (this.variant()) {
            case 'stacked':
                return 'mt-10 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6';
            case 'two-column':
                return 'grid max-w-2xl grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6 md:col-span-2';
            case 'cards':
                return 'bg-surface shadow-sm outline outline-1 outline-outline-contrast/5 sm:rounded-xl md:col-span-2 px-4 py-6 sm:p-8 grid max-w-2xl grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6';
            case 'labels-on-left':
                return 'mt-10 space-y-8 border-b border-outline-contrast/10 pb-12 sm:space-y-0 sm:divide-y sm:divide-outline-contrast/10 sm:border-t sm:border-t-outline-contrast/10 sm:pb-0 md:col-span-2';
            default:
                return 'mt-10 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6';
        }
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: FormSectionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: FormSectionComponent, isStandalone: true, selector: "pg-form-section", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<ng-template #contentTemplate>\n  <ng-content></ng-content>\n</ng-template>\n\n@if (variant() === 'stacked' || variant() === 'two-column') {\n  <div [className]=\"sectionClasses()\">\n    <div [className]=\"headerContainerClasses()\">\n      <h2 class=\"text-base/7 font-semibold text-content\">{{ title() }}</h2>\n      @if (description()) {\n        <p class=\"mt-1 text-sm/6 text-content-muted\">{{ description() }}</p>\n      }\n    </div>\n\n    <div [className]=\"fieldsContainerClasses()\">\n      <ng-container *ngTemplateOutlet=\"contentTemplate\"></ng-container>\n    </div>\n  </div>\n} @else if (variant() === 'cards') {\n  <div [className]=\"sectionClasses()\">\n    <div [className]=\"headerContainerClasses()\">\n      <h2 class=\"text-base/7 font-semibold text-content\">{{ title() }}</h2>\n      @if (description()) {\n        <p class=\"mt-1 text-sm/6 text-content-muted\">{{ description() }}</p>\n      }\n    </div>\n\n    <form [className]=\"fieldsContainerClasses()\">\n      <ng-container *ngTemplateOutlet=\"contentTemplate\"></ng-container>\n    </form>\n  </div>\n} @else if (variant() === 'labels-on-left') {\n  <div class=\"sm:grid sm:grid-cols-3 sm:items-start sm:gap-4 sm:py-6\">\n    <div [className]=\"headerContainerClasses()\">\n      <h2 class=\"text-base/7 font-semibold text-content\">{{ title() }}</h2>\n      @if (description()) {\n        <p class=\"mt-1 max-w-2xl text-sm/6 text-content-muted\">{{ description() }}</p>\n      }\n    </div>\n\n    <div [className]=\"fieldsContainerClasses()\">\n      <ng-container *ngTemplateOutlet=\"contentTemplate\"></ng-container>\n    </div>\n  </div>\n}\n", dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: FormSectionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-form-section', imports: [NgTemplateOutlet], template: "<ng-template #contentTemplate>\n  <ng-content></ng-content>\n</ng-template>\n\n@if (variant() === 'stacked' || variant() === 'two-column') {\n  <div [className]=\"sectionClasses()\">\n    <div [className]=\"headerContainerClasses()\">\n      <h2 class=\"text-base/7 font-semibold text-content\">{{ title() }}</h2>\n      @if (description()) {\n        <p class=\"mt-1 text-sm/6 text-content-muted\">{{ description() }}</p>\n      }\n    </div>\n\n    <div [className]=\"fieldsContainerClasses()\">\n      <ng-container *ngTemplateOutlet=\"contentTemplate\"></ng-container>\n    </div>\n  </div>\n} @else if (variant() === 'cards') {\n  <div [className]=\"sectionClasses()\">\n    <div [className]=\"headerContainerClasses()\">\n      <h2 class=\"text-base/7 font-semibold text-content\">{{ title() }}</h2>\n      @if (description()) {\n        <p class=\"mt-1 text-sm/6 text-content-muted\">{{ description() }}</p>\n      }\n    </div>\n\n    <form [className]=\"fieldsContainerClasses()\">\n      <ng-container *ngTemplateOutlet=\"contentTemplate\"></ng-container>\n    </form>\n  </div>\n} @else if (variant() === 'labels-on-left') {\n  <div class=\"sm:grid sm:grid-cols-3 sm:items-start sm:gap-4 sm:py-6\">\n    <div [className]=\"headerContainerClasses()\">\n      <h2 class=\"text-base/7 font-semibold text-content\">{{ title() }}</h2>\n      @if (description()) {\n        <p class=\"mt-1 max-w-2xl text-sm/6 text-content-muted\">{{ description() }}</p>\n      }\n    </div>\n\n    <div [className]=\"fieldsContainerClasses()\">\n      <ng-container *ngTemplateOutlet=\"contentTemplate\"></ng-container>\n    </div>\n  </div>\n}\n" }]
        }] });

class FormActionsComponent {
    form = inject(PgForm, { optional: true });
    variant = computed(() => {
        return this.form?.variant() || 'stacked';
    });
    actionContainerClasses = computed(() => {
        if (this.variant() === 'cards') {
            return 'flex items-center justify-end gap-x-6 border-t border-outline-contrast/10 px-4 py-4 sm:px-8';
        }
        return 'mt-6 flex items-center justify-end gap-x-6';
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: FormActionsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.21", type: FormActionsComponent, isStandalone: true, selector: "pg-form-actions", ngImport: i0, template: `
    <div [className]="actionContainerClasses()">
      <ng-content></ng-content>
    </div>
  `, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: FormActionsComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'pg-form-actions',
                    imports: [],
                    template: `
    <div [className]="actionContainerClasses()">
      <ng-content></ng-content>
    </div>
  `
                }]
        }] });

class InputDirective {
    pgInput = inject(InputComponent, { optional: true });
    el = inject((ElementRef));
    renderer = inject(Renderer2);
    disabled = false;
    isInvalid = false;
    originalType;
    constructor() {
        this.originalType = this.el.nativeElement.getAttribute('type') || 'text';
        if (this.pgInput) {
            effect(() => {
                const val = this.pgInput.value();
                this.renderer.setProperty(this.el.nativeElement, 'value', val ?? '');
            });
            effect(() => {
                const dis = this.pgInput.disabled();
                this.renderer.setProperty(this.el.nativeElement, 'disabled', dis);
            });
            effect(() => {
                const visible = this.pgInput.isPasswordVisible();
                if (this.originalType === 'password') {
                    this.renderer.setProperty(this.el.nativeElement, 'type', visible ? 'text' : 'password');
                }
            });
        }
    }
    /** Propaga el input del usuario al wrapper CVA para que Angular Forms lo reciba. */
    onInput(value) {
        this.pgInput?.setValue(value);
    }
    /** Marca el control como touched cuando el usuario sale del campo. */
    onBlur() {
        this.pgInput?.markAsTouched();
    }
    get classes() {
        const parent = this.pgInput;
        const variant = parent ? parent.variant() : 'default';
        const hasError = this.isInvalid || (parent && parent.hasError());
        const hasExtraSuffix = hasError || (parent?.success() ?? false) || (parent?.showPasswordToggle() ?? false);
        let cls = 'block w-full text-base sm:text-sm/6 ';
        cls += 'read-only:bg-surface-muted read-only:text-content-muted read-only:cursor-default ';
        if (this.disabled) {
            cls +=
                'disabled:cursor-not-allowed disabled:bg-surface-muted disabled:text-content-muted disabled:outline-outline ';
        }
        if (hasError) {
            cls += 'text-content-danger placeholder:text-red-300 ';
        }
        else if (variant === 'gray-bottom') {
            cls += 'text-content placeholder:text-content-muted ';
        }
        else {
            cls += 'text-content placeholder:text-content-subtle ';
        }
        if (variant === 'inset' || parent?.layoutType() === 'inline-flex') {
            cls += 'bg-transparent ';
        }
        else if (variant === 'gray-bottom') {
            cls += 'bg-surface-muted peer ';
        }
        else {
            cls += 'bg-surface ';
        }
        if (variant === 'pill') {
            cls += 'rounded-full ';
        }
        else if (parent && parent.sharedBorders() !== 'none') {
            switch (parent.sharedBorders()) {
                case 'top':
                    cls += 'rounded-t-md ';
                    break;
                case 'bottom':
                    cls += 'rounded-b-md ';
                    break;
                case 'bottom-left':
                    cls += 'rounded-bl-md ';
                    break;
                case 'bottom-right':
                    cls += 'rounded-br-md ';
                    break;
                case 'left':
                    cls += 'rounded-l-md ';
                    break;
                case 'right':
                    cls += 'rounded-r-md ';
                    break;
            }
        }
        else if (parent && parent.prefixAddon()) {
            cls += 'rounded-r-md ';
        }
        else if (parent && parent.suffixAddon()) {
            cls += 'rounded-l-md ';
        }
        else if (parent && parent.suffixButton()) {
            cls += 'rounded-l-md ';
        }
        else if (variant === 'gray-bottom' || variant === 'inset') {
        }
        else if (parent?.layoutType() === 'inline-flex') {
        }
        else {
            cls += 'rounded-md ';
        }
        if (variant === 'inset') {
            cls += 'py-0 ';
        }
        else {
            const size = parent?.size() ?? 'md';
            if (size === 'sm')
                cls += 'py-1 ';
            else if (size === 'lg')
                cls += 'py-2.5 ';
            else
                cls += 'py-1.5 ';
        }
        if (parent?.layoutType() === 'inline-flex') {
            if (parent.prefixInline() || parent.prefixDropdown())
                cls += 'pl-1 ';
            else
                cls += 'pl-3 ';
            if (parent.suffixInline() || parent.suffixDropdown() || parent.suffixShortcut())
                cls += 'pr-3 ';
            else if (hasExtraSuffix)
                cls += 'pr-10 sm:pr-9 ';
            else
                cls += 'pr-3 ';
            cls += 'min-w-0 grow ';
        }
        else {
            if (variant === 'pill') {
                cls += 'px-4 ';
            }
            else {
                if (parent && parent.prefixIcon())
                    cls += 'pl-10 sm:pl-9 ';
                else
                    cls += 'pl-3 ';
                if ((parent && parent.suffixIcon()) || hasExtraSuffix)
                    cls += 'pr-10 sm:pr-9 ';
                else
                    cls += 'pr-3 ';
            }
        }
        if (parent && parent.prefixAddon()) {
            cls += '-ml-px ';
        }
        if (variant === 'inset' ||
            variant === 'gray-bottom' ||
            parent?.layoutType() === 'inline-flex') {
            cls += 'focus:outline focus:outline-0 ';
        }
        else {
            cls +=
                'outline outline-1 -outline-offset-1 focus:outline focus:outline-2 focus:-outline-offset-2 ';
            if (hasError) {
                cls += 'outline-red-300 focus:outline-error ';
            }
            else if (parent?.success()) {
                cls += 'outline-green-300 focus:outline-green-500 ';
            }
            else {
                cls += 'outline-outline focus:outline-primary ';
            }
        }
        if (parent && parent.sharedBorders() !== 'none') {
            cls += 'focus:relative ';
        }
        if (parent?.layoutType() === 'grid' || parent?.layoutType() === 'addon-flex-with-icons') {
            cls += 'col-start-1 row-start-1 ';
        }
        return cls;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: InputDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: InputDirective, isStandalone: true, selector: "[pgInput]", inputs: { disabled: "disabled", isInvalid: ["aria-invalid", "isInvalid"] }, host: { listeners: { "input": "onInput($event.target.value)", "blur": "onBlur()" }, properties: { "class": "this.classes" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: InputDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pgInput]',
                    standalone: true,
                }]
        }], ctorParameters: () => [], propDecorators: { disabled: [{
                type: Input
            }], isInvalid: [{
                type: Input,
                args: ['aria-invalid']
            }], onInput: [{
                type: HostListener,
                args: ['input', ['$event.target.value']]
            }], onBlur: [{
                type: HostListener,
                args: ['blur']
            }], classes: [{
                type: HostBinding,
                args: ['class']
            }] } });
class PrefixIconDirective {
    sanitizer = inject(DomSanitizer);
    get boundInnerHTML() {
        return this.injectedHtml || null;
    }
    injectedHtml = null;
    set content(value) {
        if (value) {
            this.injectedHtml = this.sanitizer.bypassSecurityTrustHtml(value);
        }
        else {
            this.injectedHtml = null;
        }
    }
    get cls() {
        return 'pointer-events-none col-start-1 row-start-1 ml-3 size-5 self-center text-content-subtle sm:size-4 [&>svg]:size-full';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PrefixIconDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: PrefixIconDirective, isStandalone: true, selector: "[pgPrefixIcon]", inputs: { content: ["pgPrefixIcon", "content"] }, host: { properties: { "innerHTML": "this.boundInnerHTML", "class": "this.cls" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PrefixIconDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[pgPrefixIcon]', standalone: true }]
        }], propDecorators: { boundInnerHTML: [{
                type: HostBinding,
                args: ['innerHTML']
            }], content: [{
                type: Input,
                args: ['pgPrefixIcon']
            }], cls: [{
                type: HostBinding,
                args: ['class']
            }] } });
class SuffixIconDirective {
    sanitizer = inject(DomSanitizer);
    get boundInnerHTML() {
        return this.injectedHtml || null;
    }
    injectedHtml = null;
    set content(value) {
        if (value) {
            this.injectedHtml = this.sanitizer.bypassSecurityTrustHtml(value);
        }
        else {
            this.injectedHtml = null;
        }
    }
    get cls() {
        return 'pointer-events-none col-start-1 row-start-1 mr-3 size-5 self-center justify-self-end text-content-subtle sm:size-4 [&>svg]:size-full';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: SuffixIconDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: SuffixIconDirective, isStandalone: true, selector: "[pgSuffixIcon]", inputs: { content: ["pgSuffixIcon", "content"] }, host: { properties: { "innerHTML": "this.boundInnerHTML", "class": "this.cls" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: SuffixIconDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[pgSuffixIcon]', standalone: true }]
        }], propDecorators: { boundInnerHTML: [{
                type: HostBinding,
                args: ['innerHTML']
            }], content: [{
                type: Input,
                args: ['pgSuffixIcon']
            }], cls: [{
                type: HostBinding,
                args: ['class']
            }] } });
class PrefixAddonDirective {
    get cls() {
        return 'flex shrink-0 items-center rounded-l-md bg-surface px-3 text-base text-content-muted outline outline-1 -outline-offset-1 outline-outline sm:text-sm/6';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PrefixAddonDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: PrefixAddonDirective, isStandalone: true, selector: "[pgPrefixAddon]", host: { properties: { "class": "this.cls" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PrefixAddonDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[pgPrefixAddon]', standalone: true }]
        }], propDecorators: { cls: [{
                type: HostBinding,
                args: ['class']
            }] } });
class SuffixAddonDirective {
    get cls() {
        return 'flex shrink-0 items-center rounded-r-md bg-surface px-3 text-base text-content-muted outline outline-1 -outline-offset-1 outline-outline sm:text-sm/6';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: SuffixAddonDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: SuffixAddonDirective, isStandalone: true, selector: "[pgSuffixAddon]", host: { properties: { "class": "this.cls" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: SuffixAddonDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[pgSuffixAddon]', standalone: true }]
        }], propDecorators: { cls: [{
                type: HostBinding,
                args: ['class']
            }] } });
class PrefixInlineDirective {
    get cls() {
        return 'shrink-0 select-none text-base text-content-muted sm:text-sm/6';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PrefixInlineDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: PrefixInlineDirective, isStandalone: true, selector: "[pgPrefixInline]", host: { properties: { "class": "this.cls" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PrefixInlineDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[pgPrefixInline]', standalone: true }]
        }], propDecorators: { cls: [{
                type: HostBinding,
                args: ['class']
            }] } });
class SuffixInlineDirective {
    get cls() {
        return 'shrink-0 select-none text-base text-content-muted sm:text-sm/6';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: SuffixInlineDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: SuffixInlineDirective, isStandalone: true, selector: "[pgSuffixInline]", host: { properties: { "class": "this.cls" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: SuffixInlineDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[pgSuffixInline]', standalone: true }]
        }], propDecorators: { cls: [{
                type: HostBinding,
                args: ['class']
            }] } });
class PrefixDropdownDirective {
    get cls() {
        return 'grid shrink-0 grid-cols-1 focus-within:relative';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PrefixDropdownDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: PrefixDropdownDirective, isStandalone: true, selector: "[pgPrefixDropdown]", host: { properties: { "class": "this.cls" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PrefixDropdownDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[pgPrefixDropdown]', standalone: true }]
        }], propDecorators: { cls: [{
                type: HostBinding,
                args: ['class']
            }] } });
class SuffixDropdownDirective {
    get cls() {
        return 'grid shrink-0 grid-cols-1 focus-within:relative';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: SuffixDropdownDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: SuffixDropdownDirective, isStandalone: true, selector: "[pgSuffixDropdown]", host: { properties: { "class": "this.cls" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: SuffixDropdownDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[pgSuffixDropdown]', standalone: true }]
        }], propDecorators: { cls: [{
                type: HostBinding,
                args: ['class']
            }] } });
class DropdownSelectDirective {
    get cls() {
        return 'col-start-1 row-start-1 w-full appearance-none rounded-md py-1.5 pl-3 pr-7 text-base text-content-muted placeholder:text-content-subtle focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-primary sm:text-sm/6 bg-transparent';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: DropdownSelectDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: DropdownSelectDirective, isStandalone: true, selector: "[pgDropdownSelect]", host: { properties: { "class": "this.cls" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: DropdownSelectDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[pgDropdownSelect]', standalone: true }]
        }], propDecorators: { cls: [{
                type: HostBinding,
                args: ['class']
            }] } });
class SuffixButtonDirective {
    get cls() {
        return 'flex shrink-0 items-center gap-x-1.5 rounded-r-md bg-surface px-3 py-2 text-sm font-semibold text-content outline outline-1 -outline-offset-1 outline-outline hover:bg-surface-muted focus:relative focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-primary';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: SuffixButtonDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: SuffixButtonDirective, isStandalone: true, selector: "[pgSuffixButton]", host: { properties: { "class": "this.cls" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: SuffixButtonDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[pgSuffixButton]', standalone: true }]
        }], propDecorators: { cls: [{
                type: HostBinding,
                args: ['class']
            }] } });
class SuffixShortcutDirective {
    get cls() {
        return 'flex py-1.5 pr-1.5';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: SuffixShortcutDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: SuffixShortcutDirective, isStandalone: true, selector: "[pgSuffixShortcut]", host: { properties: { "class": "this.cls" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: SuffixShortcutDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[pgSuffixShortcut]', standalone: true }]
        }], propDecorators: { cls: [{
                type: HostBinding,
                args: ['class']
            }] } });

class InputComponent extends PgControlValueAccessorBase {
    idService = inject(IdService);
    _autoId = this.idService.generate('pg-input');
    // Tracks ngControl presence as a signal so layoutType can depend on it.
    // ngControl is set in ngOnInit (to break the DI cycle), so this is the only
    // way to make layoutType stable without reading hasError() at runtime.
    _hasNgControl = signal(false);
    label = input();
    helpText = input();
    errorText = input();
    cornerHint = input();
    forId = input('');
    variant = input('default');
    size = input('md');
    sharedBorders = input('none');
    required = input(false);
    /**
     * Fuerza el estado de error. Toma precedencia sobre el computed del NgControl.
     * Útil cuando el componente se usa sin ReactiveFormsModule.
     */
    error = input(undefined);
    /**
     * Muestra un ícono de éxito (check verde). No aplica si hay error activo.
     */
    success = input(false);
    /**
     * Muestra un botón de toggle para ver/ocultar contraseñas.
     * Solo tiene efecto cuando el input nativo tiene type="password".
     */
    showPasswordToggle = input(false);
    isPasswordVisible = signal(false);
    ngOnInit() {
        super.ngOnInit();
        this._hasNgControl.set(!!this.ngControl?.control);
    }
    togglePassword() {
        this.isPasswordVisible.update(v => !v);
    }
    prefixIcon = contentChild(PrefixIconDirective);
    suffixIcon = contentChild(SuffixIconDirective);
    prefixAddon = contentChild(PrefixAddonDirective);
    suffixAddon = contentChild(SuffixAddonDirective);
    prefixInline = contentChild(PrefixInlineDirective);
    suffixInline = contentChild(SuffixInlineDirective);
    prefixDropdown = contentChild(PrefixDropdownDirective);
    suffixDropdown = contentChild(SuffixDropdownDirective);
    suffixButton = contentChild(SuffixButtonDirective);
    suffixShortcut = contentChild(SuffixShortcutDirective);
    computedForId = computed(() => this.forId() || this._autoId);
    hasError = computed(() => {
        const override = this.error();
        if (override !== undefined)
            return override;
        const ctrl = this.ngControl?.control;
        if (!ctrl)
            return false;
        return ctrl.invalid && (ctrl.touched || ctrl.dirty);
    });
    layoutType = computed(() => {
        // hasError() is intentionally excluded: it changes on every validation cycle
        // (reactive forms validate on each keystroke) which would restructure the DOM
        // and move the projected <input> node — causing focus loss after one character.
        //
        // Instead we detect upfront whether an error/success/password icon might appear:
        //   - error() !== undefined  → [error] input is explicitly bound by the parent
        //   - _hasNgControl()        → a reactive form is wired up (set once in ngOnInit)
        const mightHaveErrorIcon = this.error() !== undefined || this._hasNgControl();
        const hasExtraSuffix = mightHaveErrorIcon || this.success() || this.showPasswordToggle();
        if (this.prefixInline() ||
            this.suffixInline() ||
            this.prefixDropdown() ||
            this.suffixDropdown() ||
            this.suffixShortcut()) {
            return 'inline-flex';
        }
        if (this.prefixAddon() || this.suffixAddon() || this.suffixButton()) {
            if (this.prefixIcon() || this.suffixIcon() || hasExtraSuffix) {
                return 'addon-flex-with-icons';
            }
            return 'addon-flex';
        }
        if (this.prefixIcon() || this.suffixIcon() || hasExtraSuffix) {
            return 'grid';
        }
        return 'standard';
    });
    get hostClasses() {
        let cls = 'block ';
        if (this.sharedBorders() !== 'none') {
            if (this.sharedBorders() === 'bottom-left')
                cls += '-mr-px -mt-px ';
            else if (this.sharedBorders() === 'bottom-right' || this.sharedBorders() === 'bottom')
                cls += '-mt-px ';
        }
        if (this.variant() === 'inset' && this.sharedBorders() !== 'none') {
            cls = 'block ';
        }
        return cls;
    }
    inlineContainerClass = computed(() => {
        let cls = 'flex rounded-md bg-white outline outline-1 -outline-offset-1 outline-gray-300 focus-within:outline focus-within:outline-2 focus-within:-outline-offset-2 focus-within:outline-primary ';
        if (this.prefixInline() || this.suffixInline()) {
            cls += 'items-center ';
        }
        if (this.prefixInline() && this.suffixInline()) {
            cls += 'px-3 ';
        }
        else if (this.prefixInline()) {
            cls += 'pl-3 ';
        }
        else if (this.suffixShortcut()) {
        }
        return cls;
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: InputComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: InputComponent, isStandalone: true, selector: "pg-input", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, helpText: { classPropertyName: "helpText", publicName: "helpText", isSignal: true, isRequired: false, transformFunction: null }, errorText: { classPropertyName: "errorText", publicName: "errorText", isSignal: true, isRequired: false, transformFunction: null }, cornerHint: { classPropertyName: "cornerHint", publicName: "cornerHint", isSignal: true, isRequired: false, transformFunction: null }, forId: { classPropertyName: "forId", publicName: "forId", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, sharedBorders: { classPropertyName: "sharedBorders", publicName: "sharedBorders", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, success: { classPropertyName: "success", publicName: "success", isSignal: true, isRequired: false, transformFunction: null }, showPasswordToggle: { classPropertyName: "showPasswordToggle", publicName: "showPasswordToggle", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "this.hostClasses" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => InputComponent),
                multi: true,
            },
        ], queries: [{ propertyName: "prefixIcon", first: true, predicate: PrefixIconDirective, descendants: true, isSignal: true }, { propertyName: "suffixIcon", first: true, predicate: SuffixIconDirective, descendants: true, isSignal: true }, { propertyName: "prefixAddon", first: true, predicate: PrefixAddonDirective, descendants: true, isSignal: true }, { propertyName: "suffixAddon", first: true, predicate: SuffixAddonDirective, descendants: true, isSignal: true }, { propertyName: "prefixInline", first: true, predicate: PrefixInlineDirective, descendants: true, isSignal: true }, { propertyName: "suffixInline", first: true, predicate: SuffixInlineDirective, descendants: true, isSignal: true }, { propertyName: "prefixDropdown", first: true, predicate: PrefixDropdownDirective, descendants: true, isSignal: true }, { propertyName: "suffixDropdown", first: true, predicate: SuffixDropdownDirective, descendants: true, isSignal: true }, { propertyName: "suffixButton", first: true, predicate: SuffixButtonDirective, descendants: true, isSignal: true }, { propertyName: "suffixShortcut", first: true, predicate: SuffixShortcutDirective, descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "@if (variant() === 'inset') {\n  <div\n    [ngClass]=\"[\n      'bg-surface px-3 pb-1.5 pt-2.5 outline outline-1 -outline-offset-1 outline-outline focus-within:outline focus-within:outline-2 focus-within:-outline-offset-2 focus-within:outline-primary',\n      sharedBorders() === 'none'\n        ? 'rounded-md'\n        : sharedBorders() === 'top'\n          ? 'rounded-t-md focus-within:relative'\n          : sharedBorders() === 'bottom'\n            ? 'rounded-b-md focus-within:relative'\n            : 'rounded-none focus-within:relative',\n    ]\"\n  >\n    <label [for]=\"computedForId()\" class=\"block text-xs font-medium text-content\"\n      >{{ label() }}\n      @if (required()) {\n        <span class=\"text-error ml-0.5\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n    <ng-container *ngTemplateOutlet=\"coreInput\"></ng-container>\n  </div>\n} @else if (variant() === 'overlapping') {\n  <div class=\"relative\">\n    <label\n      [for]=\"computedForId()\"\n      class=\"absolute -top-2 left-2 inline-block rounded-lg bg-surface px-1 text-xs font-medium text-content\"\n      >{{ label() }}\n      @if (required()) {\n        <span class=\"text-error ml-0.5\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n    <ng-container *ngTemplateOutlet=\"coreInput\"></ng-container>\n  </div>\n} @else if (variant() === 'gray-bottom') {\n  <ng-container *ngTemplateOutlet=\"labelAndHint\"></ng-container>\n  <div class=\"relative mt-2\">\n    <ng-container *ngTemplateOutlet=\"coreInput\"></ng-container>\n    <div\n      aria-hidden=\"true\"\n      class=\"absolute inset-x-0 bottom-0 border-t border-outline peer-focus:border-t-2 peer-focus:border-primary\"\n    ></div>\n  </div>\n} @else {\n  <ng-container *ngTemplateOutlet=\"labelAndHint\"></ng-container>\n  @if (label() || cornerHint()) {\n    <div class=\"mt-2\">\n      <ng-container *ngTemplateOutlet=\"coreInput\"></ng-container>\n    </div>\n  } @else {\n    <ng-container *ngTemplateOutlet=\"coreInput\"></ng-container>\n  }\n}\n\n@if (hasError() && errorText()) {\n  <p class=\"mt-2 text-sm text-error\" [id]=\"computedForId() + '-error'\">{{ errorText() }}</p>\n} @else if (helpText()) {\n  <p class=\"mt-2 text-sm text-content-muted\" [id]=\"computedForId() + '-description'\">{{ helpText() }}</p>\n}\n\n<ng-template #labelAndHint>\n  @if (label()) {\n    <div class=\"flex justify-between\">\n      <label\n        [for]=\"computedForId()\"\n        class=\"block text-sm/6 font-medium text-content\"\n        [ngClass]=\"{ 'ml-px pl-4': variant() === 'pill' }\"\n        >{{ label() }}\n        @if (required()) {\n          <span class=\"text-error ml-0.5\" aria-hidden=\"true\">*</span>\n        }\n      </label>\n      @if (cornerHint()) {\n        <span class=\"text-sm/6 text-content-muted\" [id]=\"computedForId() + '-optional'\">{{\n          cornerHint()\n        }}</span>\n      }\n    </div>\n  }\n</ng-template>\n\n<ng-template #coreInput>\n  @if (layoutType() === 'inline-flex') {\n    <div [className]=\"inlineContainerClass()\">\n      <ng-content select=\"[pgPrefixInline]\"></ng-content>\n      <ng-content select=\"[pgPrefixDropdown]\"></ng-content>\n\n      <ng-container *ngTemplateOutlet=\"inputWithAddons\"></ng-container>\n\n      <ng-content select=\"[pgSuffixInline]\"></ng-content>\n      <ng-content select=\"[pgSuffixDropdown]\"></ng-content>\n      <ng-content select=\"[pgSuffixShortcut]\"></ng-content>\n    </div>\n  } @else {\n    <ng-container *ngTemplateOutlet=\"inputWithAddons\"></ng-container>\n  }\n</ng-template>\n\n<ng-template #inputWithAddons>\n  @if (layoutType() === 'addon-flex' || layoutType() === 'addon-flex-with-icons') {\n    <div class=\"flex\">\n      <ng-content select=\"[pgPrefixAddon]\"></ng-content>\n\n      @if (layoutType() === 'addon-flex-with-icons') {\n        <div class=\"-mr-px grid grow grid-cols-1 focus-within:relative\">\n          <ng-container *ngTemplateOutlet=\"inputElement\"></ng-container>\n          <ng-content select=\"[pgPrefixIcon]\"></ng-content>\n          <ng-container *ngTemplateOutlet=\"errorOrSuffixIcon\"></ng-container>\n        </div>\n      } @else {\n        <ng-container *ngTemplateOutlet=\"inputElement\"></ng-container>\n      }\n\n      <ng-content select=\"[pgSuffixAddon]\"></ng-content>\n      <ng-content select=\"[pgSuffixButton]\"></ng-content>\n    </div>\n  } @else {\n    <ng-container *ngTemplateOutlet=\"inputWithGrid\"></ng-container>\n  }\n</ng-template>\n\n<ng-template #inputWithGrid>\n  @if (layoutType() === 'grid') {\n    <div class=\"grid grid-cols-1\">\n      <ng-container *ngTemplateOutlet=\"inputElement\"></ng-container>\n      <ng-content select=\"[pgPrefixIcon]\"></ng-content>\n      <ng-container *ngTemplateOutlet=\"errorOrSuffixIcon\"></ng-container>\n    </div>\n  } @else {\n    <ng-container *ngTemplateOutlet=\"inputElement\"></ng-container>\n  }\n</ng-template>\n\n<ng-template #errorOrSuffixIcon>\n  @if (hasError()) {\n    <svg\n      viewBox=\"0 0 16 16\"\n      fill=\"currentColor\"\n      aria-hidden=\"true\"\n      class=\"pointer-events-none col-start-1 row-start-1 mr-3 size-5 self-center justify-self-end text-error sm:size-4\"\n    >\n      <path\n        fill-rule=\"evenodd\"\n        clip-rule=\"evenodd\"\n        d=\"M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14ZM8 4a.75.75 0 0 1 .75.75v3a.75.75 0 0 1-1.5 0v-3A.75.75 0 0 1 8 4Zm0 8a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z\"\n      />\n    </svg>\n  } @else if (success()) {\n    <svg\n      viewBox=\"0 0 16 16\"\n      fill=\"currentColor\"\n      aria-hidden=\"true\"\n      class=\"pointer-events-none col-start-1 row-start-1 mr-3 size-5 self-center justify-self-end text-green-500 sm:size-4\"\n    >\n      <path\n        fill-rule=\"evenodd\"\n        clip-rule=\"evenodd\"\n        d=\"M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14Zm3.707-9.293a1 1 0 0 0-1.414-1.414L7 7.586 5.707 6.293a1 1 0 0 0-1.414 1.414l2 2a1 1 0 0 0 1.414 0l4-4Z\"\n      />\n    </svg>\n  } @else if (showPasswordToggle()) {\n    <button\n      type=\"button\"\n      tabindex=\"-1\"\n      class=\"col-start-1 row-start-1 mr-3 self-center justify-self-end text-content-subtle hover:text-content-muted focus:outline-none\"\n      [attr.aria-label]=\"isPasswordVisible() ? 'Ocultar contrase\u00F1a' : 'Mostrar contrase\u00F1a'\"\n      (click)=\"togglePassword()\"\n    >\n      @if (isPasswordVisible()) {\n        <svg viewBox=\"0 0 640 640\" fill=\"currentColor\" aria-hidden=\"true\" class=\"size-5 sm:size-4\">\n          <path\n            d=\"M320 96C239.2 96 174.5 132.8 127.4 176.6C80.6 220.1 49.3 272 34.4 307.7C31.1 315.6 31.1 324.4 34.4 332.3C49.3 368 80.6 420 127.4 463.4C174.5 507.1 239.2 544 320 544C400.8 544 465.5 507.2 512.6 463.4C559.4 419.9 590.7 368 605.6 332.3C608.9 324.4 608.9 315.6 605.6 307.7C590.7 272 559.4 220 512.6 176.6C465.5 132.9 400.8 96 320 96zM176 320C176 240.5 240.5 176 320 176C399.5 176 464 240.5 464 320C464 399.5 399.5 464 320 464C240.5 464 176 399.5 176 320zM320 256C320 291.3 291.3 320 256 320C244.5 320 233.7 317 224.3 311.6C223.3 322.5 224.2 333.7 227.2 344.8C240.9 396 293.6 426.4 344.8 412.7C396 399 426.4 346.3 412.7 295.1C400.5 249.4 357.2 220.3 311.6 224.3C316.9 233.6 320 244.4 320 256z\"\n          />\n        </svg>\n      } @else {\n        <svg viewBox=\"0 0 640 640\" fill=\"currentColor\" aria-hidden=\"true\" class=\"size-5 sm:size-4\">\n          <path\n            d=\"M73 39.1C63.6 29.7 48.4 29.7 39.1 39.1C29.8 48.5 29.7 63.7 39 73.1L567 601.1C576.4 610.5 591.6 610.5 600.9 601.1C610.2 591.7 610.3 576.5 600.9 567.2L504.5 470.8C507.2 468.4 509.9 466 512.5 463.6C559.3 420.1 590.6 368.2 605.5 332.5C608.8 324.6 608.8 315.8 605.5 307.9C590.6 272.2 559.3 220.2 512.5 176.8C465.4 133.1 400.7 96.2 319.9 96.2C263.1 96.2 214.3 114.4 173.9 140.4L73 39.1zM236.5 202.7C260 185.9 288.9 176 320 176C399.5 176 464 240.5 464 320C464 351.1 454.1 379.9 437.3 403.5L402.6 368.8C415.3 347.4 419.6 321.1 412.7 295.1C399 243.9 346.3 213.5 295.1 227.2C286.5 229.5 278.4 232.9 271.1 237.2L236.4 202.5zM357.3 459.1C345.4 462.3 332.9 464 320 464C240.5 464 176 399.5 176 320C176 307.1 177.7 294.6 180.9 282.7L101.4 203.2C68.8 240 46.4 279 34.5 307.7C31.2 315.6 31.2 324.4 34.5 332.3C49.4 368 80.7 420 127.5 463.4C174.6 507.1 239.3 544 320.1 544C357.4 544 391.3 536.1 421.6 523.4L357.4 459.2z\"\n          />\n        </svg>\n      }\n    </button>\n  } @else {\n    <ng-content select=\"[pgSuffixIcon]\"></ng-content>\n  }\n</ng-template>\n\n<ng-template #inputElement>\n  <ng-content select=\"[pgInput]\"></ng-content>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: InputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-input', imports: [NgTemplateOutlet, NgClass], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => InputComponent),
                            multi: true,
                        },
                    ], template: "@if (variant() === 'inset') {\n  <div\n    [ngClass]=\"[\n      'bg-surface px-3 pb-1.5 pt-2.5 outline outline-1 -outline-offset-1 outline-outline focus-within:outline focus-within:outline-2 focus-within:-outline-offset-2 focus-within:outline-primary',\n      sharedBorders() === 'none'\n        ? 'rounded-md'\n        : sharedBorders() === 'top'\n          ? 'rounded-t-md focus-within:relative'\n          : sharedBorders() === 'bottom'\n            ? 'rounded-b-md focus-within:relative'\n            : 'rounded-none focus-within:relative',\n    ]\"\n  >\n    <label [for]=\"computedForId()\" class=\"block text-xs font-medium text-content\"\n      >{{ label() }}\n      @if (required()) {\n        <span class=\"text-error ml-0.5\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n    <ng-container *ngTemplateOutlet=\"coreInput\"></ng-container>\n  </div>\n} @else if (variant() === 'overlapping') {\n  <div class=\"relative\">\n    <label\n      [for]=\"computedForId()\"\n      class=\"absolute -top-2 left-2 inline-block rounded-lg bg-surface px-1 text-xs font-medium text-content\"\n      >{{ label() }}\n      @if (required()) {\n        <span class=\"text-error ml-0.5\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n    <ng-container *ngTemplateOutlet=\"coreInput\"></ng-container>\n  </div>\n} @else if (variant() === 'gray-bottom') {\n  <ng-container *ngTemplateOutlet=\"labelAndHint\"></ng-container>\n  <div class=\"relative mt-2\">\n    <ng-container *ngTemplateOutlet=\"coreInput\"></ng-container>\n    <div\n      aria-hidden=\"true\"\n      class=\"absolute inset-x-0 bottom-0 border-t border-outline peer-focus:border-t-2 peer-focus:border-primary\"\n    ></div>\n  </div>\n} @else {\n  <ng-container *ngTemplateOutlet=\"labelAndHint\"></ng-container>\n  @if (label() || cornerHint()) {\n    <div class=\"mt-2\">\n      <ng-container *ngTemplateOutlet=\"coreInput\"></ng-container>\n    </div>\n  } @else {\n    <ng-container *ngTemplateOutlet=\"coreInput\"></ng-container>\n  }\n}\n\n@if (hasError() && errorText()) {\n  <p class=\"mt-2 text-sm text-error\" [id]=\"computedForId() + '-error'\">{{ errorText() }}</p>\n} @else if (helpText()) {\n  <p class=\"mt-2 text-sm text-content-muted\" [id]=\"computedForId() + '-description'\">{{ helpText() }}</p>\n}\n\n<ng-template #labelAndHint>\n  @if (label()) {\n    <div class=\"flex justify-between\">\n      <label\n        [for]=\"computedForId()\"\n        class=\"block text-sm/6 font-medium text-content\"\n        [ngClass]=\"{ 'ml-px pl-4': variant() === 'pill' }\"\n        >{{ label() }}\n        @if (required()) {\n          <span class=\"text-error ml-0.5\" aria-hidden=\"true\">*</span>\n        }\n      </label>\n      @if (cornerHint()) {\n        <span class=\"text-sm/6 text-content-muted\" [id]=\"computedForId() + '-optional'\">{{\n          cornerHint()\n        }}</span>\n      }\n    </div>\n  }\n</ng-template>\n\n<ng-template #coreInput>\n  @if (layoutType() === 'inline-flex') {\n    <div [className]=\"inlineContainerClass()\">\n      <ng-content select=\"[pgPrefixInline]\"></ng-content>\n      <ng-content select=\"[pgPrefixDropdown]\"></ng-content>\n\n      <ng-container *ngTemplateOutlet=\"inputWithAddons\"></ng-container>\n\n      <ng-content select=\"[pgSuffixInline]\"></ng-content>\n      <ng-content select=\"[pgSuffixDropdown]\"></ng-content>\n      <ng-content select=\"[pgSuffixShortcut]\"></ng-content>\n    </div>\n  } @else {\n    <ng-container *ngTemplateOutlet=\"inputWithAddons\"></ng-container>\n  }\n</ng-template>\n\n<ng-template #inputWithAddons>\n  @if (layoutType() === 'addon-flex' || layoutType() === 'addon-flex-with-icons') {\n    <div class=\"flex\">\n      <ng-content select=\"[pgPrefixAddon]\"></ng-content>\n\n      @if (layoutType() === 'addon-flex-with-icons') {\n        <div class=\"-mr-px grid grow grid-cols-1 focus-within:relative\">\n          <ng-container *ngTemplateOutlet=\"inputElement\"></ng-container>\n          <ng-content select=\"[pgPrefixIcon]\"></ng-content>\n          <ng-container *ngTemplateOutlet=\"errorOrSuffixIcon\"></ng-container>\n        </div>\n      } @else {\n        <ng-container *ngTemplateOutlet=\"inputElement\"></ng-container>\n      }\n\n      <ng-content select=\"[pgSuffixAddon]\"></ng-content>\n      <ng-content select=\"[pgSuffixButton]\"></ng-content>\n    </div>\n  } @else {\n    <ng-container *ngTemplateOutlet=\"inputWithGrid\"></ng-container>\n  }\n</ng-template>\n\n<ng-template #inputWithGrid>\n  @if (layoutType() === 'grid') {\n    <div class=\"grid grid-cols-1\">\n      <ng-container *ngTemplateOutlet=\"inputElement\"></ng-container>\n      <ng-content select=\"[pgPrefixIcon]\"></ng-content>\n      <ng-container *ngTemplateOutlet=\"errorOrSuffixIcon\"></ng-container>\n    </div>\n  } @else {\n    <ng-container *ngTemplateOutlet=\"inputElement\"></ng-container>\n  }\n</ng-template>\n\n<ng-template #errorOrSuffixIcon>\n  @if (hasError()) {\n    <svg\n      viewBox=\"0 0 16 16\"\n      fill=\"currentColor\"\n      aria-hidden=\"true\"\n      class=\"pointer-events-none col-start-1 row-start-1 mr-3 size-5 self-center justify-self-end text-error sm:size-4\"\n    >\n      <path\n        fill-rule=\"evenodd\"\n        clip-rule=\"evenodd\"\n        d=\"M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14ZM8 4a.75.75 0 0 1 .75.75v3a.75.75 0 0 1-1.5 0v-3A.75.75 0 0 1 8 4Zm0 8a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z\"\n      />\n    </svg>\n  } @else if (success()) {\n    <svg\n      viewBox=\"0 0 16 16\"\n      fill=\"currentColor\"\n      aria-hidden=\"true\"\n      class=\"pointer-events-none col-start-1 row-start-1 mr-3 size-5 self-center justify-self-end text-green-500 sm:size-4\"\n    >\n      <path\n        fill-rule=\"evenodd\"\n        clip-rule=\"evenodd\"\n        d=\"M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14Zm3.707-9.293a1 1 0 0 0-1.414-1.414L7 7.586 5.707 6.293a1 1 0 0 0-1.414 1.414l2 2a1 1 0 0 0 1.414 0l4-4Z\"\n      />\n    </svg>\n  } @else if (showPasswordToggle()) {\n    <button\n      type=\"button\"\n      tabindex=\"-1\"\n      class=\"col-start-1 row-start-1 mr-3 self-center justify-self-end text-content-subtle hover:text-content-muted focus:outline-none\"\n      [attr.aria-label]=\"isPasswordVisible() ? 'Ocultar contrase\u00F1a' : 'Mostrar contrase\u00F1a'\"\n      (click)=\"togglePassword()\"\n    >\n      @if (isPasswordVisible()) {\n        <svg viewBox=\"0 0 640 640\" fill=\"currentColor\" aria-hidden=\"true\" class=\"size-5 sm:size-4\">\n          <path\n            d=\"M320 96C239.2 96 174.5 132.8 127.4 176.6C80.6 220.1 49.3 272 34.4 307.7C31.1 315.6 31.1 324.4 34.4 332.3C49.3 368 80.6 420 127.4 463.4C174.5 507.1 239.2 544 320 544C400.8 544 465.5 507.2 512.6 463.4C559.4 419.9 590.7 368 605.6 332.3C608.9 324.4 608.9 315.6 605.6 307.7C590.7 272 559.4 220 512.6 176.6C465.5 132.9 400.8 96 320 96zM176 320C176 240.5 240.5 176 320 176C399.5 176 464 240.5 464 320C464 399.5 399.5 464 320 464C240.5 464 176 399.5 176 320zM320 256C320 291.3 291.3 320 256 320C244.5 320 233.7 317 224.3 311.6C223.3 322.5 224.2 333.7 227.2 344.8C240.9 396 293.6 426.4 344.8 412.7C396 399 426.4 346.3 412.7 295.1C400.5 249.4 357.2 220.3 311.6 224.3C316.9 233.6 320 244.4 320 256z\"\n          />\n        </svg>\n      } @else {\n        <svg viewBox=\"0 0 640 640\" fill=\"currentColor\" aria-hidden=\"true\" class=\"size-5 sm:size-4\">\n          <path\n            d=\"M73 39.1C63.6 29.7 48.4 29.7 39.1 39.1C29.8 48.5 29.7 63.7 39 73.1L567 601.1C576.4 610.5 591.6 610.5 600.9 601.1C610.2 591.7 610.3 576.5 600.9 567.2L504.5 470.8C507.2 468.4 509.9 466 512.5 463.6C559.3 420.1 590.6 368.2 605.5 332.5C608.8 324.6 608.8 315.8 605.5 307.9C590.6 272.2 559.3 220.2 512.5 176.8C465.4 133.1 400.7 96.2 319.9 96.2C263.1 96.2 214.3 114.4 173.9 140.4L73 39.1zM236.5 202.7C260 185.9 288.9 176 320 176C399.5 176 464 240.5 464 320C464 351.1 454.1 379.9 437.3 403.5L402.6 368.8C415.3 347.4 419.6 321.1 412.7 295.1C399 243.9 346.3 213.5 295.1 227.2C286.5 229.5 278.4 232.9 271.1 237.2L236.4 202.5zM357.3 459.1C345.4 462.3 332.9 464 320 464C240.5 464 176 399.5 176 320C176 307.1 177.7 294.6 180.9 282.7L101.4 203.2C68.8 240 46.4 279 34.5 307.7C31.2 315.6 31.2 324.4 34.5 332.3C49.4 368 80.7 420 127.5 463.4C174.6 507.1 239.3 544 320.1 544C357.4 544 391.3 536.1 421.6 523.4L357.4 459.2z\"\n          />\n        </svg>\n      }\n    </button>\n  } @else {\n    <ng-content select=\"[pgSuffixIcon]\"></ng-content>\n  }\n</ng-template>\n\n<ng-template #inputElement>\n  <ng-content select=\"[pgInput]\"></ng-content>\n</ng-template>\n" }]
        }], propDecorators: { hostClasses: [{
                type: HostBinding,
                args: ['class']
            }] } });

class PgRadioGroupComponent extends PgControlValueAccessorBase {
    idService = inject(IdService);
    _autoName = this.idService.generate('pg-radio-group');
    /** Native `name` shared by every radio input inside this group. Auto-generated unless overridden. */
    name = input('');
    orientation = input('horizontal');
    /** Shared layout for every `pg-radio` child in this group — set once here, not per option. */
    layout = input('default');
    /** Shared shape for every `pg-radio` child — only meaningful when `layout` is `'small-card'`. */
    shape = input('rounded');
    customClass = input('');
    computedName = computed(() => this.name() || this._autoName);
    hostClasses = computed(() => {
        const direction = this.orientation() === 'vertical' ? 'flex-col' : 'flex-row flex-wrap';
        const extra = this.customClass();
        return `flex gap-3 ${direction}${extra ? ` ${extra}` : ''}`;
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgRadioGroupComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.21", type: PgRadioGroupComponent, isStandalone: true, selector: "pg-radio-group", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, layout: { classPropertyName: "layout", publicName: "layout", isSignal: true, isRequired: false, transformFunction: null }, shape: { classPropertyName: "shape", publicName: "shape", isSignal: true, isRequired: false, transformFunction: null }, customClass: { classPropertyName: "customClass", publicName: "customClass", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "radiogroup" }, properties: { "class": "hostClasses()" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => PgRadioGroupComponent),
                multi: true,
            },
        ], usesInheritance: true, ngImport: i0, template: `<ng-content></ng-content>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgRadioGroupComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'pg-radio-group',
                    standalone: true,
                    template: `<ng-content></ng-content>`,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: {
                        role: 'radiogroup',
                        '[class]': 'hostClasses()',
                    },
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => PgRadioGroupComponent),
                            multi: true,
                        },
                    ],
                }]
        }] });

/**
 * Generic reactive host-binding directives for the native radio input rendered
 * inside `pg-radio`'s own template. These have zero knowledge of `RadioComponent`
 * or `PgRadioGroupComponent` — all state flows in via plain `@Input()`s bound
 * explicitly from `radio.component.html`, and state flows out via `@Output()`s.
 * This keeps them fully decoupled (no DI, no circular imports) and reusable.
 */
class RadioDirective {
    pgRadioChecked = input(false);
    pgRadioDisabled = input(false);
    pgRadioName = input('');
    pgRadioValue = input('');
    pgRadioError = input(false);
    pgRadioChange = output();
    pgRadioBlur = output();
    get checked() {
        return this.pgRadioChecked();
    }
    get disabled() {
        return this.pgRadioDisabled();
    }
    get name() {
        return this.pgRadioName();
    }
    get value() {
        return this.pgRadioValue();
    }
    onChange() {
        this.pgRadioChange.emit();
    }
    onBlur() {
        this.pgRadioBlur.emit();
    }
    get hostClasses() {
        const base = 'relative w-4 h-4 appearance-none rounded-full border border-outline bg-surface transition-colors duration-150 hover:border-primary before:absolute before:inset-1 before:rounded-full before:bg-surface checked:border-primary checked:bg-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary disabled:border-outline disabled:hover:border-outline disabled:bg-surface-muted disabled:before:bg-content-subtle forced-colors:appearance-auto forced-colors:before:hidden [&:not(:checked)]:before:hidden';
        return this.pgRadioError() ? `${base} border-error` : base;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: RadioDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "19.2.21", type: RadioDirective, isStandalone: true, selector: "input[pgRadio]", inputs: { pgRadioChecked: { classPropertyName: "pgRadioChecked", publicName: "pgRadioChecked", isSignal: true, isRequired: false, transformFunction: null }, pgRadioDisabled: { classPropertyName: "pgRadioDisabled", publicName: "pgRadioDisabled", isSignal: true, isRequired: false, transformFunction: null }, pgRadioName: { classPropertyName: "pgRadioName", publicName: "pgRadioName", isSignal: true, isRequired: false, transformFunction: null }, pgRadioValue: { classPropertyName: "pgRadioValue", publicName: "pgRadioValue", isSignal: true, isRequired: false, transformFunction: null }, pgRadioError: { classPropertyName: "pgRadioError", publicName: "pgRadioError", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { pgRadioChange: "pgRadioChange", pgRadioBlur: "pgRadioBlur" }, host: { listeners: { "change": "onChange()", "blur": "onBlur()" }, properties: { "checked": "this.checked", "disabled": "this.disabled", "name": "this.name", "value": "this.value", "class": "this.hostClasses" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: RadioDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input[pgRadio]',
                    standalone: true,
                }]
        }], propDecorators: { checked: [{
                type: HostBinding,
                args: ['checked']
            }], disabled: [{
                type: HostBinding,
                args: ['disabled']
            }], name: [{
                type: HostBinding,
                args: ['name']
            }], value: [{
                type: HostBinding,
                args: ['value']
            }], onChange: [{
                type: HostListener,
                args: ['change']
            }], onBlur: [{
                type: HostListener,
                args: ['blur']
            }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }] } });
class RadioColorDirective {
    pgRadioChecked = input(false);
    pgRadioDisabled = input(false);
    pgRadioName = input('');
    pgRadioValue = input('');
    pgRadioChange = output();
    pgRadioBlur = output();
    get checked() {
        return this.pgRadioChecked();
    }
    get disabled() {
        return this.pgRadioDisabled();
    }
    get name() {
        return this.pgRadioName();
    }
    get value() {
        return this.pgRadioValue();
    }
    onChange() {
        this.pgRadioChange.emit();
    }
    onBlur() {
        this.pgRadioBlur.emit();
    }
    get hostClasses() {
        return 'w-8 h-8 appearance-none rounded-full forced-color-adjust-none transition-transform duration-150 hover:scale-110 checked:outline checked:outline-2 checked:outline-offset-2 checked:outline-current focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-offset-[3px]';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: RadioColorDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "19.2.21", type: RadioColorDirective, isStandalone: true, selector: "input[pgRadioColor]", inputs: { pgRadioChecked: { classPropertyName: "pgRadioChecked", publicName: "pgRadioChecked", isSignal: true, isRequired: false, transformFunction: null }, pgRadioDisabled: { classPropertyName: "pgRadioDisabled", publicName: "pgRadioDisabled", isSignal: true, isRequired: false, transformFunction: null }, pgRadioName: { classPropertyName: "pgRadioName", publicName: "pgRadioName", isSignal: true, isRequired: false, transformFunction: null }, pgRadioValue: { classPropertyName: "pgRadioValue", publicName: "pgRadioValue", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { pgRadioChange: "pgRadioChange", pgRadioBlur: "pgRadioBlur" }, host: { listeners: { "change": "onChange()", "blur": "onBlur()" }, properties: { "checked": "this.checked", "disabled": "this.disabled", "name": "this.name", "value": "this.value", "class": "this.hostClasses" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: RadioColorDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input[pgRadioColor]',
                    standalone: true,
                }]
        }], propDecorators: { checked: [{
                type: HostBinding,
                args: ['checked']
            }], disabled: [{
                type: HostBinding,
                args: ['disabled']
            }], name: [{
                type: HostBinding,
                args: ['name']
            }], value: [{
                type: HostBinding,
                args: ['value']
            }], onChange: [{
                type: HostListener,
                args: ['change']
            }], onBlur: [{
                type: HostListener,
                args: ['blur']
            }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }] } });
class RadioCardDirective {
    pgRadioChecked = input(false);
    pgRadioDisabled = input(false);
    pgRadioName = input('');
    pgRadioValue = input('');
    pgRadioChange = output();
    pgRadioBlur = output();
    get checked() {
        return this.pgRadioChecked();
    }
    get disabled() {
        return this.pgRadioDisabled();
    }
    get name() {
        return this.pgRadioName();
    }
    get value() {
        return this.pgRadioValue();
    }
    onChange() {
        this.pgRadioChange.emit();
    }
    onBlur() {
        this.pgRadioBlur.emit();
    }
    get hostClasses() {
        return 'sr-only';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: RadioCardDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "19.2.21", type: RadioCardDirective, isStandalone: true, selector: "input[pgRadioCard]", inputs: { pgRadioChecked: { classPropertyName: "pgRadioChecked", publicName: "pgRadioChecked", isSignal: true, isRequired: false, transformFunction: null }, pgRadioDisabled: { classPropertyName: "pgRadioDisabled", publicName: "pgRadioDisabled", isSignal: true, isRequired: false, transformFunction: null }, pgRadioName: { classPropertyName: "pgRadioName", publicName: "pgRadioName", isSignal: true, isRequired: false, transformFunction: null }, pgRadioValue: { classPropertyName: "pgRadioValue", publicName: "pgRadioValue", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { pgRadioChange: "pgRadioChange", pgRadioBlur: "pgRadioBlur" }, host: { listeners: { "change": "onChange()", "blur": "onBlur()" }, properties: { "checked": "this.checked", "disabled": "this.disabled", "name": "this.name", "value": "this.value", "class": "this.hostClasses" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: RadioCardDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input[pgRadioCard]',
                    standalone: true,
                }]
        }], propDecorators: { checked: [{
                type: HostBinding,
                args: ['checked']
            }], disabled: [{
                type: HostBinding,
                args: ['disabled']
            }], name: [{
                type: HostBinding,
                args: ['name']
            }], value: [{
                type: HostBinding,
                args: ['value']
            }], onChange: [{
                type: HostListener,
                args: ['change']
            }], onBlur: [{
                type: HostListener,
                args: ['blur']
            }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }] } });
class RadioLabelDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: RadioLabelDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: RadioLabelDirective, isStandalone: true, selector: "[pgRadioLabel]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: RadioLabelDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pgRadioLabel]',
                    standalone: true,
                }]
        }] });
class RadioDescriptionDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: RadioDescriptionDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: RadioDescriptionDirective, isStandalone: true, selector: "[pgRadioDescription]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: RadioDescriptionDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pgRadioDescription]',
                    standalone: true,
                }]
        }] });

class RadioComponent {
    group = inject(PgRadioGroupComponent);
    idService = inject(IdService);
    _autoId = this.idService.generate('pg-radio');
    /** This option's value — compared against the parent group's selected value. */
    value = input.required();
    /** Per-option disabled override, combined (OR) with the group's own disabled state. */
    disabled = input(false);
    label = input('');
    description = input('');
    forId = input('');
    /** Controls vertical padding on `default`/`radio-right` layouts. Preserved from the pre-simplification API — the template still relies on it. */
    padding = input(true);
    /** Extra classes for this option's own host element (the `<pg-radio>` tag itself). */
    hostClass = input('');
    /** Extra classes for the internal swatch input — only meaningful for `layout: 'color'`. */
    swatchClass = input('');
    layout = computed(() => this.group.layout());
    shape = computed(() => this.group.shape());
    /** True when this option is the group's currently selected value. */
    checked = computed(() => this.group.value() === this.value());
    isDisabled = computed(() => this.group.disabled() || this.disabled());
    hasError = computed(() => this.group.hasError());
    /**
     * ID resuelto: usa el input `forId` si se provee, sino genera uno automáticamente.
     */
    computedForId = computed(() => this.forId() || this._autoId);
    computedClass = computed(() => {
        if (['panel', 'card', 'small-card', 'stacked-card'].includes(this.layout())) {
            // w-full only makes sense when the group stacks options in a column —
            // in a horizontal (row) group, forcing full width makes every option
            // claim the whole row, defeating the row layout entirely.
            const stretch = this.group.orientation() === 'vertical' ? 'w-full' : '';
            return `block h-full ${stretch} ${this.hostClass()}`.replace(/\s+/g, ' ').trim();
        }
        return this.hostClass();
    });
    onSelect() {
        this.group.setValue(this.value());
    }
    onBlur() {
        this.group.markAsTouched();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: RadioComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: RadioComponent, isStandalone: true, selector: "pg-radio", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, forId: { classPropertyName: "forId", publicName: "forId", isSignal: true, isRequired: false, transformFunction: null }, padding: { classPropertyName: "padding", publicName: "padding", isSignal: true, isRequired: false, transformFunction: null }, hostClass: { classPropertyName: "hostClass", publicName: "hostClass", isSignal: true, isRequired: false, transformFunction: null }, swatchClass: { classPropertyName: "swatchClass", publicName: "swatchClass", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.layout": "layout()", "class": "computedClass()" } }, ngImport: i0, template: "@if (layout() === 'default' || layout() === 'inline-description' || layout() === 'radio-right') {\n  <div\n    class=\"relative flex\"\n    [class.items-start]=\"description()\"\n    [class.items-center]=\"!description()\"\n    [class.gap-3]=\"layout() !== 'radio-right'\"\n    [class.py-4]=\"padding() && layout() !== 'radio-right'\"\n    [class.pb-4]=\"padding() && layout() === 'radio-right'\"\n    [class.pt-3.5]=\"padding() && layout() === 'radio-right'\"\n  >\n    @if (layout() !== 'radio-right') {\n      <div class=\"flex h-6 items-center shrink-0\">\n        <input\n          pgRadio\n          type=\"radio\"\n          [id]=\"computedForId()\"\n          [pgRadioChecked]=\"checked()\"\n          [pgRadioDisabled]=\"isDisabled()\"\n          [pgRadioName]=\"group.computedName()\"\n          [pgRadioValue]=\"value()\"\n          [pgRadioError]=\"hasError()\"\n          (pgRadioChange)=\"onSelect()\"\n          (pgRadioBlur)=\"onBlur()\"\n        />\n      </div>\n    }\n\n    <div\n      class=\"min-w-0 flex-1 text-sm/6\"\n      [class.ml-3]=\"\n        layout() !== 'radio-right' && layout() !== 'inline-description' && !description()\n      \"\n    >\n      <label [for]=\"computedForId()\" class=\"font-medium text-content\" [class.select-none]=\"true\">\n        {{ label() }}\n        <ng-content select=\"[pgRadioLabel]\"></ng-content>\n      </label>\n\n      @if (description()) {\n        @if (layout() === 'inline-description') {\n          <span [id]=\"computedForId() + '-description'\" class=\"text-content-muted\">\n            <span class=\"sr-only\">{{ label() }} </span>{{ description() }}\n          </span>\n        } @else {\n          <p [id]=\"computedForId() + '-description'\" class=\"text-content-muted\">{{ description() }}</p>\n        }\n      }\n      <ng-content select=\"[pgRadioDescription]\"></ng-content>\n    </div>\n\n    @if (layout() === 'radio-right') {\n      <div class=\"ml-3 flex h-6 shrink-0 items-center\">\n        <input\n          pgRadio\n          type=\"radio\"\n          [id]=\"computedForId()\"\n          [pgRadioChecked]=\"checked()\"\n          [pgRadioDisabled]=\"isDisabled()\"\n          [pgRadioName]=\"group.computedName()\"\n          [pgRadioValue]=\"value()\"\n          [pgRadioError]=\"hasError()\"\n          (pgRadioChange)=\"onSelect()\"\n          (pgRadioBlur)=\"onBlur()\"\n        />\n      </div>\n    }\n  </div>\n}\n\n@if (layout() === 'color') {\n  <div class=\"flex rounded-full outline outline-1 -outline-offset-1 outline-outline-contrast/10\">\n    <input\n      pgRadioColor\n      type=\"radio\"\n      [class]=\"swatchClass()\"\n      [attr.aria-label]=\"label()\"\n      [pgRadioChecked]=\"checked()\"\n      [pgRadioDisabled]=\"isDisabled()\"\n      [pgRadioName]=\"group.computedName()\"\n      [pgRadioValue]=\"value()\"\n      (pgRadioChange)=\"onSelect()\"\n      (pgRadioBlur)=\"onBlur()\"\n    />\n  </div>\n}\n\n@if (layout() === 'panel') {\n  <label\n    [attr.aria-label]=\"label()\"\n    [attr.aria-description]=\"description()\"\n    [class.border-error]=\"hasError()\"\n    class=\"w-full h-full group flex flex-col sm:flex-row border border-outline p-4 transition-colors duration-150 hover:border-primary/60 focus:outline-none has-[:checked]:relative has-[:checked]:border-primary has-[:checked]:bg-primary/10\"\n  >\n    <span class=\"flex items-center gap-3 text-sm\">\n      <input\n        pgRadio\n        type=\"radio\"\n        [pgRadioChecked]=\"checked()\"\n        [pgRadioDisabled]=\"isDisabled()\"\n        [pgRadioName]=\"group.computedName()\"\n        [pgRadioValue]=\"value()\"\n        (pgRadioChange)=\"onSelect()\"\n        (pgRadioBlur)=\"onBlur()\"\n      />\n      <span class=\"font-medium text-content group-has-[:checked]:text-primary\">\n        {{ label() }}\n        <ng-content select=\"[pgRadioLabel]\"></ng-content>\n      </span>\n    </span>\n    <span class=\"ml-6 pl-1 sm:ml-3 sm:pl-0 flex flex-col text-sm\">\n      @if (description()) {\n        <span class=\"block text-content-muted group-has-[:checked]:text-primary\">{{\n          description()\n        }}</span>\n      }\n      <ng-content select=\"[pgRadioDescription]\"></ng-content>\n    </span>\n  </label>\n}\n\n@if (layout() === 'card') {\n  <label\n    [attr.aria-label]=\"label()\"\n    [attr.aria-description]=\"description()\"\n    [class.border-error]=\"hasError()\"\n    class=\"w-full h-full cursor-pointer group relative flex gap-2 rounded-lg border border-outline bg-surface p-4 transition-colors duration-150 hover:border-primary has-[:disabled]:hover:border-gray-400 has-[:disabled]:border-gray-400 has-[:disabled]:bg-gray-200 has-[:disabled]:opacity-25 has-[:checked]:outline has-[:focus-visible]:outline has-[:checked]:outline-2 has-[:focus-visible]:outline-[3px] has-[:checked]:-outline-offset-2 has-[:focus-visible]:-outline-offset-1 has-[:checked]:outline-primary sm:justify-between\"\n  >\n    <input\n      pgRadioCard\n      type=\"radio\"\n      [pgRadioChecked]=\"checked()\"\n      [pgRadioDisabled]=\"isDisabled()\"\n      [pgRadioName]=\"group.computedName()\"\n      [pgRadioValue]=\"value()\"\n      (pgRadioChange)=\"onSelect()\"\n      (pgRadioBlur)=\"onBlur()\"\n    />\n    <div class=\"flex-1\">\n      <span class=\"block text-sm font-medium text-content\">\n        {{ label() }}\n        <ng-content select=\"[pgRadioLabel]\"></ng-content>\n      </span>\n      @if (description()) {\n        <span class=\"mt-1 block text-sm text-content-muted\">{{ description() }}</span>\n      }\n      <ng-content select=\"[pgRadioDescription]\"></ng-content>\n    </div>\n    <svg\n      viewBox=\"0 0 20 20\"\n      fill=\"currentColor\"\n      aria-hidden=\"true\"\n      class=\"invisible size-5 text-primary group-has-[:checked]:visible\"\n    >\n      <path\n        d=\"M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm3.857-9.809a.75.75 0 0 0-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 1 0-1.06 1.061l2.5 2.5a.75.75 0 0 0 1.137-.089l4-5.5Z\"\n        clip-rule=\"evenodd\"\n        fill-rule=\"evenodd\"\n      />\n    </svg>\n  </label>\n}\n\n@if (layout() === 'stacked-card') {\n  <label\n    [attr.aria-label]=\"label()\"\n    [attr.aria-description]=\"description()\"\n    [class.border-error]=\"hasError()\"\n    class=\"w-full h-full cursor-pointer group relative block sm:flex sm:justify-between rounded-lg border border-outline bg-surface px-6 py-4 transition-colors duration-150 hover:border-primary has-[:disabled]:hover:border-gray-400 has-[:disabled]:border-gray-400 has-[:disabled]:bg-gray-200 has-[:disabled]:opacity-25 has-[:checked]:outline has-[:focus-visible]:outline has-[:checked]:outline-2 has-[:focus-visible]:outline-[3px] has-[:checked]:-outline-offset-2 has-[:focus-visible]:-outline-offset-1 has-[:checked]:outline-primary\"\n  >\n    <input\n      pgRadioCard\n      type=\"radio\"\n      [pgRadioChecked]=\"checked()\"\n      [pgRadioDisabled]=\"isDisabled()\"\n      [pgRadioName]=\"group.computedName()\"\n      [pgRadioValue]=\"value()\"\n      (pgRadioChange)=\"onSelect()\"\n      (pgRadioBlur)=\"onBlur()\"\n    />\n    <span class=\"flex items-center\">\n      <span class=\"flex flex-col text-sm\">\n        <span class=\"font-medium text-content\">\n          {{ label() }}\n          <ng-content select=\"[pgRadioLabel]\"></ng-content>\n        </span>\n      </span>\n    </span>\n    <ng-content select=\"[pgRadioDescription]\"></ng-content>\n  </label>\n}\n\n@if (layout() === 'small-card') {\n  <label\n    [attr.aria-label]=\"label()\"\n    [class.rounded-md]=\"shape() === 'rounded'\"\n    [class.rounded-full]=\"shape() === 'pill'\"\n    [class.border-error]=\"hasError()\"\n    class=\"w-full h-full cursor-pointer group relative flex items-center justify-center border border-outline bg-surface px-3 py-2 transition-colors duration-150 hover:border-primary has-[:disabled]:hover:border-gray-400 has-[:checked]:border-primary has-[:disabled]:border-gray-400 has-[:checked]:bg-primary has-[:disabled]:bg-gray-200 has-[:disabled]:opacity-25 has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-primary\"\n  >\n    <input\n      pgRadioCard\n      type=\"radio\"\n      [pgRadioChecked]=\"checked()\"\n      [pgRadioDisabled]=\"isDisabled()\"\n      [pgRadioName]=\"group.computedName()\"\n      [pgRadioValue]=\"value()\"\n      (pgRadioChange)=\"onSelect()\"\n      (pgRadioBlur)=\"onBlur()\"\n    />\n    <span\n      class=\"text-sm font-medium text-content group-has-[:checked]:text-white\"\n      [class.uppercase]=\"shape() === 'rounded'\"\n    >\n      {{ label() }}\n      <ng-content select=\"[pgRadioLabel]\"></ng-content>\n    </span>\n  </label>\n}\n", styles: [":host([layout=\"panel\"]):first-of-type>label{border-top-left-radius:.375rem;border-top-right-radius:.375rem}:host([layout=\"panel\"]):last-of-type>label{border-bottom-left-radius:.375rem;border-bottom-right-radius:.375rem}\n"], dependencies: [{ kind: "directive", type: RadioDirective, selector: "input[pgRadio]", inputs: ["pgRadioChecked", "pgRadioDisabled", "pgRadioName", "pgRadioValue", "pgRadioError"], outputs: ["pgRadioChange", "pgRadioBlur"] }, { kind: "directive", type: RadioCardDirective, selector: "input[pgRadioCard]", inputs: ["pgRadioChecked", "pgRadioDisabled", "pgRadioName", "pgRadioValue"], outputs: ["pgRadioChange", "pgRadioBlur"] }, { kind: "directive", type: RadioColorDirective, selector: "input[pgRadioColor]", inputs: ["pgRadioChecked", "pgRadioDisabled", "pgRadioName", "pgRadioValue"], outputs: ["pgRadioChange", "pgRadioBlur"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: RadioComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-radio', imports: [RadioDirective, RadioCardDirective, RadioColorDirective], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        '[attr.layout]': 'layout()',
                        '[class]': 'computedClass()',
                    }, template: "@if (layout() === 'default' || layout() === 'inline-description' || layout() === 'radio-right') {\n  <div\n    class=\"relative flex\"\n    [class.items-start]=\"description()\"\n    [class.items-center]=\"!description()\"\n    [class.gap-3]=\"layout() !== 'radio-right'\"\n    [class.py-4]=\"padding() && layout() !== 'radio-right'\"\n    [class.pb-4]=\"padding() && layout() === 'radio-right'\"\n    [class.pt-3.5]=\"padding() && layout() === 'radio-right'\"\n  >\n    @if (layout() !== 'radio-right') {\n      <div class=\"flex h-6 items-center shrink-0\">\n        <input\n          pgRadio\n          type=\"radio\"\n          [id]=\"computedForId()\"\n          [pgRadioChecked]=\"checked()\"\n          [pgRadioDisabled]=\"isDisabled()\"\n          [pgRadioName]=\"group.computedName()\"\n          [pgRadioValue]=\"value()\"\n          [pgRadioError]=\"hasError()\"\n          (pgRadioChange)=\"onSelect()\"\n          (pgRadioBlur)=\"onBlur()\"\n        />\n      </div>\n    }\n\n    <div\n      class=\"min-w-0 flex-1 text-sm/6\"\n      [class.ml-3]=\"\n        layout() !== 'radio-right' && layout() !== 'inline-description' && !description()\n      \"\n    >\n      <label [for]=\"computedForId()\" class=\"font-medium text-content\" [class.select-none]=\"true\">\n        {{ label() }}\n        <ng-content select=\"[pgRadioLabel]\"></ng-content>\n      </label>\n\n      @if (description()) {\n        @if (layout() === 'inline-description') {\n          <span [id]=\"computedForId() + '-description'\" class=\"text-content-muted\">\n            <span class=\"sr-only\">{{ label() }} </span>{{ description() }}\n          </span>\n        } @else {\n          <p [id]=\"computedForId() + '-description'\" class=\"text-content-muted\">{{ description() }}</p>\n        }\n      }\n      <ng-content select=\"[pgRadioDescription]\"></ng-content>\n    </div>\n\n    @if (layout() === 'radio-right') {\n      <div class=\"ml-3 flex h-6 shrink-0 items-center\">\n        <input\n          pgRadio\n          type=\"radio\"\n          [id]=\"computedForId()\"\n          [pgRadioChecked]=\"checked()\"\n          [pgRadioDisabled]=\"isDisabled()\"\n          [pgRadioName]=\"group.computedName()\"\n          [pgRadioValue]=\"value()\"\n          [pgRadioError]=\"hasError()\"\n          (pgRadioChange)=\"onSelect()\"\n          (pgRadioBlur)=\"onBlur()\"\n        />\n      </div>\n    }\n  </div>\n}\n\n@if (layout() === 'color') {\n  <div class=\"flex rounded-full outline outline-1 -outline-offset-1 outline-outline-contrast/10\">\n    <input\n      pgRadioColor\n      type=\"radio\"\n      [class]=\"swatchClass()\"\n      [attr.aria-label]=\"label()\"\n      [pgRadioChecked]=\"checked()\"\n      [pgRadioDisabled]=\"isDisabled()\"\n      [pgRadioName]=\"group.computedName()\"\n      [pgRadioValue]=\"value()\"\n      (pgRadioChange)=\"onSelect()\"\n      (pgRadioBlur)=\"onBlur()\"\n    />\n  </div>\n}\n\n@if (layout() === 'panel') {\n  <label\n    [attr.aria-label]=\"label()\"\n    [attr.aria-description]=\"description()\"\n    [class.border-error]=\"hasError()\"\n    class=\"w-full h-full group flex flex-col sm:flex-row border border-outline p-4 transition-colors duration-150 hover:border-primary/60 focus:outline-none has-[:checked]:relative has-[:checked]:border-primary has-[:checked]:bg-primary/10\"\n  >\n    <span class=\"flex items-center gap-3 text-sm\">\n      <input\n        pgRadio\n        type=\"radio\"\n        [pgRadioChecked]=\"checked()\"\n        [pgRadioDisabled]=\"isDisabled()\"\n        [pgRadioName]=\"group.computedName()\"\n        [pgRadioValue]=\"value()\"\n        (pgRadioChange)=\"onSelect()\"\n        (pgRadioBlur)=\"onBlur()\"\n      />\n      <span class=\"font-medium text-content group-has-[:checked]:text-primary\">\n        {{ label() }}\n        <ng-content select=\"[pgRadioLabel]\"></ng-content>\n      </span>\n    </span>\n    <span class=\"ml-6 pl-1 sm:ml-3 sm:pl-0 flex flex-col text-sm\">\n      @if (description()) {\n        <span class=\"block text-content-muted group-has-[:checked]:text-primary\">{{\n          description()\n        }}</span>\n      }\n      <ng-content select=\"[pgRadioDescription]\"></ng-content>\n    </span>\n  </label>\n}\n\n@if (layout() === 'card') {\n  <label\n    [attr.aria-label]=\"label()\"\n    [attr.aria-description]=\"description()\"\n    [class.border-error]=\"hasError()\"\n    class=\"w-full h-full cursor-pointer group relative flex gap-2 rounded-lg border border-outline bg-surface p-4 transition-colors duration-150 hover:border-primary has-[:disabled]:hover:border-gray-400 has-[:disabled]:border-gray-400 has-[:disabled]:bg-gray-200 has-[:disabled]:opacity-25 has-[:checked]:outline has-[:focus-visible]:outline has-[:checked]:outline-2 has-[:focus-visible]:outline-[3px] has-[:checked]:-outline-offset-2 has-[:focus-visible]:-outline-offset-1 has-[:checked]:outline-primary sm:justify-between\"\n  >\n    <input\n      pgRadioCard\n      type=\"radio\"\n      [pgRadioChecked]=\"checked()\"\n      [pgRadioDisabled]=\"isDisabled()\"\n      [pgRadioName]=\"group.computedName()\"\n      [pgRadioValue]=\"value()\"\n      (pgRadioChange)=\"onSelect()\"\n      (pgRadioBlur)=\"onBlur()\"\n    />\n    <div class=\"flex-1\">\n      <span class=\"block text-sm font-medium text-content\">\n        {{ label() }}\n        <ng-content select=\"[pgRadioLabel]\"></ng-content>\n      </span>\n      @if (description()) {\n        <span class=\"mt-1 block text-sm text-content-muted\">{{ description() }}</span>\n      }\n      <ng-content select=\"[pgRadioDescription]\"></ng-content>\n    </div>\n    <svg\n      viewBox=\"0 0 20 20\"\n      fill=\"currentColor\"\n      aria-hidden=\"true\"\n      class=\"invisible size-5 text-primary group-has-[:checked]:visible\"\n    >\n      <path\n        d=\"M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm3.857-9.809a.75.75 0 0 0-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 1 0-1.06 1.061l2.5 2.5a.75.75 0 0 0 1.137-.089l4-5.5Z\"\n        clip-rule=\"evenodd\"\n        fill-rule=\"evenodd\"\n      />\n    </svg>\n  </label>\n}\n\n@if (layout() === 'stacked-card') {\n  <label\n    [attr.aria-label]=\"label()\"\n    [attr.aria-description]=\"description()\"\n    [class.border-error]=\"hasError()\"\n    class=\"w-full h-full cursor-pointer group relative block sm:flex sm:justify-between rounded-lg border border-outline bg-surface px-6 py-4 transition-colors duration-150 hover:border-primary has-[:disabled]:hover:border-gray-400 has-[:disabled]:border-gray-400 has-[:disabled]:bg-gray-200 has-[:disabled]:opacity-25 has-[:checked]:outline has-[:focus-visible]:outline has-[:checked]:outline-2 has-[:focus-visible]:outline-[3px] has-[:checked]:-outline-offset-2 has-[:focus-visible]:-outline-offset-1 has-[:checked]:outline-primary\"\n  >\n    <input\n      pgRadioCard\n      type=\"radio\"\n      [pgRadioChecked]=\"checked()\"\n      [pgRadioDisabled]=\"isDisabled()\"\n      [pgRadioName]=\"group.computedName()\"\n      [pgRadioValue]=\"value()\"\n      (pgRadioChange)=\"onSelect()\"\n      (pgRadioBlur)=\"onBlur()\"\n    />\n    <span class=\"flex items-center\">\n      <span class=\"flex flex-col text-sm\">\n        <span class=\"font-medium text-content\">\n          {{ label() }}\n          <ng-content select=\"[pgRadioLabel]\"></ng-content>\n        </span>\n      </span>\n    </span>\n    <ng-content select=\"[pgRadioDescription]\"></ng-content>\n  </label>\n}\n\n@if (layout() === 'small-card') {\n  <label\n    [attr.aria-label]=\"label()\"\n    [class.rounded-md]=\"shape() === 'rounded'\"\n    [class.rounded-full]=\"shape() === 'pill'\"\n    [class.border-error]=\"hasError()\"\n    class=\"w-full h-full cursor-pointer group relative flex items-center justify-center border border-outline bg-surface px-3 py-2 transition-colors duration-150 hover:border-primary has-[:disabled]:hover:border-gray-400 has-[:checked]:border-primary has-[:disabled]:border-gray-400 has-[:checked]:bg-primary has-[:disabled]:bg-gray-200 has-[:disabled]:opacity-25 has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-primary\"\n  >\n    <input\n      pgRadioCard\n      type=\"radio\"\n      [pgRadioChecked]=\"checked()\"\n      [pgRadioDisabled]=\"isDisabled()\"\n      [pgRadioName]=\"group.computedName()\"\n      [pgRadioValue]=\"value()\"\n      (pgRadioChange)=\"onSelect()\"\n      (pgRadioBlur)=\"onBlur()\"\n    />\n    <span\n      class=\"text-sm font-medium text-content group-has-[:checked]:text-white\"\n      [class.uppercase]=\"shape() === 'rounded'\"\n    >\n      {{ label() }}\n      <ng-content select=\"[pgRadioLabel]\"></ng-content>\n    </span>\n  </label>\n}\n", styles: [":host([layout=\"panel\"]):first-of-type>label{border-top-left-radius:.375rem;border-top-right-radius:.375rem}:host([layout=\"panel\"]):last-of-type>label{border-bottom-left-radius:.375rem;border-bottom-right-radius:.375rem}\n"] }]
        }] });

class TextareaDirective {
    pgTextarea = inject(TextareaComponent, { optional: true });
    el = inject((ElementRef));
    renderer = inject(Renderer2);
    disabled = false;
    constructor() {
        if (this.pgTextarea) {
            effect(() => {
                const val = this.pgTextarea.value();
                this.renderer.setProperty(this.el.nativeElement, 'value', val ?? '');
            });
            effect(() => {
                const dis = this.pgTextarea.disabled();
                this.renderer.setProperty(this.el.nativeElement, 'disabled', dis);
            });
            effect(() => {
                const parent = this.pgTextarea;
                const showError = parent.hasError() && !!parent.errorText();
                const showHelp = !showError && !!parent.helpText();
                if (showError) {
                    this.renderer.setAttribute(this.el.nativeElement, 'aria-describedby', `${parent.computedForId()}-error`);
                }
                else if (showHelp) {
                    this.renderer.setAttribute(this.el.nativeElement, 'aria-describedby', `${parent.computedForId()}-description`);
                }
                else {
                    this.renderer.removeAttribute(this.el.nativeElement, 'aria-describedby');
                }
            });
        }
    }
    onInput(value) {
        this.pgTextarea?.setValue(value);
    }
    onBlur() {
        this.pgTextarea?.markAsTouched();
    }
    get classes() {
        const parent = this.pgTextarea;
        const variant = parent ? parent.variant() : 'simple';
        let cls = 'block w-full text-base sm:text-sm/6 ';
        if (this.disabled) {
            cls +=
                'disabled:cursor-not-allowed disabled:bg-surface-muted disabled:text-content-muted disabled:outline-outline ';
        }
        cls += 'text-content placeholder:text-content-subtle ';
        if (variant === 'simple') {
            cls +=
                'rounded-md bg-surface px-3 py-1.5 outline outline-1 -outline-offset-1 outline-outline focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-primary ';
        }
        else if (variant === 'avatar-actions' || variant === 'preview') {
            cls += 'resize-none bg-transparent px-3 py-1.5 focus:outline focus:outline-0 ';
        }
        else if (variant === 'underline-actions') {
            cls += 'resize-none focus:outline focus:outline-0 ';
        }
        else if (variant === 'title-actions') {
            cls += 'resize-none px-3 py-1.5 focus:outline focus:outline-0 ';
        }
        return cls;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: TextareaDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: TextareaDirective, isStandalone: true, selector: "[pgTextarea]", inputs: { disabled: "disabled" }, host: { listeners: { "input": "onInput($event.target.value)", "blur": "onBlur()" }, properties: { "class": "this.classes" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: TextareaDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pgTextarea]',
                    standalone: true,
                }]
        }], ctorParameters: () => [], propDecorators: { disabled: [{
                type: Input
            }], onInput: [{
                type: HostListener,
                args: ['input', ['$event.target.value']]
            }], onBlur: [{
                type: HostListener,
                args: ['blur']
            }], classes: [{
                type: HostBinding,
                args: ['class']
            }] } });
class TextareaTitleDirective {
    get cls() {
        return 'block w-full px-3 pt-2.5 text-lg font-medium text-content placeholder:text-content-subtle focus:outline focus:outline-0 bg-transparent';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: TextareaTitleDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: TextareaTitleDirective, isStandalone: true, selector: "[pgTextareaTitle]", host: { properties: { "class": "this.cls" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: TextareaTitleDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[pgTextareaTitle]', standalone: true }]
        }], propDecorators: { cls: [{
                type: HostBinding,
                args: ['class']
            }] } });
class TextareaAvatarDirective {
    get cls() {
        return 'inline-block w-10 h-10 rounded-full bg-surface-muted outline outline-1 -outline-offset-1 outline-outline-contrast/5';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: TextareaAvatarDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: TextareaAvatarDirective, isStandalone: true, selector: "[pgTextareaAvatar]", host: { properties: { "class": "this.cls" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: TextareaAvatarDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[pgTextareaAvatar]', standalone: true }]
        }], propDecorators: { cls: [{
                type: HostBinding,
                args: ['class']
            }] } });
class TextareaToolbarDirective {
    pgTextarea = inject(TextareaComponent, { optional: true });
    get cls() {
        const variant = this.pgTextarea ? this.pgTextarea.variant() : 'simple';
        if (variant === 'avatar-actions' || variant === 'preview' || variant === 'title-actions') {
            return 'flex items-center space-x-5';
        }
        else if (variant === 'underline-actions') {
            return 'flex items-center space-x-5';
        }
        return 'flex items-center space-x-5';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: TextareaToolbarDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: TextareaToolbarDirective, isStandalone: true, selector: "[pgTextareaToolbar]", host: { properties: { "class": "this.cls" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: TextareaToolbarDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[pgTextareaToolbar]', standalone: true }]
        }], propDecorators: { cls: [{
                type: HostBinding,
                args: ['class']
            }] } });
class TextareaFooterDirective {
    get cls() {
        return 'shrink-0';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: TextareaFooterDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: TextareaFooterDirective, isStandalone: true, selector: "[pgTextareaFooter]", host: { properties: { "class": "this.cls" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: TextareaFooterDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[pgTextareaFooter]', standalone: true }]
        }], propDecorators: { cls: [{
                type: HostBinding,
                args: ['class']
            }] } });
class TextareaPillDirective {
    get cls() {
        return 'flex items-center space-x-2';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: TextareaPillDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: TextareaPillDirective, isStandalone: true, selector: "[pgTextareaPill]", host: { properties: { "class": "this.cls" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: TextareaPillDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[pgTextareaPill]', standalone: true }]
        }], propDecorators: { cls: [{
                type: HostBinding,
                args: ['class']
            }] } });
class TextareaPreviewDirective {
    get cls() {
        return 'mx-px mt-px px-3 pb-12 pt-2 text-sm text-content';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: TextareaPreviewDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: TextareaPreviewDirective, isStandalone: true, selector: "[pgTextareaPreview]", host: { properties: { "class": "this.cls" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: TextareaPreviewDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[pgTextareaPreview]', standalone: true }]
        }], propDecorators: { cls: [{
                type: HostBinding,
                args: ['class']
            }] } });

class TextareaComponent extends PgControlValueAccessorBase {
    idService = inject(IdService);
    _autoId = this.idService.generate('pg-textarea');
    variant = input('simple');
    label = input('');
    hideLabel = input(false);
    forId = input('');
    helpText = input();
    errorText = input();
    /**
     * Fuerza el estado de error. Toma precedencia sobre el computed del NgControl.
     * Útil cuando el componente se usa sin ReactiveFormsModule.
     */
    error = input(undefined);
    activeTab = signal('write');
    avatarIcon = contentChild(TextareaAvatarDirective);
    toolbarSection = contentChild(TextareaToolbarDirective);
    footerSection = contentChild(TextareaFooterDirective);
    hasAvatar = computed(() => !!this.avatarIcon());
    hasToolbar = computed(() => !!this.toolbarSection());
    hasFooter = computed(() => !!this.footerSection());
    /**
     * ID resuelto: usa el input `forId` si se provee, sino genera uno automáticamente.
     */
    computedForId = computed(() => this.forId() || this._autoId);
    hasError = computed(() => {
        const override = this.error();
        if (override !== undefined)
            return override;
        const ctrl = this.ngControl?.control;
        if (!ctrl)
            return false;
        return ctrl.invalid && (ctrl.touched || ctrl.dirty);
    });
    setTab(tab, event) {
        if (event) {
            event.preventDefault();
        }
        this.activeTab.set(tab);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: TextareaComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: TextareaComponent, isStandalone: true, selector: "pg-textarea", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, hideLabel: { classPropertyName: "hideLabel", publicName: "hideLabel", isSignal: true, isRequired: false, transformFunction: null }, forId: { classPropertyName: "forId", publicName: "forId", isSignal: true, isRequired: false, transformFunction: null }, helpText: { classPropertyName: "helpText", publicName: "helpText", isSignal: true, isRequired: false, transformFunction: null }, errorText: { classPropertyName: "errorText", publicName: "errorText", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => TextareaComponent),
                multi: true,
            },
        ], queries: [{ propertyName: "avatarIcon", first: true, predicate: TextareaAvatarDirective, descendants: true, isSignal: true }, { propertyName: "toolbarSection", first: true, predicate: TextareaToolbarDirective, descendants: true, isSignal: true }, { propertyName: "footerSection", first: true, predicate: TextareaFooterDirective, descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "<ng-template #textareaSlot>\n  <ng-content select=\"textarea[pgTextarea]\"></ng-content>\n</ng-template>\n\n<ng-template #avatarSlot>\n  <ng-content select=\"[pgTextareaAvatar]\"></ng-content>\n</ng-template>\n\n<ng-template #toolbarSlot>\n  <ng-content select=\"[pgTextareaToolbar]\"></ng-content>\n</ng-template>\n\n<ng-template #footerSlot>\n  <ng-content select=\"[pgTextareaFooter]\"></ng-content>\n</ng-template>\n\n@if (variant() === 'simple') {\n  <div>\n    @if (label() && !hideLabel()) {\n      <label [for]=\"forId()\" class=\"block text-sm/6 font-medium text-content\">{{ label() }}</label>\n    }\n    <div class=\"mt-2\">\n      <ng-container *ngTemplateOutlet=\"textareaSlot\"></ng-container>\n    </div>\n  </div>\n}\n\n@if (variant() === 'avatar-actions') {\n  <div class=\"flex items-start space-x-4\">\n    <div class=\"shrink-0\">\n      <ng-container *ngTemplateOutlet=\"avatarSlot\"></ng-container>\n    </div>\n    <div class=\"min-w-0 flex-1\">\n      <form action=\"#\" class=\"relative\">\n        <div\n          class=\"rounded-lg bg-surface outline outline-1 -outline-offset-1 outline-outline focus-within:outline focus-within:outline-2 focus-within:-outline-offset-2 focus-within:outline-primary\"\n        >\n          @if (label() && !hideLabel()) {\n            <label [for]=\"forId()\" class=\"sr-only\">{{ label() }}</label>\n          }\n          <ng-container *ngTemplateOutlet=\"textareaSlot\"></ng-container>\n\n          <div aria-hidden=\"true\" class=\"py-2\">\n            <div class=\"py-px\">\n              <div class=\"h-9\"></div>\n            </div>\n          </div>\n        </div>\n\n        <div class=\"absolute inset-x-0 bottom-0 flex justify-between py-2 pl-3 pr-2\">\n          <ng-container *ngTemplateOutlet=\"toolbarSlot\"></ng-container>\n          <ng-container *ngTemplateOutlet=\"footerSlot\"></ng-container>\n        </div>\n      </form>\n    </div>\n  </div>\n}\n\n@if (variant() === 'underline-actions') {\n  <div class=\"flex items-start space-x-4\">\n    <div class=\"shrink-0\">\n      <ng-container *ngTemplateOutlet=\"avatarSlot\"></ng-container>\n    </div>\n    <div class=\"min-w-0 flex-1\">\n      <form action=\"#\">\n        <div\n          class=\"border-b border-outline pb-px focus-within:border-b-2 focus-within:border-primary focus-within:pb-0\"\n        >\n          @if (label() && !hideLabel()) {\n            <label [for]=\"forId()\" class=\"sr-only\">{{ label() }}</label>\n          }\n          <ng-container *ngTemplateOutlet=\"textareaSlot\"></ng-container>\n        </div>\n        <div class=\"flex justify-between pt-2\">\n          <ng-container *ngTemplateOutlet=\"toolbarSlot\"></ng-container>\n          <ng-container *ngTemplateOutlet=\"footerSlot\"></ng-container>\n        </div>\n      </form>\n    </div>\n  </div>\n}\n\n@if (variant() === 'title-actions') {\n  <form action=\"#\" class=\"relative\">\n    <div\n      class=\"rounded-lg bg-surface outline outline-1 -outline-offset-1 outline-outline focus-within:outline focus-within:outline-2 focus-within:-outline-offset-2 focus-within:outline-primary\"\n    >\n      <label for=\"title\" class=\"sr-only\">Title</label>\n      <ng-content select=\"input[pgTextareaTitle]\"></ng-content>\n\n      @if (label() && !hideLabel()) {\n        <label [for]=\"forId()\" class=\"sr-only\">{{ label() }}</label>\n      }\n      <ng-container *ngTemplateOutlet=\"textareaSlot\"></ng-container>\n\n      <div aria-hidden=\"true\">\n        <div class=\"py-2\">\n          <div class=\"h-9\"></div>\n        </div>\n        <div class=\"h-px\"></div>\n        <div class=\"py-2\">\n          <div class=\"py-px\">\n            <div class=\"h-9\"></div>\n          </div>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"absolute inset-x-px bottom-0\">\n      <div class=\"flex flex-nowrap justify-end space-x-2 px-2 py-2 sm:px-3\">\n        <ng-content select=\"[pgTextareaPill]\"></ng-content>\n      </div>\n      <div\n        class=\"flex items-center justify-between space-x-3 border-t border-outline px-2 py-2 sm:px-3\"\n      >\n        <ng-container *ngTemplateOutlet=\"toolbarSlot\"></ng-container>\n        <ng-container *ngTemplateOutlet=\"footerSlot\"></ng-container>\n      </div>\n    </div>\n  </form>\n}\n\n@if (variant() === 'preview') {\n  <form action=\"#\">\n    <div class=\"group flex items-center\">\n      <div class=\"flex gap-2\">\n        <button\n          (click)=\"setTab('write', $event)\"\n          [attr.aria-selected]=\"activeTab() === 'write'\"\n          [class]=\"\n            activeTab() === 'write'\n              ? 'rounded-md border border-transparent bg-surface-muted px-3 py-1.5 text-sm font-medium text-content hover:bg-gray-200'\n              : 'rounded-md border border-transparent bg-surface px-3 py-1.5 text-sm font-medium text-content-muted hover:bg-surface-muted hover:text-content'\n          \"\n          type=\"button\"\n        >\n          Write\n        </button>\n        <button\n          (click)=\"setTab('preview', $event)\"\n          [attr.aria-selected]=\"activeTab() === 'preview'\"\n          [class]=\"\n            activeTab() === 'preview'\n              ? 'rounded-md border border-transparent bg-surface-muted px-3 py-1.5 text-sm font-medium text-content hover:bg-gray-200'\n              : 'rounded-md border border-transparent bg-surface px-3 py-1.5 text-sm font-medium text-content-muted hover:bg-surface-muted hover:text-content'\n          \"\n          type=\"button\"\n        >\n          Preview\n        </button>\n      </div>\n\n      @if (activeTab() === 'write') {\n        <div class=\"ml-auto flex items-center space-x-5\">\n          <ng-container *ngTemplateOutlet=\"toolbarSlot\"></ng-container>\n        </div>\n      }\n    </div>\n\n    <div class=\"mt-2 block\">\n      <div [hidden]=\"activeTab() !== 'write'\" class=\"-m-0.5 rounded-lg p-0.5\">\n        @if (label() && !hideLabel()) {\n          <label [for]=\"forId()\" class=\"sr-only\">{{ label() }}</label>\n        }\n        <div>\n          <ng-container *ngTemplateOutlet=\"textareaSlot\"></ng-container>\n        </div>\n      </div>\n\n      <div [hidden]=\"activeTab() !== 'preview'\" class=\"-m-0.5 rounded-lg p-0.5\">\n        <div class=\"border-b border-outline\">\n          <ng-content select=\"[pgTextareaPreview]\"></ng-content>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"mt-2 flex justify-end\">\n      <ng-container *ngTemplateOutlet=\"footerSlot\"></ng-container>\n    </div>\n  </form>\n}\n\n@if (hasError() && errorText()) {\n  <p class=\"mt-2 text-sm text-error\" [id]=\"computedForId() + '-error'\">{{ errorText() }}</p>\n} @else if (helpText()) {\n  <p class=\"mt-2 text-sm text-content-muted\" [id]=\"computedForId() + '-description'\">{{ helpText() }}</p>\n}\n", dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: TextareaComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-textarea', imports: [NgTemplateOutlet], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => TextareaComponent),
                            multi: true,
                        },
                    ], template: "<ng-template #textareaSlot>\n  <ng-content select=\"textarea[pgTextarea]\"></ng-content>\n</ng-template>\n\n<ng-template #avatarSlot>\n  <ng-content select=\"[pgTextareaAvatar]\"></ng-content>\n</ng-template>\n\n<ng-template #toolbarSlot>\n  <ng-content select=\"[pgTextareaToolbar]\"></ng-content>\n</ng-template>\n\n<ng-template #footerSlot>\n  <ng-content select=\"[pgTextareaFooter]\"></ng-content>\n</ng-template>\n\n@if (variant() === 'simple') {\n  <div>\n    @if (label() && !hideLabel()) {\n      <label [for]=\"forId()\" class=\"block text-sm/6 font-medium text-content\">{{ label() }}</label>\n    }\n    <div class=\"mt-2\">\n      <ng-container *ngTemplateOutlet=\"textareaSlot\"></ng-container>\n    </div>\n  </div>\n}\n\n@if (variant() === 'avatar-actions') {\n  <div class=\"flex items-start space-x-4\">\n    <div class=\"shrink-0\">\n      <ng-container *ngTemplateOutlet=\"avatarSlot\"></ng-container>\n    </div>\n    <div class=\"min-w-0 flex-1\">\n      <form action=\"#\" class=\"relative\">\n        <div\n          class=\"rounded-lg bg-surface outline outline-1 -outline-offset-1 outline-outline focus-within:outline focus-within:outline-2 focus-within:-outline-offset-2 focus-within:outline-primary\"\n        >\n          @if (label() && !hideLabel()) {\n            <label [for]=\"forId()\" class=\"sr-only\">{{ label() }}</label>\n          }\n          <ng-container *ngTemplateOutlet=\"textareaSlot\"></ng-container>\n\n          <div aria-hidden=\"true\" class=\"py-2\">\n            <div class=\"py-px\">\n              <div class=\"h-9\"></div>\n            </div>\n          </div>\n        </div>\n\n        <div class=\"absolute inset-x-0 bottom-0 flex justify-between py-2 pl-3 pr-2\">\n          <ng-container *ngTemplateOutlet=\"toolbarSlot\"></ng-container>\n          <ng-container *ngTemplateOutlet=\"footerSlot\"></ng-container>\n        </div>\n      </form>\n    </div>\n  </div>\n}\n\n@if (variant() === 'underline-actions') {\n  <div class=\"flex items-start space-x-4\">\n    <div class=\"shrink-0\">\n      <ng-container *ngTemplateOutlet=\"avatarSlot\"></ng-container>\n    </div>\n    <div class=\"min-w-0 flex-1\">\n      <form action=\"#\">\n        <div\n          class=\"border-b border-outline pb-px focus-within:border-b-2 focus-within:border-primary focus-within:pb-0\"\n        >\n          @if (label() && !hideLabel()) {\n            <label [for]=\"forId()\" class=\"sr-only\">{{ label() }}</label>\n          }\n          <ng-container *ngTemplateOutlet=\"textareaSlot\"></ng-container>\n        </div>\n        <div class=\"flex justify-between pt-2\">\n          <ng-container *ngTemplateOutlet=\"toolbarSlot\"></ng-container>\n          <ng-container *ngTemplateOutlet=\"footerSlot\"></ng-container>\n        </div>\n      </form>\n    </div>\n  </div>\n}\n\n@if (variant() === 'title-actions') {\n  <form action=\"#\" class=\"relative\">\n    <div\n      class=\"rounded-lg bg-surface outline outline-1 -outline-offset-1 outline-outline focus-within:outline focus-within:outline-2 focus-within:-outline-offset-2 focus-within:outline-primary\"\n    >\n      <label for=\"title\" class=\"sr-only\">Title</label>\n      <ng-content select=\"input[pgTextareaTitle]\"></ng-content>\n\n      @if (label() && !hideLabel()) {\n        <label [for]=\"forId()\" class=\"sr-only\">{{ label() }}</label>\n      }\n      <ng-container *ngTemplateOutlet=\"textareaSlot\"></ng-container>\n\n      <div aria-hidden=\"true\">\n        <div class=\"py-2\">\n          <div class=\"h-9\"></div>\n        </div>\n        <div class=\"h-px\"></div>\n        <div class=\"py-2\">\n          <div class=\"py-px\">\n            <div class=\"h-9\"></div>\n          </div>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"absolute inset-x-px bottom-0\">\n      <div class=\"flex flex-nowrap justify-end space-x-2 px-2 py-2 sm:px-3\">\n        <ng-content select=\"[pgTextareaPill]\"></ng-content>\n      </div>\n      <div\n        class=\"flex items-center justify-between space-x-3 border-t border-outline px-2 py-2 sm:px-3\"\n      >\n        <ng-container *ngTemplateOutlet=\"toolbarSlot\"></ng-container>\n        <ng-container *ngTemplateOutlet=\"footerSlot\"></ng-container>\n      </div>\n    </div>\n  </form>\n}\n\n@if (variant() === 'preview') {\n  <form action=\"#\">\n    <div class=\"group flex items-center\">\n      <div class=\"flex gap-2\">\n        <button\n          (click)=\"setTab('write', $event)\"\n          [attr.aria-selected]=\"activeTab() === 'write'\"\n          [class]=\"\n            activeTab() === 'write'\n              ? 'rounded-md border border-transparent bg-surface-muted px-3 py-1.5 text-sm font-medium text-content hover:bg-gray-200'\n              : 'rounded-md border border-transparent bg-surface px-3 py-1.5 text-sm font-medium text-content-muted hover:bg-surface-muted hover:text-content'\n          \"\n          type=\"button\"\n        >\n          Write\n        </button>\n        <button\n          (click)=\"setTab('preview', $event)\"\n          [attr.aria-selected]=\"activeTab() === 'preview'\"\n          [class]=\"\n            activeTab() === 'preview'\n              ? 'rounded-md border border-transparent bg-surface-muted px-3 py-1.5 text-sm font-medium text-content hover:bg-gray-200'\n              : 'rounded-md border border-transparent bg-surface px-3 py-1.5 text-sm font-medium text-content-muted hover:bg-surface-muted hover:text-content'\n          \"\n          type=\"button\"\n        >\n          Preview\n        </button>\n      </div>\n\n      @if (activeTab() === 'write') {\n        <div class=\"ml-auto flex items-center space-x-5\">\n          <ng-container *ngTemplateOutlet=\"toolbarSlot\"></ng-container>\n        </div>\n      }\n    </div>\n\n    <div class=\"mt-2 block\">\n      <div [hidden]=\"activeTab() !== 'write'\" class=\"-m-0.5 rounded-lg p-0.5\">\n        @if (label() && !hideLabel()) {\n          <label [for]=\"forId()\" class=\"sr-only\">{{ label() }}</label>\n        }\n        <div>\n          <ng-container *ngTemplateOutlet=\"textareaSlot\"></ng-container>\n        </div>\n      </div>\n\n      <div [hidden]=\"activeTab() !== 'preview'\" class=\"-m-0.5 rounded-lg p-0.5\">\n        <div class=\"border-b border-outline\">\n          <ng-content select=\"[pgTextareaPreview]\"></ng-content>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"mt-2 flex justify-end\">\n      <ng-container *ngTemplateOutlet=\"footerSlot\"></ng-container>\n    </div>\n  </form>\n}\n\n@if (hasError() && errorText()) {\n  <p class=\"mt-2 text-sm text-error\" [id]=\"computedForId() + '-error'\">{{ errorText() }}</p>\n} @else if (helpText()) {\n  <p class=\"mt-2 text-sm text-content-muted\" [id]=\"computedForId() + '-description'\">{{ helpText() }}</p>\n}\n" }]
        }] });

class PgToggle extends PgControlValueAccessorBase {
    variant = input('normal');
    withIcon = input(false);
    /**
     * 100% consumer-controlled loading indicator — mirrors `pg-select`'s
     * `loading` input. The library never infers this from async state; bind it
     * around your own request (e.g. a settings toggle awaiting a PATCH). Swaps
     * the knob's icon for a spinner and, via `ToggleDirective`, forces the
     * projected `<input pgToggle>` disabled for the duration — no separate
     * `[disabled]` binding needed.
     */
    isLoading = input(false);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgToggle, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: PgToggle, isStandalone: true, selector: "pg-toggle", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, withIcon: { classPropertyName: "withIcon", publicName: "withIcon", isSignal: true, isRequired: false, transformFunction: null }, isLoading: { classPropertyName: "isLoading", publicName: "isLoading", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "inline-flex" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => PgToggle),
                multi: true,
            },
        ], usesInheritance: true, ngImport: i0, template: "<ng-template #toggleSlot>\n  <ng-content select=\"input[pgToggle]\"></ng-content>\n</ng-template>\n\n@if (variant() === 'normal') {\n  <div\n    class=\"group relative inline-flex w-11 shrink-0 rounded-full bg-surface-muted p-0.5 outline-offset-2 outline-primary ring-1 ring-inset ring-outline-contrast/5 transition-colors duration-200 ease-in-out has-[:checked]:bg-primary has-[:disabled]:bg-surface-muted has-[:disabled]:opacity-50 has-[:focus-visible]:outline has-[:focus-visible]:outline-2 cursor-pointer has-[:disabled]:cursor-not-allowed\"\n  >\n    <span\n      class=\"pointer-events-none size-5 rounded-full bg-surface shadow-sm ring-1 ring-outline-contrast/5 transition-transform duration-200 ease-in-out group-has-[:checked]:translate-x-5 flex items-center justify-center\"\n    >\n      @if (isLoading()) {\n        <pg-loader variant=\"spinner\" size=\"sm\" label=\"Loading\" />\n      } @else if (withIcon()) {\n        <svg\n          class=\"size-3 text-content-subtle opacity-100 duration-200 ease-in group-has-[:checked]:opacity-0 group-has-[:checked]:duration-100 group-has-[:checked]:ease-out\"\n          fill=\"none\"\n          viewBox=\"0 0 12 12\"\n          stroke-width=\"1.5\"\n        >\n          <path\n            d=\"M4 8l4-4m0 4L4 4\"\n            stroke=\"currentColor\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n        <svg\n          class=\"absolute size-3 text-primary opacity-0 duration-100 ease-out group-has-[:checked]:opacity-100 group-has-[:checked]:duration-200 group-has-[:checked]:ease-in\"\n          fill=\"currentColor\"\n          viewBox=\"0 0 12 12\"\n        >\n          <path\n            d=\"M3.707 5.293a1 1 0 00-1.414 1.414l1.414-1.414zM5 8l-.707.707a1 1 0 001.414 0L5 8zm4.707-3.293a1 1 0 00-1.414-1.414l1.414 1.414zm-7.414 2l2 2 1.414-1.414-2-2-1.414 1.414zm3.414 2l4-4-1.414-1.414-4 4 1.414 1.414z\"\n          />\n        </svg>\n      }\n    </span>\n    <ng-container *ngTemplateOutlet=\"toggleSlot\"></ng-container>\n  </div>\n}\n\n@if (variant() === 'short') {\n  <div\n    class=\"group relative inline-flex h-5 w-10 shrink-0 items-center justify-center rounded-full outline-offset-2 outline-primary has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:disabled]:opacity-50 cursor-pointer has-[:disabled]:cursor-not-allowed\"\n  >\n    <span\n      class=\"pointer-events-none absolute mx-auto h-4 w-9 rounded-full bg-surface-muted ring-1 ring-inset ring-outline-contrast/5 transition-colors duration-200 ease-in-out group-has-[:checked]:bg-primary group-has-[:disabled]:bg-surface-muted\"\n    ></span>\n\n    <span\n      class=\"pointer-events-none absolute left-0 size-5 rounded-full border border-outline bg-surface shadow-sm transition-transform duration-200 ease-in-out group-has-[:checked]:translate-x-5 flex items-center justify-center\"\n    >\n      @if (isLoading()) {\n        <pg-loader variant=\"spinner\" size=\"sm\" label=\"Loading\" />\n      } @else if (withIcon()) {\n        <svg\n          class=\"size-3 text-content-subtle opacity-100 duration-200 ease-in group-has-[:checked]:opacity-0 group-has-[:checked]:duration-100 group-has-[:checked]:ease-out\"\n          fill=\"none\"\n          viewBox=\"0 0 12 12\"\n          stroke-width=\"1.5\"\n        >\n          <path\n            d=\"M4 8l4-4m0 4L4 4\"\n            stroke=\"currentColor\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n        <svg\n          class=\"absolute size-3 text-primary opacity-0 duration-100 ease-out group-has-[:checked]:opacity-100 group-has-[:checked]:duration-200 group-has-[:checked]:ease-in\"\n          fill=\"currentColor\"\n          viewBox=\"0 0 12 12\"\n        >\n          <path\n            d=\"M3.707 5.293a1 1 0 00-1.414 1.414l1.414-1.414zM5 8l-.707.707a1 1 0 001.414 0L5 8zm4.707-3.293a1 1 0 00-1.414-1.414l1.414 1.414zm-7.414 2l2 2 1.414-1.414-2-2-1.414 1.414zm3.414 2l4-4-1.414-1.414-4 4 1.414 1.414z\"\n          />\n        </svg>\n      }\n    </span>\n    <ng-container *ngTemplateOutlet=\"toggleSlot\"></ng-container>\n  </div>\n}\n", styles: [""], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: PgLoaderComponent, selector: "pg-loader", inputs: ["variant", "size", "label", "color", "title", "description"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgToggle, decorators: [{
            type: Component,
            args: [{ selector: 'pg-toggle', imports: [NgTemplateOutlet, PgLoaderComponent], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 'inline-flex'
                    }, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => PgToggle),
                            multi: true,
                        },
                    ], template: "<ng-template #toggleSlot>\n  <ng-content select=\"input[pgToggle]\"></ng-content>\n</ng-template>\n\n@if (variant() === 'normal') {\n  <div\n    class=\"group relative inline-flex w-11 shrink-0 rounded-full bg-surface-muted p-0.5 outline-offset-2 outline-primary ring-1 ring-inset ring-outline-contrast/5 transition-colors duration-200 ease-in-out has-[:checked]:bg-primary has-[:disabled]:bg-surface-muted has-[:disabled]:opacity-50 has-[:focus-visible]:outline has-[:focus-visible]:outline-2 cursor-pointer has-[:disabled]:cursor-not-allowed\"\n  >\n    <span\n      class=\"pointer-events-none size-5 rounded-full bg-surface shadow-sm ring-1 ring-outline-contrast/5 transition-transform duration-200 ease-in-out group-has-[:checked]:translate-x-5 flex items-center justify-center\"\n    >\n      @if (isLoading()) {\n        <pg-loader variant=\"spinner\" size=\"sm\" label=\"Loading\" />\n      } @else if (withIcon()) {\n        <svg\n          class=\"size-3 text-content-subtle opacity-100 duration-200 ease-in group-has-[:checked]:opacity-0 group-has-[:checked]:duration-100 group-has-[:checked]:ease-out\"\n          fill=\"none\"\n          viewBox=\"0 0 12 12\"\n          stroke-width=\"1.5\"\n        >\n          <path\n            d=\"M4 8l4-4m0 4L4 4\"\n            stroke=\"currentColor\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n        <svg\n          class=\"absolute size-3 text-primary opacity-0 duration-100 ease-out group-has-[:checked]:opacity-100 group-has-[:checked]:duration-200 group-has-[:checked]:ease-in\"\n          fill=\"currentColor\"\n          viewBox=\"0 0 12 12\"\n        >\n          <path\n            d=\"M3.707 5.293a1 1 0 00-1.414 1.414l1.414-1.414zM5 8l-.707.707a1 1 0 001.414 0L5 8zm4.707-3.293a1 1 0 00-1.414-1.414l1.414 1.414zm-7.414 2l2 2 1.414-1.414-2-2-1.414 1.414zm3.414 2l4-4-1.414-1.414-4 4 1.414 1.414z\"\n          />\n        </svg>\n      }\n    </span>\n    <ng-container *ngTemplateOutlet=\"toggleSlot\"></ng-container>\n  </div>\n}\n\n@if (variant() === 'short') {\n  <div\n    class=\"group relative inline-flex h-5 w-10 shrink-0 items-center justify-center rounded-full outline-offset-2 outline-primary has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:disabled]:opacity-50 cursor-pointer has-[:disabled]:cursor-not-allowed\"\n  >\n    <span\n      class=\"pointer-events-none absolute mx-auto h-4 w-9 rounded-full bg-surface-muted ring-1 ring-inset ring-outline-contrast/5 transition-colors duration-200 ease-in-out group-has-[:checked]:bg-primary group-has-[:disabled]:bg-surface-muted\"\n    ></span>\n\n    <span\n      class=\"pointer-events-none absolute left-0 size-5 rounded-full border border-outline bg-surface shadow-sm transition-transform duration-200 ease-in-out group-has-[:checked]:translate-x-5 flex items-center justify-center\"\n    >\n      @if (isLoading()) {\n        <pg-loader variant=\"spinner\" size=\"sm\" label=\"Loading\" />\n      } @else if (withIcon()) {\n        <svg\n          class=\"size-3 text-content-subtle opacity-100 duration-200 ease-in group-has-[:checked]:opacity-0 group-has-[:checked]:duration-100 group-has-[:checked]:ease-out\"\n          fill=\"none\"\n          viewBox=\"0 0 12 12\"\n          stroke-width=\"1.5\"\n        >\n          <path\n            d=\"M4 8l4-4m0 4L4 4\"\n            stroke=\"currentColor\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n        <svg\n          class=\"absolute size-3 text-primary opacity-0 duration-100 ease-out group-has-[:checked]:opacity-100 group-has-[:checked]:duration-200 group-has-[:checked]:ease-in\"\n          fill=\"currentColor\"\n          viewBox=\"0 0 12 12\"\n        >\n          <path\n            d=\"M3.707 5.293a1 1 0 00-1.414 1.414l1.414-1.414zM5 8l-.707.707a1 1 0 001.414 0L5 8zm4.707-3.293a1 1 0 00-1.414-1.414l1.414 1.414zm-7.414 2l2 2 1.414-1.414-2-2-1.414 1.414zm3.414 2l4-4-1.414-1.414-4 4 1.414 1.414z\"\n          />\n        </svg>\n      }\n    </span>\n    <ng-container *ngTemplateOutlet=\"toggleSlot\"></ng-container>\n  </div>\n}\n" }]
        }] });

class ToggleDirective {
    pgToggle = inject(PgToggle, { optional: true });
    el = inject((ElementRef));
    renderer = inject(Renderer2);
    constructor() {
        if (this.pgToggle) {
            this.renderer.setAttribute(this.el.nativeElement, 'role', 'switch');
            effect(() => {
                this.renderer.setProperty(this.el.nativeElement, 'checked', this.pgToggle.value() ?? false);
            });
            effect(() => {
                // isLoading forces the native input disabled too — a toggle mid-request
                // shouldn't be togglable again until the consumer flips isLoading back off.
                this.renderer.setProperty(this.el.nativeElement, 'disabled', this.pgToggle.disabled() || this.pgToggle.isLoading());
            });
            effect(() => {
                this.renderer.setAttribute(this.el.nativeElement, 'aria-checked', String(this.pgToggle.value() ?? false));
            });
        }
    }
    onChange(checked) {
        this.pgToggle?.setValue(checked);
    }
    onBlur() {
        this.pgToggle?.markAsTouched();
    }
    get hostClasses() {
        return 'absolute inset-0 z-10 size-full cursor-pointer opacity-0 appearance-none focus:outline-none disabled:cursor-not-allowed';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: ToggleDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: ToggleDirective, isStandalone: true, selector: "input[pgToggle]", host: { listeners: { "change": "onChange($event.target.checked)", "blur": "onBlur()" }, properties: { "class": "this.hostClasses" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: ToggleDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input[pgToggle]',
                    standalone: true,
                }]
        }], ctorParameters: () => [], propDecorators: { onChange: [{
                type: HostListener,
                args: ['change', ['$event.target.checked']]
            }], onBlur: [{
                type: HostListener,
                args: ['blur']
            }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }] } });

const DECLARATIONS = [
    PgForm,
    FormFieldComponent,
    FormSectionComponent,
    FormActionsComponent,
    InputComponent,
    InputDirective,
    PrefixIconDirective,
    SuffixIconDirective,
    PrefixAddonDirective,
    SuffixAddonDirective,
    PrefixInlineDirective,
    SuffixInlineDirective,
    PrefixDropdownDirective,
    SuffixDropdownDirective,
    DropdownSelectDirective,
    SuffixButtonDirective,
    SuffixShortcutDirective,
    RadioComponent,
    PgRadioGroupComponent,
    RadioDirective,
    RadioColorDirective,
    RadioCardDirective,
    RadioLabelDirective,
    RadioDescriptionDirective,
    TextareaComponent,
    TextareaDirective,
    TextareaTitleDirective,
    TextareaAvatarDirective,
    TextareaToolbarDirective,
    TextareaFooterDirective,
    TextareaPillDirective,
    TextareaPreviewDirective,
    PgToggle,
    ToggleDirective,
];
class PgFormsModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgFormsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.21", ngImport: i0, type: PgFormsModule, imports: [PgForm,
            FormFieldComponent,
            FormSectionComponent,
            FormActionsComponent,
            InputComponent,
            InputDirective,
            PrefixIconDirective,
            SuffixIconDirective,
            PrefixAddonDirective,
            SuffixAddonDirective,
            PrefixInlineDirective,
            SuffixInlineDirective,
            PrefixDropdownDirective,
            SuffixDropdownDirective,
            DropdownSelectDirective,
            SuffixButtonDirective,
            SuffixShortcutDirective,
            RadioComponent,
            PgRadioGroupComponent,
            RadioDirective,
            RadioColorDirective,
            RadioCardDirective,
            RadioLabelDirective,
            RadioDescriptionDirective,
            TextareaComponent,
            TextareaDirective,
            TextareaTitleDirective,
            TextareaAvatarDirective,
            TextareaToolbarDirective,
            TextareaFooterDirective,
            TextareaPillDirective,
            TextareaPreviewDirective,
            PgToggle,
            ToggleDirective], exports: [PgForm,
            FormFieldComponent,
            FormSectionComponent,
            FormActionsComponent,
            InputComponent,
            InputDirective,
            PrefixIconDirective,
            SuffixIconDirective,
            PrefixAddonDirective,
            SuffixAddonDirective,
            PrefixInlineDirective,
            SuffixInlineDirective,
            PrefixDropdownDirective,
            SuffixDropdownDirective,
            DropdownSelectDirective,
            SuffixButtonDirective,
            SuffixShortcutDirective,
            RadioComponent,
            PgRadioGroupComponent,
            RadioDirective,
            RadioColorDirective,
            RadioCardDirective,
            RadioLabelDirective,
            RadioDescriptionDirective,
            TextareaComponent,
            TextareaDirective,
            TextareaTitleDirective,
            TextareaAvatarDirective,
            TextareaToolbarDirective,
            TextareaFooterDirective,
            TextareaPillDirective,
            TextareaPreviewDirective,
            PgToggle,
            ToggleDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgFormsModule, imports: [PgToggle] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgFormsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [...DECLARATIONS],
                    exports: [...DECLARATIONS],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DropdownSelectDirective, FORM_VARIANT_TOKEN, FormActionsComponent, FormFieldComponent, FormSectionComponent, InputComponent, InputDirective, PgForm, PgFormsModule, PgRadioGroupComponent, PgToggle, PrefixAddonDirective, PrefixDropdownDirective, PrefixIconDirective, PrefixInlineDirective, RadioCardDirective, RadioColorDirective, RadioComponent, RadioDescriptionDirective, RadioDirective, RadioLabelDirective, SuffixAddonDirective, SuffixButtonDirective, SuffixDropdownDirective, SuffixIconDirective, SuffixInlineDirective, SuffixShortcutDirective, TextareaAvatarDirective, TextareaComponent, TextareaDirective, TextareaFooterDirective, TextareaPillDirective, TextareaPreviewDirective, TextareaTitleDirective, TextareaToolbarDirective, ToggleDirective };
//# sourceMappingURL=pagalo-ui-forms.mjs.map
