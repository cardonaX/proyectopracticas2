import * as i0 from '@angular/core';
import { inject, input, computed, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { PgDialogBase, IdService } from '@pagalo/ui/core';

class ModalComponent extends PgDialogBase {
    idService = inject(IdService);
    _autoId = this.idService.generate('pg-modal');
    /** Animación de entrada más larga que la salida, igual que la transición original de Tailwind UI. */
    panelEnterDurationMs = 300;
    panelExitDurationMs = 200;
    size = input('md');
    id = input('');
    /** ID resuelto: usa el input `id` si se provee, sino genera uno automáticamente. */
    dialogId = computed(() => this.id() || this._autoId);
    titleId = computed(() => `${this.dialogId()}-title`);
    sizeClass = computed(() => {
        const defaultClasses = 'relative overflow-hidden rounded-lg bg-surface-raised px-4 pb-4 pt-5 text-left shadow-xl sm:my-8 sm:w-full sm:p-6';
        const sizeMap = {
            sm: 'sm:max-w-sm',
            md: 'sm:max-w-md',
            lg: 'sm:max-w-lg',
            xl: 'sm:max-w-xl',
            '2xl': 'sm:max-w-2xl',
            '3xl': 'sm:max-w-3xl',
            '4xl': 'sm:max-w-4xl',
            '5xl': 'sm:max-w-5xl',
            '6xl': 'sm:max-w-6xl',
            '7xl': 'sm:max-w-7xl',
        };
        return `${defaultClasses} ${sizeMap[this.size()]}`;
    });
    ngOnInit() {
        // Hook disponible para extensiones futuras
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: ModalComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.21", type: ModalComponent, isStandalone: true, selector: "pg-modal", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null } }, usesInheritance: true, ngImport: i0, template: "<dialog\n  #dialogRef\n  [id]=\"dialogId()\"\n  [attr.aria-labelledby]=\"titleId()\"\n  class=\"fixed inset-0 m-0 size-auto max-h-none max-w-none overflow-y-auto bg-transparent p-0 backdrop:bg-transparent\"\n>\n  <div\n    class=\"fixed inset-0 bg-overlay/75\"\n    [class.animate-fade-in]=\"!isClosing()\"\n    [class.animate-fade-out]=\"isClosing()\"\n    [style.animation-duration.ms]=\"isClosing() ? panelExitDurationMs : panelEnterDurationMs\"\n  ></div>\n\n  <div\n    tabindex=\"0\"\n    class=\"fixed inset-0 flex min-h-full items-end justify-center overflow-y-auto p-4 text-center focus:outline focus:outline-0 sm:items-center sm:p-0\"\n    (click)=\"$event.target === $event.currentTarget && onBackdropClick()\"\n  >\n    <div\n      [class]=\"sizeClass()\"\n      [class.animate-fade-in-up]=\"!isClosing()\"\n      [class.animate-fade-out-down]=\"isClosing()\"\n      [style.animation-duration.ms]=\"isClosing() ? panelExitDurationMs : panelEnterDurationMs\"\n    >\n      <span [id]=\"titleId()\" class=\"sr-only\">Dialog</span>\n      <ng-content></ng-content>\n    </div>\n  </div>\n</dialog>\n", styles: [""], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: ModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-modal', imports: [], changeDetection: ChangeDetectionStrategy.OnPush, template: "<dialog\n  #dialogRef\n  [id]=\"dialogId()\"\n  [attr.aria-labelledby]=\"titleId()\"\n  class=\"fixed inset-0 m-0 size-auto max-h-none max-w-none overflow-y-auto bg-transparent p-0 backdrop:bg-transparent\"\n>\n  <div\n    class=\"fixed inset-0 bg-overlay/75\"\n    [class.animate-fade-in]=\"!isClosing()\"\n    [class.animate-fade-out]=\"isClosing()\"\n    [style.animation-duration.ms]=\"isClosing() ? panelExitDurationMs : panelEnterDurationMs\"\n  ></div>\n\n  <div\n    tabindex=\"0\"\n    class=\"fixed inset-0 flex min-h-full items-end justify-center overflow-y-auto p-4 text-center focus:outline focus:outline-0 sm:items-center sm:p-0\"\n    (click)=\"$event.target === $event.currentTarget && onBackdropClick()\"\n  >\n    <div\n      [class]=\"sizeClass()\"\n      [class.animate-fade-in-up]=\"!isClosing()\"\n      [class.animate-fade-out-down]=\"isClosing()\"\n      [style.animation-duration.ms]=\"isClosing() ? panelExitDurationMs : panelEnterDurationMs\"\n    >\n      <span [id]=\"titleId()\" class=\"sr-only\">Dialog</span>\n      <ng-content></ng-content>\n    </div>\n  </div>\n</dialog>\n" }]
        }] });

class ModalContentComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: ModalContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.21", type: ModalContentComponent, isStandalone: true, selector: "pg-modal-content", ngImport: i0, template: `
    <div class="mt-2 text-sm text-content-muted">
      <ng-content></ng-content>
    </div>
  `, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: ModalContentComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'pg-modal-content',
                    standalone: true,
                    template: `
    <div class="mt-2 text-sm text-content-muted">
      <ng-content></ng-content>
    </div>
  `,
                }]
        }] });

class ModalFooterComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: ModalFooterComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.21", type: ModalFooterComponent, isStandalone: true, selector: "pg-modal-footer", ngImport: i0, template: `
    <div class="mt-5 sm:mt-6 sm:flex sm:flex-row-reverse sm:gap-3">
      <ng-content></ng-content>
    </div>
  `, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: ModalFooterComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'pg-modal-footer',
                    standalone: true,
                    template: `
    <div class="mt-5 sm:mt-6 sm:flex sm:flex-row-reverse sm:gap-3">
      <ng-content></ng-content>
    </div>
  `,
                }]
        }] });

class ModalHeaderComponent {
    showClose = input(true);
    modal = inject(ModalComponent, { optional: true });
    close() {
        this.modal?.close();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: ModalHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: ModalHeaderComponent, isStandalone: true, selector: "pg-modal-header", inputs: { showClose: { classPropertyName: "showClose", publicName: "showClose", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <div class="mb-4 sm:flex sm:items-start sm:justify-between">
      <div class="text-left w-full">
        <ng-content></ng-content>
      </div>
      @if (showClose()) {
        <div class="ml-4 mt-1 flex h-7 items-center sm:ml-6 sm:mt-0">
          <button
            type="button"
            (click)="close()"
            class="relative rounded-md bg-surface-muted text-content-muted hover:text-content focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
          >
            <span class="absolute -inset-2.5"></span>
            <span class="sr-only">Close panel</span>
            <svg
              class="size-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke-width="1.5"
              stroke="currentColor"
              aria-hidden="true"
              data-slot="icon"
            >
              <path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      }
    </div>
  `, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: ModalHeaderComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'pg-modal-header',
                    imports: [],
                    template: `
    <div class="mb-4 sm:flex sm:items-start sm:justify-between">
      <div class="text-left w-full">
        <ng-content></ng-content>
      </div>
      @if (showClose()) {
        <div class="ml-4 mt-1 flex h-7 items-center sm:ml-6 sm:mt-0">
          <button
            type="button"
            (click)="close()"
            class="relative rounded-md bg-surface-muted text-content-muted hover:text-content focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
          >
            <span class="absolute -inset-2.5"></span>
            <span class="sr-only">Close panel</span>
            <svg
              class="size-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke-width="1.5"
              stroke="currentColor"
              aria-hidden="true"
              data-slot="icon"
            >
              <path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      }
    </div>
  `
                }]
        }] });

class PgModalModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgModalModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.21", ngImport: i0, type: PgModalModule, imports: [ModalComponent,
            ModalContentComponent,
            ModalFooterComponent,
            ModalHeaderComponent], exports: [ModalComponent,
            ModalContentComponent,
            ModalFooterComponent,
            ModalHeaderComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgModalModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgModalModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        ModalComponent,
                        ModalContentComponent,
                        ModalFooterComponent,
                        ModalHeaderComponent,
                    ],
                    exports: [
                        ModalComponent,
                        ModalContentComponent,
                        ModalFooterComponent,
                        ModalHeaderComponent,
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { ModalComponent, ModalContentComponent, ModalFooterComponent, ModalHeaderComponent, PgModalModule };
//# sourceMappingURL=pagalo-ui-modal.mjs.map
