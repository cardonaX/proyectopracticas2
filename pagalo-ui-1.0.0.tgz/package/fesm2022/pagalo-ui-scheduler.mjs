import * as i0 from '@angular/core';
import { input, output, signal, computed, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

/**
 * Pure date/layout utilities for `pg-scheduler` (design DD3/DD4). No
 * Angular, no Tailwind, no date-fns/dayjs dependency (proposal D4) — every
 * function here operates on plain `Date` objects in the host's local
 * timezone, mirroring how a scheduling UI is normally bound to the
 * consumer's device time.
 */
const MS_PER_DAY = 86_400_000;
/** Zeroes hours/minutes/seconds/ms, keeping the calendar date. Never mutates the input. */
function startOfDay(d) {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}
/**
 * Advances (or, for negative `n`, retreats) `d` by `n` *calendar* days.
 * Built on `Date`'s calendar-component constructor (not raw ms arithmetic)
 * so results are correct across month/year rollovers and are unaffected by
 * any DST shift that may occur inside the span — DST-safety here is a
 * byproduct of operating on calendar fields, not wall-clock milliseconds.
 */
function addDays(d, n) {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n, d.getHours(), d.getMinutes(), d.getSeconds(), d.getMilliseconds());
}
/**
 * Whole calendar days between `a` and `b` (`a - b`), normalizing both
 * operands to `startOfDay` first. Uses `Math.round`, never `Math.floor`: if
 * a DST transition falls inside the span, the elapsed real time between two
 * local midnights is not an exact multiple of 24h (23h or 25h for that one
 * day), so `Math.floor` can silently drop a day on a "spring forward"
 * transition. Rounding to the nearest whole day is always correct because
 * both operands are already calendar-midnight-aligned.
 */
function diffInDays(a, b) {
    const msDiff = startOfDay(a).getTime() - startOfDay(b).getTime();
    return Math.round(msDiff / MS_PER_DAY);
}
/**
 * Intersects `[s, e)` with `[min, max)`. Returns `null` when the
 * intersection is empty (including a zero-width result), which callers use
 * as "do not render".
 */
function clampRange(s, e, min, max) {
    const start = s.getTime() > min.getTime() ? s : min;
    const end = e.getTime() < max.getTime() ? e : max;
    if (start.getTime() >= end.getTime())
        return null;
    return { start, end };
}
/**
 * Places a single event against the currently visible period
 * `[visibleStart, visibleStart + visibleDays)`. Returns `null` when the
 * event does not intersect the visible period at all (spec: scheduler-events
 * "Out-of-range event"). `end` stays exclusive throughout, mirroring
 * `PgBookingEvent.end`.
 */
function placeEvent(event, visibleStart, visibleDays) {
    const visibleEnd = addDays(visibleStart, visibleDays);
    const clamped = clampRange(event.start, event.end, visibleStart, visibleEnd);
    if (!clamped)
        return null;
    return {
        colStart: diffInDays(clamped.start, visibleStart),
        colSpan: diffInDays(clamped.end, clamped.start),
        clippedLeft: event.start.getTime() < visibleStart.getTime(),
        clippedRight: event.end.getTime() > visibleEnd.getTime(),
    };
}
/**
 * Scanline row layout (design DD2). A `<table>` row is only valid if the sum
 * of `colspan` over its cells equals `visibleDays` — so this does not emit
 * "bars", it emits a complete ordered run of cells covering every column
 * exactly once:
 *
 * 1. Allocate one column slot per visible day, defaulting to "empty".
 * 2. Walk `events` in array order, writing each event's index into the
 *    columns it occupies — last write wins (proposal: overlap is out of v1
 *    scope, later array entries take visual precedence).
 * 3. Compress consecutive columns holding the same value into segments.
 *
 * If a later event splits an earlier one, the earlier event renders as two
 * segments; each is flagged `clippedLeft`/`clippedRight` on the seam side
 * (in addition to any real visible-period clipping), matching the design's
 * documented consequence of the scanline approach.
 */
function layoutRow(events, visibleStart, visibleDays) {
    const cols = new Int32Array(visibleDays).fill(-1);
    const placements = new Map();
    events.forEach((event, index) => {
        const placement = placeEvent(event, visibleStart, visibleDays);
        if (!placement)
            return;
        placements.set(index, placement);
        const end = placement.colStart + placement.colSpan;
        for (let col = placement.colStart; col < end; col++) {
            cols[col] = index;
        }
    });
    const segments = [];
    let i = 0;
    while (i < visibleDays) {
        const eventIndex = cols[i];
        let j = i + 1;
        while (j < visibleDays && cols[j] === eventIndex)
            j++;
        const colStart = i;
        const colSpan = j - i;
        if (eventIndex === -1) {
            segments.push({
                colStart,
                colSpan,
                clippedLeft: false,
                clippedRight: false,
                eventIndex: null,
            });
        }
        else {
            const placement = placements.get(eventIndex);
            const placementEnd = placement.colStart + placement.colSpan;
            const segmentEnd = colStart + colSpan;
            segments.push({
                colStart,
                colSpan,
                clippedLeft: colStart === placement.colStart ? placement.clippedLeft : true,
                clippedRight: segmentEnd === placementEnd ? placement.clippedRight : true,
                eventIndex,
            });
        }
        i = j;
    }
    return segments;
}

/**
 * Event-bar fill per `BookingStatus` (design DD5 / spec "Semantic-token-only
 * status colors"). Only the 8 semantic Tailwind tokens are used — never raw
 * palette classes. An event with no `status` falls back to `confirmed`.
 */
const BOOKING_BAR_CLASSES = {
    confirmed: 'bg-success text-white',
    'checked-in': 'bg-info text-white',
    'checked-out': 'bg-disabled text-disabled-text',
    pending: 'bg-warning text-gray-900',
    cancelled: 'bg-error/10 text-error line-through ring-1 ring-inset ring-error/20',
};
/** Resource-pill fill per `ResourceStatus` (design DD5). */
const RESOURCE_PILL_CLASSES = {
    available: 'bg-success/20 text-success',
    occupied: 'bg-error/20 text-error',
    blocked: 'bg-disabled text-disabled-text',
    dirty: 'bg-warning/20 text-gray-900',
};
/** Default resource-pill label per `ResourceStatus`, overridable via `PgResource.statusLabel`. */
const RESOURCE_STATUS_LABELS = {
    available: 'Disponible',
    occupied: 'Ocupado',
    blocked: 'Bloqueado',
    dirty: 'Necesita Limpieza',
};
function resolveRoundClass(clippedLeft, clippedRight) {
    if (clippedLeft && clippedRight)
        return 'rounded-none';
    if (clippedLeft)
        return 'rounded-l-none rounded-r-md';
    if (clippedRight)
        return 'rounded-l-md rounded-r-none';
    return 'rounded-md';
}
function formatShortDate(date, locale) {
    const day = new Intl.DateTimeFormat(locale, { day: '2-digit' }).format(date);
    const month = new Intl.DateTimeFormat(locale, { month: 'short' }).format(date);
    return `${day} ${month}`;
}
function formatRangeLabel(start, end, locale) {
    // `end` is exclusive — the label shows the last occupied day, not the
    // checkout day itself (draft §4.4 / PgBookingEvent.end doc comment).
    const lastDay = addDays(end, -1);
    const dayFmt = new Intl.DateTimeFormat(locale, { day: '2-digit' });
    const monthFmt = new Intl.DateTimeFormat(locale, { month: 'short' });
    return `${dayFmt.format(start)} - ${dayFmt.format(lastDay)} ${monthFmt.format(lastDay)}`;
}
/**
 * Horizontal resource/Gantt scheduler grid (proposal + design #464). 100%
 * presentational: every rendered value derives from the `groups`/`resources`/
 * `events` inputs plus the internal `_startDate` navigation signal through a
 * `computed()` chain — the template performs zero computation (Phase 3).
 */
class PgSchedulerComponent {
    // ── Data ──────────────────────────────────────────────────────────────
    groups = input([]);
    resources = input([]);
    events = input([]);
    // ── View configuration ───────────────────────────────────────────────
    startDate = input(new Date());
    visibleDays = input(10);
    locale = input('es-GT');
    firstDayOfWeek = input(1);
    // ── Labels / i18n ────────────────────────────────────────────────────
    todayLabel = input('Hoy');
    resourcesLabel = input('Recursos');
    // ── Outputs ──────────────────────────────────────────────────────────
    eventClick = output();
    dateClick = output();
    periodChange = output();
    /**
     * Uncontrolled period anchor (design DD1). `null` means "not navigated
     * yet" — while null, `periodStart` tracks the `startDate` input reactively.
     * The FIRST write (via `onPrev`/`onNext`/`onToday`) makes `periodStart`
     * stop depending on `startDate()` (dynamic signal dependency tracking), so
     * a later parent re-render with the same/stale `startDate` never resets
     * navigation (spec: "Uncontrolled startDate (D8)"). No `effect`, no
     * `linkedSignal` — see design DD1 for the rejected alternatives.
     */
    _startDate = signal(null);
    periodStart = computed(() => this._startDate() ?? startOfDay(this.startDate()));
    periodEnd = computed(() => addDays(this.periodStart(), this.visibleDays()));
    dayColumns = computed(() => {
        const start = this.periodStart();
        const days = this.visibleDays();
        const loc = this.locale();
        const today = startOfDay(new Date());
        const dayNameFmt = new Intl.DateTimeFormat(loc, { weekday: 'short' });
        const dayNumberFmt = new Intl.DateTimeFormat(loc, { day: 'numeric' });
        const columns = [];
        for (let i = 0; i < days; i++) {
            const date = addDays(start, i);
            columns.push({
                date,
                dayName: dayNameFmt.format(date),
                dayNumber: dayNumberFmt.format(date),
                isToday: date.getTime() === today.getTime(),
                index: i,
            });
        }
        return columns;
    });
    periodLabel = computed(() => {
        const loc = this.locale();
        const lastDay = addDays(this.periodEnd(), -1);
        return `${formatShortDate(this.periodStart(), loc)} - ${formatShortDate(lastDay, loc)}`;
    });
    /** `PgBookingEvent[]` bucketed by `resourceId`, preserving input array order. */
    eventsByResource = computed(() => {
        const map = new Map();
        for (const event of this.events()) {
            const bucket = map.get(event.resourceId);
            if (bucket)
                bucket.push(event);
            else
                map.set(event.resourceId, [event]);
        }
        return map;
    });
    /**
     * Flattened group/resource skeleton, without per-day cells: one `group`
     * row per `groups()` entry followed immediately by its resources (input
     * order); resources with no match in `groups()` are appended last, with no
     * group header (design "Open Question", adopted as documented default).
     */
    rows = computed(() => {
        const groups = this.groups();
        const resources = this.resources();
        const rows = [];
        const grouped = new Set();
        for (const group of groups) {
            rows.push({ kind: 'group', group });
            for (const resource of resources) {
                if (resource.groupId === group.id) {
                    rows.push({ kind: 'resource', resource });
                    grouped.add(resource.id);
                }
            }
        }
        for (const resource of resources) {
            if (!grouped.has(resource.id)) {
                rows.push({ kind: 'resource', resource });
            }
        }
        return rows;
    });
    /**
     * Fully-resolved render-ready rows (design's `renderRows` in the Internal
     * State Model table): `rows` + per-resource cells from `layoutRow` (design
     * DD2, colocated pure util from Phase 1), with resolved token classes.
     */
    renderRows = computed(() => {
        const skeleton = this.rows();
        const start = this.periodStart();
        const days = this.visibleDays();
        const loc = this.locale();
        const eventsByResource = this.eventsByResource();
        const today = startOfDay(new Date());
        return skeleton.map(row => {
            if (row.kind === 'group')
                return row;
            const resourceEvents = eventsByResource.get(row.resource.id) ?? [];
            const segments = layoutRow(resourceEvents, start, days);
            const cells = [];
            for (const segment of segments) {
                if (segment.eventIndex === null) {
                    for (let i = 0; i < segment.colSpan; i++) {
                        const date = addDays(start, segment.colStart + i);
                        cells.push({
                            kind: 'empty',
                            date,
                            resourceId: row.resource.id,
                            isToday: date.getTime() === today.getTime(),
                            ariaLabel: `${row.resource.label}, ${formatShortDate(date, loc)}`,
                        });
                    }
                    continue;
                }
                const event = resourceEvents[segment.eventIndex];
                cells.push({
                    kind: 'event',
                    event,
                    colSpan: segment.colSpan,
                    barClass: BOOKING_BAR_CLASSES[event.status ?? 'confirmed'],
                    roundClass: resolveRoundClass(segment.clippedLeft, segment.clippedRight),
                    rangeLabel: formatRangeLabel(event.start, event.end, loc),
                    ariaLabel: `${event.label}, del ${formatShortDate(event.start, loc)} al ${formatShortDate(event.end, loc)}`,
                });
            }
            const status = row.resource.status;
            return {
                kind: 'resource',
                resource: row.resource,
                pillClass: status ? RESOURCE_PILL_CLASSES[status] : '',
                pillLabel: row.resource.statusLabel ?? (status ? RESOURCE_STATUS_LABELS[status] : ''),
                cells,
            };
        });
    });
    onPrev() {
        this._startDate.set(addDays(this.periodStart(), -this.visibleDays()));
        this.emitPeriodChange();
    }
    onNext() {
        this._startDate.set(addDays(this.periodStart(), this.visibleDays()));
        this.emitPeriodChange();
    }
    onToday() {
        this._startDate.set(startOfDay(new Date()));
        this.emitPeriodChange();
    }
    emitPeriodChange() {
        this.periodChange.emit({ start: this.periodStart(), end: this.periodEnd() });
    }
    onEventClick(event) {
        this.eventClick.emit(event);
    }
    onDateClick(date, resourceId) {
        this.dateClick.emit({ date, resourceId });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgSchedulerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: PgSchedulerComponent, isStandalone: true, selector: "pg-scheduler", inputs: { groups: { classPropertyName: "groups", publicName: "groups", isSignal: true, isRequired: false, transformFunction: null }, resources: { classPropertyName: "resources", publicName: "resources", isSignal: true, isRequired: false, transformFunction: null }, events: { classPropertyName: "events", publicName: "events", isSignal: true, isRequired: false, transformFunction: null }, startDate: { classPropertyName: "startDate", publicName: "startDate", isSignal: true, isRequired: false, transformFunction: null }, visibleDays: { classPropertyName: "visibleDays", publicName: "visibleDays", isSignal: true, isRequired: false, transformFunction: null }, locale: { classPropertyName: "locale", publicName: "locale", isSignal: true, isRequired: false, transformFunction: null }, firstDayOfWeek: { classPropertyName: "firstDayOfWeek", publicName: "firstDayOfWeek", isSignal: true, isRequired: false, transformFunction: null }, todayLabel: { classPropertyName: "todayLabel", publicName: "todayLabel", isSignal: true, isRequired: false, transformFunction: null }, resourcesLabel: { classPropertyName: "resourcesLabel", publicName: "resourcesLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { eventClick: "eventClick", dateClick: "dateClick", periodChange: "periodChange" }, ngImport: i0, template: "<div class=\"pg-scheduler\">\n  <div class=\"pg-scheduler__toolbar flex items-center justify-between gap-4 pb-3\">\n    <div class=\"flex items-center gap-2\">\n      <button\n        type=\"button\"\n        data-testid=\"pg-scheduler-prev\"\n        class=\"pg-scheduler__nav-btn inline-flex items-center justify-center rounded-md border border-gray-300 bg-white p-1.5 text-gray-500 hover:bg-gray-50\"\n        aria-label=\"Periodo anterior\"\n        (click)=\"onPrev()\"\n        >\n        <svg viewBox=\"0 0 20 20\" fill=\"currentColor\" class=\"size-4\">\n          <path\n            fill-rule=\"evenodd\"\n            d=\"M12.79 5.23a.75.75 0 0 1-.02 1.06L8.832 10l3.938 3.71a.75.75 0 1 1-1.04 1.08l-4.5-4.25a.75.75 0 0 1 0-1.08l4.5-4.25a.75.75 0 0 1 1.06.02Z\"\n            clip-rule=\"evenodd\"\n          ></path>\n        </svg>\n      </button>\n      <button\n        type=\"button\"\n        data-testid=\"pg-scheduler-today\"\n        class=\"pg-scheduler__today-btn rounded-md border border-gray-300 bg-white px-3 py-1.5 text-sm font-medium text-gray-700 hover:bg-gray-50\"\n        (click)=\"onToday()\"\n        >\n        {{ todayLabel() }}\n      </button>\n      <button\n        type=\"button\"\n        data-testid=\"pg-scheduler-next\"\n        class=\"pg-scheduler__nav-btn inline-flex items-center justify-center rounded-md border border-gray-300 bg-white p-1.5 text-gray-500 hover:bg-gray-50\"\n        aria-label=\"Periodo siguiente\"\n        (click)=\"onNext()\"\n        >\n        <svg viewBox=\"0 0 20 20\" fill=\"currentColor\" class=\"size-4\">\n          <path\n            fill-rule=\"evenodd\"\n            d=\"M7.21 14.77a.75.75 0 0 1 .02-1.06L11.168 10 7.23 6.29a.75.75 0 1 1 1.04-1.08l4.5 4.25a.75.75 0 0 1 0 1.08l-4.5 4.25a.75.75 0 0 1-1.06-.02Z\"\n            clip-rule=\"evenodd\"\n          ></path>\n        </svg>\n      </button>\n    </div>\n    <span class=\"pg-scheduler__period-label text-sm font-medium text-gray-900\" aria-live=\"polite\">{{\n      periodLabel()\n    }}</span>\n  </div>\n\n  <div\n    class=\"pg-scheduler__scroll relative max-h-[var(--pg-scheduler-max-h)] overflow-auto rounded-lg ring-1 ring-gray-200\"\n    >\n    <table class=\"pg-scheduler__table min-w-full table-fixed border-separate border-spacing-0\" role=\"grid\">\n      <colgroup>\n        <col class=\"w-64\" />\n        @for (day of dayColumns(); track day.index) {\n          <col style=\"width: var(--pg-scheduler-day-w)\" />\n        }\n      </colgroup>\n      <thead>\n        <tr>\n          <th\n            scope=\"col\"\n            class=\"pg-scheduler__corner sticky left-0 top-0 z-30 border-b border-r border-gray-200 bg-white px-4 py-2 text-left text-sm font-semibold text-gray-900\"\n            >\n            {{ resourcesLabel() }}\n          </th>\n          @for (day of dayColumns(); track day.index) {\n            <th\n              scope=\"col\"\n              role=\"columnheader\"\n              class=\"pg-scheduler__day-header sticky top-0 z-20 border-b border-r border-gray-200 bg-white px-2 py-2 text-center text-xs\"\n              [ngClass]=\"day.isToday ? 'bg-primary/10 font-bold text-primary' : 'font-medium text-gray-500'\"\n              >\n              {{ day.dayName }} {{ day.dayNumber }}\n            </th>\n          }\n        </tr>\n      </thead>\n      <tbody>\n        @for (row of renderRows(); track row.kind === 'group' ? 'g-' + row.group.id : 'r-' + row.resource.id) {\n          @if (row.kind === 'group') {\n            <tr>\n              <th\n                scope=\"row\"\n                class=\"pg-scheduler__group-row sticky left-0 z-10 border-b border-r border-gray-200 bg-gray-50 px-4 py-2 text-left text-sm font-semibold text-gray-900\"\n                >\n                {{ row.group.label }}\n                @if (row.group.subtitle) {\n                  <span class=\"float-right text-xs font-normal text-gray-500\">{{ row.group.subtitle }}</span>\n                }\n              </th>\n              <td [attr.colspan]=\"dayColumns().length\" class=\"border-b border-gray-200 bg-gray-50\"></td>\n            </tr>\n          } @else {\n            <tr>\n              <th\n                scope=\"row\"\n                role=\"rowheader\"\n                class=\"pg-scheduler__resource-header sticky left-0 z-10 border-b border-r border-gray-200 bg-white px-4 py-2 text-left text-sm text-gray-900\"\n                >\n                <div class=\"flex items-center justify-between gap-2\">\n                  <span>{{ row.resource.label }}</span>\n                  @if (row.pillClass) {\n                    <span\n                      class=\"pg-scheduler__pill inline-flex items-center rounded-md px-1.5 py-0.5 text-xs font-medium\"\n                      [ngClass]=\"row.pillClass\"\n                      >\n                      {{ row.pillLabel }}\n                    </span>\n                  }\n                </div>\n              </th>\n              @for (cell of row.cells; track $index) {\n                @if (cell.kind === 'empty') {\n                  <td\n                    class=\"pg-scheduler__cell pg-scheduler__cell--empty border-b border-r border-gray-200\"\n                    [ngClass]=\"cell.isToday ? 'bg-primary/10' : ''\"\n                    [attr.aria-label]=\"cell.ariaLabel\"\n                    (click)=\"onDateClick(cell.date, cell.resourceId)\"\n                    ></td>\n                } @else {\n                  <td\n                    [attr.colspan]=\"cell.colSpan\"\n                    class=\"pg-scheduler__cell pg-scheduler__cell--event border-b border-r border-gray-200 p-1\"\n                    >\n                    <div\n                      class=\"pg-scheduler__event-bar flex h-full items-center justify-between gap-2 px-2 py-1 text-xs font-medium\"\n                      [ngClass]=\"[cell.barClass, cell.roundClass]\"\n                      [style.background-color]=\"cell.event.color || null\"\n                      role=\"button\"\n                      tabindex=\"0\"\n                      [attr.aria-label]=\"cell.ariaLabel\"\n                      (click)=\"onEventClick(cell.event)\"\n                      (keydown.enter)=\"onEventClick(cell.event)\"\n                      (keydown.space)=\"onEventClick(cell.event)\"\n                      >\n                      <span class=\"truncate\">{{ cell.event.label }}</span>\n                      <span class=\"shrink-0\">{{ cell.rangeLabel }}</span>\n                    </div>\n                  </td>\n                }\n              }\n            </tr>\n          }\n        }\n      </tbody>\n    </table>\n  </div>\n</div>\n", styles: [":host{display:block;--pg-scheduler-day-w: 6rem;--pg-scheduler-max-h: 32rem}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgSchedulerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-scheduler', imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"pg-scheduler\">\n  <div class=\"pg-scheduler__toolbar flex items-center justify-between gap-4 pb-3\">\n    <div class=\"flex items-center gap-2\">\n      <button\n        type=\"button\"\n        data-testid=\"pg-scheduler-prev\"\n        class=\"pg-scheduler__nav-btn inline-flex items-center justify-center rounded-md border border-gray-300 bg-white p-1.5 text-gray-500 hover:bg-gray-50\"\n        aria-label=\"Periodo anterior\"\n        (click)=\"onPrev()\"\n        >\n        <svg viewBox=\"0 0 20 20\" fill=\"currentColor\" class=\"size-4\">\n          <path\n            fill-rule=\"evenodd\"\n            d=\"M12.79 5.23a.75.75 0 0 1-.02 1.06L8.832 10l3.938 3.71a.75.75 0 1 1-1.04 1.08l-4.5-4.25a.75.75 0 0 1 0-1.08l4.5-4.25a.75.75 0 0 1 1.06.02Z\"\n            clip-rule=\"evenodd\"\n          ></path>\n        </svg>\n      </button>\n      <button\n        type=\"button\"\n        data-testid=\"pg-scheduler-today\"\n        class=\"pg-scheduler__today-btn rounded-md border border-gray-300 bg-white px-3 py-1.5 text-sm font-medium text-gray-700 hover:bg-gray-50\"\n        (click)=\"onToday()\"\n        >\n        {{ todayLabel() }}\n      </button>\n      <button\n        type=\"button\"\n        data-testid=\"pg-scheduler-next\"\n        class=\"pg-scheduler__nav-btn inline-flex items-center justify-center rounded-md border border-gray-300 bg-white p-1.5 text-gray-500 hover:bg-gray-50\"\n        aria-label=\"Periodo siguiente\"\n        (click)=\"onNext()\"\n        >\n        <svg viewBox=\"0 0 20 20\" fill=\"currentColor\" class=\"size-4\">\n          <path\n            fill-rule=\"evenodd\"\n            d=\"M7.21 14.77a.75.75 0 0 1 .02-1.06L11.168 10 7.23 6.29a.75.75 0 1 1 1.04-1.08l4.5 4.25a.75.75 0 0 1 0 1.08l-4.5 4.25a.75.75 0 0 1-1.06-.02Z\"\n            clip-rule=\"evenodd\"\n          ></path>\n        </svg>\n      </button>\n    </div>\n    <span class=\"pg-scheduler__period-label text-sm font-medium text-gray-900\" aria-live=\"polite\">{{\n      periodLabel()\n    }}</span>\n  </div>\n\n  <div\n    class=\"pg-scheduler__scroll relative max-h-[var(--pg-scheduler-max-h)] overflow-auto rounded-lg ring-1 ring-gray-200\"\n    >\n    <table class=\"pg-scheduler__table min-w-full table-fixed border-separate border-spacing-0\" role=\"grid\">\n      <colgroup>\n        <col class=\"w-64\" />\n        @for (day of dayColumns(); track day.index) {\n          <col style=\"width: var(--pg-scheduler-day-w)\" />\n        }\n      </colgroup>\n      <thead>\n        <tr>\n          <th\n            scope=\"col\"\n            class=\"pg-scheduler__corner sticky left-0 top-0 z-30 border-b border-r border-gray-200 bg-white px-4 py-2 text-left text-sm font-semibold text-gray-900\"\n            >\n            {{ resourcesLabel() }}\n          </th>\n          @for (day of dayColumns(); track day.index) {\n            <th\n              scope=\"col\"\n              role=\"columnheader\"\n              class=\"pg-scheduler__day-header sticky top-0 z-20 border-b border-r border-gray-200 bg-white px-2 py-2 text-center text-xs\"\n              [ngClass]=\"day.isToday ? 'bg-primary/10 font-bold text-primary' : 'font-medium text-gray-500'\"\n              >\n              {{ day.dayName }} {{ day.dayNumber }}\n            </th>\n          }\n        </tr>\n      </thead>\n      <tbody>\n        @for (row of renderRows(); track row.kind === 'group' ? 'g-' + row.group.id : 'r-' + row.resource.id) {\n          @if (row.kind === 'group') {\n            <tr>\n              <th\n                scope=\"row\"\n                class=\"pg-scheduler__group-row sticky left-0 z-10 border-b border-r border-gray-200 bg-gray-50 px-4 py-2 text-left text-sm font-semibold text-gray-900\"\n                >\n                {{ row.group.label }}\n                @if (row.group.subtitle) {\n                  <span class=\"float-right text-xs font-normal text-gray-500\">{{ row.group.subtitle }}</span>\n                }\n              </th>\n              <td [attr.colspan]=\"dayColumns().length\" class=\"border-b border-gray-200 bg-gray-50\"></td>\n            </tr>\n          } @else {\n            <tr>\n              <th\n                scope=\"row\"\n                role=\"rowheader\"\n                class=\"pg-scheduler__resource-header sticky left-0 z-10 border-b border-r border-gray-200 bg-white px-4 py-2 text-left text-sm text-gray-900\"\n                >\n                <div class=\"flex items-center justify-between gap-2\">\n                  <span>{{ row.resource.label }}</span>\n                  @if (row.pillClass) {\n                    <span\n                      class=\"pg-scheduler__pill inline-flex items-center rounded-md px-1.5 py-0.5 text-xs font-medium\"\n                      [ngClass]=\"row.pillClass\"\n                      >\n                      {{ row.pillLabel }}\n                    </span>\n                  }\n                </div>\n              </th>\n              @for (cell of row.cells; track $index) {\n                @if (cell.kind === 'empty') {\n                  <td\n                    class=\"pg-scheduler__cell pg-scheduler__cell--empty border-b border-r border-gray-200\"\n                    [ngClass]=\"cell.isToday ? 'bg-primary/10' : ''\"\n                    [attr.aria-label]=\"cell.ariaLabel\"\n                    (click)=\"onDateClick(cell.date, cell.resourceId)\"\n                    ></td>\n                } @else {\n                  <td\n                    [attr.colspan]=\"cell.colSpan\"\n                    class=\"pg-scheduler__cell pg-scheduler__cell--event border-b border-r border-gray-200 p-1\"\n                    >\n                    <div\n                      class=\"pg-scheduler__event-bar flex h-full items-center justify-between gap-2 px-2 py-1 text-xs font-medium\"\n                      [ngClass]=\"[cell.barClass, cell.roundClass]\"\n                      [style.background-color]=\"cell.event.color || null\"\n                      role=\"button\"\n                      tabindex=\"0\"\n                      [attr.aria-label]=\"cell.ariaLabel\"\n                      (click)=\"onEventClick(cell.event)\"\n                      (keydown.enter)=\"onEventClick(cell.event)\"\n                      (keydown.space)=\"onEventClick(cell.event)\"\n                      >\n                      <span class=\"truncate\">{{ cell.event.label }}</span>\n                      <span class=\"shrink-0\">{{ cell.rangeLabel }}</span>\n                    </div>\n                  </td>\n                }\n              }\n            </tr>\n          }\n        }\n      </tbody>\n    </table>\n  </div>\n</div>\n", styles: [":host{display:block;--pg-scheduler-day-w: 6rem;--pg-scheduler-max-h: 32rem}\n"] }]
        }] });

class PgSchedulerModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgSchedulerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.21", ngImport: i0, type: PgSchedulerModule, imports: [PgSchedulerComponent], exports: [PgSchedulerComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgSchedulerModule, imports: [PgSchedulerComponent] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgSchedulerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [PgSchedulerComponent],
                    exports: [PgSchedulerComponent],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { PgSchedulerComponent, PgSchedulerModule };
//# sourceMappingURL=pagalo-ui-scheduler.mjs.map
