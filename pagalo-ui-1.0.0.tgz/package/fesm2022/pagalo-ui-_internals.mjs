import * as i0 from '@angular/core';
import { inject, Injector, signal, computed, Directive, model, output, viewChild, effect, Injectable, input } from '@angular/core';
import { NgControl } from '@angular/forms';
import { Router } from '@angular/router';

/**
 * Clase base abstracta para componentes que implementan ControlValueAccessor.
 *
 * Uso: `extends PgControlValueAccessorBase<T>` en el componente concreto.
 * El componente concreto debe registrar NG_VALUE_ACCESSOR en sus providers:
 * ```ts
 * providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => MiComponent), multi: true }]
 * ```
 *
 * NOTA: No se hace self-injection de NgControl en el constructor para evitar
 * circular dependency con NG_VALUE_ACCESSOR. El NgControl se resuelve en ngOnInit.
 *
 * @internal No exportar en ningún public-api.ts
 */
class PgControlValueAccessorBase {
    injector = inject(Injector);
    // Estado interno via signals
    _value = signal(null);
    _disabled = signal(false);
    _touched = signal(false);
    // Referencia al NgControl — se resuelve en ngOnInit para evitar ciclo DI
    ngControl = null;
    // Callbacks registrados por Angular Forms
    _onChange = () => { };
    _onTouched = () => { };
    // Signals readonly expuestos al template
    value = this._value.asReadonly();
    disabled = this._disabled.asReadonly();
    touched = this._touched.asReadonly();
    /**
     * Indica si el control asociado tiene errores y fue tocado/modificado.
     * Si no hay NgControl asociado, retorna false (uso sin Forms).
     * Las subclases pueden hacer override para agregar lógica adicional.
     */
    hasError = computed(() => {
        const ctrl = this.ngControl?.control;
        if (!ctrl)
            return false;
        return ctrl.invalid && (ctrl.touched || ctrl.dirty);
    });
    /**
     * Resuelve NgControl post-construcción para evitar circular dependency.
     * Las subclases que implementen ngOnInit DEBEN llamar super.ngOnInit().
     */
    ngOnInit() {
        // Inyectamos NgControl aquí (no en el constructor) para romper el ciclo:
        // NG_VALUE_ACCESSOR → NgControl → NG_VALUE_ACCESSOR
        // En ngOnInit el token ya está resuelto.
        try {
            this.ngControl = this.injector.get(NgControl, null, { self: true, optional: true });
        }
        catch {
            this.ngControl = null;
        }
    }
    // ---- Contrato ControlValueAccessor ----
    writeValue(value) {
        this._value.set(value);
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this._disabled.set(isDisabled);
    }
    // ---- Helpers para subclases y directivas colaboradoras ----
    /**
     * Llamar desde el evento DOM del input (input, change) para notificar a Angular Forms.
     * `public` para que directivas colaboradoras (ej: InputDirective) puedan llamarlo.
     */
    setValue(value) {
        this._value.set(value);
        this._onChange(value);
    }
    /**
     * Llamar al blur para marcar el control como touched.
     * `public` para que directivas colaboradoras (ej: InputDirective) puedan llamarlo.
     */
    markAsTouched() {
        if (!this._touched()) {
            this._touched.set(true);
            this._onTouched();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgControlValueAccessorBase, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.21", type: PgControlValueAccessorBase, isStandalone: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgControlValueAccessorBase, decorators: [{
            type: Directive
        }] });

/**
 * Clase base abstracta para componentes de diálogo (Modal, Drawer, CommandPalette).
 *
 * Gestiona el ciclo de vida del `<dialog>` nativo con sincronización bidireccional.
 *
 * Uso:
 * 1. El componente concreto extiende `PgDialogBase`.
 * 2. El template debe tener un `<dialog #dialogRef>`.
 * 3. Heredar y re-declarar `dialogRef = viewChild.required<ElementRef<HTMLDialogElement>>('dialogRef')`.
 *
 * @internal No exportar en ningún public-api.ts
 */
class PgDialogBase {
    /**
     * Two-way binding para controlar la visibilidad del dialog.
     * Uso: `<pg-modal [(isOpen)]="show">`
     */
    isOpen = model(false);
    /** Se emite cuando el dialog se abre completamente. */
    opened = output();
    /** Se emite cuando el dialog se cierra (por cualquier razón). */
    closed = output();
    /**
     * Se emite cuando el usuario cierra el dialog activamente
     * (ESC o click fuera del panel), sin ser una acción del host.
     */
    dismissed = output();
    /**
     * Referencia al elemento `<dialog>` nativo.
     * Las subclases DEBEN re-declarar esta propiedad:
     * ```ts
     * override readonly dialogRef = viewChild.required<ElementRef<HTMLDialogElement>>('dialogRef');
     * ```
     */
    dialogRef = viewChild.required('dialogRef');
    /**
     * True mientras corre la animación de salida (entre `close()` y el `el.close()` real).
     * Las subclases la leen desde el template para aplicar la clase/estado de transición CSS.
     */
    isClosing = signal(false);
    /**
     * Duración (ms) de la animación de salida antes de soltar el `<dialog>` del top layer.
     * Cada subclase la overridea (`override readonly`) según su propia transición CSS (Modal, Drawer, etc.).
     */
    panelExitDurationMs = 200;
    /** Duración (ms) de la animación de entrada, para el binding `[style.animation-duration.ms]` del template. */
    panelEnterDurationMs = 200;
    /**
     * Flag para evitar loops: cuando el DOM actualiza el model (vía evento close/cancel),
     * el effect no debe volver a llamar close() en el elemento nativo.
     */
    syncing = false;
    closeTimeoutHandle = null;
    constructor() {
        // Sincronización model → DOM.
        effect(() => {
            const open = this.isOpen();
            const el = this.dialogRef()?.nativeElement;
            if (!el || this.syncing)
                return;
            if (open) {
                this.cancelPendingClose();
                if (!el.open) {
                    el.showModal();
                    this.opened.emit();
                }
            }
            else if (!open && el.open && this.closeTimeoutHandle === null) {
                this.isClosing.set(true);
                this.closeTimeoutHandle = setTimeout(() => {
                    this.closeTimeoutHandle = null;
                    this.syncing = true;
                    el.close(); // en un <dialog> real dispara 'close' de forma síncrona -> onNativeClose
                    this.syncing = false;
                    this.isClosing.set(false); // no depender del evento 'close' real (p.ej. en tests con close() mockeado)
                }, this.panelExitDurationMs);
            }
        });
    }
    ngAfterViewInit() {
        const el = this.dialogRef().nativeElement;
        // Sincronización DOM → model
        el.addEventListener('close', this.onNativeClose);
        el.addEventListener('cancel', this.onNativeCancel);
    }
    ngOnDestroy() {
        this.cancelPendingClose();
        const el = this.dialogRef()?.nativeElement;
        el?.removeEventListener('close', this.onNativeClose);
        el?.removeEventListener('cancel', this.onNativeCancel);
    }
    /**
     * Hook para que subclases condicionen el cierre por backdrop-click/ESC
     * (p.ej. `AlertModalComponent` respeta `allowOutsideClick`/`allowEscapeKey`).
     * Default: siempre permite el cierre — comportamiento actual sin cambios
     * para Modal/Drawer/CommandPalette.
     */
    canDismiss(source) {
        return true;
    }
    /** Click en el backdrop: cierra el dialog animando la salida y marca que fue el usuario. */
    onBackdropClick() {
        if (!this.canDismiss('backdrop'))
            return;
        this.dismissed.emit();
        this.close();
    }
    cancelPendingClose() {
        if (this.closeTimeoutHandle !== null) {
            clearTimeout(this.closeTimeoutHandle);
            this.closeTimeoutHandle = null;
        }
        this.isClosing.set(false);
    }
    // Handler: el <dialog> nativo se cerró (por close() programático, backdrop nativo, etc.)
    onNativeClose = () => {
        this.syncing = true;
        this.isOpen.set(false);
        this.cancelPendingClose(); // por si el <dialog> se cerró por una vía distinta al timer propio
        this.syncing = false;
        this.closed.emit();
    };
    // Handler: el usuario presionó ESC (cancel se emite ANTES de close).
    // Frenamos el cierre síncrono nativo para que entre por el mismo camino animado
    // que close() programático y el click en el backdrop.
    onNativeCancel = (event) => {
        event.preventDefault();
        if (!this.canDismiss('escape'))
            return;
        this.dismissed.emit();
        this.isOpen.set(false);
    };
    // ---- API imperativa ----
    /** Abre el dialog programáticamente. */
    open() {
        this.isOpen.set(true);
    }
    /** Cierra el dialog programáticamente. */
    close() {
        this.isOpen.set(false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgDialogBase, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "19.2.21", type: PgDialogBase, isStandalone: true, inputs: { isOpen: { classPropertyName: "isOpen", publicName: "isOpen", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { isOpen: "isOpenChange", opened: "opened", closed: "closed", dismissed: "dismissed" }, viewQueries: [{ propertyName: "dialogRef", first: true, predicate: ["dialogRef"], descendants: true, isSignal: true }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgDialogBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [] });

/**
 * Abstract base for components backed by the native Popover API
 * (e.g. dropdown menus, tooltips, generic popovers).
 *
 * Sister of PgDialogBase, but bound to:
 *   - element.showPopover() / hidePopover() / togglePopover()
 *   - native 'toggle' event (event.newState === 'open' | 'closed')
 *
 * Usage:
 *   1. Subclass extends PgPopoverBase.
 *   2. Template has an element with the `popover` attribute and ref #popoverRef.
 *   3. Subclass re-declares popoverRef = viewChild.required<ElementRef<HTMLElement>>('popoverRef').
 *
 * @internal Re-exported from @pagalo/ui/core for subclass use only.
 */
class PgPopoverBase {
    /** Two-way binding to control the visibility of the popover. */
    isOpen = model(false);
    /** Emitted when the popover opens. */
    opened = output();
    /** Emitted when the popover closes. */
    closed = output();
    /**
     * Reference to the native popover element.
     * Subclasses MUST re-declare this property:
     * ```ts
     * override readonly popoverRef = viewChild.required<ElementRef<HTMLElement>>('popoverRef');
     * ```
     */
    popoverRef = viewChild.required('popoverRef');
    /**
     * Anti-loop flag: DOM → model updates must NOT trigger model → DOM in the same tick.
     */
    syncing = false;
    constructor() {
        // model → DOM sync
        effect(() => {
            const open = this.isOpen();
            const el = this.popoverRef()?.nativeElement;
            if (!el || this.syncing)
                return;
            // matches(':popover-open') guards against calling show/hide when already in that state.
            // The Popover API throws InvalidStateError if showPopover() is called on an
            // already-open element (or hidePopover() on an already-closed element).
            const isCurrentlyOpen = el.matches?.(':popover-open') ?? false;
            if (open && !isCurrentlyOpen) {
                el.showPopover?.();
            }
            else if (!open && isCurrentlyOpen) {
                el.hidePopover?.();
            }
        });
    }
    ngAfterViewInit() {
        const el = this.popoverRef().nativeElement;
        el.addEventListener('toggle', this.onNativeToggle);
    }
    ngOnDestroy() {
        const el = this.popoverRef()?.nativeElement;
        el?.removeEventListener('toggle', this.onNativeToggle);
    }
    // DOM → model. Native ToggleEvent has newState: 'open' | 'closed'.
    onNativeToggle = (event) => {
        const nextOpen = event.newState === 'open';
        if (this.isOpen() === nextOpen)
            return; // already in sync, no-op
        this.syncing = true;
        this.isOpen.set(nextOpen);
        this.syncing = false;
        nextOpen ? this.opened.emit() : this.closed.emit();
    };
    // ---- Imperative API ----
    /** Opens the popover programmatically. No-op if already open. */
    open() {
        this.isOpen.set(true);
    }
    /** Closes the popover programmatically. No-op if already closed. */
    close() {
        this.isOpen.set(false);
    }
    /** Toggles the popover open/closed. */
    toggle() {
        this.isOpen.set(!this.isOpen());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgPopoverBase, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "19.2.21", type: PgPopoverBase, isStandalone: true, inputs: { isOpen: { classPropertyName: "isOpen", publicName: "isOpen", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { isOpen: "isOpenChange", opened: "opened", closed: "closed" }, viewQueries: [{ propertyName: "popoverRef", first: true, predicate: ["popoverRef"], descendants: true, isSignal: true }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgPopoverBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [] });

/**
 * Servicio interno para generación de IDs únicos, SSR-safe.
 *
 * Implementa un fallback de 3 paths:
 * 1. `crypto.randomUUID()` — Node 19+ y browsers modernos
 * 2. `crypto.getRandomValues()` — Node 18 y browsers más antiguos
 * 3. Counter monotónico + prefijo de instancia — entornos sin crypto API
 *
 * @internal No exportar en ningún public-api.ts
 */
class IdService {
    counter = 0;
    instancePrefix = this.computeInstancePrefix();
    /**
     * Genera un ID único con prefijo opcional.
     * @example generate('pg-input') → 'pg-input-3f2a1b4c'
     */
    generate(prefix = 'pg') {
        return `${prefix}-${this.uniqueSuffix()}`;
    }
    uniqueSuffix() {
        // Path 1: crypto.randomUUID disponible (Node 19+, browsers modernos)
        if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
            return crypto.randomUUID().slice(0, 8);
        }
        // Path 2: crypto.getRandomValues disponible (Node 18, browsers sin randomUUID)
        if (typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function') {
            const buf = new Uint8Array(4);
            crypto.getRandomValues(buf);
            return Array.from(buf, (b) => b.toString(16).padStart(2, '0')).join('');
        }
        // Path 3: fallback determinístico per-instance (entornos sin crypto API)
        this.counter++;
        return `${this.instancePrefix}-${this.counter}`;
    }
    computeInstancePrefix() {
        // Generado UNA vez por instancia. Solo se usa cuando no hay crypto API.
        return Math.random().toString(36).slice(2, 6);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: IdService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: IdService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: IdService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class PgLinkDirective {
    pgLink = input('');
    router = inject(Router, { optional: true });
    _href = computed(() => {
        const link = this.pgLink();
        if (!link || link === '')
            return null;
        return typeof link === 'string' ? link : null;
    });
    _onClick(event) {
        const link = this.pgLink();
        if (!link || link === '')
            return;
        if (this.router) {
            event.preventDefault();
            if (typeof link === 'string') {
                this.router.navigateByUrl(link);
            }
            else {
                this.router.navigate(link);
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgLinkDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "19.2.21", type: PgLinkDirective, isStandalone: true, selector: "[pgLink]", inputs: { pgLink: { classPropertyName: "pgLink", publicName: "pgLink", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "_onClick($event)" }, properties: { "attr.href": "_href()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgLinkDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pgLink]',
                    standalone: true,
                    host: {
                        '[attr.href]': '_href()',
                        '(click)': '_onClick($event)',
                    },
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { IdService, PgControlValueAccessorBase, PgDialogBase, PgLinkDirective, PgPopoverBase };
//# sourceMappingURL=pagalo-ui-_internals.mjs.map
