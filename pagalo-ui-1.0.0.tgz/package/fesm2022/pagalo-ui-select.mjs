import * as i0 from '@angular/core';
import { InjectionToken, inject, ElementRef, input, signal, computed, ChangeDetectionStrategy, Component, DestroyRef, output, viewChildren, viewChild, effect, Directive, forwardRef, NgModule } from '@angular/core';
import * as i1 from '@angular/cdk/overlay';
import { Overlay, OverlayModule } from '@angular/cdk/overlay';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { toSignal, toObservable, takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { debounce, timer, distinctUntilChanged, skip } from 'rxjs';
import { ActiveDescendantKeyManager } from '@angular/cdk/a11y';
import { IdService, PgControlValueAccessorBase } from '@pagalo/ui/core';

/**
 * Injection token to override the CDK scroll strategy used by `pg-select`
 * and `pg-select-multi` panels. Defaults to `reposition({ autoClose: true })`
 * so the panel follows its trigger on scroll/resize instead of closing or
 * freezing page scroll. Override by providing this token at the app/module
 * level; not part of the per-component public API surface.
 */
const PG_SELECT_SCROLL_STRATEGY = new InjectionToken('PG_SELECT_SCROLL_STRATEGY', {
    providedIn: 'root',
    factory: () => {
        const overlay = inject(Overlay);
        return () => overlay.scrollStrategies.reposition({ autoClose: true });
    },
});

/**
 * Internal option renderer used by `pg-select` and `pg-select-multi`.
 *
 * Implements CDK `Highlightable` (active/inactive styling driven by
 * `ActiveDescendantKeyManager`) and `ListKeyManagerOption` (label for
 * typeahead, disabled state). Not part of the public API — consumers only
 * ever pass `options` arrays, never author `pg-select-option` elements
 * directly (v1 has no custom option templates).
 *
 * NOTE: `disabled` is exposed as a getter (not a signal `input()`) because
 * `ListKeyManagerOption#disabled` is typed `boolean | undefined` and would
 * structurally conflict with an `InputSignal<boolean>` of the same name.
 *
 * @internal
 */
class PgSelectOptionComponent {
    idService = inject(IdService);
    elementRef = inject((ElementRef));
    id = this.idService.generate('pg-select-option');
    option = input.required();
    selected = input(false);
    primaryColor = input('');
    _active = signal(false);
    active = this._active.asReadonly();
    /** Implements `ListKeyManagerOption#disabled` via the wrapped option's flag. */
    get disabled() {
        return !!this.option().disabled;
    }
    /**
     * Tailwind utility classes for the option's layout + interaction state,
     * computed once (mirroring `InputDirective`'s `@HostBinding('class')`
     * string-getter pattern) instead of layering several boolean `[class.x]`
     * host bindings whose underlying utilities would fight for the same CSS
     * property (e.g. `text-white` vs `text-content`) with cascade order
     * decided by Tailwind's generated stylesheet, not binding order.
     */
    hostClasses = computed(() => {
        const base = 'flex items-center justify-between gap-2 px-3 py-2 mb-1 text-sm leading-5 select-none';
        if (this.disabled) {
            return `${base} cursor-not-allowed text-content-subtle pointer-events-none`;
        }
        if (this.active()) {
            return `${base} cursor-pointer bg-primary text-white${this.selected() ? ' font-semibold' : ''}`;
        }
        if (this.selected()) {
            return `${base} cursor-pointer text-content font-semibold bg-primary/10`;
        }
        return `${base} cursor-pointer text-content hover:bg-surface-muted`;
    });
    /**
     * Inline `background-color` override for `primaryColor`, mirroring
     * `hostClasses()`'s exact active/selected precedence. `null` when the
     * consumer hasn't set `primaryColor` (or the option is disabled), leaving
     * the Tailwind classes from `hostClasses()` untouched.
     */
    hostBackgroundColor = computed(() => {
        const c = this.primaryColor();
        if (!c || this.disabled)
            return null;
        if (this.active())
            return c;
        if (this.selected())
            return `color-mix(in srgb, ${c} 10%, transparent)`;
        return null;
    });
    // ---- Highlightable ----
    setActiveStyles() {
        this._active.set(true);
    }
    setInactiveStyles() {
        this._active.set(false);
    }
    // ---- ListKeyManagerOption ----
    getLabel() {
        return this.option().label;
    }
    scrollIntoViewIfNeeded() {
        this.elementRef.nativeElement.scrollIntoView({ block: 'nearest' });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgSelectOptionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: PgSelectOptionComponent, isStandalone: true, selector: "pg-select-option", inputs: { option: { classPropertyName: "option", publicName: "option", isSignal: true, isRequired: true, transformFunction: null }, selected: { classPropertyName: "selected", publicName: "selected", isSignal: true, isRequired: false, transformFunction: null }, primaryColor: { classPropertyName: "primaryColor", publicName: "primaryColor", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "option" }, properties: { "id": "id", "attr.aria-selected": "selected()", "attr.aria-disabled": "disabled || null", "class.pg-select-option--active": "active()", "class.pg-select-option--disabled": "disabled", "class.pg-select-option--selected": "selected()", "class": "hostClasses()", "style.background-color": "hostBackgroundColor()" } }, ngImport: i0, template: "<span class=\"pg-select-option__label\">{{ option().label }}</span>\n\n@if (selected()) {\n  <svg\n    class=\"pg-select-option__check size-5 shrink-0\"\n    [class.text-primary]=\"!active()\"\n    [style.color]=\"!active() ? (primaryColor() || null) : null\"\n    viewBox=\"0 0 20 20\"\n    fill=\"currentColor\"\n    aria-hidden=\"true\"\n  >\n    <path\n      fill-rule=\"evenodd\"\n      d=\"M16.704 4.153a.75.75 0 01.143 1.052l-8 10.5a.75.75 0 01-1.127.075l-4.5-4.5a.75.75 0 011.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 011.05-.143z\"\n      clip-rule=\"evenodd\"\n    />\n  </svg>\n}\n", styles: [""], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgSelectOptionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-select-option', changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        role: 'option',
                        '[id]': 'id',
                        '[attr.aria-selected]': 'selected()',
                        '[attr.aria-disabled]': 'disabled || null',
                        '[class.pg-select-option--active]': 'active()',
                        '[class.pg-select-option--disabled]': 'disabled',
                        '[class.pg-select-option--selected]': 'selected()',
                        '[class]': 'hostClasses()',
                        '[style.background-color]': 'hostBackgroundColor()',
                    }, template: "<span class=\"pg-select-option__label\">{{ option().label }}</span>\n\n@if (selected()) {\n  <svg\n    class=\"pg-select-option__check size-5 shrink-0\"\n    [class.text-primary]=\"!active()\"\n    [style.color]=\"!active() ? (primaryColor() || null) : null\"\n    viewBox=\"0 0 20 20\"\n    fill=\"currentColor\"\n    aria-hidden=\"true\"\n  >\n    <path\n      fill-rule=\"evenodd\"\n      d=\"M16.704 4.153a.75.75 0 01.143 1.052l-8 10.5a.75.75 0 01-1.127.075l-4.5-4.5a.75.75 0 011.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 011.05-.143z\"\n      clip-rule=\"evenodd\"\n    />\n  </svg>\n}\n" }]
        }] });

function isGroupArray(options) {
    return options.length > 0 && 'options' in options[0];
}
/**
 * Shared behavior for all `pg-select*` variants: overlay open/close state,
 * option/group normalization, local + async filtering, `ActiveDescendantKeyManager`
 * wiring, and CVA plumbing (inherited from `PgControlValueAccessorBase`).
 *
 * Concrete components (`pg-select`, `pg-select-multi`) provide the value-shape
 * specific behavior via the abstract members below.
 */
class PgSelectBase extends PgControlValueAccessorBase {
    idService = inject(IdService);
    destroyRef = inject(DestroyRef);
    // Non-optional: the token is `providedIn: 'root'` with a factory default, so it always resolves.
    _scrollStrategyFactory = inject(PG_SELECT_SCROLL_STRATEGY);
    _autoId = this.idService.generate('pg-select');
    listboxId = this.idService.generate('pg-select-listbox');
    /** Primary bottom-start with a top-start flip fallback, plus horizontal shift variants. */
    overlayPositions = [
        { originX: 'start', originY: 'bottom', overlayX: 'start', overlayY: 'top', offsetY: 4 },
        { originX: 'start', originY: 'top', overlayX: 'start', overlayY: 'bottom', offsetY: -4 },
        { originX: 'end', originY: 'bottom', overlayX: 'end', overlayY: 'top', offsetY: 4 },
        { originX: 'end', originY: 'top', overlayX: 'end', overlayY: 'bottom', offsetY: -4 },
    ];
    scrollStrategy = this._scrollStrategyFactory();
    // ---- Shared inputs ----
    options = input([]);
    debounceMs = input(250);
    compareWith = input((a, b) => Object.is(a, b));
    placeholder = input('');
    readonly = input(false);
    clearable = input(true);
    error = input(undefined);
    /**
     * 100% consumer-controlled loading indicator — the library never sets this
     * internally. Bind it around your own fetch (e.g. driven by `(searchChange)`)
     * to surface the `'loading'` panel state. Mirrors ng-select's own `loading`
     * input, whose CHANGELOG explicitly warns against the library trying to
     * infer loading state automatically.
     */
    loading = input(false);
    /**
     * When `true`, disables the built-in local substring filter in
     * `filteredOptions()` — set this when `[options]` already reflects a
     * server-side filtered result (e.g. from a `(searchChange)`-driven fetch)
     * so the library doesn't re-filter already-filtered data. Equivalent to
     * ng-select's `!typeahead().observed` gate, adapted to an explicit boolean
     * since Angular's signal `output()` has no "is anyone listening" introspection.
     */
    remoteFiltered = input(false);
    emptyText = input('No options available');
    loadingText = input('Loading…');
    noResultsText = input('No results found');
    forId = input('');
    customClass = input('');
    primaryColor = input('');
    // ---- Shared outputs ----
    opened = output();
    closed = output();
    cleared = output();
    searchChange = output();
    scrolledToEnd = output();
    hasError = computed(() => {
        const override = this.error();
        if (override !== undefined)
            return override;
        const ctrl = this.ngControl?.control;
        if (!ctrl)
            return false;
        return ctrl.invalid && (ctrl.touched || ctrl.dirty);
    });
    computedForId = computed(() => this.forId() || this._autoId);
    /**
     * Trigger visual-state classes (background/outline/text color), computed
     * once instead of layering conflicting boolean `[class.x]` bindings for
     * the same CSS property — mirrors `InputDirective`'s class-string getter
     * pattern (`forms/input.directives.ts`). Includes both `focus:` and
     * `focus-within:` outline-color variants so the same string works whether
     * the trigger element itself receives focus (classic `<button>`) or wraps
     * a focusable child (search/multi `<input>` inside a `<div>`).
     */
    triggerStateClasses = computed(() => {
        const extra = this.customClass();
        const suffix = extra ? ` ${extra}` : '';
        if (this.disabled()) {
            return `cursor-not-allowed bg-surface-muted text-content-muted outline-outline${suffix}`;
        }
        if (this.readonly()) {
            // Trailing space before ${suffix} is load-bearing: Tailwind's content
            // scanner fails to recognize an arbitrary-value class (ending in `]`)
            // as a candidate when it's glued directly to the template literal's
            // interpolation with no whitespace — the focus-within variant silently
            // never got its CSS emitted without it, so the wrapper fell back to
            // showing the plain gray outline instead of the primary-colored one.
            return `cursor-default bg-surface-muted text-content outline-outline focus:outline-[var(--pg-select-primary,theme(colors.primary.DEFAULT))] focus-within:outline-[var(--pg-select-primary,theme(colors.primary.DEFAULT))] ${suffix}`;
        }
        if (this.hasError()) {
            return `cursor-pointer bg-surface text-content-danger outline-red-300 focus:outline-error focus-within:outline-error${suffix}`;
        }
        return `cursor-pointer bg-surface text-content outline-outline focus:outline-[var(--pg-select-primary,theme(colors.primary.DEFAULT))] focus-within:outline-[var(--pg-select-primary,theme(colors.primary.DEFAULT))] ${suffix}`;
    });
    // ---- Panel / query state ----
    isOpen = signal(false);
    /**
     * True while the panel plays its exit animation, before `isOpen` actually
     * flips to `false` and the CDK overlay detaches. Mirrors `AlertService`'s
     * `isLeaving` flag + fixed-duration `setTimeout` removal (`alert.service.ts`).
     */
    isClosing = signal(false);
    /** Enter/exit animation durations (ms), matching `pg-alert-modal`'s enter (150ms) / leave (200ms) defaults. */
    panelEnterDurationMs = 150;
    panelExitDurationMs = 200;
    _closeTimeoutHandle = null;
    _scrollEndThresholdPx = 48;
    _scrollEndFired = signal(false);
    /**
     * Scroll position captured at the exact moment `scrolledToEnd` fires.
     * CDK's `reposition` scroll strategy (see `select.tokens.ts`) reacts to
     * ANY scroll event in the document — including our own panel's internal
     * scroll — and re-runs the connected-overlay position/size calculation
     * (`flexibleDimensions` + `growAfterOpen`), which resets the panel's
     * `scrollTop` to 0 as a side effect once new options land. This anchor
     * lets the options-growth effect below restore the exact pre-append
     * position so appending a page never visually snaps the user back to the
     * top — mirrors ng-select's continuous (no-CDK, no-reposition) scroll
     * behavior without having to drop CDK entirely.
     */
    _scrollRestoreAnchor = null;
    query = signal('');
    /**
     * Tracks a query set by the browser's native autofill rather than the
     * user typing — Chrome fires the trigger input's `input` event with
     * `inputType: 'insertReplacementText'` when it fills a field this way,
     * distinct from `insertText` for manual keystrokes. Held until a matching
     * option shows up in `flatFilteredOptions()` (synchronously for a local
     * list, or once an async remote search resolves for a `remoteFiltered`
     * one), at which point it's auto-selected exactly as if the user had
     * clicked it — otherwise picking a browser autofill suggestion just fills
     * text without ever registering as a real selection. Cleared by any
     * subsequent manual keystroke or by closing the panel.
     */
    _pendingAutofillQuery = signal(null);
    _debouncedQuery = toSignal(toObservable(this.query).pipe(debounce(() => timer(this.debounceMs())), distinctUntilChanged()), { initialValue: '' });
    /**
     * `[options]` is the single source of truth, always — static list or
     * server-driven, it doesn't matter. A consumer reassigns it themselves via
     * `(searchChange)` for a fresh search, or appends to it via
     * `(scrolledToEnd)` for pagination — both just funnel into this same
     * array, exactly like ng-select's `[items]`.
     */
    resolvedOptions = computed(() => this.options());
    isGrouped = computed(() => isGroupArray(this.resolvedOptions()));
    flatOptions = computed(() => {
        const opts = this.resolvedOptions();
        if (isGroupArray(opts)) {
            return opts.flatMap((g) => g.options);
        }
        return opts;
    });
    /**
     * Options filtered by the current query. When `remoteFiltered` is set the
     * consumer's `[options]` already reflects the query (e.g. a server-driven
     * search) — no additional local filtering is applied. Otherwise filters
     * locally by case-insensitive label match, preserving group structure and
     * dropping groups left empty by the filter.
     */
    filteredOptions = computed(() => {
        const opts = this.resolvedOptions();
        if (this.remoteFiltered())
            return opts;
        const q = this.query().trim().toLowerCase();
        if (!q)
            return opts;
        if (isGroupArray(opts)) {
            return opts
                .map((group) => ({
                ...group,
                options: group.options.filter((o) => o.label.toLowerCase().includes(q)),
            }))
                .filter((group) => group.options.length > 0);
        }
        return opts.filter((o) => o.label.toLowerCase().includes(q));
    });
    flatFilteredOptions = computed(() => {
        const opts = this.filteredOptions();
        if (isGroupArray(opts)) {
            return opts.flatMap((g) => g.options);
        }
        return opts;
    });
    hasResults = computed(() => this.flatFilteredOptions().length > 0);
    /** `filteredOptions()` narrowed to groups; empty array when the source is flat. */
    filteredGroups = computed(() => {
        const opts = this.filteredOptions();
        return isGroupArray(opts) ? opts : [];
    });
    /** `filteredOptions()` narrowed to a flat list; empty array when the source is grouped. */
    filteredFlat = computed(() => {
        const opts = this.filteredOptions();
        return isGroupArray(opts) ? [] : opts;
    });
    /** Deterministic id for a group header, referenced by the group's `aria-labelledby`. */
    groupHeaderId(index) {
        return `${this.listboxId}-group-${index}`;
    }
    panelState = computed(() => {
        // Only the "nothing to show yet" case collapses the whole panel into the
        // loading message — once options are already rendered (a scroll-appended
        // page loading its next batch), the existing list stays up via
        // `isLoadingMore()` instead of being torn down and rebuilt. Rebuilding it
        // collapses `scrollHeight`, which forces the browser to clamp `scrollTop`
        // and reads as the panel snapping back to the top on every batch.
        if (this.loading() && this.flatOptions().length === 0)
            return 'loading';
        if (this.flatOptions().length === 0 && !this.query().trim()) {
            return 'empty';
        }
        if (this.query().trim() && !this.hasResults())
            return 'no-results';
        return 'ready';
    });
    /** True while a `(scrolledToEnd)`-triggered fetch is loading the next page on top of an already-rendered list. */
    isLoadingMore = computed(() => this.loading() && this.flatOptions().length > 0);
    // ---- Key manager ----
    optionItems = viewChildren(PgSelectOptionComponent);
    keyManager = null;
    /**
     * Reference to the scrollable panel `<ul>`. Resolves the same way
     * `optionItems` does: the element lives inside the `cdkConnectedOverlay`
     * `<ng-template>` in each variant's template, and Angular view queries see
     * into that embedded view once it renders.
     */
    panelEl = viewChild('scrollPanel');
    activeOptionId = signal(null);
    constructor() {
        super();
        // Rebuild the key manager whenever the rendered option items change so the
        // active index never points at a stale/removed item.
        effect(() => {
            const items = this.optionItems();
            this.keyManager?.destroy();
            this.keyManager = new ActiveDescendantKeyManager(items)
                .withWrap()
                .withTypeAhead()
                .withHomeAndEnd()
                .skipPredicate((o) => o.disabled);
            this.keyManager.change.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => {
                this.activeOptionId.set(this.keyManager?.activeItem?.id ?? null);
            });
        });
        // Emit the debounced query (skip the initial empty value). This is now
        // the sole mechanism for server-driven search notifications — the
        // consumer's own subscription fetches and reassigns `[options]`.
        toObservable(this._debouncedQuery)
            .pipe(skip(1))
            .subscribe((q) => this.searchChange.emit(q));
        // Re-arm the "reached bottom" guard whenever the panel (re)opens or the
        // resolved query settles, and reset stale scroll position so a shorter
        // result set can't immediately read as "at bottom". Also drop any
        // pending scroll-restore anchor — a fresh search/reopen must always
        // land at the top, never at a position captured by a previous scroll.
        effect(() => {
            this.isOpen();
            this._debouncedQuery();
            this._scrollEndFired.set(false);
            this._scrollRestoreAnchor = null;
            const el = this.panelEl()?.nativeElement;
            if (el)
                el.scrollTop = 0;
        });
        // Also re-arm (without resetting scroll position) whenever the rendered
        // options list grows or shrinks — e.g. a scroll-appended page landing —
        // so a later scroll tick can fire scrolledToEnd again. Mirrors ng-select's
        // `_onItemsOrShowAddTagChange`, which resets its own one-shot scrollToEnd
        // guard on every items-list change, not just on search. Additionally
        // restores the pre-append scroll position if one was captured: CDK's
        // reposition scroll strategy resets `scrollTop` to 0 as a side effect of
        // recalculating the overlay's size when content grows, which would
        // otherwise visibly snap the list back to the top on every loaded batch.
        //
        // Also tracks `isLoadingMore()`, not just the final options length: the
        // "loading more" row itself changes the panel's content height (and can
        // trigger the same CDK reposition reset), so the anchor must keep getting
        // re-applied across that whole in-flight window — not just once when the
        // new page finally lands. The anchor itself is only cleared once loading
        // has actually finished, so an early reposition reset never permanently
        // consumes it before the real batch arrives.
        effect(() => {
            this.flatOptions().length;
            this.isLoadingMore();
            this._scrollEndFired.set(false);
            if (this._scrollRestoreAnchor !== null) {
                const el = this.panelEl()?.nativeElement;
                if (el)
                    el.scrollTop = this._scrollRestoreAnchor;
                if (!this.loading())
                    this._scrollRestoreAnchor = null;
            }
        });
        // Resolves a pending autofill match: fires whenever the flagged query or
        // the currently visible options change, covering both the local-list
        // case (options already there, matches on the same tick) and the
        // remoteFiltered case (options arrive later once the consumer's search
        // resolves and reassigns `[options]`).
        effect(() => {
            const pending = this._pendingAutofillQuery();
            if (pending === null)
                return;
            const normalized = pending.trim().toLowerCase();
            const match = this.flatFilteredOptions().find((o) => o.label.trim().toLowerCase() === normalized);
            if (match) {
                this._pendingAutofillQuery.set(null);
                this.activateOption(match);
            }
        });
        this.destroyRef.onDestroy(() => {
            if (this._closeTimeoutHandle !== null)
                clearTimeout(this._closeTimeoutHandle);
        });
    }
    ngOnInit() {
        super.ngOnInit();
    }
    // ---- Open / close ----
    open() {
        if (this.disabled() || this.readonly())
            return;
        if (this.isOpen())
            return;
        this.isOpen.set(true);
        this.opened.emit();
    }
    /**
     * Starts the closing sequence: flips `isClosing` (which swaps the panel's
     * animation class to the exit animation via the template) and defers the
     * actual `isOpen.set(false)` — which detaches the CDK overlay — until the
     * exit animation's duration has elapsed. Mirrors `AlertService.close()`'s
     * `isLeaving` flag + fixed-duration `setTimeout` removal.
     */
    close() {
        if (!this.isOpen() || this.isClosing())
            return;
        this.isClosing.set(true);
        this._pendingAutofillQuery.set(null);
        this.keyManager?.setActiveItem(-1);
        this._closeTimeoutHandle = setTimeout(() => {
            this.isOpen.set(false);
            this.isClosing.set(false);
            this._closeTimeoutHandle = null;
            this.closed.emit();
        }, this.panelExitDurationMs);
    }
    toggle() {
        if (this.isOpen())
            this.close();
        else
            this.open();
    }
    setQuery(value) {
        this.query.set(value);
    }
    /**
     * Bound to the trigger's editable `<input>` in the `search` variant of
     * both `pg-select` and `pg-select-multi`. Browser autofill fires this same
     * `input` event as manual typing — see `_pendingAutofillQuery` for why
     * that case is flagged and handled separately.
     */
    onSearchInput(event) {
        const value = event.target.value;
        this.setQuery(value);
        if (!this.isOpen())
            this.open();
        const isAutofill = event.inputType === 'insertReplacementText';
        this._pendingAutofillQuery.set(isAutofill && value.trim() ? value : null);
    }
    /**
     * Bound to the options panel's `(scroll)` event in each variant's template.
     * Emits `scrolledToEnd` once per "reached bottom" transition (re-arms when
     * the user scrolls back up, or when growing content pushes the bottom edge
     * out of range on a later scroll tick) — never on a fetch/state basis,
     * since the library has no visibility into the consumer's async source.
     */
    onPanelScroll(event) {
        const el = event.target;
        const distanceToBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
        const nearBottom = distanceToBottom <= this._scrollEndThresholdPx;
        if (nearBottom && !this._scrollEndFired()) {
            this._scrollEndFired.set(true);
            this._scrollRestoreAnchor = el.scrollTop;
            this.scrolledToEnd.emit();
        }
        else if (!nearBottom && this._scrollEndFired()) {
            this._scrollEndFired.set(false);
        }
    }
    clear() {
        if (this.disabled() || this.readonly())
            return;
        this.setValue(null);
        this.cleared.emit();
    }
    /** Selects (or toggles, for multi) an option and closes the panel when `closeOnSelect` is true. */
    activateOption(option) {
        if (option.disabled || this.disabled() || this.readonly())
            return;
        this.selectOption(option);
        this.markAsTouched();
        if (this.closeOnSelect)
            this.close();
    }
    // ---- Keyboard handling ----
    handleKeydown(event) {
        if (this.disabled())
            return;
        const key = event.key;
        if (!this.isOpen()) {
            if (key === 'ArrowDown' && event.altKey) {
                event.preventDefault();
                this.open();
                return;
            }
            if (key === 'ArrowDown' || key === 'ArrowUp' || key === 'Enter') {
                event.preventDefault();
                this.open();
                return;
            }
            return;
        }
        switch (key) {
            case 'ArrowDown':
            case 'ArrowUp':
            case 'Home':
            case 'End':
                event.preventDefault();
                this.keyManager?.onKeydown(event);
                break;
            case 'Enter': {
                event.preventDefault();
                const active = this.keyManager?.activeItem;
                if (active) {
                    this.activateOption(active.option());
                }
                break;
            }
            case 'Escape':
                event.preventDefault();
                this.close();
                break;
            case 'Tab':
                this.close();
                break;
            default:
                break;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgSelectBase, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "19.2.21", type: PgSelectBase, isStandalone: true, inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, debounceMs: { classPropertyName: "debounceMs", publicName: "debounceMs", isSignal: true, isRequired: false, transformFunction: null }, compareWith: { classPropertyName: "compareWith", publicName: "compareWith", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, clearable: { classPropertyName: "clearable", publicName: "clearable", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, remoteFiltered: { classPropertyName: "remoteFiltered", publicName: "remoteFiltered", isSignal: true, isRequired: false, transformFunction: null }, emptyText: { classPropertyName: "emptyText", publicName: "emptyText", isSignal: true, isRequired: false, transformFunction: null }, loadingText: { classPropertyName: "loadingText", publicName: "loadingText", isSignal: true, isRequired: false, transformFunction: null }, noResultsText: { classPropertyName: "noResultsText", publicName: "noResultsText", isSignal: true, isRequired: false, transformFunction: null }, forId: { classPropertyName: "forId", publicName: "forId", isSignal: true, isRequired: false, transformFunction: null }, customClass: { classPropertyName: "customClass", publicName: "customClass", isSignal: true, isRequired: false, transformFunction: null }, primaryColor: { classPropertyName: "primaryColor", publicName: "primaryColor", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { opened: "opened", closed: "closed", cleared: "cleared", searchChange: "searchChange", scrolledToEnd: "scrolledToEnd" }, viewQueries: [{ propertyName: "optionItems", predicate: PgSelectOptionComponent, descendants: true, isSignal: true }, { propertyName: "panelEl", first: true, predicate: ["scrollPanel"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgSelectBase, decorators: [{
            type: Directive
        }], ctorParameters: () => [] });

/**
 * `pg-select` — single-value select. `variant="classic"` renders a
 * button-style trigger with no editable text (type-ahead by character);
 * `variant="search"` renders an editable text input that filters options
 * live (`aria-autocomplete="list"`).
 */
class SelectComponent extends PgSelectBase {
    multiple = false;
    closeOnSelect = true;
    variant = input('classic');
    displayValue = computed(() => {
        const val = this.value();
        if (val === null || val === undefined)
            return '';
        const match = this.flatOptions().find((o) => this.compareWith()(o.value, val));
        return match?.label ?? '';
    });
    isSelected(option) {
        const val = this.value();
        if (val === null || val === undefined)
            return false;
        return this.compareWith()(option.value, val);
    }
    selectOption(option) {
        this.setValue(option.value);
    }
    onOptionClick(option) {
        this.activateOption(option);
    }
    onClearClick(event) {
        event.stopPropagation();
        this.clear();
    }
    onTriggerClick() {
        if (this.readonly())
            return;
        this.toggle();
    }
    /**
     * Type-ahead for the classic (non-editable) variant: jumps to and selects
     * the first non-disabled option whose label starts with the typed
     * character, mirroring native `<select>` behavior. Runs whether the panel
     * is open or closed because the CDK key manager's own typeahead only
     * covers items rendered inside the (lazily-stamped) overlay template.
     */
    onTriggerKeydown(event) {
        if (this.variant() !== 'classic') {
            this.handleKeydown(event);
            return;
        }
        if (!this.isOpen() &&
            event.key.length === 1 &&
            !event.altKey &&
            !event.ctrlKey &&
            !event.metaKey) {
            const char = event.key.toLowerCase();
            const match = this.flatOptions().find((o) => !o.disabled && o.label.toLowerCase().startsWith(char));
            if (match) {
                event.preventDefault();
                this.activateOption(match);
                return;
            }
        }
        this.handleKeydown(event);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: SelectComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: SelectComponent, isStandalone: true, selector: "pg-select", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SelectComponent),
                multi: true,
            },
        ], usesInheritance: true, ngImport: i0, template: "<div class=\"pg-select relative\" cdkOverlayOrigin #origin=\"cdkOverlayOrigin\">\n  @if (variant() === 'classic') {\n    <button\n      type=\"button\"\n      [id]=\"computedForId()\"\n      role=\"combobox\"\n      aria-haspopup=\"listbox\"\n      [attr.aria-expanded]=\"isOpen()\"\n      [attr.aria-controls]=\"listboxId\"\n      [attr.aria-activedescendant]=\"activeOptionId()\"\n      [attr.aria-disabled]=\"disabled() || null\"\n      [disabled]=\"disabled()\"\n      class=\"pg-select-trigger flex items-center justify-between gap-2 w-full rounded-md px-3 py-2 text-left text-sm leading-6 outline outline-1 -outline-offset-1 focus:outline focus:outline-2 focus:-outline-offset-2\"\n      [class]=\"triggerStateClasses()\"\n      [style.--pg-select-primary]=\"primaryColor() || null\"\n      (click)=\"onTriggerClick()\"\n      (keydown)=\"onTriggerKeydown($event)\"\n      (blur)=\"markAsTouched()\"\n    >\n      <span class=\"pg-select-trigger__value truncate\" [class.text-content-subtle]=\"!displayValue()\">\n        {{ displayValue() || placeholder() }}\n      </span>\n      <span class=\"pg-select-trigger__controls flex items-center gap-1 shrink-0\">\n        @if (clearable() && value() !== null && value() !== undefined && !disabled() && !readonly()) {\n          <span\n            role=\"button\"\n            tabindex=\"-1\"\n            class=\"pg-select-clear inline-flex items-center justify-center size-5 rounded-full text-content-muted hover:text-content cursor-pointer\"\n            aria-label=\"Clear selection\"\n            (click)=\"onClearClick($event)\"\n          >\n            &times;\n          </span>\n        }\n        <svg class=\"pg-select-chevron size-5 text-content-muted\" viewBox=\"0 0 20 20\" fill=\"currentColor\" aria-hidden=\"true\">\n          <path\n            fill-rule=\"evenodd\"\n            d=\"M5.22 8.22a.75.75 0 011.06 0L10 11.94l3.72-3.72a.75.75 0 111.06 1.06l-4.25 4.25a.75.75 0 01-1.06 0L5.22 9.28a.75.75 0 010-1.06z\"\n            clip-rule=\"evenodd\"\n          />\n        </svg>\n      </span>\n    </button>\n  } @else {\n    <div\n      class=\"pg-select-trigger pg-select-trigger--search flex items-center justify-between gap-2 w-full rounded-md outline outline-1 -outline-offset-1 focus-within:outline focus-within:outline-2 focus-within:-outline-offset-2\"\n      [class]=\"triggerStateClasses()\"\n      [style.--pg-select-primary]=\"primaryColor() || null\"\n    >\n      <input\n        type=\"text\"\n        [id]=\"computedForId()\"\n        role=\"combobox\"\n        aria-haspopup=\"listbox\"\n        aria-autocomplete=\"list\"\n        [attr.aria-expanded]=\"isOpen()\"\n        [attr.aria-controls]=\"listboxId\"\n        [attr.aria-activedescendant]=\"activeOptionId()\"\n        [attr.aria-disabled]=\"disabled() || null\"\n        [disabled]=\"disabled()\"\n        [readOnly]=\"readonly()\"\n        [placeholder]=\"placeholder()\"\n        class=\"pg-select-trigger__input w-full border-0 outline-none focus:shadow-none focus:ring-0 bg-transparent px-3 py-2 text-sm leading-6 text-content placeholder:text-content-subtle\"\n        [value]=\"isOpen() ? query() : displayValue()\"\n        (input)=\"onSearchInput($event)\"\n        (focus)=\"open()\"\n        (keydown)=\"handleKeydown($event)\"\n        (blur)=\"markAsTouched()\"\n      />\n      @if (clearable() && value() !== null && value() !== undefined && !disabled() && !readonly()) {\n        <span\n          role=\"button\"\n          tabindex=\"-1\"\n          class=\"pg-select-clear inline-flex items-center justify-center size-5 rounded-full text-content-muted hover:text-content cursor-pointer mr-2\"\n          aria-label=\"Clear selection\"\n          (click)=\"onClearClick($event)\"\n        >\n          &times;\n        </span>\n      }\n    </div>\n  }\n\n  <ng-template\n    cdkConnectedOverlay\n    [cdkConnectedOverlayOrigin]=\"origin\"\n    [cdkConnectedOverlayOpen]=\"isOpen()\"\n    [cdkConnectedOverlayPositions]=\"overlayPositions\"\n    [cdkConnectedOverlayWidth]=\"origin.elementRef.nativeElement.offsetWidth\"\n    [cdkConnectedOverlayFlexibleDimensions]=\"true\"\n    [cdkConnectedOverlayPush]=\"true\"\n    [cdkConnectedOverlayGrowAfterOpen]=\"true\"\n    [cdkConnectedOverlayScrollStrategy]=\"scrollStrategy\"\n    [cdkConnectedOverlayHasBackdrop]=\"true\"\n    cdkConnectedOverlayBackdropClass=\"cdk-overlay-transparent-backdrop\"\n    (backdropClick)=\"close()\"\n    (detach)=\"close()\"\n  >\n    <ul\n      #scrollPanel\n      [id]=\"listboxId\"\n      role=\"listbox\"\n      class=\"pg-select-panel max-h-60 overflow-y-auto rounded-md bg-surface-raised py-1 shadow-lg ring-1 ring-outline-contrast/5 list-none m-0\"\n      [class.animate-fade-in]=\"!isClosing()\"\n      [class.animate-fade-out]=\"isClosing()\"\n      [style.animation-duration.ms]=\"isClosing() ? panelExitDurationMs : panelEnterDurationMs\"\n      [style.min-width.px]=\"origin.elementRef.nativeElement.offsetWidth\"\n      (scroll)=\"onPanelScroll($event)\"\n    >\n      @switch (panelState()) {\n        @case ('loading') {\n          <li class=\"pg-select-panel__message px-3 py-2 text-sm text-content-muted\">{{ loadingText() }}</li>\n        }\n        @case ('empty') {\n          <li class=\"pg-select-panel__message px-3 py-2 text-sm text-content-muted\">{{ emptyText() }}</li>\n        }\n        @case ('no-results') {\n          <li class=\"pg-select-panel__message px-3 py-2 text-sm text-content-muted\">{{ noResultsText() }}</li>\n        }\n        @default {\n          @if (isGrouped()) {\n            @for (group of filteredGroups(); track group.label; let gi = $index) {\n              <li role=\"group\" [attr.aria-labelledby]=\"groupHeaderId(gi)\" class=\"pg-select-group\">\n                <div\n                  [id]=\"groupHeaderId(gi)\"\n                  class=\"pg-select-group__label px-3 pt-1.5 pb-0.5 text-xs font-semibold text-content-muted\"\n                >\n                  {{ group.label }}\n                </div>\n                @for (opt of group.options; track opt.value) {\n                  <pg-select-option\n                    [option]=\"opt\"\n                    [selected]=\"isSelected(opt)\"\n                    [primaryColor]=\"primaryColor()\"\n                    (click)=\"onOptionClick(opt)\"\n                  ></pg-select-option>\n                }\n              </li>\n            }\n          } @else {\n            @for (opt of filteredFlat(); track opt.value) {\n              <pg-select-option\n                [option]=\"opt\"\n                [selected]=\"isSelected(opt)\"\n                [primaryColor]=\"primaryColor()\"\n                (click)=\"onOptionClick(opt)\"\n              ></pg-select-option>\n            }\n          }\n          @if (isLoadingMore()) {\n            <li class=\"pg-select-panel__message px-3 py-2 text-sm text-content-muted\" aria-live=\"polite\">\n              {{ loadingText() }}\n            </li>\n          }\n        }\n      }\n    </ul>\n  </ng-template>\n</div>\n", styles: [":host{display:block;width:100%}\n"], dependencies: [{ kind: "ngmodule", type: OverlayModule }, { kind: "directive", type: i1.CdkConnectedOverlay, selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]", inputs: ["cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayPositionStrategy", "cdkConnectedOverlayOffsetX", "cdkConnectedOverlayOffsetY", "cdkConnectedOverlayWidth", "cdkConnectedOverlayHeight", "cdkConnectedOverlayMinWidth", "cdkConnectedOverlayMinHeight", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayPanelClass", "cdkConnectedOverlayViewportMargin", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOpen", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayTransformOriginOn", "cdkConnectedOverlayHasBackdrop", "cdkConnectedOverlayLockPosition", "cdkConnectedOverlayFlexibleDimensions", "cdkConnectedOverlayGrowAfterOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayDisposeOnNavigation"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cdkConnectedOverlay"] }, { kind: "directive", type: i1.CdkOverlayOrigin, selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]", exportAs: ["cdkOverlayOrigin"] }, { kind: "component", type: PgSelectOptionComponent, selector: "pg-select-option", inputs: ["option", "selected", "primaryColor"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: SelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-select', imports: [OverlayModule, PgSelectOptionComponent], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SelectComponent),
                            multi: true,
                        },
                    ], template: "<div class=\"pg-select relative\" cdkOverlayOrigin #origin=\"cdkOverlayOrigin\">\n  @if (variant() === 'classic') {\n    <button\n      type=\"button\"\n      [id]=\"computedForId()\"\n      role=\"combobox\"\n      aria-haspopup=\"listbox\"\n      [attr.aria-expanded]=\"isOpen()\"\n      [attr.aria-controls]=\"listboxId\"\n      [attr.aria-activedescendant]=\"activeOptionId()\"\n      [attr.aria-disabled]=\"disabled() || null\"\n      [disabled]=\"disabled()\"\n      class=\"pg-select-trigger flex items-center justify-between gap-2 w-full rounded-md px-3 py-2 text-left text-sm leading-6 outline outline-1 -outline-offset-1 focus:outline focus:outline-2 focus:-outline-offset-2\"\n      [class]=\"triggerStateClasses()\"\n      [style.--pg-select-primary]=\"primaryColor() || null\"\n      (click)=\"onTriggerClick()\"\n      (keydown)=\"onTriggerKeydown($event)\"\n      (blur)=\"markAsTouched()\"\n    >\n      <span class=\"pg-select-trigger__value truncate\" [class.text-content-subtle]=\"!displayValue()\">\n        {{ displayValue() || placeholder() }}\n      </span>\n      <span class=\"pg-select-trigger__controls flex items-center gap-1 shrink-0\">\n        @if (clearable() && value() !== null && value() !== undefined && !disabled() && !readonly()) {\n          <span\n            role=\"button\"\n            tabindex=\"-1\"\n            class=\"pg-select-clear inline-flex items-center justify-center size-5 rounded-full text-content-muted hover:text-content cursor-pointer\"\n            aria-label=\"Clear selection\"\n            (click)=\"onClearClick($event)\"\n          >\n            &times;\n          </span>\n        }\n        <svg class=\"pg-select-chevron size-5 text-content-muted\" viewBox=\"0 0 20 20\" fill=\"currentColor\" aria-hidden=\"true\">\n          <path\n            fill-rule=\"evenodd\"\n            d=\"M5.22 8.22a.75.75 0 011.06 0L10 11.94l3.72-3.72a.75.75 0 111.06 1.06l-4.25 4.25a.75.75 0 01-1.06 0L5.22 9.28a.75.75 0 010-1.06z\"\n            clip-rule=\"evenodd\"\n          />\n        </svg>\n      </span>\n    </button>\n  } @else {\n    <div\n      class=\"pg-select-trigger pg-select-trigger--search flex items-center justify-between gap-2 w-full rounded-md outline outline-1 -outline-offset-1 focus-within:outline focus-within:outline-2 focus-within:-outline-offset-2\"\n      [class]=\"triggerStateClasses()\"\n      [style.--pg-select-primary]=\"primaryColor() || null\"\n    >\n      <input\n        type=\"text\"\n        [id]=\"computedForId()\"\n        role=\"combobox\"\n        aria-haspopup=\"listbox\"\n        aria-autocomplete=\"list\"\n        [attr.aria-expanded]=\"isOpen()\"\n        [attr.aria-controls]=\"listboxId\"\n        [attr.aria-activedescendant]=\"activeOptionId()\"\n        [attr.aria-disabled]=\"disabled() || null\"\n        [disabled]=\"disabled()\"\n        [readOnly]=\"readonly()\"\n        [placeholder]=\"placeholder()\"\n        class=\"pg-select-trigger__input w-full border-0 outline-none focus:shadow-none focus:ring-0 bg-transparent px-3 py-2 text-sm leading-6 text-content placeholder:text-content-subtle\"\n        [value]=\"isOpen() ? query() : displayValue()\"\n        (input)=\"onSearchInput($event)\"\n        (focus)=\"open()\"\n        (keydown)=\"handleKeydown($event)\"\n        (blur)=\"markAsTouched()\"\n      />\n      @if (clearable() && value() !== null && value() !== undefined && !disabled() && !readonly()) {\n        <span\n          role=\"button\"\n          tabindex=\"-1\"\n          class=\"pg-select-clear inline-flex items-center justify-center size-5 rounded-full text-content-muted hover:text-content cursor-pointer mr-2\"\n          aria-label=\"Clear selection\"\n          (click)=\"onClearClick($event)\"\n        >\n          &times;\n        </span>\n      }\n    </div>\n  }\n\n  <ng-template\n    cdkConnectedOverlay\n    [cdkConnectedOverlayOrigin]=\"origin\"\n    [cdkConnectedOverlayOpen]=\"isOpen()\"\n    [cdkConnectedOverlayPositions]=\"overlayPositions\"\n    [cdkConnectedOverlayWidth]=\"origin.elementRef.nativeElement.offsetWidth\"\n    [cdkConnectedOverlayFlexibleDimensions]=\"true\"\n    [cdkConnectedOverlayPush]=\"true\"\n    [cdkConnectedOverlayGrowAfterOpen]=\"true\"\n    [cdkConnectedOverlayScrollStrategy]=\"scrollStrategy\"\n    [cdkConnectedOverlayHasBackdrop]=\"true\"\n    cdkConnectedOverlayBackdropClass=\"cdk-overlay-transparent-backdrop\"\n    (backdropClick)=\"close()\"\n    (detach)=\"close()\"\n  >\n    <ul\n      #scrollPanel\n      [id]=\"listboxId\"\n      role=\"listbox\"\n      class=\"pg-select-panel max-h-60 overflow-y-auto rounded-md bg-surface-raised py-1 shadow-lg ring-1 ring-outline-contrast/5 list-none m-0\"\n      [class.animate-fade-in]=\"!isClosing()\"\n      [class.animate-fade-out]=\"isClosing()\"\n      [style.animation-duration.ms]=\"isClosing() ? panelExitDurationMs : panelEnterDurationMs\"\n      [style.min-width.px]=\"origin.elementRef.nativeElement.offsetWidth\"\n      (scroll)=\"onPanelScroll($event)\"\n    >\n      @switch (panelState()) {\n        @case ('loading') {\n          <li class=\"pg-select-panel__message px-3 py-2 text-sm text-content-muted\">{{ loadingText() }}</li>\n        }\n        @case ('empty') {\n          <li class=\"pg-select-panel__message px-3 py-2 text-sm text-content-muted\">{{ emptyText() }}</li>\n        }\n        @case ('no-results') {\n          <li class=\"pg-select-panel__message px-3 py-2 text-sm text-content-muted\">{{ noResultsText() }}</li>\n        }\n        @default {\n          @if (isGrouped()) {\n            @for (group of filteredGroups(); track group.label; let gi = $index) {\n              <li role=\"group\" [attr.aria-labelledby]=\"groupHeaderId(gi)\" class=\"pg-select-group\">\n                <div\n                  [id]=\"groupHeaderId(gi)\"\n                  class=\"pg-select-group__label px-3 pt-1.5 pb-0.5 text-xs font-semibold text-content-muted\"\n                >\n                  {{ group.label }}\n                </div>\n                @for (opt of group.options; track opt.value) {\n                  <pg-select-option\n                    [option]=\"opt\"\n                    [selected]=\"isSelected(opt)\"\n                    [primaryColor]=\"primaryColor()\"\n                    (click)=\"onOptionClick(opt)\"\n                  ></pg-select-option>\n                }\n              </li>\n            }\n          } @else {\n            @for (opt of filteredFlat(); track opt.value) {\n              <pg-select-option\n                [option]=\"opt\"\n                [selected]=\"isSelected(opt)\"\n                [primaryColor]=\"primaryColor()\"\n                (click)=\"onOptionClick(opt)\"\n              ></pg-select-option>\n            }\n          }\n          @if (isLoadingMore()) {\n            <li class=\"pg-select-panel__message px-3 py-2 text-sm text-content-muted\" aria-live=\"polite\">\n              {{ loadingText() }}\n            </li>\n          }\n        }\n      }\n    </ul>\n  </ng-template>\n</div>\n", styles: [":host{display:block;width:100%}\n"] }]
        }] });

/**
 * `pg-select-multi` — multi-value select. Renders removable chips plus a
 * search input in the trigger. Selecting an option toggles its membership in
 * the `T[]` value and keeps the panel open (does not close on select).
 */
class MultiSelectComponent extends PgSelectBase {
    multiple = true;
    closeOnSelect = false;
    /** Optional cap on the number of selected options. */
    maxSelected = input(undefined);
    selectedOptions = computed(() => {
        const values = this.value() ?? [];
        if (values.length === 0)
            return [];
        return this.flatOptions().filter((o) => values.some((v) => this.compareWith()(o.value, v)));
    });
    displayValue = computed(() => this.selectedOptions().map((o) => o.label));
    atMaxSelected = computed(() => {
        const max = this.maxSelected();
        if (max === undefined)
            return false;
        return (this.value()?.length ?? 0) >= max;
    });
    isSelected(option) {
        const values = this.value();
        if (!values || values.length === 0)
            return false;
        return values.some((v) => this.compareWith()(option.value, v));
    }
    /** Toggles membership: removes if already selected, adds otherwise (respecting `maxSelected`). */
    selectOption(option) {
        const current = this.value() ?? [];
        const already = this.isSelected(option);
        if (already) {
            this.setValue(current.filter((v) => !this.compareWith()(option.value, v)));
            return;
        }
        if (this.atMaxSelected())
            return;
        this.setValue([...current, option.value]);
    }
    onOptionClick(option) {
        this.activateOption(option);
    }
    removeChip(option, event) {
        event.stopPropagation();
        if (this.disabled() || this.readonly())
            return;
        const current = this.value() ?? [];
        this.setValue(current.filter((v) => !this.compareWith()(option.value, v)));
        this.markAsTouched();
    }
    onClearAllClick(event) {
        event.stopPropagation();
        this.clear();
    }
    clear() {
        if (this.disabled() || this.readonly())
            return;
        this.setValue([]);
        this.cleared.emit();
    }
    onSearchKeydown(event) {
        if (event.key === 'Backspace' && this.query() === '') {
            const current = this.value() ?? [];
            if (current.length > 0) {
                event.preventDefault();
                this.setValue(current.slice(0, -1));
                this.markAsTouched();
                return;
            }
        }
        this.handleKeydown(event);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: MultiSelectComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.21", type: MultiSelectComponent, isStandalone: true, selector: "pg-select-multi", inputs: { maxSelected: { classPropertyName: "maxSelected", publicName: "maxSelected", isSignal: true, isRequired: false, transformFunction: null } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => MultiSelectComponent),
                multi: true,
            },
        ], usesInheritance: true, ngImport: i0, template: "<div class=\"pg-select relative\" cdkOverlayOrigin #origin=\"cdkOverlayOrigin\">\n  <div\n    class=\"pg-select-trigger pg-select-trigger--multi flex items-start justify-between gap-2 w-full rounded-md py-1.5 px-2 outline outline-1 -outline-offset-1 focus-within:outline focus-within:outline-2 focus-within:-outline-offset-2\"\n    [class]=\"triggerStateClasses()\"\n    [style.--pg-select-primary]=\"primaryColor() || null\"\n  >\n    <ul class=\"pg-select-chips flex flex-wrap items-center gap-1 flex-1 min-w-0 list-none m-0 p-0\" role=\"list\">\n      @for (opt of selectedOptions(); track opt.value) {\n        <li\n          class=\"pg-select-chip inline-flex items-center gap-2 rounded-md bg-primary/10 px-2 py-0.5 text-xs leading-5 text-content\"\n          [style.background-color]=\"\n            primaryColor() ? 'color-mix(in srgb, ' + primaryColor() + ' 10%, transparent)' : null\n          \"\n        >\n          <span class=\"pg-select-chip__label\">{{ opt.label }}</span>\n          @if (!disabled() && !readonly()) {\n            <span\n              role=\"button\"\n              tabindex=\"-1\"\n              class=\"pg-select-chip__remove cursor-pointer font-semibold\"\n              [attr.aria-label]=\"'Remove ' + opt.label\"\n              (click)=\"removeChip(opt, $event)\"\n            >\n              &times;\n            </span>\n          }\n        </li>\n      }\n      <li class=\"pg-select-chips__input-wrap grow basis-24 min-w-16\">\n        <input\n          type=\"text\"\n          [id]=\"computedForId()\"\n          role=\"combobox\"\n          aria-haspopup=\"listbox\"\n          aria-autocomplete=\"list\"\n          [attr.aria-expanded]=\"isOpen()\"\n          [attr.aria-controls]=\"listboxId\"\n          [attr.aria-activedescendant]=\"activeOptionId()\"\n          [attr.aria-disabled]=\"disabled() || null\"\n          [disabled]=\"disabled()\"\n          [readOnly]=\"readonly()\"\n          [placeholder]=\"selectedOptions().length === 0 ? placeholder() : ''\"\n          class=\"pg-select-trigger__input w-full border-0 outline-none focus:shadow-none focus:ring-0 bg-transparent text-sm leading-6 text-content placeholder:text-content-subtle\"\n          [value]=\"query()\"\n          (input)=\"onSearchInput($event)\"\n          (focus)=\"open()\"\n          (keydown)=\"onSearchKeydown($event)\"\n          (blur)=\"markAsTouched()\"\n        />\n      </li>\n    </ul>\n    @if (clearable() && selectedOptions().length > 0 && !disabled() && !readonly()) {\n      <span\n        role=\"button\"\n        tabindex=\"-1\"\n        class=\"pg-select-clear inline-flex items-center justify-center size-5 text-content-muted hover:text-content cursor-pointer shrink-0\"\n        aria-label=\"Clear all selections\"\n        (click)=\"onClearAllClick($event)\"\n      >\n        &times;\n      </span>\n    }\n  </div>\n\n  <ng-template\n    cdkConnectedOverlay\n    [cdkConnectedOverlayOrigin]=\"origin\"\n    [cdkConnectedOverlayOpen]=\"isOpen()\"\n    [cdkConnectedOverlayPositions]=\"overlayPositions\"\n    [cdkConnectedOverlayWidth]=\"origin.elementRef.nativeElement.offsetWidth\"\n    [cdkConnectedOverlayFlexibleDimensions]=\"true\"\n    [cdkConnectedOverlayPush]=\"true\"\n    [cdkConnectedOverlayGrowAfterOpen]=\"true\"\n    [cdkConnectedOverlayScrollStrategy]=\"scrollStrategy\"\n    [cdkConnectedOverlayHasBackdrop]=\"true\"\n    cdkConnectedOverlayBackdropClass=\"cdk-overlay-transparent-backdrop\"\n    (backdropClick)=\"close()\"\n    (detach)=\"close()\"\n  >\n    <ul\n      #scrollPanel\n      [id]=\"listboxId\"\n      role=\"listbox\"\n      aria-multiselectable=\"true\"\n      class=\"pg-select-panel max-h-60 overflow-y-auto rounded-md bg-surface-raised py-1 shadow-lg ring-1 ring-outline-contrast/5 list-none m-0\"\n      [class.animate-fade-in]=\"!isClosing()\"\n      [class.animate-fade-out]=\"isClosing()\"\n      [style.animation-duration.ms]=\"isClosing() ? panelExitDurationMs : panelEnterDurationMs\"\n      [style.min-width.px]=\"origin.elementRef.nativeElement.offsetWidth\"\n      (scroll)=\"onPanelScroll($event)\"\n    >\n      @switch (panelState()) {\n        @case ('loading') {\n          <li class=\"pg-select-panel__message px-3 py-2 text-sm text-content-muted\">{{ loadingText() }}</li>\n        }\n        @case ('empty') {\n          <li class=\"pg-select-panel__message px-3 py-2 text-sm text-content-muted\">{{ emptyText() }}</li>\n        }\n        @case ('no-results') {\n          <li class=\"pg-select-panel__message px-3 py-2 text-sm text-content-muted\">{{ noResultsText() }}</li>\n        }\n        @default {\n          @if (isGrouped()) {\n            @for (group of filteredGroups(); track group.label; let gi = $index) {\n              <li role=\"group\" [attr.aria-labelledby]=\"groupHeaderId(gi)\" class=\"pg-select-group\">\n                <div\n                  [id]=\"groupHeaderId(gi)\"\n                  class=\"pg-select-group__label px-3 pt-1.5 pb-0.5 text-xs font-semibold text-content-muted\"\n                >\n                  {{ group.label }}\n                </div>\n                @for (opt of group.options; track opt.value) {\n                  <pg-select-option\n                    [option]=\"opt\"\n                    [selected]=\"isSelected(opt)\"\n                    [primaryColor]=\"primaryColor()\"\n                    (click)=\"onOptionClick(opt)\"\n                  ></pg-select-option>\n                }\n              </li>\n            }\n          } @else {\n            @for (opt of filteredFlat(); track opt.value) {\n              <pg-select-option\n                [option]=\"opt\"\n                [selected]=\"isSelected(opt)\"\n                [primaryColor]=\"primaryColor()\"\n                (click)=\"onOptionClick(opt)\"\n              ></pg-select-option>\n            }\n          }\n          @if (isLoadingMore()) {\n            <li class=\"pg-select-panel__message px-3 py-2 text-sm text-content-muted\" aria-live=\"polite\">\n              {{ loadingText() }}\n            </li>\n          }\n        }\n      }\n    </ul>\n  </ng-template>\n</div>\n", styles: [":host{display:block;width:100%}\n"], dependencies: [{ kind: "ngmodule", type: OverlayModule }, { kind: "directive", type: i1.CdkConnectedOverlay, selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]", inputs: ["cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayPositionStrategy", "cdkConnectedOverlayOffsetX", "cdkConnectedOverlayOffsetY", "cdkConnectedOverlayWidth", "cdkConnectedOverlayHeight", "cdkConnectedOverlayMinWidth", "cdkConnectedOverlayMinHeight", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayPanelClass", "cdkConnectedOverlayViewportMargin", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOpen", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayTransformOriginOn", "cdkConnectedOverlayHasBackdrop", "cdkConnectedOverlayLockPosition", "cdkConnectedOverlayFlexibleDimensions", "cdkConnectedOverlayGrowAfterOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayDisposeOnNavigation"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cdkConnectedOverlay"] }, { kind: "directive", type: i1.CdkOverlayOrigin, selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]", exportAs: ["cdkOverlayOrigin"] }, { kind: "component", type: PgSelectOptionComponent, selector: "pg-select-option", inputs: ["option", "selected", "primaryColor"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: MultiSelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-select-multi', imports: [OverlayModule, PgSelectOptionComponent], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => MultiSelectComponent),
                            multi: true,
                        },
                    ], template: "<div class=\"pg-select relative\" cdkOverlayOrigin #origin=\"cdkOverlayOrigin\">\n  <div\n    class=\"pg-select-trigger pg-select-trigger--multi flex items-start justify-between gap-2 w-full rounded-md py-1.5 px-2 outline outline-1 -outline-offset-1 focus-within:outline focus-within:outline-2 focus-within:-outline-offset-2\"\n    [class]=\"triggerStateClasses()\"\n    [style.--pg-select-primary]=\"primaryColor() || null\"\n  >\n    <ul class=\"pg-select-chips flex flex-wrap items-center gap-1 flex-1 min-w-0 list-none m-0 p-0\" role=\"list\">\n      @for (opt of selectedOptions(); track opt.value) {\n        <li\n          class=\"pg-select-chip inline-flex items-center gap-2 rounded-md bg-primary/10 px-2 py-0.5 text-xs leading-5 text-content\"\n          [style.background-color]=\"\n            primaryColor() ? 'color-mix(in srgb, ' + primaryColor() + ' 10%, transparent)' : null\n          \"\n        >\n          <span class=\"pg-select-chip__label\">{{ opt.label }}</span>\n          @if (!disabled() && !readonly()) {\n            <span\n              role=\"button\"\n              tabindex=\"-1\"\n              class=\"pg-select-chip__remove cursor-pointer font-semibold\"\n              [attr.aria-label]=\"'Remove ' + opt.label\"\n              (click)=\"removeChip(opt, $event)\"\n            >\n              &times;\n            </span>\n          }\n        </li>\n      }\n      <li class=\"pg-select-chips__input-wrap grow basis-24 min-w-16\">\n        <input\n          type=\"text\"\n          [id]=\"computedForId()\"\n          role=\"combobox\"\n          aria-haspopup=\"listbox\"\n          aria-autocomplete=\"list\"\n          [attr.aria-expanded]=\"isOpen()\"\n          [attr.aria-controls]=\"listboxId\"\n          [attr.aria-activedescendant]=\"activeOptionId()\"\n          [attr.aria-disabled]=\"disabled() || null\"\n          [disabled]=\"disabled()\"\n          [readOnly]=\"readonly()\"\n          [placeholder]=\"selectedOptions().length === 0 ? placeholder() : ''\"\n          class=\"pg-select-trigger__input w-full border-0 outline-none focus:shadow-none focus:ring-0 bg-transparent text-sm leading-6 text-content placeholder:text-content-subtle\"\n          [value]=\"query()\"\n          (input)=\"onSearchInput($event)\"\n          (focus)=\"open()\"\n          (keydown)=\"onSearchKeydown($event)\"\n          (blur)=\"markAsTouched()\"\n        />\n      </li>\n    </ul>\n    @if (clearable() && selectedOptions().length > 0 && !disabled() && !readonly()) {\n      <span\n        role=\"button\"\n        tabindex=\"-1\"\n        class=\"pg-select-clear inline-flex items-center justify-center size-5 text-content-muted hover:text-content cursor-pointer shrink-0\"\n        aria-label=\"Clear all selections\"\n        (click)=\"onClearAllClick($event)\"\n      >\n        &times;\n      </span>\n    }\n  </div>\n\n  <ng-template\n    cdkConnectedOverlay\n    [cdkConnectedOverlayOrigin]=\"origin\"\n    [cdkConnectedOverlayOpen]=\"isOpen()\"\n    [cdkConnectedOverlayPositions]=\"overlayPositions\"\n    [cdkConnectedOverlayWidth]=\"origin.elementRef.nativeElement.offsetWidth\"\n    [cdkConnectedOverlayFlexibleDimensions]=\"true\"\n    [cdkConnectedOverlayPush]=\"true\"\n    [cdkConnectedOverlayGrowAfterOpen]=\"true\"\n    [cdkConnectedOverlayScrollStrategy]=\"scrollStrategy\"\n    [cdkConnectedOverlayHasBackdrop]=\"true\"\n    cdkConnectedOverlayBackdropClass=\"cdk-overlay-transparent-backdrop\"\n    (backdropClick)=\"close()\"\n    (detach)=\"close()\"\n  >\n    <ul\n      #scrollPanel\n      [id]=\"listboxId\"\n      role=\"listbox\"\n      aria-multiselectable=\"true\"\n      class=\"pg-select-panel max-h-60 overflow-y-auto rounded-md bg-surface-raised py-1 shadow-lg ring-1 ring-outline-contrast/5 list-none m-0\"\n      [class.animate-fade-in]=\"!isClosing()\"\n      [class.animate-fade-out]=\"isClosing()\"\n      [style.animation-duration.ms]=\"isClosing() ? panelExitDurationMs : panelEnterDurationMs\"\n      [style.min-width.px]=\"origin.elementRef.nativeElement.offsetWidth\"\n      (scroll)=\"onPanelScroll($event)\"\n    >\n      @switch (panelState()) {\n        @case ('loading') {\n          <li class=\"pg-select-panel__message px-3 py-2 text-sm text-content-muted\">{{ loadingText() }}</li>\n        }\n        @case ('empty') {\n          <li class=\"pg-select-panel__message px-3 py-2 text-sm text-content-muted\">{{ emptyText() }}</li>\n        }\n        @case ('no-results') {\n          <li class=\"pg-select-panel__message px-3 py-2 text-sm text-content-muted\">{{ noResultsText() }}</li>\n        }\n        @default {\n          @if (isGrouped()) {\n            @for (group of filteredGroups(); track group.label; let gi = $index) {\n              <li role=\"group\" [attr.aria-labelledby]=\"groupHeaderId(gi)\" class=\"pg-select-group\">\n                <div\n                  [id]=\"groupHeaderId(gi)\"\n                  class=\"pg-select-group__label px-3 pt-1.5 pb-0.5 text-xs font-semibold text-content-muted\"\n                >\n                  {{ group.label }}\n                </div>\n                @for (opt of group.options; track opt.value) {\n                  <pg-select-option\n                    [option]=\"opt\"\n                    [selected]=\"isSelected(opt)\"\n                    [primaryColor]=\"primaryColor()\"\n                    (click)=\"onOptionClick(opt)\"\n                  ></pg-select-option>\n                }\n              </li>\n            }\n          } @else {\n            @for (opt of filteredFlat(); track opt.value) {\n              <pg-select-option\n                [option]=\"opt\"\n                [selected]=\"isSelected(opt)\"\n                [primaryColor]=\"primaryColor()\"\n                (click)=\"onOptionClick(opt)\"\n              ></pg-select-option>\n            }\n          }\n          @if (isLoadingMore()) {\n            <li class=\"pg-select-panel__message px-3 py-2 text-sm text-content-muted\" aria-live=\"polite\">\n              {{ loadingText() }}\n            </li>\n          }\n        }\n      }\n    </ul>\n  </ng-template>\n</div>\n", styles: [":host{display:block;width:100%}\n"] }]
        }] });

class PgSelectModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgSelectModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.21", ngImport: i0, type: PgSelectModule, imports: [SelectComponent, MultiSelectComponent, PgSelectOptionComponent], exports: [SelectComponent, MultiSelectComponent, PgSelectOptionComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgSelectModule, imports: [SelectComponent, MultiSelectComponent] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgSelectModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [SelectComponent, MultiSelectComponent, PgSelectOptionComponent],
                    exports: [SelectComponent, MultiSelectComponent, PgSelectOptionComponent],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { MultiSelectComponent, PG_SELECT_SCROLL_STRATEGY, PgSelectModule, PgSelectOptionComponent, SelectComponent };
//# sourceMappingURL=pagalo-ui-select.mjs.map
