import * as i0 from '@angular/core';
import { inject, ElementRef, input, model, output, signal, computed, viewChild, effect, ChangeDetectionStrategy, Component, contentChild, NgModule } from '@angular/core';
import * as i1 from '@angular/cdk/overlay';
import { OverlayModule } from '@angular/cdk/overlay';
import { FocusKeyManager } from '@angular/cdk/a11y';

const PLACEMENT_POSITIONS = {
    'bottom-start': { originX: 'start', originY: 'bottom', overlayX: 'start', overlayY: 'top', offsetY: 8 },
    'bottom-end': { originX: 'end', originY: 'bottom', overlayX: 'end', overlayY: 'top', offsetY: 8 },
    'top-start': { originX: 'start', originY: 'top', overlayX: 'start', overlayY: 'bottom', offsetY: -8 },
    'top-end': { originX: 'end', originY: 'top', overlayX: 'end', overlayY: 'bottom', offsetY: -8 },
    'left-start': { originX: 'start', originY: 'top', overlayX: 'end', overlayY: 'top', offsetX: -8 },
    'left-end': { originX: 'start', originY: 'bottom', overlayX: 'end', overlayY: 'bottom', offsetX: -8 },
    'right-start': { originX: 'end', originY: 'top', overlayX: 'start', overlayY: 'top', offsetX: 8 },
    'right-end': { originX: 'end', originY: 'bottom', overlayX: 'start', overlayY: 'bottom', offsetX: 8 },
};
/** Wraps a raw projected `<a>`/`<button>` menu item as a CDK-navigable option. */
class MenuItemFocusableOption {
    el;
    disabled = false;
    constructor(el) {
        this.el = el;
    }
    focus() {
        this.el.focus();
    }
    getLabel() {
        return this.el.textContent?.trim() ?? '';
    }
}
class PgDropdownMenuComponent {
    elementRef = inject((ElementRef));
    dropdown = inject(PgDropdownComponent, { optional: true });
    /** Placement of the menu relative to its trigger. Default: 'bottom-end'. */
    placement = input('bottom-end');
    /** Two-way binding to read or programmatically control menu visibility. */
    isOpen = model(false);
    /** Emitted when the menu opens. */
    opened = output();
    /** Emitted when the menu closes (after the exit animation completes). */
    closed = output();
    panelEnterDurationMs = 100;
    panelExitDurationMs = 75;
    /** True while the exit animation plays, before the overlay actually detaches. */
    isClosing = signal(false);
    /** Anchor for the CDK overlay: the parent `pg-dropdown`'s trigger, or this element as a standalone fallback. */
    origin = computed(() => this.dropdown?.elementRef ?? this.elementRef);
    overlayPositions = computed(() => [PLACEMENT_POSITIONS[this.placement()]]);
    menuPanel = viewChild('menuPanel');
    focusKeyManager = null;
    closeTimeoutHandle = null;
    everOpened = false;
    /**
     * Drives the exit-animation window: `isOpen` flips immediately (public
     * model contract, unchanged), but the overlay stays attached for
     * `panelExitDurationMs` more via `isOpen() || isClosing()` in the template
     * so the CSS exit animation can play out. Reacts to `isOpen` regardless of
     * whether it changed via `toggle()`/`close()` or an external `[(isOpen)]` set.
     */
    _closeAnimationEffect = effect(() => {
        const open = this.isOpen();
        if (open) {
            this.everOpened = true;
            if (this.closeTimeoutHandle !== null) {
                clearTimeout(this.closeTimeoutHandle);
                this.closeTimeoutHandle = null;
            }
            this.isClosing.set(false);
            this.opened.emit();
            return;
        }
        if (!this.everOpened || this.closeTimeoutHandle !== null)
            return;
        this.isClosing.set(true);
        this.closeTimeoutHandle = setTimeout(() => {
            this.isClosing.set(false);
            this.closeTimeoutHandle = null;
            this.closed.emit();
        }, this.panelExitDurationMs);
    });
    open() {
        this.isOpen.set(true);
    }
    close() {
        this.isOpen.set(false);
    }
    toggle() {
        this.isOpen() ? this.close() : this.open();
    }
    /** Builds keyboard navigation over the projected items once the overlay content mounts. */
    onOverlayAttach() {
        const panelEl = this.menuPanel()?.nativeElement;
        if (!panelEl)
            return;
        const items = Array.from(panelEl.querySelectorAll('a[href], button:not([disabled])')).map((el) => new MenuItemFocusableOption(el));
        this.focusKeyManager = new FocusKeyManager(items).withWrap().withTypeAhead().withHomeAndEnd();
        panelEl.focus();
    }
    onOverlayDetach() {
        this.focusKeyManager = null;
    }
    onOverlayKeydown(event) {
        switch (event.key) {
            case 'Escape':
                event.preventDefault();
                this.close();
                this.focusOrigin();
                break;
            case 'ArrowDown':
            case 'ArrowUp':
            case 'Home':
            case 'End':
                event.preventDefault();
                this.focusKeyManager?.onKeydown(event);
                break;
            case 'Tab':
                this.close();
                break;
            default:
                break;
        }
    }
    focusOrigin() {
        this.origin().nativeElement.querySelector('button, a[href], [tabindex]')?.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgDropdownMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "19.2.21", type: PgDropdownMenuComponent, isStandalone: true, selector: "pg-dropdown-menu", inputs: { placement: { classPropertyName: "placement", publicName: "placement", isSignal: true, isRequired: false, transformFunction: null }, isOpen: { classPropertyName: "isOpen", publicName: "isOpen", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { isOpen: "isOpenChange", opened: "opened", closed: "closed" }, viewQueries: [{ propertyName: "menuPanel", first: true, predicate: ["menuPanel"], descendants: true, isSignal: true }], ngImport: i0, template: "<ng-template\n  cdkConnectedOverlay\n  [cdkConnectedOverlayOrigin]=\"origin()\"\n  [cdkConnectedOverlayOpen]=\"isOpen() || isClosing()\"\n  [cdkConnectedOverlayPositions]=\"overlayPositions()\"\n  [cdkConnectedOverlayPush]=\"true\"\n  cdkConnectedOverlayHasBackdrop=\"true\"\n  cdkConnectedOverlayBackdropClass=\"cdk-overlay-transparent-backdrop\"\n  (backdropClick)=\"close()\"\n  (attach)=\"onOverlayAttach()\"\n  (detach)=\"onOverlayDetach()\"\n  (overlayKeydown)=\"onOverlayKeydown($event)\"\n>\n  <div\n    #menuPanel\n    tabindex=\"-1\"\n    class=\"w-56 rounded-md bg-surface-raised py-1 shadow-lg outline-1 -outline-offset-1 outline-outline-contrast/5 focus:outline-none\"\n    [class.pg-dropdown-menu-enter]=\"!isClosing()\"\n    [class.pg-dropdown-menu-exit]=\"isClosing()\"\n    [style.animation-duration.ms]=\"isClosing() ? panelExitDurationMs : panelEnterDurationMs\"\n  >\n    <ng-content></ng-content>\n  </div>\n</ng-template>\n", styles: ["@keyframes pg-dropdown-menu-enter{0%{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}@keyframes pg-dropdown-menu-exit{0%{opacity:1;transform:scale(1)}to{opacity:0;transform:scale(.95)}}.pg-dropdown-menu-enter{animation-name:pg-dropdown-menu-enter;animation-timing-function:ease-out;animation-fill-mode:both}.pg-dropdown-menu-exit{animation-name:pg-dropdown-menu-exit;animation-timing-function:ease-in;animation-fill-mode:both}\n"], dependencies: [{ kind: "ngmodule", type: OverlayModule }, { kind: "directive", type: i1.CdkConnectedOverlay, selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]", inputs: ["cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayPositionStrategy", "cdkConnectedOverlayOffsetX", "cdkConnectedOverlayOffsetY", "cdkConnectedOverlayWidth", "cdkConnectedOverlayHeight", "cdkConnectedOverlayMinWidth", "cdkConnectedOverlayMinHeight", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayPanelClass", "cdkConnectedOverlayViewportMargin", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOpen", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayTransformOriginOn", "cdkConnectedOverlayHasBackdrop", "cdkConnectedOverlayLockPosition", "cdkConnectedOverlayFlexibleDimensions", "cdkConnectedOverlayGrowAfterOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayDisposeOnNavigation"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cdkConnectedOverlay"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgDropdownMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-dropdown-menu', imports: [OverlayModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-template\n  cdkConnectedOverlay\n  [cdkConnectedOverlayOrigin]=\"origin()\"\n  [cdkConnectedOverlayOpen]=\"isOpen() || isClosing()\"\n  [cdkConnectedOverlayPositions]=\"overlayPositions()\"\n  [cdkConnectedOverlayPush]=\"true\"\n  cdkConnectedOverlayHasBackdrop=\"true\"\n  cdkConnectedOverlayBackdropClass=\"cdk-overlay-transparent-backdrop\"\n  (backdropClick)=\"close()\"\n  (attach)=\"onOverlayAttach()\"\n  (detach)=\"onOverlayDetach()\"\n  (overlayKeydown)=\"onOverlayKeydown($event)\"\n>\n  <div\n    #menuPanel\n    tabindex=\"-1\"\n    class=\"w-56 rounded-md bg-surface-raised py-1 shadow-lg outline-1 -outline-offset-1 outline-outline-contrast/5 focus:outline-none\"\n    [class.pg-dropdown-menu-enter]=\"!isClosing()\"\n    [class.pg-dropdown-menu-exit]=\"isClosing()\"\n    [style.animation-duration.ms]=\"isClosing() ? panelExitDurationMs : panelEnterDurationMs\"\n  >\n    <ng-content></ng-content>\n  </div>\n</ng-template>\n", styles: ["@keyframes pg-dropdown-menu-enter{0%{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}@keyframes pg-dropdown-menu-exit{0%{opacity:1;transform:scale(1)}to{opacity:0;transform:scale(.95)}}.pg-dropdown-menu-enter{animation-name:pg-dropdown-menu-enter;animation-timing-function:ease-out;animation-fill-mode:both}.pg-dropdown-menu-exit{animation-name:pg-dropdown-menu-exit;animation-timing-function:ease-in;animation-fill-mode:both}\n"] }]
        }] });

/**
 * Trigger wrapper for `pg-dropdown-menu`. Exposes its own `ElementRef` as the
 * CDK overlay's anchor and toggles the projected menu on click. Projects the
 * trigger element (e.g. a `<button>`) followed by a `pg-dropdown-menu`.
 */
class PgDropdownComponent {
    elementRef = inject((ElementRef));
    menu = contentChild(PgDropdownMenuComponent);
    onTriggerClick() {
        this.menu()?.toggle();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgDropdownComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "19.2.21", type: PgDropdownComponent, isStandalone: true, selector: "pg-dropdown", host: { listeners: { "click": "onTriggerClick()" } }, queries: [{ propertyName: "menu", first: true, predicate: PgDropdownMenuComponent, descendants: true, isSignal: true }], ngImport: i0, template: "<ng-content></ng-content>\n", changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgDropdownComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pg-dropdown', changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        '(click)': 'onTriggerClick()',
                    }, template: "<ng-content></ng-content>\n" }]
        }] });

class PgDropdownModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgDropdownModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.21", ngImport: i0, type: PgDropdownModule, imports: [PgDropdownComponent, PgDropdownMenuComponent], exports: [PgDropdownComponent, PgDropdownMenuComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgDropdownModule, imports: [PgDropdownMenuComponent] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.21", ngImport: i0, type: PgDropdownModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [PgDropdownComponent, PgDropdownMenuComponent],
                    exports: [PgDropdownComponent, PgDropdownMenuComponent],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { PgDropdownComponent, PgDropdownMenuComponent, PgDropdownModule };
//# sourceMappingURL=pagalo-ui-dropdown.mjs.map
