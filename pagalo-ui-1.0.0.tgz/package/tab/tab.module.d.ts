import * as i0 from "@angular/core";
import * as i1 from "./tab.component";
export declare class PgTabModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgTabModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgTabModule, never, [typeof i1.TabComponent], [typeof i1.TabComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgTabModule>;
}
