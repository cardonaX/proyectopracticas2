import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export interface Tab {
    id: string;
    name: string;
    icon?: string;
    badge?: number;
    current: boolean;
}
export declare class TabComponent {
    variant: 'underline' | 'underline-icons' | 'pills' | 'pills-gray' | 'pills-rounded' | 'full-width' | 'bar' | 'simple';
    tabs: Tab[];
    /** Controla el tab activo externamente. Si se provee, toma precedencia sobre tab.current. */
    set activeTabId(id: string | null);
    tabChange: EventEmitter<Tab>;
    private pillsRoundedNav?;
    private pillsRoundedTabs;
    private readonly _activeTabId;
    readonly effectiveActiveId: import("@angular/core").Signal<string | null>;
    readonly sliderLeft: import("@angular/core").WritableSignal<number>;
    readonly sliderWidth: import("@angular/core").WritableSignal<number>;
    constructor();
    isActive(tab: Tab): boolean;
    selectTab(tab: Tab, event: Event): void;
    onMobileSelectChange(event: Event): void;
    private updateSlider;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabComponent, "pg-tab", never, { "variant": { "alias": "variant"; "required": false; }; "tabs": { "alias": "tabs"; "required": false; }; "activeTabId": { "alias": "activeTabId"; "required": false; }; }, { "tabChange": "tabChange"; }, never, never, true, never>;
}
