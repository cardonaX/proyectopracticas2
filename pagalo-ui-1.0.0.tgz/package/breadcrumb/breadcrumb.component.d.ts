import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type BreadcrumbVariant = 'contained' | 'full-width' | 'simple-chevrons' | 'simple-slashes';
export interface BreadcrumbItem {
    label: string;
    url?: string;
}
export declare class BreadcrumbComponent {
    variant: BreadcrumbVariant;
    items: BreadcrumbItem[];
    homeUrl: string;
    itemClick: EventEmitter<BreadcrumbItem>;
    onItemClick(item: BreadcrumbItem, event: Event): void;
    get navClass(): string;
    get olClass(): string;
    get liClass(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BreadcrumbComponent, "pg-breadcrumbs", never, { "variant": { "alias": "variant"; "required": false; }; "items": { "alias": "items"; "required": false; }; "homeUrl": { "alias": "homeUrl"; "required": false; }; }, { "itemClick": "itemClick"; }, never, never, true, never>;
}
