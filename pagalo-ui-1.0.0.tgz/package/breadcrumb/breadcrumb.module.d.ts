import * as i0 from "@angular/core";
import * as i1 from "./breadcrumb.component";
export declare class PgBreadcrumbModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgBreadcrumbModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgBreadcrumbModule, never, [typeof i1.BreadcrumbComponent], [typeof i1.BreadcrumbComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgBreadcrumbModule>;
}
