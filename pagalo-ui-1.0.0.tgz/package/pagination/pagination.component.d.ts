import * as i0 from "@angular/core";
export declare class PaginationComponent {
    currentPage: import("@angular/core").InputSignal<number>;
    totalPages: import("@angular/core").InputSignal<number>;
    pageSize: import("@angular/core").InputSignal<number>;
    totalItems: import("@angular/core").InputSignal<number>;
    maxPagesToShow: import("@angular/core").InputSignal<number>;
    variant: import("@angular/core").InputSignal<"default" | "centered" | "simple">;
    /** @deprecated Use pageChange instead. Will be removed in v2.0. */
    readonly onPageChange: import("@angular/core").OutputEmitterRef<number>;
    readonly pageChange: import("@angular/core").OutputEmitterRef<number>;
    pages: import("@angular/core").Signal<(string | number)[]>;
    startIndex: import("@angular/core").Signal<number>;
    endIndex: import("@angular/core").Signal<number>;
    goToPage(page: number, event?: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PaginationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PaginationComponent, "pg-pagination", never, { "currentPage": { "alias": "currentPage"; "required": false; "isSignal": true; }; "totalPages": { "alias": "totalPages"; "required": false; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": false; "isSignal": true; }; "totalItems": { "alias": "totalItems"; "required": false; "isSignal": true; }; "maxPagesToShow": { "alias": "maxPagesToShow"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, { "onPageChange": "onPageChange"; "pageChange": "pageChange"; }, never, never, true, never>;
}
