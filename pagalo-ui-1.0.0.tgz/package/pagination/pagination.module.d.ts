import * as i0 from "@angular/core";
import * as i1 from "./pagination.component";
export declare class PgPaginationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgPaginationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgPaginationModule, never, [typeof i1.PaginationComponent], [typeof i1.PaginationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgPaginationModule>;
}
