import * as i0 from "@angular/core";
import * as i1 from "./progress-bar.component";
import * as i2 from "./progress.component";
import * as i3 from "./simple.component";
import * as i4 from "./bullets.component";
import * as i5 from "./circles.component";
import * as i6 from "./bullets-and-text.component";
import * as i7 from "./circles-with-text.component";
import * as i8 from "./panels.component";
import * as i9 from "./panels-with-border.component";
export declare class PgProgressBarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgProgressBarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgProgressBarModule, never, [typeof i1.ProgressBarComponent, typeof i2.ProgressComponent, typeof i3.SimpleComponent, typeof i4.BulletsComponent, typeof i5.CirclesComponent, typeof i6.BulletsAndTextComponent, typeof i7.CirclesWithTextComponent, typeof i8.PanelsComponent, typeof i9.PanelsWithBorderComponent], [typeof i1.ProgressBarComponent, typeof i2.ProgressComponent, typeof i3.SimpleComponent, typeof i4.BulletsComponent, typeof i5.CirclesComponent, typeof i6.BulletsAndTextComponent, typeof i7.CirclesWithTextComponent, typeof i8.PanelsComponent, typeof i9.PanelsWithBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgProgressBarModule>;
}
