export type StepStatus = 'complete' | 'current' | 'upcoming';
export interface ProgressStep {
    id?: string | number;
    name: string;
    description?: string;
    status: StepStatus;
    href?: string;
    routerLink?: string | string[];
    disabled?: boolean;
}
