import { ProgressStep } from './progress.types';
import * as i0 from "@angular/core";
export declare class SimpleComponent {
    steps: import("@angular/core").InputSignal<ProgressStep[]>;
    orientation: import("@angular/core").InputSignal<"vertical" | "horizontal" | "auto">;
    label: import("@angular/core").InputSignal<string>;
    customClass: import("@angular/core").InputSignal<string>;
    primaryColor: import("@angular/core").InputSignal<string>;
    stepClick: import("@angular/core").OutputEmitterRef<ProgressStep>;
    onStepClick(step: ProgressStep, event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SimpleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SimpleComponent, "pg-progress-simple", never, { "steps": { "alias": "steps"; "required": true; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "customClass": { "alias": "customClass"; "required": false; "isSignal": true; }; "primaryColor": { "alias": "primaryColor"; "required": false; "isSignal": true; }; }, { "stepClick": "stepClick"; }, never, never, true, never>;
}
