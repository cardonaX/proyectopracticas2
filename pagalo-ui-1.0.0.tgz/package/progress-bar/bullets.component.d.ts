import { ProgressStep } from './progress.types';
import * as i0 from "@angular/core";
export declare class BulletsComponent {
    steps: import("@angular/core").InputSignal<ProgressStep[]>;
    label: import("@angular/core").InputSignal<string>;
    customClass: import("@angular/core").InputSignal<string>;
    stepClick: import("@angular/core").OutputEmitterRef<ProgressStep>;
    onStepClick(step: ProgressStep, event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BulletsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BulletsComponent, "pg-progress-bullets", never, { "steps": { "alias": "steps"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "customClass": { "alias": "customClass"; "required": false; "isSignal": true; }; }, { "stepClick": "stepClick"; }, never, never, true, never>;
}
