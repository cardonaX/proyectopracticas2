import { ProgressStep } from './progress.types';
import * as i0 from "@angular/core";
export declare class BulletsAndTextComponent {
    steps: import("@angular/core").InputSignal<ProgressStep[]>;
    orientation: import("@angular/core").InputSignal<"vertical" | "horizontal">;
    label: import("@angular/core").InputSignal<string>;
    customClass: import("@angular/core").InputSignal<string>;
    primaryColor: import("@angular/core").InputSignal<string>;
    successColor: import("@angular/core").InputSignal<string>;
    stepClick: import("@angular/core").OutputEmitterRef<ProgressStep>;
    onStepClick(step: ProgressStep, event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BulletsAndTextComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BulletsAndTextComponent, "pg-progress-bullets-text", never, { "steps": { "alias": "steps"; "required": true; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "customClass": { "alias": "customClass"; "required": false; "isSignal": true; }; "primaryColor": { "alias": "primaryColor"; "required": false; "isSignal": true; }; "successColor": { "alias": "successColor"; "required": false; "isSignal": true; }; }, { "stepClick": "stepClick"; }, never, never, true, never>;
}
