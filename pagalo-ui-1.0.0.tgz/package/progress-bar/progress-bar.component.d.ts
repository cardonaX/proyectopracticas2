import { OnInit } from '@angular/core';
import { ProgressStep } from './progress.types';
import * as i0 from "@angular/core";
export type ProgressBarVariant = 'simple' | 'steps' | 'bullets' | 'circles' | 'bullets-text' | 'circles-text' | 'panels' | 'panels-border';
export declare class ProgressBarComponent implements OnInit {
    /** Valor del progreso entre 0 y 100. Valores fuera de rango se clampean. */
    readonly value: import("@angular/core").InputSignal<number>;
    /** Variante de visualización. */
    readonly variant: import("@angular/core").InputSignal<ProgressBarVariant>;
    /** Label accesible para el progressbar. */
    readonly label: import("@angular/core").InputSignal<string>;
    /** Si `true`, muestra el porcentaje como texto. Solo aplica a variant "simple". */
    readonly showPercentage: import("@angular/core").InputSignal<boolean>;
    /** Color personalizado (CSS color string). Pasado al subcomponente si lo soporta. */
    readonly color: import("@angular/core").InputSignal<string>;
    /** Clase CSS personalizada. Pasada al elemento raíz de cualquier subcomponente. */
    readonly customClass: import("@angular/core").InputSignal<string>;
    /** Pasos para variantes de tipo step (bullets, circles, steps, etc). */
    readonly steps: import("@angular/core").InputSignal<ProgressStep[]>;
    /** Orientación del stepper. Solo aplica a variantes 'circles-text' y 'bullets-text'. */
    readonly orientation: import("@angular/core").InputSignal<"vertical" | "horizontal">;
    /** aria-label del elemento nav interno. Útil si hay múltiples steppers en la misma página. */
    readonly navLabel: import("@angular/core").InputSignal<string>;
    /** Color del step "current" (CSS color string). Pasado a las variantes que lo soportan. */
    readonly primaryColor: import("@angular/core").InputSignal<string>;
    /** Color del step "complete" (CSS color string). Pasado a las variantes que lo soportan. */
    readonly successColor: import("@angular/core").InputSignal<string>;
    /** Color de la descripción del step (CSS color string). Pasado a las variantes que lo soportan. */
    readonly descriptionColor: import("@angular/core").InputSignal<string>;
    /** Valor clampeado entre 0 y 100, siempre seguro para ARIA y subcomponentes. */
    readonly clampedValue: import("@angular/core").Signal<number>;
    private readonly elementRef;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProgressBarComponent, "pg-progress-bar, pg-progress-bars", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "showPercentage": { "alias": "showPercentage"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "customClass": { "alias": "customClass"; "required": false; "isSignal": true; }; "steps": { "alias": "steps"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "navLabel": { "alias": "navLabel"; "required": false; "isSignal": true; }; "primaryColor": { "alias": "primaryColor"; "required": false; "isSignal": true; }; "successColor": { "alias": "successColor"; "required": false; "isSignal": true; }; "descriptionColor": { "alias": "descriptionColor"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
