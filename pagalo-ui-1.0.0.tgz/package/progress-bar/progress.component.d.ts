import * as i0 from "@angular/core";
export declare class ProgressComponent {
    percentage: import("@angular/core").InputSignal<number>;
    title: import("@angular/core").InputSignal<string | undefined>;
    description: import("@angular/core").InputSignal<string | undefined>;
    checkpoints: import("@angular/core").InputSignal<string[]>;
    color: import("@angular/core").InputSignal<string>;
    customClass: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProgressComponent, "pg-progress", never, { "percentage": { "alias": "percentage"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "checkpoints": { "alias": "checkpoints"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "customClass": { "alias": "customClass"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
