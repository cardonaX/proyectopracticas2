import { ElementRef, OnDestroy } from '@angular/core';
import { PgLoaderVariant, PgLoaderSize, PgLoaderColor } from './loader.types';
import * as i0 from "@angular/core";
/**
 * Renders the single global loading overlay driven by `LoaderService`.
 * Mount exactly once per application (e.g. at the app shell root).
 *
 * The overlay is strictly blocking: no ESC, no click-outside dismissal.
 * Only `LoaderService` reaching an idle count (or `reset()`) can hide it.
 * Focus containment, background inert and top-layer stacking are entirely
 * delegated to the native `<dialog>` `showModal()` — no hand-rolled focus
 * trap.
 */
export declare class LoaderContainerComponent implements OnDestroy {
    private readonly loaderService;
    variant: import("@angular/core").InputSignal<PgLoaderVariant>;
    size: import("@angular/core").InputSignal<PgLoaderSize>;
    label: import("@angular/core").InputSignal<string>;
    color: import("@angular/core").InputSignal<PgLoaderColor>;
    title: import("@angular/core").InputSignal<string | undefined>;
    description: import("@angular/core").InputSignal<string | undefined>;
    delayBeforeShow: import("@angular/core").InputSignal<number>;
    minDisplayTime: import("@angular/core").InputSignal<number>;
    protected readonly dialogRef: import("@angular/core").Signal<ElementRef<HTMLDialogElement>>;
    constructor();
    /** Blocks ESC dismissal — the overlay is non-dismissible by design. */
    protected onCancel(event: Event): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoaderContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoaderContainerComponent, "pg-loader-container", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "delayBeforeShow": { "alias": "delayBeforeShow"; "required": false; "isSignal": true; }; "minDisplayTime": { "alias": "minDisplayTime"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
