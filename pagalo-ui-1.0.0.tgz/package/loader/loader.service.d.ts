import { Observable } from 'rxjs';
import { PgLoaderPhase, PgLoaderTimingConfig } from './loader.types';
import * as i0 from "@angular/core";
export declare class LoaderService {
    private _count;
    private _phase;
    private _timing;
    private _delayTimerId;
    private _minTimerId;
    /** Readonly reference counter, exposed for debugging/devtools. */
    readonly pendingCount: import("@angular/core").Signal<number>;
    /** Readonly FSM state, exposed for tests/devtools. */
    readonly phase: import("@angular/core").Signal<PgLoaderPhase>;
    /** True while the overlay is (or must remain) rendered. */
    readonly isVisible: import("@angular/core").Signal<boolean>;
    configure(config: Partial<PgLoaderTimingConfig>): void;
    show(): void;
    hide(): void;
    /**
     * Wraps a `Promise` so the overlay counter reflects its lifetime: `show()`
     * is called immediately, and `hide()` runs in a `finally` block so it
     * fires on BOTH resolve and reject — the settle value/error is passed
     * through unchanged.
     */
    wrap<T>(work: Promise<T>): Promise<T>;
    /**
     * Wraps an `Observable` so the overlay counter reflects each
     * subscription's lifetime. Uses `defer()` so `show()` only runs on
     * subscribe (not on call), matching reference-counting semantics: two
     * independent subscriptions to the returned observable count as two. Uses
     * `finalize()` so `hide()` runs on complete, error, AND unsubscribe.
     */
    track<T>(source$: Observable<T>): Observable<T>;
    /**
     * Escape hatch: force the overlay closed and the counter to 0, cancelling
     * BOTH pending timers regardless of the current phase. Bypasses
     * `minDisplayTime` on purpose — this is for router guards / error
     * boundaries, not a normal hide.
     */
    reset(): void;
    /**
     * The single imperative state-machine step. Deliberately NOT an
     * Angular `effect()`: effects are microtask-batched and can collapse a
     * same-tick show()+hide() pair, silently missing the 0<->0 boundary
     * crossing the FSM depends on.
     */
    private transition;
    private scheduleDelayTimer;
    private clearDelayTimer;
    private scheduleMinTimer;
    private clearMinTimer;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoaderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoaderService>;
}
