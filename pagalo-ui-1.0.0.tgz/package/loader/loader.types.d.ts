export type PgLoaderVariant = 'spinner' | 'dots' | 'pulse-ring' | 'brand' | 'second-variant';
export type PgLoaderSize = 'sm' | 'md' | 'lg' | 'xl';
export type PgLoaderColor = 'primary' | 'secondary';
export type PgLoaderPhase = 'idle' | 'pending-show' | 'visible-locked' | 'visible-free' | 'hide-pending';
export interface PgLoaderTimingConfig {
    delayBeforeShow: number;
    minDisplayTime: number;
}
