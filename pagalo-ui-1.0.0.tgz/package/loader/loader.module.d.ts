import * as i0 from "@angular/core";
import * as i1 from "./loader.component";
import * as i2 from "./loader-container.component";
export declare class PgLoaderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgLoaderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgLoaderModule, never, [typeof i1.PgLoaderComponent, typeof i2.LoaderContainerComponent], [typeof i1.PgLoaderComponent, typeof i2.LoaderContainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgLoaderModule>;
}
