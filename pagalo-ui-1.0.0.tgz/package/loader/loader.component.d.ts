import { PgLoaderVariant, PgLoaderSize, PgLoaderColor } from './loader.types';
import * as i0 from "@angular/core";
/**
 * Pure presentational animated SVG loader. Zero service knowledge — safe to reuse
 * standalone (e.g. inline inside a button or card) independent of the global
 * `LoaderService`/`LoaderContainerComponent` overlay.
 */
export declare class PgLoaderComponent {
    variant: import("@angular/core").InputSignal<PgLoaderVariant>;
    size: import("@angular/core").InputSignal<PgLoaderSize>;
    label: import("@angular/core").InputSignal<string>;
    color: import("@angular/core").InputSignal<PgLoaderColor>;
    title: import("@angular/core").InputSignal<string | undefined>;
    description: import("@angular/core").InputSignal<string | undefined>;
    protected hostClass: import("@angular/core").Signal<string>;
    protected brandSvg: string;
    protected secondVariantSvg: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgLoaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PgLoaderComponent, "pg-loader", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
