import * as i0 from "@angular/core";
export declare class DrawerFooterComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DrawerFooterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DrawerFooterComponent, "pg-drawer-footer", never, {}, {}, never, ["*"], true, never>;
}
