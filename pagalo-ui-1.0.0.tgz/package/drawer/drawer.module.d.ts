import * as i0 from "@angular/core";
import * as i1 from "./drawer.component";
import * as i2 from "./drawer-content.component";
import * as i3 from "./drawer-footer.component";
import * as i4 from "./drawer-header.component";
export declare class PgDrawerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgDrawerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgDrawerModule, never, [typeof i1.DrawerComponent, typeof i2.DrawerContentComponent, typeof i3.DrawerFooterComponent, typeof i4.DrawerHeaderComponent], [typeof i1.DrawerComponent, typeof i2.DrawerContentComponent, typeof i3.DrawerFooterComponent, typeof i4.DrawerHeaderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgDrawerModule>;
}
