import * as i0 from "@angular/core";
export declare class DrawerHeaderComponent {
    showClose: import("@angular/core").InputSignal<boolean>;
    private readonly el;
    private readonly drawer;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DrawerHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DrawerHeaderComponent, "pg-drawer-header", never, { "showClose": { "alias": "showClose"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
