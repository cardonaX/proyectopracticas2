import { PgDialogBase } from '@pagalo/ui/core';
import * as i0 from "@angular/core";
export type DrawerSize = 'sm' | 'md' | 'lg' | 'xl' | '2xl' | 'full';
export declare class DrawerComponent extends PgDialogBase {
    private readonly idService;
    private readonly _autoId;
    readonly panelEnterDurationMs = 500;
    readonly panelExitDurationMs = 500;
    size: import("@angular/core").InputSignal<DrawerSize>;
    id: import("@angular/core").InputSignal<string>;
    /** ID resuelto: usa el input `id` si se provee, sino genera uno automáticamente. */
    readonly dialogId: import("@angular/core").Signal<string>;
    readonly titleId: import("@angular/core").Signal<string>;
    readonly sizeClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DrawerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DrawerComponent, "pg-drawer", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
