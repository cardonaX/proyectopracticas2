import * as i0 from "@angular/core";
export declare class DrawerContentComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DrawerContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DrawerContentComponent, "pg-drawer-content", never, {}, {}, never, ["*"], true, never>;
}
