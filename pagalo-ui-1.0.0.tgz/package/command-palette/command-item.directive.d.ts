import { Highlightable, ListKeyManagerOption } from '@angular/cdk/a11y';
import type { CommandItem } from './command-palette.component';
import * as i0 from "@angular/core";
/**
 * Marks an item `<a>` inside `pg-command-palette` as a keyboard-navigable
 * option. Implements CDK `Highlightable` (active/inactive styling driven by
 * `ActiveDescendantKeyManager`) and `ListKeyManagerOption` (label for
 * typeahead). Mirrors `PgSelectOptionComponent`'s role in `pg-select`,
 * adapted to a directive since each command-palette variant renders very
 * different markup around the same `<a>`.
 *
 * @internal
 */
export declare class PgCommandItemDirective implements Highlightable, ListKeyManagerOption {
    private readonly idService;
    private readonly elementRef;
    readonly id: string;
    readonly item: import("@angular/core").InputSignal<CommandItem>;
    /** No item-level disabled concept in `CommandItem` today — always keyboard-reachable. */
    readonly disabled = false;
    private readonly _active;
    readonly active: import("@angular/core").Signal<boolean>;
    setActiveStyles(): void;
    setInactiveStyles(): void;
    getLabel(): string;
    scrollIntoViewIfNeeded(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgCommandItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PgCommandItemDirective, "[pgCommandItem]", never, { "item": { "alias": "pgCommandItem"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
