import { EventEmitter } from '@angular/core';
import { ActiveDescendantKeyManager } from '@angular/cdk/a11y';
import { PgDialogBase } from '@pagalo/ui/core';
import { PgCommandItemDirective } from './command-item.directive';
import * as i0 from "@angular/core";
export type CommandPaletteVariant = 'simple' | 'simple-padding' | 'with-preview' | 'with-icons';
export interface CommandItem {
    id: string;
    title: string;
    description?: string;
    url?: string;
    icon?: string;
    bgColor?: string;
    image?: string;
    email?: string;
    phone?: string;
    role?: string;
    shortcut?: string;
}
export interface CommandGroup {
    name: string;
    items: CommandItem[];
}
export declare class CommandPaletteComponent extends PgDialogBase {
    private readonly idService;
    private readonly router;
    private readonly destroyRef;
    readonly panelEnterDurationMs = 300;
    readonly panelExitDurationMs = 200;
    variant: import("@angular/core").InputSignal<CommandPaletteVariant>;
    openButtonText: import("@angular/core").InputSignal<string>;
    placeholder: import("@angular/core").InputSignal<string>;
    items: import("@angular/core").InputSignal<CommandItem[] | CommandGroup[]>;
    recentItems: import("@angular/core").InputSignal<CommandItem[]>;
    /** ID único generado para este dialog. Elimina el id="dialog" hardcodeado. */
    readonly dialogId: string;
    readonly searchInputId: string;
    readonly listboxId: string;
    searchQuery: import("@angular/core").WritableSignal<string>;
    /** Emite cuando el usuario selecciona un item de la lista. */
    itemSelected: EventEmitter<CommandItem>;
    /**
     * Navegación por teclado para las 4 variantes (with-preview incluida desde PR4c).
     * Se reconstruye cada vez que cambian los items renderizados (nuevo filtro,
     * variante, o apertura/cierre). Mismo patrón que `select-base.directive.ts`:
     * no activa un item por defecto, el usuario navega con flechas primero.
     */
    protected readonly commandItems: import("@angular/core").Signal<readonly PgCommandItemDirective[]>;
    protected keyManager: ActiveDescendantKeyManager<PgCommandItemDirective> | null;
    readonly activeItemId: import("@angular/core").WritableSignal<string | null>;
    /** Item activo con sus datos completos, para el panel de preview de la variante with-preview. */
    readonly activeCommandItem: import("@angular/core").WritableSignal<CommandItem | null>;
    private readonly _keyManagerEffect;
    hasGroups: import("@angular/core").Signal<boolean>;
    filteredItems: import("@angular/core").Signal<CommandItem[] | CommandGroup[]>;
    getFlatFilteredItems(): CommandItem[];
    getGroups(): CommandGroup[];
    hasResults: import("@angular/core").Signal<boolean>;
    onSearch(event: Event): void;
    /** Maneja flechas/Home/End/Enter sobre la lista para simple/simple-padding/with-icons. */
    handleKeydown(event: KeyboardEvent): void;
    /** Selecciona un item y emite el output itemSelected. Cierra el dialog. */
    selectItem(item: CommandItem): void;
    /**
     * Heurística simple para distinguir URLs internas de externas: si empieza
     * con http://, https://, // (protocol-relative) o mailto:/tel:, se considera
     * externa y se deja que la navegación nativa del <a> siga su curso.
     */
    private isInternalUrl;
    /**
     * Maneja el click en un item de la lista. Si hay Router disponible (uso
     * standalone del componente sin RouterModule) y la URL es interna, previene
     * la navegación nativa del <a> y navega vía Router para preservar el
     * comportamiento de SPA. Para URLs externas, mailto:, tel:, o sin Router
     * disponible, deja que el <a> navegue de forma nativa. En ambos casos
     * preserva el comportamiento de selección/cierre existente.
     */
    onItemClick(event: MouseEvent, item: CommandItem): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommandPaletteComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CommandPaletteComponent, "pg-command-palette", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "openButtonText": { "alias": "openButtonText"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": false; "isSignal": true; }; "recentItems": { "alias": "recentItems"; "required": false; "isSignal": true; }; }, { "itemSelected": "itemSelected"; }, never, never, true, never>;
}
