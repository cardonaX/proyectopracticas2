import * as i0 from "@angular/core";
import * as i1 from "./command-palette.component";
export declare class PgCommandPaletteModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgCommandPaletteModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgCommandPaletteModule, never, [typeof i1.CommandPaletteComponent], [typeof i1.CommandPaletteComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgCommandPaletteModule>;
}
