import { AfterViewInit, ElementRef, OnDestroy } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Abstract base for components backed by the native Popover API
 * (e.g. dropdown menus, tooltips, generic popovers).
 *
 * Sister of PgDialogBase, but bound to:
 *   - element.showPopover() / hidePopover() / togglePopover()
 *   - native 'toggle' event (event.newState === 'open' | 'closed')
 *
 * Usage:
 *   1. Subclass extends PgPopoverBase.
 *   2. Template has an element with the `popover` attribute and ref #popoverRef.
 *   3. Subclass re-declares popoverRef = viewChild.required<ElementRef<HTMLElement>>('popoverRef').
 *
 * @internal Re-exported from @pagalo/ui/core for subclass use only.
 */
export declare abstract class PgPopoverBase implements AfterViewInit, OnDestroy {
    /** Two-way binding to control the visibility of the popover. */
    readonly isOpen: import("@angular/core").ModelSignal<boolean>;
    /** Emitted when the popover opens. */
    readonly opened: import("@angular/core").OutputEmitterRef<void>;
    /** Emitted when the popover closes. */
    readonly closed: import("@angular/core").OutputEmitterRef<void>;
    /**
     * Reference to the native popover element.
     * Subclasses MUST re-declare this property:
     * ```ts
     * override readonly popoverRef = viewChild.required<ElementRef<HTMLElement>>('popoverRef');
     * ```
     */
    readonly popoverRef: import("@angular/core").Signal<ElementRef<HTMLElement>>;
    /**
     * Anti-loop flag: DOM → model updates must NOT trigger model → DOM in the same tick.
     */
    private syncing;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private onNativeToggle;
    /** Opens the popover programmatically. No-op if already open. */
    open(): void;
    /** Closes the popover programmatically. No-op if already closed. */
    close(): void;
    /** Toggles the popover open/closed. */
    toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgPopoverBase, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PgPopoverBase, never, never, { "isOpen": { "alias": "isOpen"; "required": false; "isSignal": true; }; }, { "isOpen": "isOpenChange"; "opened": "opened"; "closed": "closed"; }, never, never, true, never>;
}
