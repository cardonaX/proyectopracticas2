import { AfterViewInit, ElementRef, OnDestroy } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Clase base abstracta para componentes de diálogo (Modal, Drawer, CommandPalette).
 *
 * Gestiona el ciclo de vida del `<dialog>` nativo con sincronización bidireccional.
 *
 * Uso:
 * 1. El componente concreto extiende `PgDialogBase`.
 * 2. El template debe tener un `<dialog #dialogRef>`.
 * 3. Heredar y re-declarar `dialogRef = viewChild.required<ElementRef<HTMLDialogElement>>('dialogRef')`.
 *
 * @internal No exportar en ningún public-api.ts
 */
export declare abstract class PgDialogBase implements AfterViewInit, OnDestroy {
    /**
     * Two-way binding para controlar la visibilidad del dialog.
     * Uso: `<pg-modal [(isOpen)]="show">`
     */
    readonly isOpen: import("@angular/core").ModelSignal<boolean>;
    /** Se emite cuando el dialog se abre completamente. */
    readonly opened: import("@angular/core").OutputEmitterRef<void>;
    /** Se emite cuando el dialog se cierra (por cualquier razón). */
    readonly closed: import("@angular/core").OutputEmitterRef<void>;
    /**
     * Se emite cuando el usuario cierra el dialog activamente
     * (ESC o click fuera del panel), sin ser una acción del host.
     */
    readonly dismissed: import("@angular/core").OutputEmitterRef<void>;
    /**
     * Referencia al elemento `<dialog>` nativo.
     * Las subclases DEBEN re-declarar esta propiedad:
     * ```ts
     * override readonly dialogRef = viewChild.required<ElementRef<HTMLDialogElement>>('dialogRef');
     * ```
     */
    readonly dialogRef: import("@angular/core").Signal<ElementRef<HTMLDialogElement>>;
    /**
     * True mientras corre la animación de salida (entre `close()` y el `el.close()` real).
     * Las subclases la leen desde el template para aplicar la clase/estado de transición CSS.
     */
    readonly isClosing: import("@angular/core").WritableSignal<boolean>;
    /**
     * Duración (ms) de la animación de salida antes de soltar el `<dialog>` del top layer.
     * Cada subclase la overridea (`override readonly`) según su propia transición CSS (Modal, Drawer, etc.).
     */
    readonly panelExitDurationMs: number;
    /** Duración (ms) de la animación de entrada, para el binding `[style.animation-duration.ms]` del template. */
    readonly panelEnterDurationMs: number;
    /**
     * Flag para evitar loops: cuando el DOM actualiza el model (vía evento close/cancel),
     * el effect no debe volver a llamar close() en el elemento nativo.
     */
    private syncing;
    private closeTimeoutHandle;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /**
     * Hook para que subclases condicionen el cierre por backdrop-click/ESC
     * (p.ej. `AlertModalComponent` respeta `allowOutsideClick`/`allowEscapeKey`).
     * Default: siempre permite el cierre — comportamiento actual sin cambios
     * para Modal/Drawer/CommandPalette.
     */
    protected canDismiss(source: 'backdrop' | 'escape'): boolean;
    /** Click en el backdrop: cierra el dialog animando la salida y marca que fue el usuario. */
    onBackdropClick(): void;
    private cancelPendingClose;
    private onNativeClose;
    private onNativeCancel;
    /** Abre el dialog programáticamente. */
    open(): void;
    /** Cierra el dialog programáticamente. */
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgDialogBase, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PgDialogBase, never, never, { "isOpen": { "alias": "isOpen"; "required": false; "isSignal": true; }; }, { "isOpen": "isOpenChange"; "opened": "opened"; "closed": "closed"; "dismissed": "dismissed"; }, never, never, true, never>;
}
