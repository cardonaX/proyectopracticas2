import * as i0 from "@angular/core";
/**
 * Servicio interno para generación de IDs únicos, SSR-safe.
 *
 * Implementa un fallback de 3 paths:
 * 1. `crypto.randomUUID()` — Node 19+ y browsers modernos
 * 2. `crypto.getRandomValues()` — Node 18 y browsers más antiguos
 * 3. Counter monotónico + prefijo de instancia — entornos sin crypto API
 *
 * @internal No exportar en ningún public-api.ts
 */
export declare class IdService {
    private counter;
    private readonly instancePrefix;
    /**
     * Genera un ID único con prefijo opcional.
     * @example generate('pg-input') → 'pg-input-3f2a1b4c'
     */
    generate(prefix?: string): string;
    private uniqueSuffix;
    private computeInstancePrefix;
    static ɵfac: i0.ɵɵFactoryDeclaration<IdService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IdService>;
}
