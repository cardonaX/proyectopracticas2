import { OnInit } from '@angular/core';
import { ControlValueAccessor, NgControl } from '@angular/forms';
import * as i0 from "@angular/core";
/**
 * Clase base abstracta para componentes que implementan ControlValueAccessor.
 *
 * Uso: `extends PgControlValueAccessorBase<T>` en el componente concreto.
 * El componente concreto debe registrar NG_VALUE_ACCESSOR en sus providers:
 * ```ts
 * providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => MiComponent), multi: true }]
 * ```
 *
 * NOTA: No se hace self-injection de NgControl en el constructor para evitar
 * circular dependency con NG_VALUE_ACCESSOR. El NgControl se resuelve en ngOnInit.
 *
 * @internal No exportar en ningún public-api.ts
 */
export declare abstract class PgControlValueAccessorBase<T> implements ControlValueAccessor, OnInit {
    private readonly injector;
    protected readonly _value: import("@angular/core").WritableSignal<T | null>;
    protected readonly _disabled: import("@angular/core").WritableSignal<boolean>;
    protected readonly _touched: import("@angular/core").WritableSignal<boolean>;
    protected ngControl: NgControl | null;
    protected _onChange: (value: T | null) => void;
    protected _onTouched: () => void;
    readonly value: import("@angular/core").Signal<T | null>;
    readonly disabled: import("@angular/core").Signal<boolean>;
    readonly touched: import("@angular/core").Signal<boolean>;
    /**
     * Indica si el control asociado tiene errores y fue tocado/modificado.
     * Si no hay NgControl asociado, retorna false (uso sin Forms).
     * Las subclases pueden hacer override para agregar lógica adicional.
     */
    readonly hasError: import("@angular/core").Signal<boolean>;
    /**
     * Resuelve NgControl post-construcción para evitar circular dependency.
     * Las subclases que implementen ngOnInit DEBEN llamar super.ngOnInit().
     */
    ngOnInit(): void;
    writeValue(value: T | null): void;
    registerOnChange(fn: (value: T | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    /**
     * Llamar desde el evento DOM del input (input, change) para notificar a Angular Forms.
     * `public` para que directivas colaboradoras (ej: InputDirective) puedan llamarlo.
     */
    setValue(value: T | null): void;
    /**
     * Llamar al blur para marcar el control como touched.
     * `public` para que directivas colaboradoras (ej: InputDirective) puedan llamarlo.
     */
    markAsTouched(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgControlValueAccessorBase<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PgControlValueAccessorBase<any>, never, never, {}, {}, never, never, true, never>;
}
