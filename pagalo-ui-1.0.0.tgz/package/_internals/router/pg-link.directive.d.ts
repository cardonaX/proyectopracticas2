import * as i0 from "@angular/core";
export declare class PgLinkDirective {
    readonly pgLink: import("@angular/core").InputSignal<string | any[]>;
    private readonly router;
    protected readonly _href: import("@angular/core").Signal<string | null>;
    protected _onClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgLinkDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PgLinkDirective, "[pgLink]", never, { "pgLink": { "alias": "pgLink"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
