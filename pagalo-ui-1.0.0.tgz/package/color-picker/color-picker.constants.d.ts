/**
 * Default preset palette: one Tailwind `-500` shade per curated color
 * family (green, emerald, blue, indigo, violet, purple, fuchsia, pink,
 * rose, red, orange, amber). Used as the `[presetColors]` fallback for the
 * `swatch-grid` and `palette` variants whenever the consumer leaves that
 * input unbound. Independent of `[savedColors]`.
 */
export declare const PG_DEFAULT_PRESET_COLORS: readonly string[];
/**
 * `generateSpectrumGrid()` step constants (design D6): 12 hue columns x 9
 * rows. Column `i` sits at hue `i * PG_SPECTRUM_HUE_STEP_DEG` (0..330). Row
 * 0 is a neutral (fully desaturated) brightness ramp; rows 1-8 are per-hue
 * levels — the first `PG_SPECTRUM_TINT_ROWS` are saturation tints at full
 * brightness, the remaining rows are brightness shades at full saturation.
 */
export declare const PG_SPECTRUM_COLUMNS = 12;
export declare const PG_SPECTRUM_ROWS = 9;
export declare const PG_SPECTRUM_HUE_STEP_DEG: number;
export declare const PG_SPECTRUM_TINT_ROWS = 4;
export declare const PG_SPECTRUM_SATURATION_STEP = 25;
export declare const PG_SPECTRUM_BRIGHTNESS_SHADE_STEP = 20;
