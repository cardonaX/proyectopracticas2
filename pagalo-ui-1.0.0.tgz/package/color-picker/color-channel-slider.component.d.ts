import * as i0 from "@angular/core";
export type PgColorChannel = 'hue' | 'alpha';
/**
 * Hue or alpha channel control. Uses a native `<input type="range">` so
 * keyboard interaction and form semantics come for free from the browser
 * (spec requirement "Channel Sliders Keyboard & ARIA") — this component
 * never intercepts keydown. The alpha channel renders over the shared
 * checkerboard background (design D8) so full transparency stays visible.
 */
export declare class PgColorChannelSliderComponent {
    channel: import("@angular/core").InputSignal<PgColorChannel>;
    /** Hue: 0-360 degrees. Alpha: 0-1. */
    value: import("@angular/core").InputSignal<number>;
    /** Current hue (0-360) — only used to color the alpha track's opaque end. */
    hue: import("@angular/core").InputSignal<number>;
    disabled: import("@angular/core").InputSignal<boolean>;
    readonly valueChange: import("@angular/core").OutputEmitterRef<number>;
    readonly ariaLabel: import("@angular/core").Signal<"Hue" | "Alpha">;
    readonly valueText: import("@angular/core").Signal<string>;
    readonly hueOpaqueColor: import("@angular/core").Signal<string>;
    onInput(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgColorChannelSliderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PgColorChannelSliderComponent, "pg-color-channel-slider", never, { "channel": { "alias": "channel"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "hue": { "alias": "hue"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
