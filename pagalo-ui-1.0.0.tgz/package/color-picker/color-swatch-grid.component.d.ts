import { ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Roving-tabindex color grid — serves the preset palette, the saved-colors
 * row, AND the `palette` variant's generated spectrum, all via the same
 * `role="grid"`/`gridcell` + `FocusKeyManager` contract (pattern mirrors
 * `dropdown-menu.component.ts`'s `MenuItemFocusableOption`/key-manager
 * wiring). Enter/Space select the active cell; Delete removes it, but only
 * when `[removable]` is set (saved swatches only — spec requirement
 * "Swatch Grid Keyboard & ARIA").
 */
export declare class PgColorSwatchGridComponent {
    private readonly destroyRef;
    colors: import("@angular/core").InputSignal<readonly string[]>;
    selected: import("@angular/core").InputSignal<string | null>;
    /** Allows Delete/Backspace to remove the active cell — saved-colors grids only. */
    removable: import("@angular/core").InputSignal<boolean>;
    ariaLabel: import("@angular/core").InputSignal<string>;
    disabled: import("@angular/core").InputSignal<boolean>;
    /** Cell size — `'sm'` for the `swatch-grid` variant's `density="compact"`. */
    size: import("@angular/core").InputSignal<"sm" | "md">;
    /**
     * Column count for a REAL 2D grid (e.g. `palette`'s 12x9 spectrum: pass
     * `12`). Omitted/`null` (the default) keeps the flat 1D roving-tabindex
     * list every other swatch grid (presets, saved colors) already uses —
     * that shape is a single logical row, so a dedicated `columns` isn't
     * meaningful for it.
     */
    columns: import("@angular/core").InputSignal<number | null>;
    readonly colorSelected: import("@angular/core").OutputEmitterRef<string>;
    readonly colorRemoved: import("@angular/core").OutputEmitterRef<string>;
    protected readonly cellRefs: import("@angular/core").Signal<readonly ElementRef<HTMLButtonElement>[]>;
    /**
     * Cell indices grouped by DOM row. A single group (one `role="row"`) when
     * `[columns]` is unset/`<= 1`/`>=` the cell count — matches every existing
     * 1D usage exactly. Multiple groups (one `role="row"` each) when `columns`
     * genuinely describes a 2D layout, giving real per-row ARIA structure
     * instead of one `role="row"` wrapping every cell.
     */
    protected readonly rowGroups: import("@angular/core").Signal<number[][]>;
    protected readonly isGrid2D: import("@angular/core").Signal<boolean>;
    private keyManager;
    readonly activeIndex: import("@angular/core").WritableSignal<number>;
    constructor();
    isActive(index: number): boolean;
    onCellClick(index: number, hex: string): void;
    onGridKeydown(event: KeyboardEvent): void;
    /**
     * Real row/column-aware navigation for a genuine 2D grid (`[columns]`
     * set — e.g. `palette`'s 12x9 spectrum). `FocusKeyManager`'s
     * `ListKeyManager` is flat/1D: its `vertical`/`horizontal` orientation
     * flags both walk the SAME underlying array by ±1, so without this,
     * ArrowUp/ArrowDown would be indistinguishable from ArrowLeft/ArrowRight
     * (the bug this method fixes).
     *
     * Decisions (no spec/design mandate beyond "12 hue columns x 9 rows" +
     * WAI-ARIA grid semantics, so documented here):
     * - ArrowLeft/ArrowRight move within the current row and CLAMP at its
     *   edges — no wrap into the adjacent row, so a boundary press is a
     *   deliberate no-op rather than a surprising jump to a different row.
     * - ArrowUp/ArrowDown move by a full row (±`columns`) and CLAMP at the
     *   grid's top/bottom for the same reason.
     * - Home/End move to the current row's start/end (mirrors native
     *   spreadsheet/grid widgets); Ctrl+Home/Ctrl+End jump to the whole
     *   grid's first/last cell.
     */
    private handle2DNavigation;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgColorSwatchGridComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PgColorSwatchGridComponent, "pg-color-swatch-grid", never, { "colors": { "alias": "colors"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "removable": { "alias": "removable"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "columns": { "alias": "columns"; "required": false; "isSignal": true; }; }, { "colorSelected": "colorSelected"; "colorRemoved": "colorRemoved"; }, never, never, true, never>;
}
