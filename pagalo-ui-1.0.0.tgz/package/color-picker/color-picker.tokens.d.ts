import { InjectionToken } from '@angular/core';
import { ScrollStrategy } from '@angular/cdk/overlay';
/**
 * Injection token to override the CDK scroll strategy used by
 * `pg-color-picker`'s panel. Defaults to `reposition({ autoClose: true })`
 * so the panel follows its trigger on scroll/resize instead of closing or
 * freezing page scroll. Mirrors `PG_SELECT_SCROLL_STRATEGY`
 * (`select/select.tokens.ts`). Override by providing this token at the
 * app/module level; not part of the per-component public API surface.
 */
export declare const PG_COLOR_PICKER_SCROLL_STRATEGY: InjectionToken<() => ScrollStrategy>;
