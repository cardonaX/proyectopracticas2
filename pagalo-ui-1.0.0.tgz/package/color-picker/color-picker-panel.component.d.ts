import { PgColorFormat, PgColorPickerVariant, PgHsb, PgSwatchDensity } from './color-picker.types';
import * as i0 from "@angular/core";
/**
 * Internal presentational panel — composes the shared primitives per
 * `variant()` (design's variant composition table). Owns zero forms logic:
 * every primitive event is relayed upward via this component's own outputs,
 * and the shell (`PgColorPickerComponent`) is the single CVA/state owner.
 * Also the seam for a future D1 Popover migration (design note).
 */
export declare class PgColorPickerPanelComponent {
    variant: import("@angular/core").InputSignal<PgColorPickerVariant>;
    density: import("@angular/core").InputSignal<PgSwatchDensity>;
    hsb: import("@angular/core").InputSignal<PgHsb>;
    alpha: import("@angular/core").InputSignal<number>;
    format: import("@angular/core").InputSignal<PgColorFormat>;
    presetColors: import("@angular/core").InputSignal<readonly string[]>;
    savedColors: import("@angular/core").InputSignal<readonly string[]>;
    disabled: import("@angular/core").InputSignal<boolean>;
    readonly hsbChange: import("@angular/core").OutputEmitterRef<PgHsb>;
    readonly alphaChange: import("@angular/core").OutputEmitterRef<number>;
    /**
     * Fired instead of `hsbChange`/`alphaChange` when both change together as
     * one atomic user action (format-input commit, preset/spectrum/saved
     * swatch selection) — keeps the shell's `(colorChange)` a single emission
     * per gesture rather than two.
     */
    readonly colorCommit: import("@angular/core").OutputEmitterRef<{
        hsb: PgHsb;
        alpha: number;
    }>;
    readonly formatChange: import("@angular/core").OutputEmitterRef<PgColorFormat>;
    readonly savedColorAdded: import("@angular/core").OutputEmitterRef<string>;
    readonly savedColorRemoved: import("@angular/core").OutputEmitterRef<string>;
    readonly savedColorSelected: import("@angular/core").OutputEmitterRef<string>;
    readonly allFormats: readonly PgColorFormat[];
    readonly hexOnlyFormats: readonly PgColorFormat[];
    readonly currentColor: import("@angular/core").Signal<import("@pagalo/ui/color-picker").PgColor>;
    /**
     * Flattened `generateSpectrumGrid()` (design D6: 12 hue columns x 9 rows =
     * 108 cells), rendered as ONE `pg-color-swatch-grid` instance with
     * `[columns]="spectrumColumns"` so it gets REAL 2D grid semantics (one
     * `role="row"` per row of 12 cells, ArrowUp/ArrowDown move a full row) —
     * see `color-swatch-grid.component.ts`'s `handle2DNavigation`.
     */
    readonly flatSpectrum: import("@angular/core").Signal<string[]>;
    readonly spectrumColumns = 12;
    readonly swatchSize: import("@angular/core").Signal<"sm" | "md">;
    onSaturationChange(s: number): void;
    onBrightnessChange(b: number): void;
    /**
     * Pointer-driven gradient-surface update: both axes come from ONE physical
     * gesture and MUST be merged into the next `hsb` value in a single atomic
     * spread. Splitting this into two separate `hsbChange` emissions (one per
     * axis, like `onSaturationChange`/`onBrightnessChange` above) would race:
     * this panel's own `hsb` INPUT signal only reflects the shell's committed
     * state after a full round trip through the parent, and no CD tick runs
     * between two synchronous emissions in the same pointer event — so the
     * second emit would read a stale `hsb()` and clobber the first axis.
     */
    onPositionChange(position: {
        saturation: number;
        brightness: number;
    }): void;
    onHueChange(h: number): void;
    onAlphaInput(a: number): void;
    onFormatSelect(f: PgColorFormat): void;
    onCommit(parsed: {
        hsb: PgHsb;
        alpha: number;
    }): void;
    onPresetSelected(hex: string): void;
    onSpectrumSelected(hex: string): void;
    onSavedSelected(hex: string): void;
    onSavedRemoved(hex: string): void;
    onAddSaved(): void;
    private applyHex;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgColorPickerPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PgColorPickerPanelComponent, "pg-color-picker-panel", never, { "variant": { "alias": "variant"; "required": true; "isSignal": true; }; "density": { "alias": "density"; "required": false; "isSignal": true; }; "hsb": { "alias": "hsb"; "required": true; "isSignal": true; }; "alpha": { "alias": "alpha"; "required": false; "isSignal": true; }; "format": { "alias": "format"; "required": false; "isSignal": true; }; "presetColors": { "alias": "presetColors"; "required": false; "isSignal": true; }; "savedColors": { "alias": "savedColors"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "hsbChange": "hsbChange"; "alphaChange": "alphaChange"; "colorCommit": "colorCommit"; "formatChange": "formatChange"; "savedColorAdded": "savedColorAdded"; "savedColorRemoved": "savedColorRemoved"; "savedColorSelected": "savedColorSelected"; }, never, never, true, never>;
}
