/**
 * RGB channel values, each in the `0`-`255` range.
 */
export interface PgRgb {
    r: number;
    g: number;
    b: number;
}
/**
 * HSL representation. `h` in `0`-`360` (degrees), `s`/`l` in `0`-`100` (percent).
 */
export interface PgHsl {
    h: number;
    s: number;
    l: number;
}
/**
 * HSB/HSV representation. `h` in `0`-`360` (degrees), `s`/`b` in `0`-`100` (percent).
 * This is the internal source of truth for `pg-color-picker` — see design D7.
 */
export interface PgHsb {
    h: number;
    s: number;
    b: number;
}
/**
 * Structured color payload emitted by `(colorChange)` on every committed
 * change. `hex` is `#RRGGBB`, or `#RRGGBBAA` when `alpha < 1`.
 */
export interface PgColor {
    hex: string;
    rgb: PgRgb;
    hsl: PgHsl;
    hsb: PgHsb;
    alpha: number;
}
/**
 * Text-entry / display representation selectable via the format selector.
 */
export type PgColorFormat = 'hex' | 'rgb' | 'hsl' | 'hsb';
/**
 * Panel layout composition. Variants differ only in which primitives the
 * internal panel renders — the shell component and its CVA contract are
 * identical across all four.
 */
export type PgColorPickerVariant = 'full' | 'minimal' | 'swatch-grid' | 'palette';
/**
 * Density for the `swatch-grid` variant. `'default'` shows a large preview
 * plus large swatches; `'compact'` shows small swatches plus a labeled
 * "Custom" hex input row.
 */
export type PgSwatchDensity = 'default' | 'compact';
