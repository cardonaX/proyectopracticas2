import { FormControl } from '@angular/forms';
import { PgSelectOption } from '@pagalo/ui/select';
import { PgColor, PgColorFormat, PgHsb } from './color-picker.types';
import * as i0 from "@angular/core";
/**
 * Format selector (Hex/RGB/HSL/HSB) + commit-on-confirm text entry (spec
 * requirements "Format Switching" and "Input Validation & Edge Cases").
 * Purely presentational/controlled: `color`/`format` are owned by the
 * shell, this component only ever proposes changes via `(formatChange)`
 * (switching format alone never touches the color) and `(commit)` (a
 * confirmed, already-clamped edit). Invalid text reverts to the last valid
 * value on blur without emitting.
 */
export declare class PgColorFormatInputComponent {
    private readonly renderer;
    private readonly idService;
    private readonly textInputRef;
    color: import("@angular/core").InputSignal<PgColor>;
    format: import("@angular/core").InputSignal<PgColorFormat>;
    /** Which formats the selector offers. A single entry hides the selector (e.g. `minimal`/`swatch-grid`/`palette` variants: hex only). */
    formats: import("@angular/core").InputSignal<readonly PgColorFormat[]>;
    disabled: import("@angular/core").InputSignal<boolean>;
    readonly formatChange: import("@angular/core").OutputEmitterRef<PgColorFormat>;
    readonly commit: import("@angular/core").OutputEmitterRef<{
        hsb: PgHsb;
        alpha: number;
    }>;
    readonly formatSelectId: string;
    readonly formatOptions: import("@angular/core").Signal<PgSelectOption<PgColorFormat>[]>;
    /**
     * `pg-select` only exposes disabled state through `ControlValueAccessor.setDisabledState`
     * (no plain `[disabled]` input) — a local `FormControl` is the only way to drive that,
     * kept in sync with the `format`/`disabled` inputs via the effects below.
     */
    readonly formatControl: FormControl<PgColorFormat>;
    /** Text currently shown in the input — diverges from `formatColor(color, format)` only while actively editing. */
    readonly draftText: import("@angular/core").WritableSignal<string>;
    private isEditing;
    constructor();
    onFocus(): void;
    onInput(event: Event): void;
    onBlur(): void;
    onKeydown(event: KeyboardEvent): void;
    private confirm;
    private revert;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgColorFormatInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PgColorFormatInputComponent, "pg-color-format-input", never, { "color": { "alias": "color"; "required": true; "isSignal": true; }; "format": { "alias": "format"; "required": false; "isSignal": true; }; "formats": { "alias": "formats"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "formatChange": "formatChange"; "commit": "commit"; }, never, never, true, never>;
}
