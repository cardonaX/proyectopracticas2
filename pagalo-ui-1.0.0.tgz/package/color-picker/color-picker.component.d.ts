import { ConnectedPosition, ScrollStrategy } from '@angular/cdk/overlay';
import { PgControlValueAccessorBase } from '@pagalo/ui/core';
import { PgColor, PgColorFormat, PgColorPickerVariant, PgHsb, PgSwatchDensity } from './color-picker.types';
import * as i0 from "@angular/core";
/**
 * `pg-color-picker` — accessible color selection with 4 layout variants
 * (`full`/`minimal`/`swatch-grid`/`palette`), always-on alpha, and
 * multi-format text entry. Single public component + CVA implementation
 * (design: "one component + conditional templates" — no per-variant base
 * directive needed, unlike `pg-select`). Trigger + `cdkConnectedOverlay`
 * panel mirror `select.component.html`'s overlay setup; the panel itself is
 * wrapped in `cdkTrapFocus` since opening it MUST trap focus (spec
 * requirement "Panel Focus Management").
 */
export declare class PgColorPickerComponent extends PgControlValueAccessorBase<string> {
    private readonly idService;
    private readonly renderer;
    private readonly _scrollStrategyFactory;
    private readonly _autoId;
    readonly scrollStrategy: ScrollStrategy;
    /** Primary bottom-start with a top-start flip fallback, plus horizontal shift variants. Mirrors `PgSelectBase`. */
    readonly overlayPositions: ConnectedPosition[];
    variant: import("@angular/core").InputSignal<PgColorPickerVariant>;
    density: import("@angular/core").InputSignal<PgSwatchDensity>;
    /** Two-way: reflects/drives the format-selector's currently displayed format. */
    format: import("@angular/core").ModelSignal<PgColorFormat>;
    presetColors: import("@angular/core").InputSignal<readonly string[] | undefined>;
    savedColors: import("@angular/core").InputSignal<readonly string[]>;
    placeholder: import("@angular/core").InputSignal<string>;
    readonly: import("@angular/core").InputSignal<boolean>;
    error: import("@angular/core").InputSignal<boolean | undefined>;
    forId: import("@angular/core").InputSignal<string>;
    customClass: import("@angular/core").InputSignal<string>;
    primaryColor: import("@angular/core").InputSignal<string>;
    readonly colorChange: import("@angular/core").OutputEmitterRef<PgColor>;
    readonly opened: import("@angular/core").OutputEmitterRef<void>;
    readonly closed: import("@angular/core").OutputEmitterRef<void>;
    readonly savedColorAdded: import("@angular/core").OutputEmitterRef<string>;
    readonly savedColorRemoved: import("@angular/core").OutputEmitterRef<string>;
    readonly savedColorSelected: import("@angular/core").OutputEmitterRef<string>;
    readonly computedForId: import("@angular/core").Signal<string>;
    readonly resolvedPresetColors: import("@angular/core").Signal<readonly string[]>;
    readonly hasError: import("@angular/core").Signal<boolean>;
    readonly triggerStateClasses: import("@angular/core").Signal<string>;
    private readonly _hsb;
    private readonly _alpha;
    /** Guards against re-deriving HSB from a hex string this component itself just emitted (lossy round trip at s=0/b=0). */
    private _lastEmittedHex;
    readonly currentColor: import("@angular/core").Signal<PgColor>;
    readonly isOpen: import("@angular/core").WritableSignal<boolean>;
    readonly isClosing: import("@angular/core").WritableSignal<boolean>;
    readonly panelEnterDurationMs = 150;
    readonly panelExitDurationMs = 200;
    private _closeTimeoutHandle;
    private readonly swatchBtnRef;
    private readonly valueInputRef;
    /** Text currently shown in the trigger's value input — diverges from `currentColor().hex` only while actively editing (mirrors `PgColorFormatInputComponent`'s draft pattern). */
    readonly draftHex: import("@angular/core").WritableSignal<string>;
    private _editingHex;
    constructor();
    writeValue(value: string | null): void;
    open(): void;
    close(): void;
    toggle(): void;
    onTriggerClick(): void;
    onEscape(): void;
    onValueFocus(): void;
    onValueInput(event: Event): void;
    onValueBlur(): void;
    onValueKeydown(event: KeyboardEvent): void;
    private confirmValueEdit;
    private revertValueEdit;
    onHsbChange(hsb: PgHsb): void;
    onAlphaChange(alpha: number): void;
    /** Atomic hsb+alpha commit (format-input confirm, swatch/spectrum/saved selection) — single `colorChange` emission. */
    onColorCommit(parsed: {
        hsb: PgHsb;
        alpha: number;
    }): void;
    onFormatChange(format: PgColorFormat): void;
    onSavedColorAdded(hex: string): void;
    onSavedColorRemoved(hex: string): void;
    onSavedColorSelected(hex: string): void;
    private commit;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgColorPickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PgColorPickerComponent, "pg-color-picker", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "density": { "alias": "density"; "required": false; "isSignal": true; }; "format": { "alias": "format"; "required": false; "isSignal": true; }; "presetColors": { "alias": "presetColors"; "required": false; "isSignal": true; }; "savedColors": { "alias": "savedColors"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "forId": { "alias": "forId"; "required": false; "isSignal": true; }; "customClass": { "alias": "customClass"; "required": false; "isSignal": true; }; "primaryColor": { "alias": "primaryColor"; "required": false; "isSignal": true; }; }, { "format": "formatChange"; "colorChange": "colorChange"; "opened": "opened"; "closed": "closed"; "savedColorAdded": "savedColorAdded"; "savedColorRemoved": "savedColorRemoved"; "savedColorSelected": "savedColorSelected"; }, never, never, true, never>;
}
