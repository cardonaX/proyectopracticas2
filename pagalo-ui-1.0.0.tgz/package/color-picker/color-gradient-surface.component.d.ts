import * as i0 from "@angular/core";
/**
 * Continuous 2D saturation/brightness handle for the `full` and `minimal`
 * variants. One focusable `role="slider"` element (spec requirement "2D
 * Handle Keyboard & ARIA"). Pointer dragging uses `setPointerCapture` so
 * the drag continues to track even when the pointer leaves the element's
 * bounds. `hue` positions the background gradient; this component owns no
 * hue state of its own.
 */
export declare class PgColorGradientSurfaceComponent {
    /** Hue (0-360) driving the surface's background color. */
    hue: import("@angular/core").InputSignal<number>;
    /** Current saturation, 0-100. */
    saturation: import("@angular/core").InputSignal<number>;
    /** Current brightness, 0-100. */
    brightness: import("@angular/core").InputSignal<number>;
    disabled: import("@angular/core").InputSignal<boolean>;
    /**
     * Discrete keyboard nav emits one axis at a time — `emitSaturation`/
     * `emitBrightness` below. Safe as separate outputs: each key press is one
     * full round trip (with an Angular CD tick before the next), so there is
     * no risk of a consumer reading a stale value.
     */
    readonly saturationChange: import("@angular/core").OutputEmitterRef<number>;
    readonly brightnessChange: import("@angular/core").OutputEmitterRef<number>;
    /**
     * Pointer drag computes BOTH axes from the same `PointerEvent` and MUST
     * emit them together, atomically. Two separate synchronous emissions
     * (formerly `saturationChange`+`brightnessChange` back-to-back) let a
     * consumer that merges via "spread current input, apply one field" read a
     * stale value on the second emit (no CD tick runs between two synchronous
     * emits in the same call stack) — clobbering the first axis. See
     * `updateFromPointer`.
     */
    readonly positionChange: import("@angular/core").OutputEmitterRef<{
        saturation: number;
        brightness: number;
    }>;
    private readonly surfaceRef;
    private pointerId;
    readonly hueBackgroundColor: import("@angular/core").Signal<string>;
    readonly valueText: import("@angular/core").Signal<string>;
    onPointerDown(event: PointerEvent): void;
    onPointerMove(event: PointerEvent): void;
    onPointerUp(event: PointerEvent): void;
    private updateFromPointer;
    onKeydown(event: KeyboardEvent): void;
    private emitSaturation;
    private emitBrightness;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgColorGradientSurfaceComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PgColorGradientSurfaceComponent, "pg-color-gradient-surface", never, { "hue": { "alias": "hue"; "required": true; "isSignal": true; }; "saturation": { "alias": "saturation"; "required": false; "isSignal": true; }; "brightness": { "alias": "brightness"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "saturationChange": "saturationChange"; "brightnessChange": "brightnessChange"; "positionChange": "positionChange"; }, never, never, true, never>;
}
