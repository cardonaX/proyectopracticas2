import { PgColor, PgColorFormat, PgHsb, PgHsl, PgRgb } from './color-picker.types';
/**
 * Parses `#RGB`, `#RGBA`, `#RRGGBB`, or `#RRGGBBAA` into RGB channel bytes
 * plus alpha (`0`-`1`). Returns `null` for anything else — never throws.
 */
export declare function parseHex(hex: string): {
    rgb: PgRgb;
    alpha: number;
} | null;
/** `#RRGGBB`, or `#RRGGBBAA` only when `alpha < 1` (CVA value contract). */
export declare function rgbToHex(rgb: PgRgb, alpha?: number): string;
export declare function rgbToHsb(rgb: PgRgb): PgHsb;
export declare function hsbToRgb(hsb: PgHsb): PgRgb;
export declare function rgbToHsl(rgb: PgRgb): PgHsl;
export declare function hslToRgb(hsl: PgHsl): PgRgb;
export declare function hsbToHex(hsb: PgHsb, alpha?: number): string;
export declare function hexToHsb(hex: string): PgHsb | null;
/** Builds a full `PgColor` payload (hex/rgb/hsl/hsb/alpha) from HSB + alpha. */
export declare function buildPgColor(hsb: PgHsb, alpha?: number): PgColor;
/** Formats a `PgColor` for display/editing in the given format. Never mutates the underlying color. */
export declare function formatColor(color: PgColor, format: PgColorFormat): string;
/**
 * Parses typed text per the given format back into HSB + alpha. Returns
 * `null` for anything that can't be confidently parsed — callers (the
 * format-input primitive) revert to the last valid value on `null` rather
 * than committing a bad one. Out-of-range numeric channels clamp to the
 * nearest bound instead of failing.
 */
export declare function parseColorInput(text: string, format: PgColorFormat): {
    hsb: PgHsb;
    alpha: number;
} | null;
/**
 * Generates the 9x12 `palette` variant spectrum grid at render time (design
 * D6) — a pure function of the step constants, never a stored dataset. Row
 * 0 is a neutral (fully desaturated) brightness ramp; rows 1-8 are per-hue
 * levels (saturation tints, then brightness shades), one column per hue
 * step around the wheel.
 */
export declare function generateSpectrumGrid(): readonly (readonly string[])[];
