export * from './safe-html.pipe';
export * from './pipe.module';
