import * as i0 from "@angular/core";
import * as i1 from "./safe-html.pipe";
export declare class PgPipeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgPipeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgPipeModule, never, [typeof i1.SafeHtmlPipe], [typeof i1.SafeHtmlPipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgPipeModule>;
}
