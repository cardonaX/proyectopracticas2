import { PgBookingEvent, PgEventPlacement, PgRowSegment } from './scheduler.types';
/** Zeroes hours/minutes/seconds/ms, keeping the calendar date. Never mutates the input. */
export declare function startOfDay(d: Date): Date;
/**
 * Advances (or, for negative `n`, retreats) `d` by `n` *calendar* days.
 * Built on `Date`'s calendar-component constructor (not raw ms arithmetic)
 * so results are correct across month/year rollovers and are unaffected by
 * any DST shift that may occur inside the span — DST-safety here is a
 * byproduct of operating on calendar fields, not wall-clock milliseconds.
 */
export declare function addDays(d: Date, n: number): Date;
/**
 * Whole calendar days between `a` and `b` (`a - b`), normalizing both
 * operands to `startOfDay` first. Uses `Math.round`, never `Math.floor`: if
 * a DST transition falls inside the span, the elapsed real time between two
 * local midnights is not an exact multiple of 24h (23h or 25h for that one
 * day), so `Math.floor` can silently drop a day on a "spring forward"
 * transition. Rounding to the nearest whole day is always correct because
 * both operands are already calendar-midnight-aligned.
 */
export declare function diffInDays(a: Date, b: Date): number;
/**
 * Intersects `[s, e)` with `[min, max)`. Returns `null` when the
 * intersection is empty (including a zero-width result), which callers use
 * as "do not render".
 */
export declare function clampRange(s: Date, e: Date, min: Date, max: Date): {
    start: Date;
    end: Date;
} | null;
/**
 * Places a single event against the currently visible period
 * `[visibleStart, visibleStart + visibleDays)`. Returns `null` when the
 * event does not intersect the visible period at all (spec: scheduler-events
 * "Out-of-range event"). `end` stays exclusive throughout, mirroring
 * `PgBookingEvent.end`.
 */
export declare function placeEvent(event: PgBookingEvent, visibleStart: Date, visibleDays: number): PgEventPlacement | null;
/**
 * Scanline row layout (design DD2). A `<table>` row is only valid if the sum
 * of `colspan` over its cells equals `visibleDays` — so this does not emit
 * "bars", it emits a complete ordered run of cells covering every column
 * exactly once:
 *
 * 1. Allocate one column slot per visible day, defaulting to "empty".
 * 2. Walk `events` in array order, writing each event's index into the
 *    columns it occupies — last write wins (proposal: overlap is out of v1
 *    scope, later array entries take visual precedence).
 * 3. Compress consecutive columns holding the same value into segments.
 *
 * If a later event splits an earlier one, the earlier event renders as two
 * segments; each is flagged `clippedLeft`/`clippedRight` on the seam side
 * (in addition to any real visible-period clipping), matching the design's
 * documented consequence of the scanline approach.
 */
export declare function layoutRow(events: PgBookingEvent[], visibleStart: Date, visibleDays: number): PgRowSegment[];
