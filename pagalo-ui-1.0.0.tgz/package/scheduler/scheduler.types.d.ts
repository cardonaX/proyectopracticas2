/**
 * Status of a `PgResource` (e.g. a room, account, or employee) at the current
 * point in time. Drives the resource pill styling in the sticky resource
 * column (design DD5).
 */
export type ResourceStatus = 'available' | 'occupied' | 'blocked' | 'dirty';
/**
 * Lifecycle status of a `PgBookingEvent`. Drives the event bar fill (design
 * D1): `pending` (warning) -> `confirmed` (success) -> `checked-in` (info) ->
 * `checked-out` (disabled), with `cancelled` (error) as the off-ramp.
 */
export type BookingStatus = 'confirmed' | 'checked-in' | 'checked-out' | 'pending' | 'cancelled';
/**
 * A category that groups one or more `PgResource` rows under a colspan
 * header row.
 */
export interface PgResourceGroup {
    id: string;
    /** e.g. "Single Room" */
    label: string;
    /** e.g. "$255 / noche" — rendered right-aligned in the group header row */
    subtitle?: string;
}
/** A single row in the resource axis (Y axis) of the scheduler grid. */
export interface PgResource {
    id: string;
    /** e.g. "Room 101" */
    label: string;
    /** References `PgResourceGroup.id`. Resources with no match render last, ungrouped. */
    groupId?: string;
    status?: ResourceStatus;
    /** Overrides the default label for `status` (e.g. "Needs Cleaning"). */
    statusLabel?: string;
    /** Arbitrary consumer-owned data, never read by the component. */
    meta?: Record<string, unknown>;
}
/** A booking/occupancy event rendered as a horizontal bar on the grid. */
export interface PgBookingEvent {
    id: string;
    /** References `PgResource.id`. */
    resourceId: string;
    /** e.g. "Cemile K." */
    label: string;
    start: Date;
    /** Exclusive — the checkout day itself is not counted as occupied. */
    end: Date;
    status?: BookingStatus;
    /** Overrides the status-derived fill as an inline `background-color`. Consumer owns contrast. */
    color?: string;
    /** Arbitrary consumer-owned data, never read by the component. */
    meta?: Record<string, unknown>;
}
/** Payload emitted by `(dateClick)` when an empty grid cell is clicked. */
export interface PgSchedulerDateClick {
    date: Date;
    resourceId: string;
}
/** Payload emitted by `(periodChange)` whenever the visible period moves. */
export interface PgSchedulerPeriodChange {
    start: Date;
    end: Date;
}
/**
 * Result of placing a single event against the currently visible period
 * (design DD3). `end` is exclusive, mirroring `PgBookingEvent.end`.
 */
export interface PgEventPlacement {
    /** 0-indexed day column where the visible portion of the event starts. */
    colStart: number;
    /** Number of day columns the visible portion of the event spans. */
    colSpan: number;
    /** `true` when the event's real start is before the visible period — squares the left corner. */
    clippedLeft: boolean;
    /** `true` when the event's real end is after the visible period — squares the right corner. */
    clippedRight: boolean;
}
/**
 * A compressed run of columns produced by `layoutRow` (design DD2 — scanline
 * layout). `eventIndex` is `null` for an empty run (no event occupies those
 * columns for this resource).
 */
export interface PgRowSegment extends PgEventPlacement {
    eventIndex: number | null;
}
/** A single fully-resolved cell in the render-ready view model (design). */
export type PgSchedulerCell = {
    kind: 'empty';
    date: Date;
    resourceId: string;
    isToday: boolean;
    ariaLabel: string;
} | {
    kind: 'event';
    event: PgBookingEvent;
    colSpan: number;
    barClass: string;
    roundClass: string;
    rangeLabel: string;
    ariaLabel: string;
};
/** A single fully-resolved row in the render-ready view model (design). */
export type PgSchedulerRow = {
    kind: 'group';
    group: PgResourceGroup;
} | {
    kind: 'resource';
    resource: PgResource;
    pillClass: string;
    pillLabel: string;
    cells: PgSchedulerCell[];
};
