import * as i0 from "@angular/core";
import * as i1 from "./scheduler.component";
export declare class PgSchedulerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgSchedulerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgSchedulerModule, never, [typeof i1.PgSchedulerComponent], [typeof i1.PgSchedulerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgSchedulerModule>;
}
