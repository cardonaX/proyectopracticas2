import { PgBookingEvent, PgResource, PgResourceGroup, PgSchedulerDateClick, PgSchedulerPeriodChange, PgSchedulerRow } from './scheduler.types';
import * as i0 from "@angular/core";
/** A single visible day column in the grid header. */
export interface PgSchedulerDayColumn {
    date: Date;
    dayName: string;
    dayNumber: string;
    isToday: boolean;
    index: number;
}
/**
 * Horizontal resource/Gantt scheduler grid (proposal + design #464). 100%
 * presentational: every rendered value derives from the `groups`/`resources`/
 * `events` inputs plus the internal `_startDate` navigation signal through a
 * `computed()` chain — the template performs zero computation (Phase 3).
 */
export declare class PgSchedulerComponent {
    groups: import("@angular/core").InputSignal<PgResourceGroup[]>;
    resources: import("@angular/core").InputSignal<PgResource[]>;
    events: import("@angular/core").InputSignal<PgBookingEvent[]>;
    startDate: import("@angular/core").InputSignal<Date>;
    visibleDays: import("@angular/core").InputSignal<number>;
    locale: import("@angular/core").InputSignal<string>;
    firstDayOfWeek: import("@angular/core").InputSignal<0 | 1>;
    todayLabel: import("@angular/core").InputSignal<string>;
    resourcesLabel: import("@angular/core").InputSignal<string>;
    eventClick: import("@angular/core").OutputEmitterRef<PgBookingEvent>;
    dateClick: import("@angular/core").OutputEmitterRef<PgSchedulerDateClick>;
    periodChange: import("@angular/core").OutputEmitterRef<PgSchedulerPeriodChange>;
    /**
     * Uncontrolled period anchor (design DD1). `null` means "not navigated
     * yet" — while null, `periodStart` tracks the `startDate` input reactively.
     * The FIRST write (via `onPrev`/`onNext`/`onToday`) makes `periodStart`
     * stop depending on `startDate()` (dynamic signal dependency tracking), so
     * a later parent re-render with the same/stale `startDate` never resets
     * navigation (spec: "Uncontrolled startDate (D8)"). No `effect`, no
     * `linkedSignal` — see design DD1 for the rejected alternatives.
     */
    private _startDate;
    periodStart: import("@angular/core").Signal<Date>;
    periodEnd: import("@angular/core").Signal<Date>;
    dayColumns: import("@angular/core").Signal<PgSchedulerDayColumn[]>;
    periodLabel: import("@angular/core").Signal<string>;
    /** `PgBookingEvent[]` bucketed by `resourceId`, preserving input array order. */
    private eventsByResource;
    /**
     * Flattened group/resource skeleton, without per-day cells: one `group`
     * row per `groups()` entry followed immediately by its resources (input
     * order); resources with no match in `groups()` are appended last, with no
     * group header (design "Open Question", adopted as documented default).
     */
    private rows;
    /**
     * Fully-resolved render-ready rows (design's `renderRows` in the Internal
     * State Model table): `rows` + per-resource cells from `layoutRow` (design
     * DD2, colocated pure util from Phase 1), with resolved token classes.
     */
    renderRows: import("@angular/core").Signal<PgSchedulerRow[]>;
    onPrev(): void;
    onNext(): void;
    onToday(): void;
    private emitPeriodChange;
    onEventClick(event: PgBookingEvent): void;
    onDateClick(date: Date, resourceId: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgSchedulerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PgSchedulerComponent, "pg-scheduler", never, { "groups": { "alias": "groups"; "required": false; "isSignal": true; }; "resources": { "alias": "resources"; "required": false; "isSignal": true; }; "events": { "alias": "events"; "required": false; "isSignal": true; }; "startDate": { "alias": "startDate"; "required": false; "isSignal": true; }; "visibleDays": { "alias": "visibleDays"; "required": false; "isSignal": true; }; "locale": { "alias": "locale"; "required": false; "isSignal": true; }; "firstDayOfWeek": { "alias": "firstDayOfWeek"; "required": false; "isSignal": true; }; "todayLabel": { "alias": "todayLabel"; "required": false; "isSignal": true; }; "resourcesLabel": { "alias": "resourcesLabel"; "required": false; "isSignal": true; }; }, { "eventClick": "eventClick"; "dateClick": "dateClick"; "periodChange": "periodChange"; }, never, never, true, never>;
}
