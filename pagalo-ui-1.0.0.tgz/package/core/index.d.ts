/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@pagalo/ui/core" />
export * from './public-api';
