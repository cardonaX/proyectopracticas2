import * as i0 from "@angular/core";
import * as i1 from "./sidebar.component";
export declare class PgSidebarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgSidebarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgSidebarModule, never, [typeof i1.SidebarComponent], [typeof i1.SidebarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgSidebarModule>;
}
