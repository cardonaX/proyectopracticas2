import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import * as i0 from "@angular/core";
export interface NavigationItem {
    id?: string;
    name: string;
    path?: string;
    icon?: string;
    badge?: number | string;
    /**
     * Whether this item is the active/current one. When omitted, it is
     * derived from the injected Router (if any) by matching `path` against
     * the current URL -- see `SidebarComponent.isCurrent()`. An explicit
     * value here always wins over the router-derived one, which keeps every
     * existing consumer (this used to be a required boolean) working exactly
     * as before.
     */
    current?: boolean;
    children?: NavigationItem[];
    expanded?: boolean;
}
export interface TeamItem {
    id: string;
    name: string;
    initial: string;
    current: boolean;
}
export interface UserProfile {
    name: string;
    avatarUrl: string;
}
export type SidebarVariant = 'light' | 'dark' | 'brand';
export declare class SidebarComponent implements OnChanges {
    variant: SidebarVariant;
    logoUrl: string;
    navigation: NavigationItem[];
    teams: TeamItem[];
    userProfile?: UserProfile;
    hasSecondaryNavigation: boolean;
    teamsLabel: string;
    navClick: EventEmitter<NavigationItem>;
    teamClick: EventEmitter<TeamItem>;
    profileClick: EventEmitter<UserProfile>;
    private readonly router;
    /**
     * Reactive snapshot of the current router URL, used to derive `current`
     * for items that don't set it explicitly. Falls back to a static `null`
     * signal when no Router is available (e.g. the library used outside a
     * routed app) -- in that case every path comparison simply never matches.
     */
    private readonly _currentUrl;
    private readonly _expandedIds;
    /**
     * Ids ever auto-seeded into `_expandedIds`, either because `item.expanded
     * === true` or because a descendant matched the router-current URL. This
     * is intentionally plain bookkeeping (not a signal) rather than render
     * state.
     *
     * Tradeoff (see plan's "seed once" rule): seeding an id happens at most
     * once, ever. If a consumer manually closes a submenu that was
     * auto-opened, and later passes a *new* `navigation` array reference (or
     * the router re-derives the same descendant match) where that same item
     * is still flagged, we do NOT reopen it -- the manual close wins from
     * that point on. The alternative (re-seed every time the flag/condition
     * is present) would make it impossible for a consumer to ever keep a
     * flagged submenu closed, fighting the user's toggle on every subsequent
     * `navigation` reassignment or route change. See
     * sidebar.component.spec.ts for the behavior this locks in.
     */
    private readonly _autoSeededIds;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    private _idsWithCurrentDescendant;
    private _hasCurrentDescendant;
    private _seedAutoExpand;
    isExpanded(item: NavigationItem): boolean;
    toggleSubMenu(item: NavigationItem, event: Event): void;
    /**
     * Resolves whether `item` should be rendered as "current"/active.
     * Precedence:
     *  1. An explicit `item.current` always wins.
     *  2. Otherwise, when a Router is injected:
     *     - leaf item (no `children`): exact match of `item.path` against the
     *       tracked URL.
     *     - parent item (`children` present): true if any descendant's
     *       `path` exactly matches the tracked URL (recursive).
     *  3. Otherwise `false`.
     */
    isCurrent(item: NavigationItem): boolean;
    onNavClick(item: NavigationItem, event: Event): void;
    onTeamClick(team: TeamItem, event: Event): void;
    onProfileClick(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidebarComponent, "pg-sidebar", never, { "variant": { "alias": "variant"; "required": false; }; "logoUrl": { "alias": "logoUrl"; "required": false; }; "navigation": { "alias": "navigation"; "required": false; }; "teams": { "alias": "teams"; "required": false; }; "userProfile": { "alias": "userProfile"; "required": false; }; "hasSecondaryNavigation": { "alias": "hasSecondaryNavigation"; "required": false; }; "teamsLabel": { "alias": "teamsLabel"; "required": false; }; }, { "navClick": "navClick"; "teamClick": "teamClick"; "profileClick": "profileClick"; }, never, never, true, never>;
}
