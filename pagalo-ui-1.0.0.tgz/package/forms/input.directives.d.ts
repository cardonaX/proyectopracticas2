import { SafeHtml } from '@angular/platform-browser';
import * as i0 from "@angular/core";
export declare class InputDirective {
    private pgInput;
    private el;
    private renderer;
    disabled: boolean;
    isInvalid: boolean;
    private readonly originalType;
    constructor();
    /** Propaga el input del usuario al wrapper CVA para que Angular Forms lo reciba. */
    onInput(value: string): void;
    /** Marca el control como touched cuando el usuario sale del campo. */
    onBlur(): void;
    get classes(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<InputDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<InputDirective, "[pgInput]", never, { "disabled": { "alias": "disabled"; "required": false; }; "isInvalid": { "alias": "aria-invalid"; "required": false; }; }, {}, never, never, true, never>;
}
export declare class PrefixIconDirective {
    private sanitizer;
    get boundInnerHTML(): SafeHtml | null;
    private injectedHtml;
    set content(value: string | undefined | null);
    get cls(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PrefixIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PrefixIconDirective, "[pgPrefixIcon]", never, { "content": { "alias": "pgPrefixIcon"; "required": false; }; }, {}, never, never, true, never>;
}
export declare class SuffixIconDirective {
    private sanitizer;
    get boundInnerHTML(): SafeHtml | null;
    private injectedHtml;
    set content(value: string | undefined | null);
    get cls(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SuffixIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SuffixIconDirective, "[pgSuffixIcon]", never, { "content": { "alias": "pgSuffixIcon"; "required": false; }; }, {}, never, never, true, never>;
}
export declare class PrefixAddonDirective {
    get cls(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PrefixAddonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PrefixAddonDirective, "[pgPrefixAddon]", never, {}, {}, never, never, true, never>;
}
export declare class SuffixAddonDirective {
    get cls(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SuffixAddonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SuffixAddonDirective, "[pgSuffixAddon]", never, {}, {}, never, never, true, never>;
}
export declare class PrefixInlineDirective {
    get cls(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PrefixInlineDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PrefixInlineDirective, "[pgPrefixInline]", never, {}, {}, never, never, true, never>;
}
export declare class SuffixInlineDirective {
    get cls(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SuffixInlineDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SuffixInlineDirective, "[pgSuffixInline]", never, {}, {}, never, never, true, never>;
}
export declare class PrefixDropdownDirective {
    get cls(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PrefixDropdownDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PrefixDropdownDirective, "[pgPrefixDropdown]", never, {}, {}, never, never, true, never>;
}
export declare class SuffixDropdownDirective {
    get cls(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SuffixDropdownDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SuffixDropdownDirective, "[pgSuffixDropdown]", never, {}, {}, never, never, true, never>;
}
export declare class DropdownSelectDirective {
    get cls(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DropdownSelectDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DropdownSelectDirective, "[pgDropdownSelect]", never, {}, {}, never, never, true, never>;
}
export declare class SuffixButtonDirective {
    get cls(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SuffixButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SuffixButtonDirective, "[pgSuffixButton]", never, {}, {}, never, never, true, never>;
}
export declare class SuffixShortcutDirective {
    get cls(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SuffixShortcutDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SuffixShortcutDirective, "[pgSuffixShortcut]", never, {}, {}, never, never, true, never>;
}
