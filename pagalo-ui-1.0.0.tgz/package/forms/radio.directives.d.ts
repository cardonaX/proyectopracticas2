import * as i0 from "@angular/core";
/**
 * Generic reactive host-binding directives for the native radio input rendered
 * inside `pg-radio`'s own template. These have zero knowledge of `RadioComponent`
 * or `PgRadioGroupComponent` — all state flows in via plain `@Input()`s bound
 * explicitly from `radio.component.html`, and state flows out via `@Output()`s.
 * This keeps them fully decoupled (no DI, no circular imports) and reusable.
 */
export declare class RadioDirective {
    pgRadioChecked: import("@angular/core").InputSignal<boolean>;
    pgRadioDisabled: import("@angular/core").InputSignal<boolean>;
    pgRadioName: import("@angular/core").InputSignal<string>;
    pgRadioValue: import("@angular/core").InputSignal<string | number>;
    pgRadioError: import("@angular/core").InputSignal<boolean>;
    readonly pgRadioChange: import("@angular/core").OutputEmitterRef<void>;
    readonly pgRadioBlur: import("@angular/core").OutputEmitterRef<void>;
    get checked(): boolean;
    get disabled(): boolean;
    get name(): string;
    get value(): string | number;
    onChange(): void;
    onBlur(): void;
    get hostClasses(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RadioDirective, "input[pgRadio]", never, { "pgRadioChecked": { "alias": "pgRadioChecked"; "required": false; "isSignal": true; }; "pgRadioDisabled": { "alias": "pgRadioDisabled"; "required": false; "isSignal": true; }; "pgRadioName": { "alias": "pgRadioName"; "required": false; "isSignal": true; }; "pgRadioValue": { "alias": "pgRadioValue"; "required": false; "isSignal": true; }; "pgRadioError": { "alias": "pgRadioError"; "required": false; "isSignal": true; }; }, { "pgRadioChange": "pgRadioChange"; "pgRadioBlur": "pgRadioBlur"; }, never, never, true, never>;
}
export declare class RadioColorDirective {
    pgRadioChecked: import("@angular/core").InputSignal<boolean>;
    pgRadioDisabled: import("@angular/core").InputSignal<boolean>;
    pgRadioName: import("@angular/core").InputSignal<string>;
    pgRadioValue: import("@angular/core").InputSignal<string | number>;
    readonly pgRadioChange: import("@angular/core").OutputEmitterRef<void>;
    readonly pgRadioBlur: import("@angular/core").OutputEmitterRef<void>;
    get checked(): boolean;
    get disabled(): boolean;
    get name(): string;
    get value(): string | number;
    onChange(): void;
    onBlur(): void;
    get hostClasses(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioColorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RadioColorDirective, "input[pgRadioColor]", never, { "pgRadioChecked": { "alias": "pgRadioChecked"; "required": false; "isSignal": true; }; "pgRadioDisabled": { "alias": "pgRadioDisabled"; "required": false; "isSignal": true; }; "pgRadioName": { "alias": "pgRadioName"; "required": false; "isSignal": true; }; "pgRadioValue": { "alias": "pgRadioValue"; "required": false; "isSignal": true; }; }, { "pgRadioChange": "pgRadioChange"; "pgRadioBlur": "pgRadioBlur"; }, never, never, true, never>;
}
export declare class RadioCardDirective {
    pgRadioChecked: import("@angular/core").InputSignal<boolean>;
    pgRadioDisabled: import("@angular/core").InputSignal<boolean>;
    pgRadioName: import("@angular/core").InputSignal<string>;
    pgRadioValue: import("@angular/core").InputSignal<string | number>;
    readonly pgRadioChange: import("@angular/core").OutputEmitterRef<void>;
    readonly pgRadioBlur: import("@angular/core").OutputEmitterRef<void>;
    get checked(): boolean;
    get disabled(): boolean;
    get name(): string;
    get value(): string | number;
    onChange(): void;
    onBlur(): void;
    get hostClasses(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioCardDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RadioCardDirective, "input[pgRadioCard]", never, { "pgRadioChecked": { "alias": "pgRadioChecked"; "required": false; "isSignal": true; }; "pgRadioDisabled": { "alias": "pgRadioDisabled"; "required": false; "isSignal": true; }; "pgRadioName": { "alias": "pgRadioName"; "required": false; "isSignal": true; }; "pgRadioValue": { "alias": "pgRadioValue"; "required": false; "isSignal": true; }; }, { "pgRadioChange": "pgRadioChange"; "pgRadioBlur": "pgRadioBlur"; }, never, never, true, never>;
}
export declare class RadioLabelDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioLabelDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RadioLabelDirective, "[pgRadioLabel]", never, {}, {}, never, never, true, never>;
}
export declare class RadioDescriptionDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioDescriptionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RadioDescriptionDirective, "[pgRadioDescription]", never, {}, {}, never, never, true, never>;
}
