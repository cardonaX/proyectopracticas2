import { PgForm } from './form.component';
import * as i0 from "@angular/core";
export declare class FormFieldComponent {
    label: import("@angular/core").InputSignal<string>;
    description: import("@angular/core").InputSignal<string | undefined>;
    forId: import("@angular/core").InputSignal<string>;
    colSpanClass: import("@angular/core").InputSignal<string>;
    form: PgForm | null;
    variant: import("@angular/core").Signal<import("@pagalo/ui/forms").FormVariant>;
    get hostClasses(): string;
    fieldContainerClasses: import("@angular/core").Signal<"" | "sm:grid sm:grid-cols-3 sm:items-start sm:gap-4 sm:py-6">;
    labelClasses: import("@angular/core").Signal<"block text-sm/6 font-medium text-content sm:pt-1.5" | "block text-sm/6 font-medium text-content">;
    inputContainerClasses: import("@angular/core").Signal<"mt-2 sm:col-span-2 sm:mt-0" | "mt-2">;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormFieldComponent, "pg-form-field", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "forId": { "alias": "forId"; "required": false; "isSignal": true; }; "colSpanClass": { "alias": "colSpanClass"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
