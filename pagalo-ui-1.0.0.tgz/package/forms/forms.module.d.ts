import * as i0 from "@angular/core";
import * as i1 from "./form.component";
import * as i2 from "./form-field.component";
import * as i3 from "./form-section.component";
import * as i4 from "./form-actions.component";
import * as i5 from "./input.component";
import * as i6 from "./input.directives";
import * as i7 from "./radio.component";
import * as i8 from "./radio-group.component";
import * as i9 from "./radio.directives";
import * as i10 from "./textarea.component";
import * as i11 from "./textarea.directives";
import * as i12 from "./toggle.component";
import * as i13 from "./toggle.directives";
export declare class PgFormsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgFormsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgFormsModule, never, [typeof i1.PgForm, typeof i2.FormFieldComponent, typeof i3.FormSectionComponent, typeof i4.FormActionsComponent, typeof i5.InputComponent, typeof i6.InputDirective, typeof i6.PrefixIconDirective, typeof i6.SuffixIconDirective, typeof i6.PrefixAddonDirective, typeof i6.SuffixAddonDirective, typeof i6.PrefixInlineDirective, typeof i6.SuffixInlineDirective, typeof i6.PrefixDropdownDirective, typeof i6.SuffixDropdownDirective, typeof i6.DropdownSelectDirective, typeof i6.SuffixButtonDirective, typeof i6.SuffixShortcutDirective, typeof i7.RadioComponent, typeof i8.PgRadioGroupComponent, typeof i9.RadioDirective, typeof i9.RadioColorDirective, typeof i9.RadioCardDirective, typeof i9.RadioLabelDirective, typeof i9.RadioDescriptionDirective, typeof i10.TextareaComponent, typeof i11.TextareaDirective, typeof i11.TextareaTitleDirective, typeof i11.TextareaAvatarDirective, typeof i11.TextareaToolbarDirective, typeof i11.TextareaFooterDirective, typeof i11.TextareaPillDirective, typeof i11.TextareaPreviewDirective, typeof i12.PgToggle, typeof i13.ToggleDirective], [typeof i1.PgForm, typeof i2.FormFieldComponent, typeof i3.FormSectionComponent, typeof i4.FormActionsComponent, typeof i5.InputComponent, typeof i6.InputDirective, typeof i6.PrefixIconDirective, typeof i6.SuffixIconDirective, typeof i6.PrefixAddonDirective, typeof i6.SuffixAddonDirective, typeof i6.PrefixInlineDirective, typeof i6.SuffixInlineDirective, typeof i6.PrefixDropdownDirective, typeof i6.SuffixDropdownDirective, typeof i6.DropdownSelectDirective, typeof i6.SuffixButtonDirective, typeof i6.SuffixShortcutDirective, typeof i7.RadioComponent, typeof i8.PgRadioGroupComponent, typeof i9.RadioDirective, typeof i9.RadioColorDirective, typeof i9.RadioCardDirective, typeof i9.RadioLabelDirective, typeof i9.RadioDescriptionDirective, typeof i10.TextareaComponent, typeof i11.TextareaDirective, typeof i11.TextareaTitleDirective, typeof i11.TextareaAvatarDirective, typeof i11.TextareaToolbarDirective, typeof i11.TextareaFooterDirective, typeof i11.TextareaPillDirective, typeof i11.TextareaPreviewDirective, typeof i12.PgToggle, typeof i13.ToggleDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgFormsModule>;
}
