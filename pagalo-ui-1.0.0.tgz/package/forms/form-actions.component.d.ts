import { PgForm } from './form.component';
import * as i0 from "@angular/core";
export declare class FormActionsComponent {
    form: PgForm | null;
    variant: import("@angular/core").Signal<import("@pagalo/ui/forms").FormVariant>;
    actionContainerClasses: import("@angular/core").Signal<"flex items-center justify-end gap-x-6 border-t border-outline-contrast/10 px-4 py-4 sm:px-8" | "mt-6 flex items-center justify-end gap-x-6">;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormActionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormActionsComponent, "pg-form-actions", never, {}, {}, never, ["*"], true, never>;
}
