import * as i0 from "@angular/core";
export declare class TextareaDirective {
    private pgTextarea;
    private el;
    private renderer;
    disabled: boolean;
    constructor();
    onInput(value: string): void;
    onBlur(): void;
    get classes(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextareaDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextareaDirective, "[pgTextarea]", never, { "disabled": { "alias": "disabled"; "required": false; }; }, {}, never, never, true, never>;
}
export declare class TextareaTitleDirective {
    get cls(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextareaTitleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextareaTitleDirective, "[pgTextareaTitle]", never, {}, {}, never, never, true, never>;
}
export declare class TextareaAvatarDirective {
    get cls(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextareaAvatarDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextareaAvatarDirective, "[pgTextareaAvatar]", never, {}, {}, never, never, true, never>;
}
export declare class TextareaToolbarDirective {
    private pgTextarea;
    get cls(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextareaToolbarDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextareaToolbarDirective, "[pgTextareaToolbar]", never, {}, {}, never, never, true, never>;
}
export declare class TextareaFooterDirective {
    get cls(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextareaFooterDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextareaFooterDirective, "[pgTextareaFooter]", never, {}, {}, never, never, true, never>;
}
export declare class TextareaPillDirective {
    get cls(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextareaPillDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextareaPillDirective, "[pgTextareaPill]", never, {}, {}, never, never, true, never>;
}
export declare class TextareaPreviewDirective {
    get cls(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextareaPreviewDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextareaPreviewDirective, "[pgTextareaPreview]", never, {}, {}, never, never, true, never>;
}
