import { PgRadioGroupComponent } from './radio-group.component';
import * as i0 from "@angular/core";
export declare class RadioComponent {
    protected readonly group: PgRadioGroupComponent;
    private readonly idService;
    private readonly _autoId;
    /** This option's value — compared against the parent group's selected value. */
    value: import("@angular/core").InputSignal<string | number>;
    /** Per-option disabled override, combined (OR) with the group's own disabled state. */
    disabled: import("@angular/core").InputSignal<boolean>;
    label: import("@angular/core").InputSignal<string>;
    description: import("@angular/core").InputSignal<string>;
    forId: import("@angular/core").InputSignal<string>;
    /** Controls vertical padding on `default`/`radio-right` layouts. Preserved from the pre-simplification API — the template still relies on it. */
    padding: import("@angular/core").InputSignal<boolean>;
    /** Extra classes for this option's own host element (the `<pg-radio>` tag itself). */
    hostClass: import("@angular/core").InputSignal<string>;
    /** Extra classes for the internal swatch input — only meaningful for `layout: 'color'`. */
    swatchClass: import("@angular/core").InputSignal<string>;
    readonly layout: import("@angular/core").Signal<import("@pagalo/ui/forms").RadioLayout>;
    readonly shape: import("@angular/core").Signal<import("@pagalo/ui/forms").RadioShape>;
    /** True when this option is the group's currently selected value. */
    readonly checked: import("@angular/core").Signal<boolean>;
    readonly isDisabled: import("@angular/core").Signal<boolean>;
    readonly hasError: import("@angular/core").Signal<boolean>;
    /**
     * ID resuelto: usa el input `forId` si se provee, sino genera uno automáticamente.
     */
    readonly computedForId: import("@angular/core").Signal<string>;
    readonly computedClass: import("@angular/core").Signal<string>;
    onSelect(): void;
    onBlur(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RadioComponent, "pg-radio", never, { "value": { "alias": "value"; "required": true; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "forId": { "alias": "forId"; "required": false; "isSignal": true; }; "padding": { "alias": "padding"; "required": false; "isSignal": true; }; "hostClass": { "alias": "hostClass"; "required": false; "isSignal": true; }; "swatchClass": { "alias": "swatchClass"; "required": false; "isSignal": true; }; }, {}, never, ["[pgRadioLabel]", "[pgRadioDescription]", "[pgRadioLabel]", "[pgRadioDescription]", "[pgRadioLabel]", "[pgRadioDescription]", "[pgRadioLabel]", "[pgRadioDescription]", "[pgRadioLabel]"], true, never>;
}
