import * as i0 from "@angular/core";
export declare class ToggleDirective {
    private pgToggle;
    private el;
    private renderer;
    constructor();
    onChange(checked: boolean): void;
    onBlur(): void;
    get hostClasses(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToggleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ToggleDirective, "input[pgToggle]", never, {}, {}, never, never, true, never>;
}
