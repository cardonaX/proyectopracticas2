import { PgControlValueAccessorBase } from '@pagalo/ui/core';
import * as i0 from "@angular/core";
export type ToggleVariant = 'normal' | 'short';
export declare class PgToggle extends PgControlValueAccessorBase<boolean> {
    variant: import("@angular/core").InputSignal<ToggleVariant>;
    withIcon: import("@angular/core").InputSignal<boolean>;
    /**
     * 100% consumer-controlled loading indicator — mirrors `pg-select`'s
     * `loading` input. The library never infers this from async state; bind it
     * around your own request (e.g. a settings toggle awaiting a PATCH). Swaps
     * the knob's icon for a spinner and, via `ToggleDirective`, forces the
     * projected `<input pgToggle>` disabled for the duration — no separate
     * `[disabled]` binding needed.
     */
    isLoading: import("@angular/core").InputSignal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgToggle, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PgToggle, "pg-toggle", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "withIcon": { "alias": "withIcon"; "required": false; "isSignal": true; }; "isLoading": { "alias": "isLoading"; "required": false; "isSignal": true; }; }, {}, never, ["input[pgToggle]"], true, never>;
}
