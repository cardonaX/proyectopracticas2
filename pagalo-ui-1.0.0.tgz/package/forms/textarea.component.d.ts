import { TextareaAvatarDirective, TextareaToolbarDirective, TextareaFooterDirective } from './textarea.directives';
import { PgControlValueAccessorBase } from '@pagalo/ui/core';
import * as i0 from "@angular/core";
export type TextareaVariant = 'simple' | 'avatar-actions' | 'underline-actions' | 'title-actions' | 'preview';
export declare class TextareaComponent extends PgControlValueAccessorBase<string> {
    private readonly idService;
    private readonly _autoId;
    variant: import("@angular/core").InputSignal<TextareaVariant>;
    label: import("@angular/core").InputSignal<string>;
    hideLabel: import("@angular/core").InputSignal<boolean>;
    forId: import("@angular/core").InputSignal<string>;
    helpText: import("@angular/core").InputSignal<string | undefined>;
    errorText: import("@angular/core").InputSignal<string | undefined>;
    /**
     * Fuerza el estado de error. Toma precedencia sobre el computed del NgControl.
     * Útil cuando el componente se usa sin ReactiveFormsModule.
     */
    error: import("@angular/core").InputSignal<boolean | undefined>;
    activeTab: import("@angular/core").WritableSignal<"preview" | "write">;
    avatarIcon: import("@angular/core").Signal<TextareaAvatarDirective | undefined>;
    toolbarSection: import("@angular/core").Signal<TextareaToolbarDirective | undefined>;
    footerSection: import("@angular/core").Signal<TextareaFooterDirective | undefined>;
    hasAvatar: import("@angular/core").Signal<boolean>;
    hasToolbar: import("@angular/core").Signal<boolean>;
    hasFooter: import("@angular/core").Signal<boolean>;
    /**
     * ID resuelto: usa el input `forId` si se provee, sino genera uno automáticamente.
     */
    readonly computedForId: import("@angular/core").Signal<string>;
    readonly hasError: import("@angular/core").Signal<boolean>;
    setTab(tab: 'write' | 'preview', event?: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextareaComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextareaComponent, "pg-textarea", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "hideLabel": { "alias": "hideLabel"; "required": false; "isSignal": true; }; "forId": { "alias": "forId"; "required": false; "isSignal": true; }; "helpText": { "alias": "helpText"; "required": false; "isSignal": true; }; "errorText": { "alias": "errorText"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; }, {}, ["avatarIcon", "toolbarSection", "footerSection"], ["textarea[pgTextarea]", "[pgTextareaAvatar]", "[pgTextareaToolbar]", "[pgTextareaFooter]", "input[pgTextareaTitle]", "[pgTextareaPill]", "[pgTextareaPreview]"], true, never>;
}
