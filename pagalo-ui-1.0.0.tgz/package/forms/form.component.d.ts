import { InjectionToken } from '@angular/core';
import * as i0 from "@angular/core";
export type FormVariant = 'stacked' | 'two-column' | 'cards' | 'labels-on-left';
export declare const FORM_VARIANT_TOKEN: InjectionToken<FormVariant>;
export declare class PgForm {
    /**
     * Define la variante de diseño del formulario.
     * - stacked: Formulario vertical tradicional.
     * - two-column: Formulario dividido en dos columnas (título a la izquierda, campos a la derecha).
     * - cards: Secciones del formulario separadas por bordes y tarjetas con sombras.
     * - labels-on-left: Campos del formulario divididos con las etiquetas a la izquierda y las entradas a la derecha.
     */
    variant: import("@angular/core").InputSignal<FormVariant>;
    containerClasses: import("@angular/core").Signal<"space-y-12 sm:space-y-16" | "divide-y divide-outline-contrast/10">;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgForm, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PgForm, "pg-form", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
