import { PgControlValueAccessorBase } from '@pagalo/ui/core';
import * as i0 from "@angular/core";
export type RadioGroupOrientation = 'horizontal' | 'vertical';
export type RadioLayout = 'default' | 'inline-description' | 'radio-right' | 'panel' | 'color' | 'card' | 'stacked-card' | 'small-card';
export type RadioShape = 'rounded' | 'pill';
export declare class PgRadioGroupComponent extends PgControlValueAccessorBase<string | number> {
    private readonly idService;
    private readonly _autoName;
    /** Native `name` shared by every radio input inside this group. Auto-generated unless overridden. */
    name: import("@angular/core").InputSignal<string>;
    orientation: import("@angular/core").InputSignal<RadioGroupOrientation>;
    /** Shared layout for every `pg-radio` child in this group — set once here, not per option. */
    layout: import("@angular/core").InputSignal<RadioLayout>;
    /** Shared shape for every `pg-radio` child — only meaningful when `layout` is `'small-card'`. */
    shape: import("@angular/core").InputSignal<RadioShape>;
    customClass: import("@angular/core").InputSignal<string>;
    readonly computedName: import("@angular/core").Signal<string>;
    readonly hostClasses: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgRadioGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PgRadioGroupComponent, "pg-radio-group", never, { "name": { "alias": "name"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "shape": { "alias": "shape"; "required": false; "isSignal": true; }; "customClass": { "alias": "customClass"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
