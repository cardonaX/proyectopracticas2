import { PgForm } from './form.component';
import * as i0 from "@angular/core";
export declare class FormSectionComponent {
    title: import("@angular/core").InputSignal<string>;
    description: import("@angular/core").InputSignal<string | undefined>;
    form: PgForm | null;
    variant: import("@angular/core").Signal<import("@pagalo/ui/forms").FormVariant>;
    sectionClasses: import("@angular/core").Signal<"border-b border-outline-contrast/10 pb-12" | "grid grid-cols-1 gap-x-8 gap-y-10 border-b border-outline-contrast/10 pb-12 md:grid-cols-3 sm:py-6">;
    headerContainerClasses: import("@angular/core").Signal<"" | "px-4 sm:px-0">;
    fieldsContainerClasses: import("@angular/core").Signal<"mt-10 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6" | "grid max-w-2xl grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6 md:col-span-2" | "bg-surface shadow-sm outline outline-1 outline-outline-contrast/5 sm:rounded-xl md:col-span-2 px-4 py-6 sm:p-8 grid max-w-2xl grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6" | "mt-10 space-y-8 border-b border-outline-contrast/10 pb-12 sm:space-y-0 sm:divide-y sm:divide-outline-contrast/10 sm:border-t sm:border-t-outline-contrast/10 sm:pb-0 md:col-span-2">;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormSectionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormSectionComponent, "pg-form-section", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
