import { OnInit } from '@angular/core';
import { PrefixIconDirective, SuffixIconDirective, PrefixAddonDirective, SuffixAddonDirective, PrefixInlineDirective, SuffixInlineDirective, PrefixDropdownDirective, SuffixDropdownDirective, SuffixButtonDirective, SuffixShortcutDirective } from './input.directives';
import { PgControlValueAccessorBase } from '@pagalo/ui/core';
import * as i0 from "@angular/core";
export type InputVariant = 'default' | 'inset' | 'overlapping' | 'gray-bottom' | 'pill';
export type InputSize = 'sm' | 'md' | 'lg';
export type SharedBorders = 'none' | 'top' | 'bottom' | 'bottom-left' | 'bottom-right' | 'left' | 'right';
export declare class InputComponent extends PgControlValueAccessorBase<string> implements OnInit {
    private readonly idService;
    private readonly _autoId;
    private readonly _hasNgControl;
    label: import("@angular/core").InputSignal<string | undefined>;
    helpText: import("@angular/core").InputSignal<string | undefined>;
    errorText: import("@angular/core").InputSignal<string | undefined>;
    cornerHint: import("@angular/core").InputSignal<string | undefined>;
    forId: import("@angular/core").InputSignal<string>;
    variant: import("@angular/core").InputSignal<InputVariant>;
    size: import("@angular/core").InputSignal<InputSize>;
    sharedBorders: import("@angular/core").InputSignal<SharedBorders>;
    required: import("@angular/core").InputSignal<boolean>;
    /**
     * Fuerza el estado de error. Toma precedencia sobre el computed del NgControl.
     * Útil cuando el componente se usa sin ReactiveFormsModule.
     */
    error: import("@angular/core").InputSignal<boolean | undefined>;
    /**
     * Muestra un ícono de éxito (check verde). No aplica si hay error activo.
     */
    success: import("@angular/core").InputSignal<boolean>;
    /**
     * Muestra un botón de toggle para ver/ocultar contraseñas.
     * Solo tiene efecto cuando el input nativo tiene type="password".
     */
    showPasswordToggle: import("@angular/core").InputSignal<boolean>;
    readonly isPasswordVisible: import("@angular/core").WritableSignal<boolean>;
    ngOnInit(): void;
    togglePassword(): void;
    prefixIcon: import("@angular/core").Signal<PrefixIconDirective | undefined>;
    suffixIcon: import("@angular/core").Signal<SuffixIconDirective | undefined>;
    prefixAddon: import("@angular/core").Signal<PrefixAddonDirective | undefined>;
    suffixAddon: import("@angular/core").Signal<SuffixAddonDirective | undefined>;
    prefixInline: import("@angular/core").Signal<PrefixInlineDirective | undefined>;
    suffixInline: import("@angular/core").Signal<SuffixInlineDirective | undefined>;
    prefixDropdown: import("@angular/core").Signal<PrefixDropdownDirective | undefined>;
    suffixDropdown: import("@angular/core").Signal<SuffixDropdownDirective | undefined>;
    suffixButton: import("@angular/core").Signal<SuffixButtonDirective | undefined>;
    suffixShortcut: import("@angular/core").Signal<SuffixShortcutDirective | undefined>;
    readonly computedForId: import("@angular/core").Signal<string>;
    readonly hasError: import("@angular/core").Signal<boolean>;
    readonly layoutType: import("@angular/core").Signal<"inline-flex" | "addon-flex-with-icons" | "addon-flex" | "grid" | "standard">;
    get hostClasses(): string;
    readonly inlineContainerClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<InputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InputComponent, "pg-input", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "helpText": { "alias": "helpText"; "required": false; "isSignal": true; }; "errorText": { "alias": "errorText"; "required": false; "isSignal": true; }; "cornerHint": { "alias": "cornerHint"; "required": false; "isSignal": true; }; "forId": { "alias": "forId"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "sharedBorders": { "alias": "sharedBorders"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "success": { "alias": "success"; "required": false; "isSignal": true; }; "showPasswordToggle": { "alias": "showPasswordToggle"; "required": false; "isSignal": true; }; }, {}, ["prefixIcon", "suffixIcon", "prefixAddon", "suffixAddon", "prefixInline", "suffixInline", "prefixDropdown", "suffixDropdown", "suffixButton", "suffixShortcut"], ["[pgPrefixInline]", "[pgPrefixDropdown]", "[pgSuffixInline]", "[pgSuffixDropdown]", "[pgSuffixShortcut]", "[pgPrefixAddon]", "[pgPrefixIcon]", "[pgSuffixAddon]", "[pgSuffixButton]", "[pgPrefixIcon]", "[pgSuffixIcon]", "[pgInput]"], true, never>;
}
