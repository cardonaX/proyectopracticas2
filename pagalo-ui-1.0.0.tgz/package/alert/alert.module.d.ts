import * as i0 from "@angular/core";
import * as i1 from "./toast/alert-toast.component";
import * as i2 from "./modal/alert-modal.component";
import * as i3 from "./alert-container.component";
export declare class PgAlertModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgAlertModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgAlertModule, never, [typeof i1.AlertToastComponent, typeof i2.AlertModalComponent, typeof i3.AlertContainerComponent], [typeof i1.AlertToastComponent, typeof i2.AlertModalComponent, typeof i3.AlertContainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgAlertModule>;
}
