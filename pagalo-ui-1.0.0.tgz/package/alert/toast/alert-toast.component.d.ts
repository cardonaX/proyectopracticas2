import { Alert } from '../alert.types';
import * as i0 from "@angular/core";
export declare class AlertToastComponent {
    alert: import("@angular/core").InputSignal<Alert>;
    close: import("@angular/core").OutputEmitterRef<void>;
    iconInfo: import("@angular/core").Signal<{
        timerClass: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertToastComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlertToastComponent, "pg-alert-toast", never, { "alert": { "alias": "alert"; "required": true; "isSignal": true; }; }, { "close": "close"; }, never, never, true, never>;
}
