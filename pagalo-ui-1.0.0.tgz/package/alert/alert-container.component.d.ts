import { AlertService } from './alert.service';
import { Alert, AlertPosition } from './alert.types';
import * as i0 from "@angular/core";
export declare class AlertContainerComponent {
    alertService: AlertService;
    duration: import("@angular/core").InputSignal<number>;
    /**
     * Referencia al contenedor `popover="manual"` que envuelve todas las
     * posiciones de toasts (ver template). `#toastLayer` ancla el elemento
     * al DOM; ver el effect() del constructor para el show/hidePopover().
     */
    private toastLayer;
    toasts: import("@angular/core").Signal<Alert[]>;
    hasToasts: import("@angular/core").Signal<boolean>;
    modals: import("@angular/core").Signal<Alert[]>;
    groupedToasts: import("@angular/core").Signal<{
        position: AlertPosition;
        normal: Alert[];
        pile: Alert[];
        pileFirst: boolean;
    }[]>;
    getPositionClasses(pos: AlertPosition): string;
    getAlignmentClasses(pos: AlertPosition): string;
    private isTopAnchored;
    private getDepth;
    getStackStyle(pile: readonly {
        id: string;
    }[], alert: {
        id: string;
    }, pos: AlertPosition): Record<string, string>;
    closeToast(id: string): void;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlertContainerComponent, "pg-alert-container", never, { "duration": { "alias": "duration"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
