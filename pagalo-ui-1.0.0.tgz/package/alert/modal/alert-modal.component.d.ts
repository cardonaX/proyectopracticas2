import { ElementRef } from '@angular/core';
import { PgDialogBase } from '@pagalo/ui/core';
import { Alert, AlertResult } from '../alert.types';
import * as i0 from "@angular/core";
export declare class AlertModalComponent extends PgDialogBase {
    private readonly idService;
    private readonly _autoId;
    alert: import("@angular/core").InputSignal<Alert>;
    closeResult: import("@angular/core").OutputEmitterRef<AlertResult>;
    /**
     * A diferencia de Modal (que alterna visibilidad en un template siempre montado),
     * AlertModal solo se monta mientras hay un alert activo en el AlertService.
     */
    readonly isOpen: import("@angular/core").ModelSignal<boolean>;
    /** Re-declarada por requerimiento de PgDialogBase. */
    readonly dialogRef: import("@angular/core").Signal<ElementRef<HTMLDialogElement>>;
    /**
     * Defaults que matchean animationDurationEnter/Leave actuales.
     * Los overrides per-instance viven en el TEMPLATE (bindings directos a
     * notif().animationDurationEnter/Leave) — NO como getters acá: son fields
     * planos asignados en el constructor de la clase base, y un `get` accessor
     * en la subclase rompería con "Cannot set property which has only a getter".
     */
    readonly panelEnterDurationMs = 150;
    readonly panelExitDurationMs = 200;
    readonly dialogId: import("@angular/core").Signal<string>;
    readonly titleId: import("@angular/core").Signal<string>;
    notif: import("@angular/core").Signal<Alert>;
    backdropColor: import("@angular/core").Signal<string>;
    iconInfo: import("@angular/core").Signal<{
        timerClass: string;
    }>;
    /** Header: wrapper de ícono + botón de cerrar según `headerLayout`. */
    readonly headerWrapperClass: import("@angular/core").Signal<"flex justify-center mb-3 sm:mb-4" | "flex items-start justify-between mb-3 sm:mb-4">;
    /** Contenido: alineación de título/mensaje según `headerLayout`. */
    readonly contentAlignClass: import("@angular/core").Signal<"text-center" | "text-center sm:text-left">;
    /** Footer de acciones: wrapper según `buttonsLayout` (+ `reverseButtons`). */
    readonly actionsWrapperClass: import("@angular/core").Signal<string>;
    /** Footer de acciones: ancho de cada botón según `buttonsLayout`. */
    readonly actionButtonWidthClass: import("@angular/core").Signal<"w-full" | "w-auto" | "w-full sm:w-auto">;
    constructor();
    protected canDismiss(source: 'backdrop' | 'escape'): boolean;
    onBackdropClick(): void;
    onDismiss(reason: 'cancel' | 'backdrop' | 'esc' | 'close' | 'timer'): void;
    onConfirm(): void;
    onCancel(): void;
    onDeny(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlertModalComponent, "pg-alert-modal", never, { "alert": { "alias": "alert"; "required": true; "isSignal": true; }; "isOpen": { "alias": "isOpen"; "required": false; "isSignal": true; }; }, { "closeResult": "closeResult"; "isOpen": "isOpenChange"; }, never, never, true, never>;
}
