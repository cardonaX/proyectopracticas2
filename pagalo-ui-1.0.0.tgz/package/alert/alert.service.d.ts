import { Alert, AlertConfig, AlertResult } from './alert.types';
import * as i0 from "@angular/core";
export declare class AlertService {
    private _alerts;
    readonly alerts: import("@angular/core").Signal<Alert[]>;
    defaultDuration: number;
    setDefaultDuration(duration: number): void;
    private generateId;
    show(config: AlertConfig): Promise<AlertResult>;
    close(id: string, result: AlertResult): void;
    /**
     * Saca el alert del array + dispara `didClose()`. Se llama desde el
     * container cuando el `(closed)` de `PgDialogBase` confirma que la
     * animación de salida del modal terminó de verdad.
     */
    finalizeRemoval(id: string): void;
    remove(id: string): void;
    success(title: string, message?: string, duration?: number): Promise<AlertResult>;
    error(title: string, message?: string, duration?: number): Promise<AlertResult>;
    info(title: string, message?: string, duration?: number): Promise<AlertResult>;
    warning(title: string, message?: string, duration?: number): Promise<AlertResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AlertService>;
}
