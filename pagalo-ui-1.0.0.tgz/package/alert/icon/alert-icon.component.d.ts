import { AlertType } from '../alert.types';
import * as i0 from "@angular/core";
export type AlertIconSize = 'sm' | 'lg' | 'xl';
interface IconPalette {
    /** Border + fill color (the circle background) */
    fill: string;
    /** Foreground glyph color (must contrast against `fill`) */
    foreground: string;
    /** Light tint used behind the circle */
    tint: string;
}
export declare class AlertIconComponent {
    type: import("@angular/core").InputSignal<AlertType>;
    size: import("@angular/core").InputSignal<AlertIconSize>;
    protected hostClass: import("@angular/core").Signal<string>;
    protected palette: import("@angular/core").Signal<IconPalette>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlertIconComponent, "pg-alert-icon", never, { "type": { "alias": "type"; "required": true; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
export {};
