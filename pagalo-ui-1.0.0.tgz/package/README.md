# @pagalo/ui

Angular 19 component library for Pagalo internal projects.

## Installation

```bash
npm install @pagalo/ui
```

Add `styles.css` to your `angular.json`:

```json
"styles": ["node_modules/@pagalo/ui/styles.css"]
```

## Usage

Import each entry point independently:

```typescript
import { PgButtonComponent } from '@pagalo/ui/button';
import { PgAlertService } from '@pagalo/ui/alert';
```

### `@pagalo/ui/select` (`pg-select`, `pg-select-multi`)

This entry point uses `@angular/cdk/overlay` to position its dropdown panel. Consumers must:

1. Install `@angular/cdk` (declared as a `peerDependency`; version must match your `@angular/core` major).
2. Add the CDK overlay stylesheet to their `angular.json` `styles` array — without it, panels will not position or z-index correctly:

```json
"styles": [
  "node_modules/@pagalo/ui/styles.css",
  "node_modules/@angular/cdk/overlay-prebuilt.css"
]
```

This step is required for both the `build` and `test` targets of any app consuming `pg-select`/`pg-select-multi`. It is not folded into the library's Tailwind preset in v1 to avoid injecting CDK/overlay CSS into apps that never use `pg-select`.

## MCP Catalog Server

`@pagalo/ui` ships an MCP server that exposes the component catalog to AI coding tools (Claude Code, Cursor, Windsurf, Gemini CLI, etc.), so agents know which components exist and how to use them.

**Bundle location after install:**

```
node_modules/@pagalo/ui/mcp/server.bundle.mjs
```

**Configuration — add this block to your project-level MCP config file:**

```json
{
  "mcpServers": {
    "pagalo-ui": {
      "command": "node_modules/.bin/pagalo-ui-mcp"
    }
  }
}
```

| AI Tool    | Config file                  |
|------------|------------------------------|
| Claude Code | `.mcp.json`                 |
| Cursor     | `.cursor/mcp.json`           |
| Windsurf   | `.windsurf/mcp.json`         |
| Gemini CLI | `.gemini/settings.json`      |
| OpenCode   | `.opencode/mcp.json`         |

> These are **project-level** config files (not global IDE config). The path `node_modules/.bin/pagalo-ui-mcp` resolves relative to your project root, which is the working directory the IDE uses when launching servers from project config.

Restart your AI tool after adding the config.

### Available MCP tools

| Tool              | Description                              |
|-------------------|------------------------------------------|
| `list_components` | List all available components            |
| `get_component`   | Get full API for a specific component    |
| `get_conventions` | Get usage conventions and coding style   |
| `get_snippet`     | Get ready-to-use Angular 19 code snippet |
