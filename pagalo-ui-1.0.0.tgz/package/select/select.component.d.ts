import { PgSelectBase } from './_base/select-base.directive';
import { PgSelectOption } from './select.types';
import * as i0 from "@angular/core";
export type PgSelectVariant = 'classic' | 'search';
/**
 * `pg-select` — single-value select. `variant="classic"` renders a
 * button-style trigger with no editable text (type-ahead by character);
 * `variant="search"` renders an editable text input that filters options
 * live (`aria-autocomplete="list"`).
 */
export declare class SelectComponent<T = unknown> extends PgSelectBase<T, T> {
    readonly multiple: false;
    readonly closeOnSelect = true;
    variant: import("@angular/core").InputSignal<PgSelectVariant>;
    readonly displayValue: import("@angular/core").Signal<string>;
    isSelected(option: PgSelectOption<T>): boolean;
    selectOption(option: PgSelectOption<T>): void;
    onOptionClick(option: PgSelectOption<T>): void;
    onClearClick(event: Event): void;
    onTriggerClick(): void;
    /**
     * Type-ahead for the classic (non-editable) variant: jumps to and selects
     * the first non-disabled option whose label starts with the typed
     * character, mirroring native `<select>` behavior. Runs whether the panel
     * is open or closed because the CDK key manager's own typeahead only
     * covers items rendered inside the (lazily-stamped) overlay template.
     */
    onTriggerKeydown(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SelectComponent<any>, "pg-select", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
