import { Highlightable, ListKeyManagerOption } from '@angular/cdk/a11y';
import { PgSelectOption } from './select.types';
import * as i0 from "@angular/core";
/**
 * Internal option renderer used by `pg-select` and `pg-select-multi`.
 *
 * Implements CDK `Highlightable` (active/inactive styling driven by
 * `ActiveDescendantKeyManager`) and `ListKeyManagerOption` (label for
 * typeahead, disabled state). Not part of the public API — consumers only
 * ever pass `options` arrays, never author `pg-select-option` elements
 * directly (v1 has no custom option templates).
 *
 * NOTE: `disabled` is exposed as a getter (not a signal `input()`) because
 * `ListKeyManagerOption#disabled` is typed `boolean | undefined` and would
 * structurally conflict with an `InputSignal<boolean>` of the same name.
 *
 * @internal
 */
export declare class PgSelectOptionComponent implements Highlightable, ListKeyManagerOption {
    private readonly idService;
    private readonly elementRef;
    readonly id: string;
    option: import("@angular/core").InputSignal<PgSelectOption<unknown>>;
    selected: import("@angular/core").InputSignal<boolean>;
    primaryColor: import("@angular/core").InputSignal<string>;
    private readonly _active;
    readonly active: import("@angular/core").Signal<boolean>;
    /** Implements `ListKeyManagerOption#disabled` via the wrapped option's flag. */
    get disabled(): boolean;
    /**
     * Tailwind utility classes for the option's layout + interaction state,
     * computed once (mirroring `InputDirective`'s `@HostBinding('class')`
     * string-getter pattern) instead of layering several boolean `[class.x]`
     * host bindings whose underlying utilities would fight for the same CSS
     * property (e.g. `text-white` vs `text-content`) with cascade order
     * decided by Tailwind's generated stylesheet, not binding order.
     */
    readonly hostClasses: import("@angular/core").Signal<string>;
    /**
     * Inline `background-color` override for `primaryColor`, mirroring
     * `hostClasses()`'s exact active/selected precedence. `null` when the
     * consumer hasn't set `primaryColor` (or the option is disabled), leaving
     * the Tailwind classes from `hostClasses()` untouched.
     */
    readonly hostBackgroundColor: import("@angular/core").Signal<string | null>;
    setActiveStyles(): void;
    setInactiveStyles(): void;
    getLabel(): string;
    scrollIntoViewIfNeeded(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgSelectOptionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PgSelectOptionComponent, "pg-select-option", never, { "option": { "alias": "option"; "required": true; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "primaryColor": { "alias": "primaryColor"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
