/**
 * A single selectable option.
 */
export interface PgSelectOption<T = unknown> {
    label: string;
    value: T;
    disabled?: boolean;
}
/**
 * A labeled group of options. When present in the `options` source,
 * groups render with `role="group"` headers and are skipped over during
 * keyboard navigation.
 */
export interface PgSelectGroup<T = unknown> {
    label: string;
    options: PgSelectOption<T>[];
    disabled?: boolean;
}
/**
 * Static options source: a flat array of options, or an array of groups.
 * Discriminated at runtime by checking for the `options` property on the
 * first element.
 */
export type PgSelectOptions<T = unknown> = PgSelectOption<T>[] | PgSelectGroup<T>[];
/**
 * Derived visual/interaction state of the options panel.
 */
export type PgSelectPanelState = 'idle' | 'loading' | 'ready' | 'empty' | 'no-results';
