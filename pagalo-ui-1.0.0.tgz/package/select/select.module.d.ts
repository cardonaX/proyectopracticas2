import * as i0 from "@angular/core";
import * as i1 from "./select.component";
import * as i2 from "./multi-select.component";
import * as i3 from "./select-option.component";
export declare class PgSelectModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgSelectModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgSelectModule, never, [typeof i1.SelectComponent, typeof i2.MultiSelectComponent, typeof i3.PgSelectOptionComponent], [typeof i1.SelectComponent, typeof i2.MultiSelectComponent, typeof i3.PgSelectOptionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgSelectModule>;
}
