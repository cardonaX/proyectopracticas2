import { InjectionToken } from '@angular/core';
import { ScrollStrategy } from '@angular/cdk/overlay';
/**
 * Injection token to override the CDK scroll strategy used by `pg-select`
 * and `pg-select-multi` panels. Defaults to `reposition({ autoClose: true })`
 * so the panel follows its trigger on scroll/resize instead of closing or
 * freezing page scroll. Override by providing this token at the app/module
 * level; not part of the per-component public API surface.
 */
export declare const PG_SELECT_SCROLL_STRATEGY: InjectionToken<() => ScrollStrategy>;
