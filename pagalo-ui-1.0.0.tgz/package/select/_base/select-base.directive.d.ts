import { ElementRef, OnInit, Signal } from '@angular/core';
import { ActiveDescendantKeyManager } from '@angular/cdk/a11y';
import { ConnectedPosition, ScrollStrategy } from '@angular/cdk/overlay';
import { PgControlValueAccessorBase } from '@pagalo/ui/core';
import { PgSelectOption, PgSelectGroup, PgSelectOptions, PgSelectPanelState } from '../select.types';
import { PgSelectOptionComponent } from '../select-option.component';
import * as i0 from "@angular/core";
/**
 * Shared behavior for all `pg-select*` variants: overlay open/close state,
 * option/group normalization, local + async filtering, `ActiveDescendantKeyManager`
 * wiring, and CVA plumbing (inherited from `PgControlValueAccessorBase`).
 *
 * Concrete components (`pg-select`, `pg-select-multi`) provide the value-shape
 * specific behavior via the abstract members below.
 */
export declare abstract class PgSelectBase<TOption = unknown, TValue = unknown> extends PgControlValueAccessorBase<TValue> implements OnInit {
    private readonly idService;
    private readonly destroyRef;
    private readonly _scrollStrategyFactory;
    private readonly _autoId;
    readonly listboxId: string;
    /** Primary bottom-start with a top-start flip fallback, plus horizontal shift variants. */
    readonly overlayPositions: ConnectedPosition[];
    readonly scrollStrategy: ScrollStrategy;
    options: import("@angular/core").InputSignal<PgSelectOptions<TOption>>;
    debounceMs: import("@angular/core").InputSignal<number>;
    compareWith: import("@angular/core").InputSignal<(a: TOption, b: TOption) => boolean>;
    placeholder: import("@angular/core").InputSignal<string>;
    readonly: import("@angular/core").InputSignal<boolean>;
    clearable: import("@angular/core").InputSignal<boolean>;
    error: import("@angular/core").InputSignal<boolean | undefined>;
    /**
     * 100% consumer-controlled loading indicator — the library never sets this
     * internally. Bind it around your own fetch (e.g. driven by `(searchChange)`)
     * to surface the `'loading'` panel state. Mirrors ng-select's own `loading`
     * input, whose CHANGELOG explicitly warns against the library trying to
     * infer loading state automatically.
     */
    loading: import("@angular/core").InputSignal<boolean>;
    /**
     * When `true`, disables the built-in local substring filter in
     * `filteredOptions()` — set this when `[options]` already reflects a
     * server-side filtered result (e.g. from a `(searchChange)`-driven fetch)
     * so the library doesn't re-filter already-filtered data. Equivalent to
     * ng-select's `!typeahead().observed` gate, adapted to an explicit boolean
     * since Angular's signal `output()` has no "is anyone listening" introspection.
     */
    remoteFiltered: import("@angular/core").InputSignal<boolean>;
    emptyText: import("@angular/core").InputSignal<string>;
    loadingText: import("@angular/core").InputSignal<string>;
    noResultsText: import("@angular/core").InputSignal<string>;
    forId: import("@angular/core").InputSignal<string>;
    customClass: import("@angular/core").InputSignal<string>;
    primaryColor: import("@angular/core").InputSignal<string>;
    readonly opened: import("@angular/core").OutputEmitterRef<void>;
    readonly closed: import("@angular/core").OutputEmitterRef<void>;
    readonly cleared: import("@angular/core").OutputEmitterRef<void>;
    readonly searchChange: import("@angular/core").OutputEmitterRef<string>;
    readonly scrolledToEnd: import("@angular/core").OutputEmitterRef<void>;
    abstract readonly multiple: boolean;
    abstract readonly closeOnSelect: boolean;
    abstract isSelected(option: PgSelectOption<TOption>): boolean;
    abstract selectOption(option: PgSelectOption<TOption>): void;
    abstract readonly displayValue: Signal<unknown>;
    readonly hasError: Signal<boolean>;
    readonly computedForId: Signal<string>;
    /**
     * Trigger visual-state classes (background/outline/text color), computed
     * once instead of layering conflicting boolean `[class.x]` bindings for
     * the same CSS property — mirrors `InputDirective`'s class-string getter
     * pattern (`forms/input.directives.ts`). Includes both `focus:` and
     * `focus-within:` outline-color variants so the same string works whether
     * the trigger element itself receives focus (classic `<button>`) or wraps
     * a focusable child (search/multi `<input>` inside a `<div>`).
     */
    readonly triggerStateClasses: Signal<string>;
    readonly isOpen: import("@angular/core").WritableSignal<boolean>;
    /**
     * True while the panel plays its exit animation, before `isOpen` actually
     * flips to `false` and the CDK overlay detaches. Mirrors `AlertService`'s
     * `isLeaving` flag + fixed-duration `setTimeout` removal (`alert.service.ts`).
     */
    readonly isClosing: import("@angular/core").WritableSignal<boolean>;
    /** Enter/exit animation durations (ms), matching `pg-alert-modal`'s enter (150ms) / leave (200ms) defaults. */
    readonly panelEnterDurationMs = 150;
    readonly panelExitDurationMs = 200;
    private _closeTimeoutHandle;
    private readonly _scrollEndThresholdPx;
    private readonly _scrollEndFired;
    /**
     * Scroll position captured at the exact moment `scrolledToEnd` fires.
     * CDK's `reposition` scroll strategy (see `select.tokens.ts`) reacts to
     * ANY scroll event in the document — including our own panel's internal
     * scroll — and re-runs the connected-overlay position/size calculation
     * (`flexibleDimensions` + `growAfterOpen`), which resets the panel's
     * `scrollTop` to 0 as a side effect once new options land. This anchor
     * lets the options-growth effect below restore the exact pre-append
     * position so appending a page never visually snaps the user back to the
     * top — mirrors ng-select's continuous (no-CDK, no-reposition) scroll
     * behavior without having to drop CDK entirely.
     */
    private _scrollRestoreAnchor;
    readonly query: import("@angular/core").WritableSignal<string>;
    /**
     * Tracks a query set by the browser's native autofill rather than the
     * user typing — Chrome fires the trigger input's `input` event with
     * `inputType: 'insertReplacementText'` when it fills a field this way,
     * distinct from `insertText` for manual keystrokes. Held until a matching
     * option shows up in `flatFilteredOptions()` (synchronously for a local
     * list, or once an async remote search resolves for a `remoteFiltered`
     * one), at which point it's auto-selected exactly as if the user had
     * clicked it — otherwise picking a browser autofill suggestion just fills
     * text without ever registering as a real selection. Cleared by any
     * subsequent manual keystroke or by closing the panel.
     */
    private readonly _pendingAutofillQuery;
    private readonly _debouncedQuery;
    /**
     * `[options]` is the single source of truth, always — static list or
     * server-driven, it doesn't matter. A consumer reassigns it themselves via
     * `(searchChange)` for a fresh search, or appends to it via
     * `(scrolledToEnd)` for pagination — both just funnel into this same
     * array, exactly like ng-select's `[items]`.
     */
    readonly resolvedOptions: Signal<PgSelectOptions<TOption>>;
    readonly isGrouped: Signal<boolean>;
    readonly flatOptions: Signal<PgSelectOption<TOption>[]>;
    /**
     * Options filtered by the current query. When `remoteFiltered` is set the
     * consumer's `[options]` already reflects the query (e.g. a server-driven
     * search) — no additional local filtering is applied. Otherwise filters
     * locally by case-insensitive label match, preserving group structure and
     * dropping groups left empty by the filter.
     */
    readonly filteredOptions: Signal<PgSelectOptions<TOption>>;
    readonly flatFilteredOptions: Signal<PgSelectOption<TOption>[]>;
    readonly hasResults: Signal<boolean>;
    /** `filteredOptions()` narrowed to groups; empty array when the source is flat. */
    readonly filteredGroups: Signal<PgSelectGroup<TOption>[]>;
    /** `filteredOptions()` narrowed to a flat list; empty array when the source is grouped. */
    readonly filteredFlat: Signal<PgSelectOption<TOption>[]>;
    /** Deterministic id for a group header, referenced by the group's `aria-labelledby`. */
    groupHeaderId(index: number): string;
    readonly panelState: Signal<PgSelectPanelState>;
    /** True while a `(scrolledToEnd)`-triggered fetch is loading the next page on top of an already-rendered list. */
    readonly isLoadingMore: Signal<boolean>;
    protected readonly optionItems: Signal<readonly PgSelectOptionComponent[]>;
    protected keyManager: ActiveDescendantKeyManager<PgSelectOptionComponent> | null;
    /**
     * Reference to the scrollable panel `<ul>`. Resolves the same way
     * `optionItems` does: the element lives inside the `cdkConnectedOverlay`
     * `<ng-template>` in each variant's template, and Angular view queries see
     * into that embedded view once it renders.
     */
    protected readonly panelEl: Signal<ElementRef<HTMLElement> | undefined>;
    readonly activeOptionId: import("@angular/core").WritableSignal<string | null>;
    constructor();
    ngOnInit(): void;
    open(): void;
    /**
     * Starts the closing sequence: flips `isClosing` (which swaps the panel's
     * animation class to the exit animation via the template) and defers the
     * actual `isOpen.set(false)` — which detaches the CDK overlay — until the
     * exit animation's duration has elapsed. Mirrors `AlertService.close()`'s
     * `isLeaving` flag + fixed-duration `setTimeout` removal.
     */
    close(): void;
    toggle(): void;
    setQuery(value: string): void;
    /**
     * Bound to the trigger's editable `<input>` in the `search` variant of
     * both `pg-select` and `pg-select-multi`. Browser autofill fires this same
     * `input` event as manual typing — see `_pendingAutofillQuery` for why
     * that case is flagged and handled separately.
     */
    onSearchInput(event: Event): void;
    /**
     * Bound to the options panel's `(scroll)` event in each variant's template.
     * Emits `scrolledToEnd` once per "reached bottom" transition (re-arms when
     * the user scrolls back up, or when growing content pushes the bottom edge
     * out of range on a later scroll tick) — never on a fetch/state basis,
     * since the library has no visibility into the consumer's async source.
     */
    onPanelScroll(event: Event): void;
    clear(): void;
    /** Selects (or toggles, for multi) an option and closes the panel when `closeOnSelect` is true. */
    activateOption(option: PgSelectOption<TOption>): void;
    handleKeydown(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgSelectBase<any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PgSelectBase<any, any>, never, never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "debounceMs": { "alias": "debounceMs"; "required": false; "isSignal": true; }; "compareWith": { "alias": "compareWith"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "clearable": { "alias": "clearable"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "remoteFiltered": { "alias": "remoteFiltered"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; "loadingText": { "alias": "loadingText"; "required": false; "isSignal": true; }; "noResultsText": { "alias": "noResultsText"; "required": false; "isSignal": true; }; "forId": { "alias": "forId"; "required": false; "isSignal": true; }; "customClass": { "alias": "customClass"; "required": false; "isSignal": true; }; "primaryColor": { "alias": "primaryColor"; "required": false; "isSignal": true; }; }, { "opened": "opened"; "closed": "closed"; "cleared": "cleared"; "searchChange": "searchChange"; "scrolledToEnd": "scrolledToEnd"; }, never, never, true, never>;
}
