import { PgSelectBase } from './_base/select-base.directive';
import { PgSelectOption } from './select.types';
import * as i0 from "@angular/core";
/**
 * `pg-select-multi` — multi-value select. Renders removable chips plus a
 * search input in the trigger. Selecting an option toggles its membership in
 * the `T[]` value and keeps the panel open (does not close on select).
 */
export declare class MultiSelectComponent<T = unknown> extends PgSelectBase<T, T[]> {
    readonly multiple: true;
    readonly closeOnSelect = false;
    /** Optional cap on the number of selected options. */
    maxSelected: import("@angular/core").InputSignal<number | undefined>;
    readonly selectedOptions: import("@angular/core").Signal<PgSelectOption<T>[]>;
    readonly displayValue: import("@angular/core").Signal<string[]>;
    readonly atMaxSelected: import("@angular/core").Signal<boolean>;
    isSelected(option: PgSelectOption<T>): boolean;
    /** Toggles membership: removes if already selected, adds otherwise (respecting `maxSelected`). */
    selectOption(option: PgSelectOption<T>): void;
    onOptionClick(option: PgSelectOption<T>): void;
    removeChip(option: PgSelectOption<T>, event: Event): void;
    onClearAllClick(event: Event): void;
    clear(): void;
    onSearchKeydown(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MultiSelectComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MultiSelectComponent<any>, "pg-select-multi", never, { "maxSelected": { "alias": "maxSelected"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
