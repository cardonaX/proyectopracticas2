import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type BadgeVariant = 'outline' | 'flat';
export type BadgeSize = 'sm' | 'md';
export type BadgeShape = 'rounded' | 'pill';
export type BadgeColor = 'primary' | 'secondary' | 'info' | 'success' | 'warning' | 'error' | 'neutral' | 'disabled';
export declare class BadgeComponent {
    label?: string;
    variant: BadgeVariant;
    size: BadgeSize;
    shape: BadgeShape;
    color: BadgeColor;
    dot: boolean;
    dotColor?: BadgeColor;
    dismissible: boolean;
    dismiss: EventEmitter<void>;
    get classes(): string;
    get dotClasses(): string;
    get removeButtonClasses(): string;
    get removeIconClasses(): string;
    onDismiss(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BadgeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BadgeComponent, "pg-badge", never, { "label": { "alias": "label"; "required": false; }; "variant": { "alias": "variant"; "required": false; }; "size": { "alias": "size"; "required": false; }; "shape": { "alias": "shape"; "required": false; }; "color": { "alias": "color"; "required": false; }; "dot": { "alias": "dot"; "required": false; }; "dotColor": { "alias": "dotColor"; "required": false; }; "dismissible": { "alias": "dismissible"; "required": false; }; }, { "dismiss": "dismiss"; }, never, ["*"], true, never>;
}
