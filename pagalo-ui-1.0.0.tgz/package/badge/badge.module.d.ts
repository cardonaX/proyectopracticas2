import * as i0 from "@angular/core";
import * as i1 from "./badge.component";
export declare class PgBadgeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgBadgeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgBadgeModule, never, [typeof i1.BadgeComponent], [typeof i1.BadgeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgBadgeModule>;
}
