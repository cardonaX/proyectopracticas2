import { TemplateRef } from '@angular/core';
import { EmptyStatePreset, EmptyStateSize } from './empty-state.types';
import * as i0 from "@angular/core";
export declare class PgEmptyStateComponent {
    readonly preset: import("@angular/core").InputSignal<EmptyStatePreset>;
    readonly title: import("@angular/core").InputSignal<string | undefined>;
    readonly description: import("@angular/core").InputSignal<string | undefined>;
    readonly size: import("@angular/core").InputSignal<EmptyStateSize>;
    readonly iconSlot: import("@angular/core").Signal<TemplateRef<any> | undefined>;
    readonly titleSlot: import("@angular/core").Signal<TemplateRef<any> | undefined>;
    readonly descriptionSlot: import("@angular/core").Signal<TemplateRef<any> | undefined>;
    readonly actionsSlot: import("@angular/core").Signal<TemplateRef<any> | undefined>;
    protected readonly config: import("@angular/core").Signal<import("@pagalo/ui/empty-state").EmptyStatePresetConfig>;
    protected readonly resolvedTitle: import("@angular/core").Signal<string>;
    protected readonly resolvedDescription: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PgEmptyStateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PgEmptyStateComponent, "pg-empty-state", never, { "preset": { "alias": "preset"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, ["iconSlot", "titleSlot", "descriptionSlot", "actionsSlot"], never, true, never>;
}
