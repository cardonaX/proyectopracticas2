import * as i0 from "@angular/core";
/**
 * Marker directive for the `pg-empty-state` icon slot.
 * When present, fully replaces the preset SVG.
 */
export declare class PgEmptyStateIconDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgEmptyStateIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PgEmptyStateIconDirective, "[pgEmptyStateIcon]", never, {}, {}, never, never, true, never>;
}
/**
 * Marker directive for the `pg-empty-state` title slot.
 * When present, fully replaces the resolved title (preset or input override).
 */
export declare class PgEmptyStateTitleDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgEmptyStateTitleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PgEmptyStateTitleDirective, "[pgEmptyStateTitle]", never, {}, {}, never, never, true, never>;
}
/**
 * Marker directive for the `pg-empty-state` description slot.
 * When present, fully replaces the resolved description (preset or input override).
 */
export declare class PgEmptyStateDescriptionDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgEmptyStateDescriptionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PgEmptyStateDescriptionDirective, "[pgEmptyStateDescription]", never, {}, {}, never, never, true, never>;
}
/**
 * Marker directive for the `pg-empty-state` actions slot.
 * The actions zone only renders in the DOM when this slot is provided.
 */
export declare class PgEmptyStateActionsDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgEmptyStateActionsDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PgEmptyStateActionsDirective, "[pgEmptyStateActions]", never, {}, {}, never, never, true, never>;
}
