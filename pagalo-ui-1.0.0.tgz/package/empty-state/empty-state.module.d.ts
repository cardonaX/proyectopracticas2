import * as i0 from "@angular/core";
import * as i1 from "./empty-state.component";
export declare class PgEmptyStateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PgEmptyStateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PgEmptyStateModule, never, [typeof i1.PgEmptyStateComponent], [typeof i1.PgEmptyStateComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PgEmptyStateModule>;
}
