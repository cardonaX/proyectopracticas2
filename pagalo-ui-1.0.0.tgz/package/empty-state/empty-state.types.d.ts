export type EmptyStatePreset = 'no-data' | 'no-results' | 'no-connection' | 'empty-cart' | 'no-notifications' | 'error' | 'not-found' | 'no-permissions';
export type EmptyStateSize = 'md' | 'lg';
export interface EmptyStatePresetConfig {
    svg: string;
    title: string;
    description: string;
}
